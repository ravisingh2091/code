export interface DocumentData {
    doc_key: string,
    type: string,
    processing?: Boolean
}