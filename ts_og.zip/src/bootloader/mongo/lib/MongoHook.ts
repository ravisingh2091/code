export default class MongoHook {
    constructor() {
    }

	pre(save: string, validateObjectIds: (next, done) => Promise<any>) {
    }

}
