import mongoose from "mongoose";
declare var config: any,global:any
export default class Connection {

	/**
	 * connect : connecting with mongo-db
	 *
	 * @author Nitesh <nitesh.meena@biz2credit.com>
	 *
	 * @param mongo_url string
	 * @param callback object
	 */

	public connect(mongo_url) {
        if (!mongo_url) throw new Error(config.mongo.URL_NOT_FOUND);
        return new Promise((resolve, reject) => {   
            if (global[process.env.TENANT] && global[process.env.TENANT]["dbData"]) {
                resolve({
                    db: global[process.env.TENANT]["dbData"],
                    mongoose
                });
            } else {
                mongoose.createConnection(mongo_url, { useCreateIndex: true, useNewUrlParser: true })
                    .then((db) => {
                        console.log("db connected -------------------------  ",new Date().getTime(),mongo_url);
                        resolve({ db, mongoose })
                    })
                    .catch(error => {
                        console.log('Failed to connect mongo server', error.message);
                        reject(error.message)
                    });
            }
 
        })
    }
}
