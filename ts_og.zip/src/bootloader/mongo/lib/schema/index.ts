import AutoIncrement from "./AutoIncrement";

export default new class Schema {
	AutoIncrement = AutoIncrement;
}
