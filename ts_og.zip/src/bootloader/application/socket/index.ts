// import socket from "socket";
export default class Socket {

}
