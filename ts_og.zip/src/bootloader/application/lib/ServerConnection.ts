import express from 'express'
import * as bodyParser from 'body-parser';
import MultiTenant from "../../../middleware/MultiTenant";
import Seed from "../../../seed/index";
import compression from "compression";


declare var config: any, middleware: any;
export default class ServerConnection {
    _app: any;
    constructor() {
        this._app = express();
        if (process.argv.slice(2)[0] == "seed") {
            Seed.seed();
        } else {
            this.listen();
        }
    }

    /**
     * addSafeReadOnlyGlobal : defining property
     *
     * @author Nitesh <nitesh.meena@biz2credit.com>
     *
     */

    private listen(): void {
        this._app.listen(config.PORT || 3014, err => {
            if (err) throw new Error(err);
            console.log("server active on PORT : " + (config.PORT ? config.PORT : 3014))

        });
        this.activeRoutes();

    }

    /**
     * addSafeReadOnlyGlobal : defining property
     *
     * @author Nitesh <nitesh.meena@biz2credit.com>
     *
     */

    private activeRoutes(): void {
        this._app.use((req, res, next) => {
            next();
        });
        this._app.use(compression());
        this._app.use(bodyParser.json());
        this._app.use(bodyParser.urlencoded({ extended: false }));
        this._app.use(MultiTenant.CheckTenant);
        this._app.use(middleware.save_information.saveRequest, middleware.logger.log);
    }

    /**
     * app : returning app
     *
     * @author Nitesh <nitesh.meena@biz2credit.com>
     */

    get app(): void {
        return this._app;
    }
}
