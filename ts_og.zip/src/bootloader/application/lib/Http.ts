import https  from "https"

export default class Http extends  https.Agent {
	get GET() {
		return "";
	}
}

