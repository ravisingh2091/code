import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class GroupServiceBusiness extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            group_id: { type: String, required: true },
            user_id: { type: String, required: true },
            ref_id: { type: String, trim: true, required: true,
                validate: [
                    this.validator,              
                    this.message
                ]
            },
            type: { type: String, trim: true, required: true },
            provider: { type: String, trim: true, required: true },
            backend_user_id: { type: String, trim: true }
        });
    }

    static get Indexes() {
        return ["user_id","group_id"];
    }

    static get Name() {
        return "group_service_business";
    }
}
