import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class Product extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            app_id: { type: String, required: true },
            user_id: { type: String, required: true },
        });
    }

    static get Indexes() {
        return ["app_id", "user_id"];
    }

    static get Name() {
        return "products";
    }
}
