import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class Audit extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            app_id: { type: String, required: true },
            is_completed: { type: String, trim: true, required: true },
        });
    }

    static get Indexes() {
        return [];
    }

    static get Name() {
        return "audits";
    }
}
