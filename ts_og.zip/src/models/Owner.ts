import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

declare var config: any;
export default class Owner extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            app_id: { type: String, required: true },
            user_id: { type: String, required: true },

            name_of_the_direct_owner: { type: String, trim: true },
            owner_email: { type: String, trim: true },
            owner_type: { type: String, enum: config.SCHEMA_FIELDS.OWNER.OWNER_TYPE },
            ownership_percent: { type: Number, min: 0, max: 100 },
            actual_percent: { type: Number, min: 0, max: 100 },

            level: { type: Number },
            parent_id: { type: String, trim: true, default: "0" },
            consent: { type: String, trim: true, default: config.FIELDS.PENDING },

            other: {
                child_count: { type: Number, default: 0 },
                ratio_by_root: { type: Number, default: 0 },
                ancestor_1_ownership_percent: { type: Number, default: 0 },
            }

        });
    }

    static get Indexes() {
        return ["app_id", "user_id"];
    }

    static get Name() {
        return "owner_details";
    }
}
