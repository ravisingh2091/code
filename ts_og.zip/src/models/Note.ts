import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class Note extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            app_id: { type: String, required: true },
        });
    }

    static get Indexes() {
        return [];
    }

    static get Name() {
        return "notes";
    }
}
