import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class ServiceOwner extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            owner_id: { type: String, required: true },
            app_id: { type: String, required: true },
            user_id: { type: String, trim: true, required: true },
            ref_id: { type: String, trim: true, required: true , 
                validate: [
                    this.validator,              
                    this.message
                ]},
            type: { type: String, trim: true, required: true },
            provider: { type: String, trim: true, required: true },
            backend_user_id: { type: String, trim: true },
        });
    }

    static get Indexes() {
        return ["app_id", "user_id"];
    }

    static get Name() {
        return "service_owner";
    }
}
