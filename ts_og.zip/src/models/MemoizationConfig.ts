import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class MemoizationConfig extends MongoDBModel {
	static get Schema() {
		return mongoose => ({
			record_id: { type: Number, default: 0 },
		});
	}
}
