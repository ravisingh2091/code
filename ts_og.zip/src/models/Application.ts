import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class Application extends MongoDBModel {

    static get Name() {
        return "application";
    }

    static get Schema() {
        return mongoose => ({
            user_id: { type:  String, required: true },
            record_id: { type: Number, default: 0 },
            product_type: { type: String, trim: true },
            status_id: { type: mongoose.Schema.Types.Mixed },
            note: { type: String},
            replicated: {type: Object},
            backend_user_id: { type: String },
            last_assigned_to: { type: String }
        });
    }

    static get Indexes() {
        return ["user_id", "record_id", "status_id"];
    }
}
