import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class OwnerWeightedAverage extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            app_id: { type: String, required: true },
            weighted_average: { type: Number, required: true },
        });
    }

    static get Indexes() {
        return ["app_id"];
    }

    static get Name() {
        return "owners_weighted_avg";
    }
}
