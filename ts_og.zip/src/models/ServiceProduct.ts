import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class ServiceProduct extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
        });
    }

    static get Indexes() {
        return [];
    }

    static get Name() {
        return "service_product";
    }
}
