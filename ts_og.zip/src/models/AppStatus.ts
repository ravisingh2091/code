import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

declare var config: any;
export default class AppStatus extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            app_id: { type:  String, required: true },
            user_id: { type:  String, required: true },
            status_id: { type:  String, required: true },
            note: { type: String, trim: true }
        });
    }

    static get Indexes() {
        return ["user_id", "record_id", "status_id"];
    }

    static get Name() {
        return "app_status_history";
    }
}
