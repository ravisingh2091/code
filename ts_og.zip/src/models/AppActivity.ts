import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

declare var config: any;
export default class AppActivity extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            app_id: { type: String, required: true },
            role_id: { type: String, trim: true },
            assigned_to: { type: String, trim: true },
            backend_user_id: { type: String, trim: true },

            action: { type: String, enum: config.SCHEMA_FIELDS.ASSIGNMENT.ACTION },
            action_from: { type: String, enum: config.SCHEMA_FIELDS.ASSIGNMENT.ACTION_FROM, default: config.FIELDS.FRONTEND },
            is_completed: { type: Number, enum: [0, 1] },
            note: { type: String, trim: true }
        });
    }

    static get Indexes() {
        return ["app_id", "status_id", "is_completed"];
    }

    static get Name() {
        return 'app_activity';
    }
}
