import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class GroupCases extends MongoDBModel {
  static get Name() {
    return 'group_cases';
  }

  static get Schema() {
    return (mongoose) => ({
      group_name: { type: String},
      app_id: { type: Array, required: true },
      status_id: { type: String },
      backend_user_id: { type: String },
      group_record_id: { type: Number, default: 0 },
    });
  }

  
  static get Indexes() {
    return ["app_id"];
}
}
