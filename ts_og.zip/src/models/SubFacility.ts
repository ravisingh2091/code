import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class SubFacility extends MongoDBModel {

    static get Name() {
        return "sub_product";
    }

    static get Schema() {
        return mongoose => ({
            facility_name: { type: String, trim: true , required:true},
            amount: { type: String, trim: true ,required:true},
            tenure: { type: Number, trim: true , required:true},
            decision:{type:String,default:"Pending"},
            app_id: { type: String, trim: true, required: true },
            accepted_amount: { type: Number, trim: true},
            accepted_tenure: { type: Number, trim: true},
            product_id: {type:String,trim:true,required:true}
        });
    }
}
