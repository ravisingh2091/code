import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class WeightedAverage extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            app_id: { type: String },
            weighted_average: { type: Number, required: true },
        });
    }

    static get Indexes() {
        return [];
    }
}
