import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class Counter extends MongoDBModel {

    static get Name() {
        return "counter";
    }

    static get Schema() {
        return mongoose => ({
            name:{type:String},
            sequence_value:{type:Number,default:0}
        });
    }

    static get Indexes() {
        return [];
    }
}