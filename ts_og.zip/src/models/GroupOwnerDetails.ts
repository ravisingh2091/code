import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

declare var config: any;
export default class GroupOwnerDetails extends MongoDBModel {
  static get Name() {
    return 'group_owner_details';
  }

  static get Schema() {
    return (mongoose) => ({
      group_id: { type: String, required: true },
      user_id: { type: String, required: true },
      owner_type: { type: String, enum: config.SCHEMA_FIELDS.OWNER.OWNER_TYPE },
      name_of_the_direct_owner: { type: String, trim: true },
      owner_email: { type: String, trim: true }
    });
  }
}
