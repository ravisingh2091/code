import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

declare var config: any;
export default class Checklist extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            app_id: { type: String, required: true },
            owner_id: { type: String },
            role_id: { type: String, trim: true, required: true },
            backend_user_id: { type: String, trim: true, required: true },
            comment: { type: String, trim: true, minLength: 3, maxLength: 2000 },

            checklist_id: { type: String },
            checklist_action: { type: String, enum: config.SCHEMA_FIELDS.CHECKLIST.CHECKLIST_ACTION },
        });
    }

    static get Indexes() {
        return [];
    }

    static get Name() {
        return "checklist";
    }
}
