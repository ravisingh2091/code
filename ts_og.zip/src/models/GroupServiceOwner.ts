import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class GroupServiceOwner extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            owner_id: { type: String, required: true },
            group_id: { type: String, required: true },
            user_id: { type: String, trim: true, required: true },
            ref_id: { type: String, trim: true, required: true , 
                validate: [
                    this.validator,              
                    this.message
                ]},
            type: { type: String, trim: true, required: true },
            provider: { type: String, trim: true, required: true },
            backend_user_id: { type: String, trim: true },
        });
    }

    static get Indexes() {
        return ["user_id","group_id","owner_id"];
    }

    static get Name() {
        return "group_service_owner";
    }
}
