import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

export default class Facility extends MongoDBModel {

    static get Name() {
        return "product";
    }

    static get Schema() {
        return mongoose => ({
            entity_name: { type:  String, trim: true},
            product: { type: String, trim: true , required:true},
            amount: { type: String, trim: true ,required:true},
            tenure: { type: Number, trim: true , required:true},
            decision:{type:String,default:"Pending"},
            accepted_amount: { type: Number, trim: true},
            accepted_tenure: { type: Number, trim: true},
            app_id: { type: String, trim: true, required: true },
        });
    }

    static get Indexes() {
        return ["app_id"];
    }
}
