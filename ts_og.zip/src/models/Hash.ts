import MongoDBModel from '../bootloader/mongo/lib/MongoDBModel';

declare var config: any;
export default class Hash extends MongoDBModel {

    static get Schema() {
        return mongoose => ({
            app_id: { type: String, trim: true },
            owner_id: { type: String, trim: true },
            hash: { type: String, trim: true },
            hash_for: { type: String, trim: true, default: config.FIELDS.OWNER_CONSENT },
            hash_verified: { type: Boolean, trim: true, enum: [true, false], default: false },
            encrypted_hash: { type: String, trim: true },
            expiry: { type: Number },
        });
    }

    static get Indexes() {
        return ["owner_id", "hash_verified"];
    }

    static get Name() {
        return "hash";
    }
}
