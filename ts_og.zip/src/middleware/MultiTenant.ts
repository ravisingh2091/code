import path from 'path';
import fs from 'fs';
import * as dotenv from 'dotenv';
import mongoose from 'mongoose';
import AppConfig from "../config/App";
 
declare var config: any, global: any, middleware: any;
 
export default class MultiTenant {
  _config: any;
  static async CheckTenant(request, response, next) {
    try {
      let tenant = request.headers['x-tenant-id'];
      if (tenant) {
        tenant = tenant.trim();
      }
      let envFile = (tenant) ? `.env.${tenant}` : `.env`;
      envFile = envFile.trim()
      if (!fs.existsSync(envFile)) {
        middleware.response.sendResponse(request, response, middleware.response.tenantIdNotFound)
      }
      const envConfig: any = dotenv.parse(fs.readFileSync(`${envFile}`))
      for (const k in envConfig) {
        process.env[k] = envConfig[k];
      }
 
      tenant = tenant || '&default&'
      process.env.TENANT = tenant
      request.headers['x-tenant-id']=tenant
 
      if (!global[tenant]) {
        // await mongoose.connection.close();
        new AppConfig().updateUrls();
        config.MODELS = {};
        let list = fs.readdirSync(path.join(path.join(__dirname, ".."), (config.FIELDS.MODELS).toString())),
          dbb = {}, i = 0, prod_flag = 1;
        for (let item of list) {
          if (item.search(/.map$/) === -1 && item.search(/.[tj]s$/) !== -1) {
 
            let name = item.toString().replace(/\.[tj]s$/, '');
            const db = await (require(path.join(path.join(__dirname, ".."), config.FIELDS.MODELS, item)).default).initialize(process.env.DATABASE_URL)
            ++i;
            
            const model_name = name.replace(/([a-z])([A-Z])/g, '$1_$2').toLowerCase()
            config.MODELS[model_name.toUpperCase()] = config['MODEL_CONFIG'][model_name.toUpperCase()];
            dbb[model_name] = db.model(config['MODEL_CONFIG'][model_name.toUpperCase()]);
            global[tenant] = {}
            global[tenant]["_db"] = dbb;
            global[tenant]["dbData"] = db;
            if (i === list.length / prod_flag) {
              delete global[tenant]["dbData"]
              next()
            }
 
          } else if (item.search(/.map$/) !== -1) prod_flag = 2;
        }
      }else {
        next()
      }
    } catch (e) {
      console.log({ e });
 
    }
  }
}