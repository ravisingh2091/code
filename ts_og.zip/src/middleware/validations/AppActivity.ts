import ApplicationResource from "../../resources/AppActivity";

export default class AppActivity {
    static recent(request, response) {
        return ApplicationResource.recent(request, response);
    }
}
