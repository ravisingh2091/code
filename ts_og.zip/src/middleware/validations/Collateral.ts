import External from "../../routes/external";
import CollateralResource from "../../resources/Collateral";
import ApplicationResource from "../../resources/Application";

declare var middleware: any, services: any, _db: any, config: any;
export default class Collateral {

	static async post(request, response) {
		console.log("Post Api In Collateral Called--",new Date().getTime())
		const errors = await this.fieldsValidationUtil(request, response);
		if (errors === false) return await CollateralResource.post(request, response);
		return errors;
	}

	static async fieldsValidationUtil(request, response) {
		try {
			console.log("filed validartion method is called -----------------")
			if (!request.body.slug && !request.body.orch_url) return new Error(JSON.stringify({
				...config.getResponse(config.FIELD_INVALID_CODE),
				errors: [middleware.response.getErrorMessage(config.FIELDS.SLUG_OR_ORCH_URL, config.API_RESPONSE.FIELD_REQUIRED)]
			}));
	
			const application = await ApplicationResource.isApplicationExist(request,request.body[config.FIELDS.APP_ID], request.body[config.FIELDS.USER_ID]);
			if (!!!application || !application.length) return middleware.http.urlNotFound(request, response, {});
	
			let form_fields, fields_resp = await new External().getOrchFileds(request, response);
			fields_resp = fields_resp.data;
	
			if (fields_resp === undefined || fields_resp === null) return { ...config.getResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.MASTER_SERVICE_ERROR_MESSAGE };
	
			/*getting master config*/
			let master_config = await (new External().get({}, config.MASTER_URL + "/product_config?type=max_collateral"));
	
			if (!master_config.data.length) return new Error(JSON.stringify({ ...config.getApiResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.MASTER_SERVICE_ERROR_MESSAGE }));
			const max_allowed_collateral = +master_config.data[0].value || +config.Default.MAX_ALLOWED_COLLATERAL;
			if (request.body.collaterals.length > max_allowed_collateral) return new Error(JSON.stringify({ ...config.getApiResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.MASTER_SERVICE_ERROR_MESSAGE }));
	
			if (fields_resp.info && fields_resp.info.form_fields) form_fields = fields_resp.info.form_fields;
			else form_fields = fields_resp.form_fields;
	
			const error =  Collateral.fieldsValidation(request.body.action_type, request.body.collaterals, form_fields);
			if(error.length) return new Error(JSON.stringify({ ...config.getApiResponse(config.API_RESPONSE.FIELD_INVALID), errors: error }));
			return false;
		} catch (error) {
			console.log("error validation ----------------------------",error)
		}
	
	}

	static fieldsValidation(action_type, collateral, form_fields) {
		for (let i = 0; i < collateral.length; ++i) {
			const error = middleware.fields.initUtil(collateral[i], form_fields);
			if (error.length) return error;
		}
		return [];
	}

	static async _patch(request, response) {
		console.log("_patch Api In Collateral Called--",new Date().getTime())
		const errors = await this.fieldsValidationUtil(request, response);
		if (errors === false) return await CollateralResource.patch(request, response);
		return errors;
	}
}
