import FacilityResource from "../../resources/Facility";
declare var config: any
export default class Application {
    
    static post(request, response) {
        //console.log("Post Api in Facility Called--",new Date().getTime())
        return FacilityResource.post(request, response);
    }

    static put(request,response){
        //console.log("Put Api in Facility Called--",new Date().getTime())
        return FacilityResource.put(request,response)
    }

    static delete(request,response){
        //console.log("Delete Api in Facility Called--",new Date().getTime())
        return FacilityResource.delete(request,response)
    }

    static get(request,response){
        //console.log("Get Api in Facility Called--",new Date().getTime())
        return FacilityResource.get(request,response)
    }
}