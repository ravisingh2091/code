import HashResource from "../../resources/Hash";

declare var middleware: any, services: any, _db: any, config: any;
export default class Hash {

	static async get(request, response) {
		//console.log("Get Api in Hash is Called--",new Date().getTime())
		return HashResource.get(request, response);
	}

	static async put(request, response) {
		//console.log("Put Api in Hash is Called--",new Date().getTime())
		return HashResource.put(request, response);
	}
	static async post(request, response) {
		//console.log("Post Api in Hash is Called--",new Date().getTime())
		return HashResource.post(request, response);
	}

	static async _delete(request, response) {
		//console.log("_Delete Api in Hash is Called--",new Date().getTime())
		return HashResource._delete(request, response);
	}
	static async expire(request, response) {
		//console.log("Expire Api in Hash is Called--",new Date().getTime())
		return HashResource.expire(request, response);
	}
}
