import AppAssignmentResource from "../../resources/AppAssignment";

declare var services: any, middleware: any, config: any;
export default class AppAssignment {
	static get(request, response) {
		return AppAssignmentResource.get(request, response);
	}
	static delete(request, response) {
		const errors = [];
		if (Boolean(request.headers[config.FIELDS.X_DELETE_ALL]) === true) {
			errors.push(...middleware.fields.initUtil(request.query, config.assignment.app));
			request.query = { app_id: services.collection.convertToObjectId(request.query[config.FIELDS.APP_ID]) || -1 };
		}
		else {
			errors.push(...middleware.fields.initUtil(request.query, config.assignment.query));
			request.query = {
				app_id: services.collection.convertToObjectId(request.query[config.FIELDS.APP_ID]) || -1,
				role_id: services.collection.convertToObjectId(request.query[config.FIELDS.ROLE_ID]) || -1,
				assigned_to: services.collection.convertToObjectId(request.query[config.FIELDS.ASSIGNED_TO]) || -1,
			};
		}
		if (errors.length) return middleware.response.getFieldsError(errors);
		return AppAssignmentResource.delete(request, response);
	}

	static post(request, response) {
		return AppAssignmentResource.post(request, response);
	}

}
