import External from "../../routes/external";
import OwnerResource from "../../resources/Owner";
import ApplicationResource from "../../resources/Application";
import Queue from "../../classes/Queue";

declare var middleware: any, services: any, _db: any, config: any;
export default class Owner {

	static get(request, response) {
		//console.log("Get Api in Owner is Called----------------",new Date().getTime())
		const errors = [];
		if (Boolean(request.query.tree) === true) errors.push(... middleware.fields.initUtil(request.query, config.owner.app));
		if (errors.length) return middleware.response.getFieldsError(errors);
		return OwnerResource.get(request, response);
	}
	static async post(request, response,flag=false) {
		//console.log("Post Api in Owner is Called------------------------------------",new Date().getTime())
		if (!request.body.slug && !request.body.orch_url) return new Error(JSON.stringify({
			...config.getResponse(config.FIELD_INVALID_CODE),
			errors: [middleware.response.getErrorMessage(config.FIELDS.SLUG_OR_ORCH_URL, config.API_RESPONSE.FIELD_REQUIRED)]
		}));
		return await Owner.postUtil(request, response,flag)
	}
	static async citizenship(request, response) {
		//console.log("Citizen Ship Api in Owner is Called")
		request.model = config.MAP_CONFIG.APPLICATION;
		const application = await services.collection.find(request, response);
		if (!application.length) return middleware.response.throwErrorMessage({ ...config.getApiResponse(config.API_RESPONSE.NOT_FOUND), errors: config.getApiErrorResponse("NOT_FOUND") });
		request.model = config.MAP_CONFIG.OWNER
		request.query = {
			app_id: services.collection.convertToObjectId(request.query._id),
			user_id: services.collection.convertToObjectId(request.query.user_id),
			owner_type: config.OWNER.INDIVIDUAL,
		};
		request.query["consent!"] = config.OWNER.RECEIVED;
		const invalid_owners = await services.collection.find(request, response);
		if (invalid_owners.length) return middleware.response.throwErrorMessage({ ...config.getApiResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.getApiErrorResponse(config.API_RESPONSE.BAD_REQUEST) });

		return await OwnerResource.citizenship(request, response);
	}

	static async postUtil(request, response,flag=false) {
		/*getting master config*/
		let master_config = await (new External().get({}, config.MASTER_URL + "/" + config.FIELDS.PRODUCT_CONFIG + "?type=maximum_owners&type=owner_level")), maximum_owners = 0, owner_level = 0;
		if (master_config.data.length !== 2) return new Error(JSON.stringify({ ...config.getApiResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.getApiErrorResponse(config.API_RESPONSE.FIELD_REQUIRED, config.FIELDS.PRODUCT_CONFIG, config.MASTER_SERVICE_ERROR_MESSAGE) }));

		owner_level = master_config.data[0].type === config.FIELDS.OWNER_LEVEL ? +master_config.data[0].value : +master_config.data[1].value;
		maximum_owners = master_config.data[0].type === config.FIELDS.MAXIMUM_OWNERS ? +master_config.data[0].value : +master_config.data[1].value;

		let fields_resp = await new External().getOrchFileds(request, response);

		fields_resp = fields_resp.data;

		if (fields_resp === undefined || fields_resp === null) return { ...config.getResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.MASTER_SERVICE_ERROR_MESSAGE };
		let form_fields = [];
		if (fields_resp.info && fields_resp.info.form_fields) form_fields = fields_resp.info.form_fields;
		else form_fields = fields_resp.form_fields;
		const errors = Owner.ownersFieldsValidation(request.body.action_type, request.body.owners, form_fields, owner_level, maximum_owners);
		if(errors.length) return middleware.response.getFieldsError(errors);

		if (!Array.isArray(request.body.owners) || !request.body.owners.length) return { data: [] };

		// const mask = Owner.ownerTypeMasking(request.body.owners);
		// for (let i = 2; i < config.CONSTANT.MAX_BITS; ++i) if ((mask & (1 << 1)) && (mask & (1 << i))) return new Error(JSON.stringify({ ...config.getApiResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.getApiErrorResponse(config.API_RESPONSE.FIELD_INVALID) }));
		const is_owner_email_valid = Owner.ownerEmailValidation(request.body.owners);
		if (is_owner_email_valid instanceof Error) return is_owner_email_valid;
		/*const duplicate_owner_type_emails = Object.keys(is_owner_email_valid);
		for (let i = 0; i < duplicate_owner_type_emails.length; ++i) {
			if (is_owner_email_valid[duplicate_owner_type_emails[i]] < 2) continue;
			const type = duplicate_owner_type_emails[i].split("|||")[0];
			return new Error(JSON.stringify({ ...config.getApiResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.getApiErrorResponse(config.API_RESPONSE.FIELD_DUPLICATE, type) }));
		}*/
		return await OwnerResource.post(request, response,flag);
	}

	/* 32 bit mask
	*
	* 31 represent individual
	*
	*   */

	static ownersValidation(data: any, mask: Number): any {
		//console.log("Owners Validation Api in Owner is Called")
		let ar = [], resp, queue = new Queue();
		if (data === undefined) return [];
		try {
			while(!queue.isEmpty) {
				for (let i = 0; i < data.length; ++i) {
					queue.push({});
				}
				return ar;
			}
		} catch (exception) {
			const exception_obj = middleware.response.sendExceptionResponse(exception, {});
			const obj:any = {
				code: config.FIELD_INVALID_CODE,
				status: config.FIELD_INVALID_STATUS,
			};
			obj.errors = exception_obj.errors || exception.message;
			return new Error(JSON.stringify(obj));
		}
	}

	static ownerTypeMasking(data: any): any {
		let mask = 0;
		if (data === undefined) return 0;
		try {
			for (let i = 0; i < data.length; ++i) {
				mask = Number(mask) | Number(1 << Owner.getOwnerTypeIndex(data[i].owner_type));
				if (!!data[i].owners) mask = Number(mask) | Owner.ownerTypeMasking(data[i].owners);
			}
			return mask;
		} catch (exception) {
			return mask;
		}
	}

	static ownerEmailValidation(data: any, parent_email = "", parent_type: any = ""): any {
		let obj = {};
		try {
			for (let i = 0; i < data.length; ++i) {
				if (parent_type === config.FIELDS.INDIVIDUAL && data[i][config.FIELDS.OWNER_TYPE] !== config.FIELDS.INDIVIDUAL) return new Error(JSON.stringify({ ...config.getApiResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.getApiErrorResponse(config.API_RESPONSE.FIELD_INVALID, config.FIELDS.OWNER_TYPE) }));
				const unique_id = data[i][config.FIELDS.OWNER_EMAIL];
				/* Checking owner email is equal to parent owner email */
				if (data[i][config.FIELDS.OWNER_EMAIL] === parent_email) return new Error(JSON.stringify({ ...config.getApiResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.getApiErrorResponse(config.API_RESPONSE.FIELD_DUPLICATE, config.FIELDS.OWNER_EMAIL) }));
				if (!!obj[data[i][config.FIELDS.OWNER_EMAIL]] && (data[i][config.FIELDS.OWNER_TYPE] !== config.FIELDS.INDIVIDUAL || data[i][config.FIELDS.OWNER_TYPE] !== obj[data[i][config.FIELDS.OWNER_EMAIL]]))	return new Error(JSON.stringify({ ...config.getApiResponse(config.API_RESPONSE.BAD_REQUEST), errors: config.getApiErrorResponse(config.API_RESPONSE.FIELD_DUPLICATE, config.FIELDS.OWNER_EMAIL) }));
				obj[unique_id] = data[i][config.FIELDS.OWNER_TYPE];
				if (!!data[i].owners) {
					const resp = Owner.ownerEmailValidation(data[i].owners, data[i][config.FIELDS.OWNER_EMAIL], data[i][config.FIELDS.OWNER_TYPE]);
					if (resp instanceof Error) return obj = resp;
				}
			}
			return obj;
		} catch (exception) {
			return exception;
		}
	}

	static getOwnerTypeIndex(owner_type: String): number {
		const obj: Object = {};
		for (let i = 0; i < config.SCHEMA_FIELDS.OWNER.OWNER_TYPE.length; ++i) obj[config.SCHEMA_FIELDS.OWNER.OWNER_TYPE[i]] = i + 1;
		// @ts-ignore
		return obj[owner_type];
	}

	static ownersFieldsValidation(action_type, data, fields, owner_level, maximum_owners, depth = 1): any {
		let errors = [], ownership_percent: Number = 0;
		if (!!data && !Array.isArray(data)) errors.push(config.getApiErrorResponse(config.API_RESPONSE.BAD_REQUEST, config.FIELDS.OWNERS, "owners must be in array"));
		else if (!!data && data.length > maximum_owners) errors.push(config.getApiErrorResponse(config.API_RESPONSE.BAD_REQUEST, config.FIELDS.MAXIMUM_OWNERS, "maximum owners must be <=  " + maximum_owners));
		else {
			for (let i = 0; i < data.length; ++i) {
				ownership_percent = Number((+ownership_percent + +data[i].ownership_percent).toFixed(2));
				errors.push(...middleware.fields.initUtil(data[i], fields, action_type));
				if (depth > owner_level) errors.push(config.getApiErrorResponse(config.API_RESPONSE.BAD_REQUEST, config.FIELDS.OWNER_LEVEL, "owner level must be <= " + owner_level));
				else if (data[i].owners) errors.push(...Owner.ownersFieldsValidation(action_type, data[i].owners, fields, owner_level, maximum_owners, depth + 1));
			}
		}
		if (ownership_percent > 100) errors.push(config.getApiErrorResponse(config.API_RESPONSE.BAD_REQUEST, config.FIELDS.OWNERSHIP_PERCENT, "total owner percent must be <= 100%"));
		return errors;
	}


	static async patch(request, response) {
		try {
			//console.log("patch api is called ---",new Date().getTime());
			
			const errors = [], owners_id = [], owners = [];
			// delete request.body[config.FIELDS.APP_ID];
			if (!!request.params[config.FIELDS.APP_ID] || !!request.body[config.FIELDS.USER_ID]) {
				const application = await ApplicationResource.isApplicationExist(request,request.params[config.FIELDS.APP_ID],request.body[config.FIELDS.USER_ID]);
				if (!!!application || !application.length) return middleware.http.urlNotFound(request, response, {});
			}
			if (!!request.body[config.FIELDS.OWNERS]) {
				errors.push(...middleware.fields.initUtil(request.body, config.owner.application));
				errors.push(...middleware.fields.arrayFieldsValidation(request.body[config.FIELDS.OWNERS], config.owner.update_percent));
	
				for (let i = 0; !errors.length && i < request.body[config.FIELDS.OWNERS].length; ++i) {
					// if(request.body[config.FIELDS.OWNERS][i][config.FIELDS.UPDATE_PERCENT_CONSENT] !== config.FIELDS.INDIVIDUAL) return config.getResponse(config.API_RESPONSE.BAD_REQUEST);
					const _id = services.collection.convertToObjectId(request.body[config.FIELDS.OWNERS][i].owner_id);
					if (_id) owners_id.push(_id);
				}
				if (!errors.length) owners.push(...await services.collection.find({ model: request.model, query: { "owner_type!": config.FIELDS.INDIVIDUAL, "_id.in": owners_id }}, response));
			} else {
				request.body[config.FIELDS.OWNER_ID] = services.collection.convertToObjectId(request.body[config.FIELDS.OWNER_ID]);
				errors.push(...middleware.fields.initUtil(request.body, config.owner.owner_id));
			}
			if (errors.length) return middleware.response.getFieldsError(errors);
			// else if (!!request.body[config.FIELDS.OWNERS] && owners.length !== request.body[config.FIELDS.OWNERS].length) return new Error(JSON.stringify(middleware.response.urlNotFound));
			return await OwnerResource.patch(request, response);
		} catch (error) {
			//console.log("error--------------------",error)
		}
	}
}
