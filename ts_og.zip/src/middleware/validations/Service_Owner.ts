import ServiceOwnerResource from "../../resources/service/Owner";

export default class Service_Owner{
	static async patch(request, response) {
		console.log("Patch Api Called in Onwer------------------------------------",new Date().getTime())
		return await ServiceOwnerResource.patch(request, response);
	}
}
