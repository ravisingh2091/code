import WeightedAverageResource from "../../resources/WeightedAverage";

declare var services: any, middleware: any, config: any;
export default class WeightedAverage {
	static get notResourceFound() {
		return middleware.response.throwError(config.API_RESPONSE.NOT_FOUND);
	}
	static async post(request, response) {
		//console.log("Post Api Called in WeightedAverage--",new Date().getTime())
		const owners = request.body.owners, owners_arr = [];
		if (!owners.length) return WeightedAverage.notResourceFound;
		request.model = config.MAP_CONFIG.OWNER
		for (let i = 0; i < owners.length; ++i) {
			request.query = { _id: owners[i].owner_id };
			const owner = await services.collection.find(request, response);
			if (!owner || !owner.length) return WeightedAverage.notResourceFound;
			else owners_arr.push(...owner)
		}
		request.owners_arr = owners_arr;
		return await WeightedAverageResource.post(request, response);
	}
}
