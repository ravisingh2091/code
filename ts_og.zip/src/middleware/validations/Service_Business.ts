import ServiceBusinessResource from "../../resources/service/Business";

export default class Service_Business {
	static async patch(request, response) {
		console.log("Patch Api Called in Business------------------------------------",new Date().getTime())
		return await ServiceBusinessResource.patch(request, response);
	}
}
