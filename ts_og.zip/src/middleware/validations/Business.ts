import BusinessResource from "../../resources/Business";

declare var config: any, middleware: any;
export default class Business {
	validations: any = config.ORCHESTRATOR_FIELDS;
	action_type: String;

	static async post(request, response) {
		//console.log("Post Api In Business Called--",new Date().getTime())
		return await BusinessResource.post(request, response);
	}

	static async patch(request, response) {
		//console.log("Patch Api In Business Called--",new Date().getTime())
		return await BusinessResource.patch(request, response);
	}
}
