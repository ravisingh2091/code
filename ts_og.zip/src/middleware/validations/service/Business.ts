import ServiceBusinessResource from "../../../resources/service/Business";

export default class Business {
	static async post(request, response) {
		//console.log("Post Api Called in Business--",new Date().getTime())
		return await ServiceBusinessResource.post(request, response);
	}
}
