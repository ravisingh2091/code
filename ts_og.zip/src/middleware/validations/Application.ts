import ApplicationResource from "../../resources/Application";
import External from "../../routes/external";
declare var config: any
export default class Application {
    
    static post(request, response) {
        //console.log("Post Api In Application Called --",new Date().getTime())
        return ApplicationResource.post(request, response);
    }

    static clone(request, response) {
        //console.log("Clone Api In Application Called--",new Date().getTime())
        return ApplicationResource.clone(request, response);
    }

    static patch(request, response) {
        //console.log("Patch Api In Application Called--",new Date().getTime())
        return ApplicationResource.patch(request, response);
    }

    static async getApplication(request, response) {
      //console.log("get application method is called in Application.ts file--",new Date().getTime() )
          if (request.query.email_address) {
            let res = await new External().get(
              {
                query: { email_address: request.query.email_address },
              },
              config.USER_URL.USERS
            );
            if (res && res.data && res.data.length > 0 && res.data[0].id) {
              request.query['user_id'] = res.data[0].id;
              delete request.query.email_address;
            }
          } else if (request.query.user_phone_number) {
            let res = await new External().get(
              {
                query: {
                  phone_number: request.query.user_phone_number,
                  use_filter: true,
                  partial_match: 'phone_number',
                },
              },
              config.USER_URL.USERS
            );
            if (res && res.data && res?.data?.result?.length > 0) {
              let user_id = res.data.result.map((item) => item.id);
              request.query['user_id'] = user_id.join();
              delete request.query.user_phone_number;
            }
          }
       
          return await ApplicationResource.getApplication(request, response);
      }
    
      
  

    static async filter_app(request,response){
        //console.log("Filter App Api In Application Called--",new Date().getTime())
        let query = request.body;
        request.query = query;
        delete request.body
        return this.getApplication(request,response)
    }

    static filter(request, response) {
        //console.log("Filter Api In Application Called--",new Date().getTime())
        return ApplicationResource.filter(request, response);
    }

    static delete_app_status(request,response){
        //console.log("Delete App Status Api In Application Called--",new Date().getTime())
        return ApplicationResource.delete_app_status(request, response);
    }
    static script(request,response){
        //console.log("script App Status Api In Application Called--",new Date().getTime())
        return ApplicationResource.script(request, response);
    }
}
