import GroupOwnerDetailsResource from '../../resources/GroupOwnerDetails';
declare var config: any;
export default class GroupOwnerDetails {

} 
