import GroupCasesResource from '../../resources/GroupCases';
declare var config: any;
export default class GroupCases {
  // @route    PATCH api/v1/group_cases/status/_id
  // @desc     Update Status of group along with internal application enclosed with group
  static status(request, response) {
    //console.log("Status Update Api Called in group Cases ",new Date().getTime())
    return GroupCasesResource.status(request, response);
  }
  // @route    PATCH api/v1/group_cases/assign_backened_user/_id
  // @desc     Assign backend user id to the group along with enclosed internal applications
  static assign_backened_user(request, response) {
    //console.log("Assign Backened User Api Called in group Cases ",new Date().getTime())
    return GroupCasesResource.assign_backened_user(request, response);
  }
  // @route    POST api/v1/group_cases
  // @desc     Multiple application creation based on number of entities to be mapped with a Group
  static post(request, response) {
    //console.log("Post Api Called in group Cases ",new Date().getTime())
    return GroupCasesResource.post(request, response);
  }
  // @route    GET api/v1/group_cases
  // @desc     entity specific data entities for linked applications of a group.
  static get(request, response) {
    //console.log("Get Api Called in group Cases ",new Date().getTime())
    return GroupCasesResource.get(request, response);
  }
  //@route    DELETE api/v1/group_cases/group_id
  //@desc      it is used to delete an application from group 
  static delete(request,response){
    //console.log("Delete Api Called in group Cases ",new Date().getTime())
    return GroupCasesResource.delete(request, response);
  }
  //@route    PUT api/v1/group_cases/group_id
  //@desc     Api for updating an app_id
  static put(request,response){
    //console.log("Put Api Called in group Cases ",new Date().getTime())
    return GroupCasesResource.put(request, response);
  }
} 
