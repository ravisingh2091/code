export default class Auth {
}
