export default class ResponseType {
	status: String;
	type?: String;
	code: Number;
	message?: String;
	errors?: String;
}
