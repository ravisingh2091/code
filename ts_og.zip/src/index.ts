require("dotenv").config();
import PsychoJS from "./PsychoJS";
new PsychoJS({
	bugsnag: true,
	max_events: 30,
	callback: function (error, success) {
		if (error) throw error;
		else console.log("Application Loaded Successfully");
	}
});
