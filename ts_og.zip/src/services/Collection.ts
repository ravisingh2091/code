import UtilServices from "./UtilServices";

const ObjectId = require('mongoose').Types.ObjectId;

declare var services: any, _db: any, config: any, event: any,gloabl:any;
export default class Collection {
  /**
   * get : returning mongo Document
   *
   * @author Nitesh <nitesh.meena@biz2credit.com>
   *
   * @param request
   * @param response
   * @param other
   */
  protected async find(request, response = {}, other: any = {}) {
    let partial_search = null;
    let sub_document = [];
    let partial_search_flag = false;
    let partial_record_search_flag = false;
    let partial_record_search = null;
    if (request.query.partial == 'true' && request.query.partial_search) {
      partial_search = request.query.partial_search;
      partial_search_flag = true;
      delete request.query.partial_search;
      delete request.query.partial;
    } else {
      delete request.query.partial;
    }

    if (request.query.partial_group_record_id == 'true' && request.query.partial_group_record) {      
      partial_record_search = request.query.partial_group_record;
      partial_record_search_flag = true;
      delete request.query.partial_group_record;
      delete request.query.partial_group_record_id;
    } else {
      delete request.query.partial_group_record_id;
    }

    let facility_flag = false;
    if (request.params && request.params['facility_flag']) {
      facility_flag = request.params['facility_flag']
      delete request.params['facility_flag'];
    }


    const _config = {
      ...services.util_services.getRequestFields(request),
      ...other,
    };

    Object.keys(_config.query).forEach((key) => {
      if(typeof _config.query[key] === 'string') {
        _config.query[key] = decodeURIComponent(UtilServices.decodeURIComponentSafe(_config.query[key]));
      } else if(typeof _config.query[key] === 'object' && _config.query[key] !== null) {
        Object.keys(_config.query[key]).forEach((childKey) => {
          if(typeof _config.query[key][childKey] === 'string') {
            _config.query[key][childKey] = decodeURIComponent(UtilServices.decodeURIComponentSafe(_config.query[key][childKey]));
          }
        })
      }
    });

    const aggregate_options = [],
    skip = Math.max(0, Number(+(_config.query.start || 0)));
    let alias,
      _alis = {},
      query = { ..._config.query, ..._config.params },
      populate = [],
      select = [],
      hide = [],
      _hide: any = {},
      _select: any = {},
      sort_by = _config.query.sort_by,
      sort_by_keys = sort_by ? sort_by.split(',') : [],
      _sort_by: any = {},
      limit: Number = 0;
    let child_ref = [],
      facet_options = [];
    let db_query = services.util_services.deleteUnwantedKeys(query, [
      'fields',
      'd_fields',
      'sort_by',
      'expands',
      'limit',
      'start',
      'child_ref',
      'start_date',
      'end_date',
      'group_by'
    ]),
      db_query_keys = Object.keys(db_query);

    try {
      limit = +_config.query.limit || limit;
      if (!db_query._id) delete db_query._id;

      child_ref = query.child_ref ? query.child_ref.split(',') : [];
      alias = query.alias ? query.alias.split(',') : [];
      populate = query.expands ? query.expands.split(',') : populate;
      select = query.fields ? query.fields.split(',') : select;
      hide = query.d_fields ? query.d_fields.split(',') : hide;

      for (let i = 0; i < db_query_keys.length; ++i) {
        let schema_paths =  global[request.headers['x-tenant-id']]["_db"][request.model].schema.paths,
          n = db_query_keys[i].length,
          key = db_query_keys[i],
          old_key = key,
          ch = db_query_keys[i][n - 1],
          _ch = ch;
        if (!db_query[db_query_keys[i]]) {
          delete db_query[db_query_keys[i]];
          continue;
        } else if (db_query[key][0] === '=') {
          ch += '=';
          db_query[key] = db_query[key].replace(/[=]/gm, '');
        } else if (db_query_keys[i].search(/.in$/) !== -1) {
          key = db_query_keys[i].replace(/.in$/, '');
          db_query[key] = this.in(typeof db_query[old_key]==='string'?db_query[old_key].split(','):db_query[old_key]);
          delete db_query[old_key];
        }
        if (!!config.operators[ch]) {
          key = db_query_keys[i].replace(_ch, '');
          db_query[key] = this[config.operators[ch]](
            db_query[db_query_keys[i]]
          );
          delete db_query[db_query_keys[i]];
        }
        // else if (!!schema_paths[key] && schema_paths[key].instance === "ObjectID" && old_key === key) {
        else if (
          !!schema_paths[key] &&
          key === config.FIELDS._ID &&
          !populate.length
        ) {
          db_query[key] = this.convertToObjectId(db_query[key]);
        }
        db_query[key] = /^[1-9][0-9]*$/.test(db_query[key]) ? +db_query[key] : db_query[key];
      }
 

      // if(_config.query.app_not_assign){
      //   let assigned_to = _config.query.assigned_to
      //   let assignedApplications;
      //   if(assigned_to){
      //     assignedApplications = await global[request.headers['x-tenant-id']]["_db"][
      //       config.MAP_CONFIG.APPMETRIX
      //     ].aggregate([
      //       this.match({ assigned_to:(assigned_to == "null") ? "0" : assigned_to}),
      //       this.addFields(this.convert(config.FIELDS.APP_ID, 1)),
      //     ]);
      //   }else{
      //     assignedApplications = await global[request.headers['x-tenant-id']]["_db"][
      //       config.MAP_CONFIG.APPMETRIX
      //     ].aggregate([
      //       this.match({ assigned_to:this.ne("0") }),
      //       this.addFields(this.convert(config.FIELDS.APP_ID, 1)),
      //     ]);
      //   }

      //   console.log(JSON.stringify([this.match({ assigned_to:(assigned_to == "null") ? "0" : assigned_to}),
      //   this.addFields(this.convert(config.FIELDS.APP_ID, 1))]))
      //   if (assignedApplications.length > 0) {
      //     delete db_query["app_not_assign"]
      //     delete db_query["assigned_to"]
      //     let app_id = []
      //     for(let i=0;i<assignedApplications.length;i++){
      //       app_id.push(assignedApplications[i]['app_id'])
      //     }
      //     db_query[config.FIELDS._ID] = {
      //       $in: JSON.parse(JSON.stringify(app_id)),
      //     };
      //   }
      // }

      if (!!_config.query.count) {
        let aggregate_options = [];
        db_query = {};
        if (_config.query.assigned_to) {
          let assignedApplications = await global[request.headers['x-tenant-id']]["_db"][
            config.MAP_CONFIG.APPMETRIX
          ].aggregate([
            this.match({ assigned_to: _config.query.assigned_to }),
            this.addFields(this.convert(config.FIELDS.APP_ID, 1)),
            this.group({
              _id: '$' + config.FIELDS.ASSIGNED_TO,
              applications: { $push: '$' + config.FIELDS.APP_ID },
            }),
          ]);
          if (assignedApplications.length > 0) {
            for(let i=0;i<assignedApplications[0].applications.length;i++){
              this.convert(assignedApplications[0].applications[i],1)
              }
            db_query[config.FIELDS._ID] = {
              $in: assignedApplications[0].applications,
            };
          } else {
            return assignedApplications;
          }
        }
        if (_config.query.end_date) {
          db_query[config.CREATED_AT] = { ...this.lte(_config.query.end_date) };
        }
        if (_config.query.start_date) {
          db_query[config.CREATED_AT] = db_query[config.CREATED_AT]
            ? {
              ...db_query[config.CREATED_AT],
              ...this.gte(_config.query.start_date),
            }
            : { ...this.gte(_config.query.start_date) };
        }
        db_query_keys.forEach((key) => {
          if (key !== config.COUNT && key !== config.FIELDS.ASSIGNED_TO) {
            if (key.search(/.in$/) !== -1) {
              db_query[ key.replace(/.in$/, '')] = this.in(typeof _config.query[key]==='string'?_config.query[key].split(','):_config.query[key]);
            }
            else{            
            db_query[key] = _config.query[key];
            }
          }
        });


        if (_config.query.is_deleted != "true") {
          db_query[config.IS_DELETED] = this.ne(true);
        } else {
          delete db_query[config.IS_DELETED];
        }

        if (_config.query.parent_status_id) {
          db_query[config.PARENT_STATUS_ID] = _config.query.parent_status_id;
        }

        
        aggregate_options.push(this.match(db_query));
        aggregate_options.push(this.unwind(_config.query.count));
        this.populateOptions(populate,aggregate_options,request,query,db_query,sub_document,partial_search_flag,partial_search,facility_flag,partial_record_search_flag,partial_record_search)
        const project = {
          _id: 0,
          count: 1,
        };
        
        project[_config.query.count] = '$_id';
        aggregate_options.push(
          this.group({ _id: '$' + _config.query.count, count: { $sum: 1 } })
        );
        aggregate_options.push(this.project(project));
        return global[request.headers['x-tenant-id']]["_db"][request.model].aggregate(aggregate_options);
      }


      for (let i = 0; !alias.length && i < hide.length; ++i)
        _hide[hide[i].trim()] = 0;

      for (let i = 0; i < select.length; ++i) {
        if (_hide.hasOwnProperty(select[i].trim()))
          delete _hide[select[i].trim()];
        _select[select[i].trim()] = 1;
      }


      for (let i = 0; i < sort_by_keys.length; ++i)
        _sort_by[sort_by_keys[i].replace(/[-+]/, '')] =
          sort_by_keys[i][0] === '-' ? -1 : 1;
      if (!sort_by_keys.length) _sort_by.created_at = 1;
      aggregate_options.push(this.sort(_sort_by));
      let filter_query = {}
      if (db_query && db_query.status_id) {
        let obj = this.in(db_query.status_id.split(","));
        filter_query['status_id'] = obj
        delete db_query.status_id 
      }

      if (db_query && db_query.product_type) {
        filter_query['product_type'] = db_query.product_type
        delete db_query.product_type 
      }

     if (db_query && db_query.only_assign =="true") {
        filter_query['last_assigned_to'] =  this.ne("null")
        delete db_query.only_assign 
        delete db_query.last_assigned_to 
      }
    
      
      if (db_query && db_query.user_id) {
        let obj = this.in(db_query.user_id.split(","))
        filter_query['user_id'] = obj;
        delete db_query.user_id ;
      }

      if(request.query.is_deleted == "true"){
        db_query.is_deleted = this.ne(false);
      }else{
        filter_query['is_deleted'] = this.ne(true)
      }
      aggregate_options.push(this.match(filter_query));
      aggregate_options.push(this.skip(skip));
      sub_document=this.populateOptions(populate,aggregate_options,request,query,db_query,sub_document,partial_search_flag,partial_search,facility_flag,partial_record_search_flag,partial_record_search)
      for (let i = 0; i < alias.length; ++i) {
        let val = alias[i].split(':');
        if (val.length < 2) val = [val[0], val[0]];
        if (_select[val[0].toString().trim()] === 1)
          delete _select[val[0].toString().trim()];
        _alis[val[1].toString().trim()] = '$' + val[0].toString().trim();
        _alis['_id'] = 0;
      }

      if(request.query.is_deleted == "true"){
        request.disable_is_deleted = true;
        db_query.is_deleted = this.ne(false);
      }
      // if(request.query?.expands?.split(",").includes("appmetrix")  && request.query?.only_assign){
      //  delete db_query.only_assign;
      //  aggregate_options.push(this.match({ "appmetrix": this.ne([]) }));
      // }

      if (request.disable_is_deleted !== true)
        db_query.is_deleted = this.ne(true); 
        if (request.query.end_date) {
          let end_date = new Date(request.query.end_date).getTime()/1000;
            db_query[config.CREATED_AT] = { ...this.lte(end_date.toString()) };
        }
        if (request.query.start_date) {
          let start_date = new Date(request.query.start_date).getTime()/1000;
            db_query[config.CREATED_AT] = db_query[config.CREATED_AT]
              ? {
                ...db_query[config.CREATED_AT],
                ...this.gte(start_date.toString()),
              }
              : { ...this.gte(start_date.toString()) };
      }

      if(request.query.record_id && request.query.is_record == "true"){
        let record_id  = (Number(request.query.record_id)+1).toString();
        db_query[config.RECORD_ID] =  { ...this.gte(record_id) };
        delete db_query['is_record'];
      }else if(request.query.record_id && request.query.partial_record == "true"){
        aggregate_options.push(
          this.addFields({record: {$toString: '$record_id'}})
        );
        db_query.record = {$regex:new RegExp(request.query.record_id, 'gi')}
        delete db_query["record_id"];
        delete db_query['partial_record'];
        }else if(request.query.group_record_id && request.query.partial_record == "true"){
          aggregate_options.push(
            this.addFields({group_record: {$toString: '$group_record_id'}})
          );
          db_query.group_record = {$regex:new RegExp(request.query.group_record_id, 'gi')}
          delete db_query["group_record_id"];
          delete db_query['partial_record'];
          }else{
          delete db_query['partial_record'];
        }
      
      _hide.is_deleted = 0;
      _hide.other = 0;
   


      let query_keys = Object.keys(db_query)
      for(let i=0;i<query_keys.length;i++){
        let obj1 = {};
        let obj2 = {};
        obj1[query_keys[i]] =  Number(db_query[query_keys[i]]);
        obj2[query_keys[i]] =  db_query[query_keys[i]]+"";
        if (
          /^[1-9][0-9]*$/.test(
            db_query[query_keys[i]]
          )
        ) {
            aggregate_options.push(this.match(this.or([obj1,obj2])))
            delete db_query[query_keys[i]];
      }
    }
      aggregate_options.push(this.match(db_query));

      if (_config.query.group_by) {
        aggregate_options.push(this.group({
          _id: '$' + _config.query.group_by,
          latest: { $last: "$$ROOT" },
          records: { $push: '$$ROOT' },
        }));
        aggregate_options.push(this.sort({ "_id": 1 }));
      }

      let facet_aggregate_options = [];
      if (sub_document && sub_document.length <= 0 && !!_config.headers &&
        Boolean(_config.headers[config.FIELDS.X_TOTAL_COUNT]) === true && partial_search_flag === false) {
        facet_aggregate_options = [...aggregate_options, ...facet_aggregate_options]
        facet_aggregate_options = facet_aggregate_options.filter(function (returnableObjects) {
          let keys = Object.keys(returnableObjects);
          if (keys[0] !== "$lookup") {
            return true
          }
        });
      }
      if (
        !!_config.headers &&
        Boolean(_config.headers[config.FIELDS.X_TOTAL_COUNT]) === true
      ) {
        if (facet_aggregate_options && facet_aggregate_options.length > 0) {
          let aggregate = []
          aggregate = [...facet_aggregate_options,...aggregate]  
          this.filterProperty(aggregate,"$skip")                 
          facet_options = [
            this.facet({
              total: [...aggregate, this.group()],
              data: aggregate_options,
            }),
          ];
        }
        else {
          let aggregate = []
          aggregate = [...aggregate_options,...aggregate]  
          this.filterProperty(aggregate,"$skip")  
          facet_options = [
            this.facet({
              total: [...aggregate, this.group()],
              data: aggregate_options,
            }),
          ];
        }
      }      
      if(sub_document.length>0){
        this.filterProperty(aggregate_options,"$skip")       
        aggregate_options.push(this.skip(skip));
      }
      aggregate_options.push(this.project(_hide));

      if (select.length) aggregate_options.push(this.project(_select));
      if (limit) aggregate_options.push(this.limit(limit));


      if (child_ref.length) {
        for (let i = 0; i < child_ref.length; ++i) {
          const _ref_table = child_ref[i].trim();
          let local_field = _ref_table;
          let foreign_field = config.FIELDS._ID;
          if (
            config[request[config.FIELDS.MODEL]] &&
            config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER] &&
            config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER][
            _ref_table
            ]
          ) {
            const filter_object =
              config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER][
              _ref_table
              ];
            local_field = filter_object.local_field
              ? filter_object.local_field
              : local_field;
            foreign_field = filter_object.foreign_field
              ? filter_object.foreign_field
              : foreign_field;
          }
          if (foreign_field === config.FIELDS._ID) {
            aggregate_options.push(
              this.addFields(this.convert(local_field, 1))
            );
          }
          aggregate_options.push(
            this.lookup(child_ref[i].trim(), local_field, foreign_field)
          );
          const obj = {};
          obj[_ref_table + '.' + config.FIELDS.OTHER] = 0;
          obj[_ref_table + '.' + config.FIELDS.IS_DELETED] = 0;
          aggregate_options.push(this.project(obj));
        }
      }


      aggregate_options.push(
        this.addFields({
          created_at: {
            $toDate: { $multiply: ['$' + config.FIELDS.CREATED_AT, 1000] },
          },
          updated_at: {
            $toDate: { $multiply: ['$' + config.FIELDS.UPDATED_AT, 1000] },
          },
        })
      );


      if (request.groupBy) {
        aggregate_options.push(this.group(request.groupBy));
      }
      
      // console.log(JSON.stringify(facet_options));
      
      return  await global[request.headers['x-tenant-id']]["_db"][request.model].aggregate(
        facet_options.length > 0 ? facet_options : aggregate_options
      );
      
    } catch (exception) {
      return new Error(exception.message);
    }
  }

  /**
   * update : finding and updating document
   * @author Nitesh <nitesh.meena@biz2credit.com>
   *
   * @param request
   * @param response
   * @param other
   */
  protected update(request, response, other: any = {}) {
    const options = { new: true, useFindAndModify: true };    
    return this.findOneAndUpdate(request, response, { ...other, db: options });
  }

  protected modifyObj(request,obj){

    // obj[request.headers['x-tenant-id']] = {}

    // obj[request.headers['x-tenant-id']]["_db"]= global[request.headers['x-tenant-id']]["_db"];
    obj["headers"] = {}
    obj["headers"]['x-tenant-id'] = request.headers['x-tenant-id'];
    
    return obj;
  }
  /**
   * update : multiple updating document
   * @author Nitesh <nitesh.meena@biz2credit.com>
   *
   * @param request
   * @param response
   * @param other
   */
  protected updateMany(request, response, other: any = {}) {
    const obj = this.getDbQuery(request, other);
    return global[request.headers['x-tenant-id']]["_db"][request.model].updateMany(obj.db_query, { $set: obj.data });
  }

  /**
   * deleteMany : multiple soft delete
   * @author Nitesh <nitesh.meena@biz2credit.com>
   *
   * @param request
   * @param response
   * @param other
   */
  protected deleteMany(request, response, other: any = {}) {
    request.body = { is_deleted: true };
    return this.updateMany(request, response, other);
  }

  private getDbQuery(request, other) {
    const obj = {
      ...services.util_services.getRequestFields(request),
      ...other,
    },
      db_query = {},
      query = { ...obj.query, ...obj.params },
      keys = Object.keys(query);
    for (let i = 0; i < keys.length; ++i)
      db_query[keys[i]] =
        typeof query[keys[i]] === 'string'
          ? this.in(query[keys[i]].split(','))
          : query[keys[i]];

    return { ...obj, db_query };
  }

  /**
   * get : returning mongo Document
   *
   * @author Nitesh <nitesh.meena@biz2credit.com>
   *
   * @param param
   */
  protected findOne(request,param) {
    // return _db[param.model].findOne(param.query);
    return  global[request.headers['x-tenant-id']]["_db"][param.model].findOne(param.query)
  }

  /**
   * get : returning mongo Document
   *
   * @author Nitesh <nitesh.meena@biz2credit.com>
   *
   * @param param
   */
  protected async filterApplication(request, response) {

    const { user_ids, expands } = request.body;

    const aggregation_options = [];

    aggregation_options.push(this.match({ user_id: this.in(user_ids), is_deleted: { $ne: true } }));
    aggregation_options.push(this.addFields({ app_id: { $toString: '$_id' } }));

    if (expands && expands.length) {
      expands.forEach((el) => {
        let pipeline;
        let select;
        if (el.select && el.select.length) {
          select = {};
          pipeline = [];
          el.select.map((s) => select[s] = 1);
          pipeline.push(
            { $eq: ["$app_id", "$$app_id"] }
          );
        }

        aggregation_options.push(
          this.lookup(el.key, el.local_field, el.foreign_field, el.as, pipeline, select)
        );

      });
    }

    return await global[request.headers['x-tenant-id']]["_db"][config.MAP_CONFIG.APPLICATION].aggregate(aggregation_options);
  }

  /**
   * get : returning mongo Document
   *
   * @author Amit Kishore <amit.kishore@biz2credit.com>
   *
   * @param param
   * @param appData
   * @param ignore
   */
  protected async findAllAndClone(request,param, appData: any, ignore: any) {
    const result = await global[request.headers['x-tenant-id']]["_db"][param.model].find(
      { ...param.query, ...this.ignoreQuery(ignore) },
      { _id: 0 }
    );
    const copiedData = {};
    result.forEach(async (item) => {
      item.app_id = appData._id;
      copiedData[param.model] = await services.collection.saveItem(request,
        param.model,
        item
      );
    });

    return copiedData;
  }

  /**
   * get: Ignore query
   *
   * @author Amit Kishore <amit.kishore@biz2credit.com>
   *
   * @param ignoreParams
   */
  protected ignoreQuery(ignoreParams) {
    const ignoreQuery = {};
    if (ignoreParams && ignoreParams.match_key) {
      ignoreQuery[ignoreParams.match_key] = { $nin: ignoreParams.match };
    }

    return { ...ignoreQuery };
  }

  /**
   * insert : adding new document
   *
   * @author Amit Kishore <amit.kishore@biz2credit.com>
   *
   * @param model
   * @param data
   */
  protected saveItem(request,model, data) {
    const item = new  global[request.headers['x-tenant-id']]["_db"][model](data);
    item.isNew = true;
    item.copied = true;
    return item.save();
  }

  /**
   * get : returning mongo Document
   *
   * @author Nitesh <nitesh.meena@biz2credit.com>
   *
   * @param param
   */
  protected save(request,param) {
    return global[request.headers['x-tenant-id']]["_db"][param.model](param.data).save();
  }

  /**
   * findOneAndUpdate : finding and updating document
   *
   * @author Nitesh <nitesh.meena@biz2credit.com>
   *
   * @param request
   * @param response
   * @param other
   */
  protected findOneAndUpdate(request, response, other: any = {}) {
    if (!other.deleted) other.deleted = true;
    if (!request.query) request.query = {};
    let options = { upsert: true, new: true };
    if (other.db) {
      options = options = other.db;
      delete other.db;
    }
    if (other) {
      options = { ...options, ...other };
      other = {};
    }

    if(other.deleted)
    request.query.is_deleted = this.ne(true);
    const obj = this.getDbQuery(request, other);
    if (request.counter) {
      return global[request.headers['x-tenant-id']]["_db"][request.model]
      .findOneAndUpdate(
        obj.query,
        { $inc: obj.data },
        options
      );
    }
    else {
      return global[request.headers['x-tenant-id']]["_db"][request.model]
      .findOneAndUpdate(
        obj.db_query,
        { $set: obj.data },
        options
      );
    }
  }

  /**
   * insert : adding new document
   *
   * @author Nitesh <nitesh.meena@biz2credit.com>
   *
   * @param request
   * @param response
   * @param other
   */
  protected insert(request, response = {}, other: any = {}) {
    const _config = {
      ...services.util_services.getRequestFields(request),
      ...other,
    };
    return global[request.headers['x-tenant-id']]["_db"][request.model](_config.data).save();
  }

  protected delete(request, response) {
    request.body = {};
    request.body.deleted_at = new Date();
    request.body.is_deleted = true;
    return this.update(request, response);
  }

  protected undo(request, response) {
    request.body.deleted_at = new Date();
    request.body.is_deleted = false;
    return this.update(request, response);
  }

  protected _delete(request, response) {
    const _config = services.util_services.getRequestFields(request),
      db_query = {},
      query = { ..._config.query, ..._config.params, is_deleted: false };
    const keys = Object.keys(db_query);
    for (let i = 0; i < keys.length; ++i)
      db_query[keys[i]] = this.in(query[keys[i]].split(','));
    return  global[request.headers['x-tenant-id']]["_db"][request.model].deleteMany(db_query);
  }

  /**
   * replaceOne : adding new document
   *
   * @author Nitesh <nitesh.meena@biz2credit.com>
   *
   * @param request
   * @param response
   * @param p
   */
  protected async replaceOne(
    request,
    response,
    p: { new: boolean; useFindAndModify: boolean }
  ) {
    const _config = services.util_services.getRequestFields(request),
      query = { ..._config.query, ..._config.params, is_deleted: false };
    return  global[request.headers['x-tenant-id']]["_db"][request.model].replaceOne(query, _config.data, {
      new: true,
      useFindAndModify: true,
    });
  }

  lookup(
    from,
    local_field,
    foreign_field,
    as = undefined,
    pipeline = undefined,
    project = undefined,
    addFields = false,
    addPartialFields = false
  ) {    
    if (!pipeline) {
      return {
        $lookup: {
          from: from,
          localField: local_field,
          foreignField: foreign_field,
          as: as || from,
        },
      };
    } else {
      let field;
      if(addFields){
        let query = {[foreign_field]: { "$toString": "$_id" }};
        field = this.addFields(query) 
      }
      let queryPipeline:any = [];
      if(field){
        queryPipeline.push(field)
      }
      if(addPartialFields){
        let query = {"group_record": {
          "$toString": "$group_record_id"
      }}
        queryPipeline.push( this.addFields(query))
      }
      queryPipeline.push(this.match(this.expr(this.and(pipeline))));
      if (project && Object.keys(project).length>0) {
        queryPipeline.push(this.project(project));
      }
      return {
        $lookup: {
          from: from,
          pipeline: queryPipeline,
          let: { [foreign_field.replace(/^_/, '')]: '$' + local_field },
          as: as || from,
        },
      };
    }
  }
  expr(query = {}) {
    return { $expr: query };
  }
  and(query = {}) {
    return { $and: query };
  }

  or(query = []) {
    return { $or: query };
  }

  facet(query = {}) {
    return { $facet: query };
  }
  group(query: any = { _id: null, total: { $sum: 1 } }) {
    return { $group: query };
  }

  project(query: any = { _id: 0 }) {
    return { $project: query };
  }

  addFields(query: any) {
    return { $addFields: query };
  }

  replaceRoot(query: any) {
    return {
      $replaceRoot: {
        newRoot: query,
      },
    };
  }

  filter(input, query: any, as = null) {
    return {
      $filter: {
        input: '$' + input,
        as: as || input,
        cond: query,
      },
    };
  }

  /*
  type code
  1: toObject,
  2: int,
  else: toString
  * */
  convert(field = '_id', type: number = -1) {
    let obj = {},
      convert_type = 'toString';
    obj[field] = {};
    if (type == 1) convert_type = 'toObjectId';
    else if (type == 2) convert_type = 'parseInt';
    obj[field]['$' + convert_type] = '$' + field;
    return obj;
  }

  in(query: any) {
    return { $in: query };
  }

  ne(value: any) {
    return { $ne: value };
  }

  eq(key, value) {
    return { $eq: [key, value] };
  }
  regexMatch(input, regex, options = '') {
    return { $regexMatch: { input, regex, options } };
  }
  strcasecmp(key, value) {
    return { $strcasecmp: [key, value] };
  }
  gt(value: String) {
    return { $gt: +value };
  }

  gte(value: String) {
    return { $gte: +value };
  }

  lt(value: String) {
    return { $lt: +value };
  }

  lte(value: String) {
    return { $lte: +value };
  }

  skip(value: Number) {
    return { $skip: +value };
  }

  unwind(key:String){
    return {$unwind:'$'+key};
  }

  limit(query: {}) {
    return { $limit: query };
  }

  sort(query: {}) {
    return { $sort: query };
  }

  match(query: {}) {
    return { $match: query };
  }

  convertToObjectId(id) {
    if (!id) return null;
    if (id instanceof ObjectId || typeof id !== 'string') return id;

    try {
      return ObjectId(id);
    } catch (c) {
      return null;
    }
  }

  protected async getNextRecordId(request,response) {
    return await this.findOneAndUpdate(request,response)
    }

    filterProperty(aggregate,prop){
      let index = aggregate.findIndex(obj => obj.hasOwnProperty(prop));
      aggregate.splice(index,1)
      return aggregate;
    }
    populateOptions(populate,aggregate_options,request,query,db_query,sub_document,partial_search_flag,partial_search,facility_flag,partial_record_search_flag,partial_record_search){    if (populate.length)
        aggregate_options.push(this.addFields(this.convert()));

      for (let i = 0; i < populate.length; ++i) {
        let old_key = populate[i];
        let  _key = old_key;
        if (config.EXPANDS[populate[i]]) _key = config.EXPANDS[populate[i]];
        let local_field = config.FIELDS._ID,
          foreign_field = config.FIELDS.APP_ID;
        if (
          config[request[config.FIELDS.MODEL]] &&
          config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER]
        ) {

          const filter_object = config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER][populate[i]] || config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER];
          local_field = filter_object.local_field
            ? filter_object.local_field
            : local_field;
          foreign_field = filter_object.foreign_field
            ? filter_object.foreign_field
            : foreign_field;
        }
        if (foreign_field === config.FIELDS._ID) {
          aggregate_options.push(
            this.addFields(this.convert(local_field, 1))
          );
        }
        let pipeline: any = [];
        if (facility_flag) {
          foreign_field = config.FIELDS.PRODUCT_ID;
          pipeline = [this.eq('$' + foreign_field, '$$' + foreign_field.replace(/^_/, ''))];
        }else if(populate[i] == 'group_cases'){
          foreign_field = config.FIELDS._ID;
          local_field = config.FIELDS.GROUP_ID;
          pipeline = [this.eq('$' + foreign_field, '$$' + foreign_field.replace(/^_/, ''))];
        }else if(populate[i] == 'group_owner_details' || populate[i] == "group_owner_references" || populate[i] == 'group_business_references'){
          foreign_field = config.FIELDS.GROUP_ID;
          local_field = config.FIELDS.GROUP_ID;
          pipeline = [this.eq('$' + foreign_field, '$$' + foreign_field.replace(/^_/, ''))];
        } else {
          pipeline = [this.eq('$' + foreign_field, '$$' + foreign_field.replace(/^_/, ''))];
        }
        if (query[old_key]) {
          let project:any={};
          const sub_document_query = query[old_key],
            sub_document_query_keys = Object.keys(sub_document_query);

          sub_document = [...sub_document, ...sub_document_query_keys];
          let delete_sub_key_identifier = false
          for (let j = 0; j < sub_document_query_keys.length; ++j) {
            if (sub_document_query_keys[j] == "is_deleted" && query[populate[i]][sub_document_query_keys[j]] == "true") {
              delete_sub_key_identifier = true;
              pipeline.push(
                this.eq(
                  '$' + sub_document_query_keys[j],
                  true
                )
              );
            }
            else if (sub_document_query_keys[j] != "is_deleted") {
              if (
                /^[1-9][0-9]*$/.test(
                  query[populate[i]][sub_document_query_keys[j]]
                )
              ) {
                  pipeline.push(this.or([this.eq(
                    '$' + sub_document_query_keys[j],
                    Number(query[populate[i]][sub_document_query_keys[j]])
                  ), this.eq(
                    '$' + sub_document_query_keys[j],
                    query[populate[i]][sub_document_query_keys[j]]
                  )]));
              }
              else if(populate[i] == "business" && sub_document_query_keys[j] == "business_location" && sub_document_query_keys[j] != "fields"){
                let business_location = query[populate[i]][sub_document_query_keys[j]].split(",");
                let business_location_filter_arr = [];
                for(let k=0;k<business_location.length;k++){
                  let query = this.eq( '$' + sub_document_query_keys[j],business_location[k]);
                  business_location_filter_arr.push(query);
                }
                pipeline.push(
                  this.or(business_location_filter_arr)
                );
              }
              else if(populate[i] == "business" && sub_document_query_keys[j] == "qualified_loan_amount" && sub_document_query_keys[j] != "fields"){
                let qualified_loan_amount = query[populate[i]][sub_document_query_keys[j]].split(":");
                if(qualified_loan_amount[0] == "greater"){
                  pipeline.push(this.or([{$gt:[
                    '$' + sub_document_query_keys[j],
                    +qualified_loan_amount[1]]}]))
                }else if(qualified_loan_amount[0] == "less"){
                  pipeline.push({$lt:[
                    '$' + sub_document_query_keys[j],
                    +qualified_loan_amount[1]]});

                  pipeline.push({$gte:[
                      '$' + sub_document_query_keys[j],
                   0]})
                  }
                }
           
              else if(sub_document_query_keys[j] == "fields"){
                let fields =  query[populate[i]][sub_document_query_keys[j]].split(",");
                for(let i=0;i<fields.length;i++){
                  project[fields[i].trim()] = 1;
                }
              }else if(sub_document_query_keys[j] == "d_fields"){
                let fields =  query[populate[i]][sub_document_query_keys[j]].split(",");
                for(let i=0;i<fields.length;i++){
                  project[fields[i].trim()] = 0;
                }
              }else if(sub_document_query_keys[j].search(/.in$/) !== -1){
                
                pipeline.push(
                  {
                    "$in":
                    ['$' + sub_document_query_keys[j].replace(/.in$/, ''),
                    typeof query[populate[i]][sub_document_query_keys[j]]==='string'?query[populate[i]][sub_document_query_keys[j]].split(','):query[populate[i]][sub_document_query_keys[j]]
                  ]
                  }
                );
              }
              else{
                pipeline.push(
                  this.eq(
                    '$' + sub_document_query_keys[j],
                    query[populate[i]][sub_document_query_keys[j]]
                  )
                );
              }
            }
          }

          // if (delete_sub_key_identifier === false &&  populate[i] !='appmetrix') {
          //   pipeline.push(
          //     this.eq(
          //       '$' + "is_deleted",
          //       false
          //     )
          //   );
          // }

         
          if(populate[i] == "group_cases" && partial_record_search_flag){
            aggregate_options.push(
              this.lookup(_key, local_field, foreign_field, populate[i], pipeline,project,true,true)
            );
          }else if(populate[i] == "group_cases"){
            aggregate_options.push(
              this.lookup(_key, local_field, foreign_field, populate[i], pipeline,project,true)
            );
          }else{
            aggregate_options.push(
              this.lookup(_key, local_field, foreign_field, populate[i], pipeline,project)
            );
          }
          aggregate_options.push(this.match({ [populate[i]]: this.ne([]) }));

          delete query[old_key];
          delete db_query[old_key];
        }
        else {
          // if(populate[i] !="appmetrix"){          
            pipeline.push(
              this.eq(
                '$' + "is_deleted",
                false
              )
            );
          // }
          
          // if(populate[i] =="appmetrix" && query['only_assign'] == "true"){
          //   pipeline.push({$ne:['$assigned_to',"0"]})
          // }


        if(populate[i] == "group_cases"){
          aggregate_options.push(
            this.lookup(_key, local_field, foreign_field, populate[i], pipeline,undefined,true)
          );
        }else{
          aggregate_options.push(
            this.lookup(_key, local_field, foreign_field, populate[i], pipeline)
          );
        }

        }
        if (partial_search_flag && populate[i] == 'business') {
          for (partial_search of partial_search) {
            aggregate_options.push(this.match(partial_search));
          }
        }

        if (partial_record_search_flag && populate[i] == 'group_cases') {
          for (partial_record_search of partial_record_search) {
            aggregate_options.push(this.match(partial_record_search));
          }
        }
      }
      return sub_document;
  }
}
