export default class CollectionQueryBuilder {
	//
}
