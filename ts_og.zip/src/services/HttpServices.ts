import request from "request";

export default class Http {
    init(options) {
        return new Promise((resolve, reject) => {
            request(options, (e, resp, body) => {
                if (!e) resolve(JSON.parse(body));
                else reject(e);
            });
        });
    }
}
