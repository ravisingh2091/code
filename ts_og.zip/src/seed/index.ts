import MultiTenant from "./MultiTenant";
import External from "../routes/external";
declare var config: any,  services: any
export default class Index{

  static async  seed(){
      //console.log("seed is called ")
    await MultiTenant.CheckTenant()
    this.assign_rule()

    }
    static async assign_rule(){
        try {
            let USER_URL = process.env.USER_URL+"/api/backend/v1/users";
            let users= await new External().get({
                },USER_URL);
            let resp = []
            
            for(let i=0;i<users.data.length;i++){
                if(users.data[i].role_id){
                    let obj :any = {}
                    obj.query = {"assigned_to":users.data[i].id}
                    obj.body = {"assigned_to_role_id":users.data[i].role_id}
                    obj.model =  config.assignment.model;
                    let data = await services.collection.updateMany(obj, {});
                    if(data)
                    resp.push(data)
                }
            }	
            process.exit(0)
        } catch (error) {
            //console.log(error); 
            process.exit(0)
        }
       
}

}