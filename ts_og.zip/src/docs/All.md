##Service - Case x.x.x

###What’s new in App-Assignment
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.
		
#### New Routes

| Route         | Method        |
| ------------  |-------------  |
| /:_id         | DELETE        |

#### Deprecated Routes

| Route         | Method        |
| ------------  |-------------  |
| /delete       | POST          |
| /app_count    | GET           |
| zebra stripes | are neat      |


-----

###What’s new in Application
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.
 - optimized memory/load time to get record.
 - added indexing for getting record fast.

 ###Bug fixes
 - issue resolved of server failed to return in huge number of amount record.

#### Deprecated Routes

| Route                 | Method        |
| ------------------    |-------------  |
| /all                  | GET           |
| /app_status/{id}      | GET           |
| app_count             | GET           |
| app_activity/{app_id} | PUT           |


-----

###What’s new in Business
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.

#### Deprecated Routes

| Route                 | Method        |
| ------------------    |-------------  |
| /{business_id}        | GET           |


---

###What’s new in Checklist
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.
 
 ###W Bug fixes
  - removed duplicate working
  - some end points have been decrypted as we can handle their work in a single end point with the help of query.

#### Deprecated Routes

| Route                 | Method        |
| ------------------    |-------------  |
| /all                  | GET           |
| /all                  | POST          |
| /{id}                 | GET           |
| /checklists           | PUT           |
| /checklists           | POST          |


---

###What’s new in Collateral
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.
 
 ###W Bug fixes
 - removed duplicate working
 - some end points have been decrypted as we can handle their work in a single end point with the help of query.
	
#### Deprecated Routes

| Route                 | Method        |
| ------------------    |-------------  |
| /{id}                 | GET           |
| /                     | PUT           |


---

###What’s new in Owner
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.
 - optimized memory/load time to get record.
 - reduced owner single owner actual_percent calculation time from <b>O(N<sup>^M</sup>)</b> to <b>O(1)</b> { N: max size of owners, M: max level of owners. }.
 - reduced owner_individual_percent calculation time from <b>O(N*M)</b> to <b>O(N)</b> { N: number of owners, M: Level of owners }.
 - reduced owner citizenship, weighted_average etc. calculation time from <b>O(N)</b> to <b>O(M)</b> { N: number of owners with query, M: number of valid owners (we are returning only valid | required information with extra query params) }.
 - added indexing for getting record fast.
 
 ###W Bug fixes
 - issue resolved of server failed to return in huge number of amount record. 
 - removed duplicate working
 - some end points have been decrypted as we can handle their work to a single end point with the help of query.
 		
#### Deprecated Routes

| Route                 | Method        |
| ------------------    |-------------  |
| /all                  | GET           |
| /individual_percent   | GET           |
| /verify_hash          | GET           |
| /new_hash             | PUT           |
| /delete_hash          | POST          |
| /percent_consent      | PUT           |


---

###What’s new in Product
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.
 
 ###W Bug fixes
 - issue resolved of server failed to return in huge number of amount record. 
 - removed duplicate working
 - some end points have been decrypted as we can handle their work in a single end point with the help of query.
        
#### Deprecated Routes

| Route                 | Method        |
| ------------------    |-------------  |
| /{id}                 | GET           |
| /list                 | POST          |
| /                     | PUT           |



---------

## Features

return required docs as per queries 

        /api/v1/application?user_id=5e8073a83e01b1653844e154&email=xyz@biz2credit.com

return limited records 

        /api/v1/application?limit=10

return greater than to some value records.

        /api/v1/application?price>=2413

return smaller than to some value records.

        /api/v1/application?price<=2413
        
return greater than and equal to some value records.

        /api/v1/application?price>==2413

return smaller than and equal to some value records.

        /api/v1/application?price<==2413
        
return all records their given key value is not equal to given value.

        /api/v1/application?price!=2413

return document in ASCENDING sorted order 

        /api/v1/application?sort_by=name

return document in DESCENDING sorted order 

        /api/v1/application?sort_by=-name
        
        :: - is using for descending order

return all records except first n records

        /api/v1/application?skip=4

return range index records

        /api/v1/application?start=4
        /api/v1/application?end=10
        
expand child collection records by default will return mongo _id. 

        /api/v1/application?expands=owner

return only required fields

        /api/v1/application?fields=name,owners

return all fields except mentioned fields on d_fields query option

        /api/v1/application?d_fields=name,owners

get child record if necessary by default not returning child records
        
        /api/v1/application?child_ref=owners:app_id,businesses:app_id
        
        explaination => 
                owners is collection name,
                app_id is foriegn key

get total number of records without any record returning
        
        /api/v1/application
        
        headers => 
                x-total-count: true

get count (number of records) of a key (eg. status_id, email etc)
        
        /api/v1/application?count=status_id
