###What’s new in Owner
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.
 - optimized memory/load time to get record.
 - reduced owner single owner actual_percent calculation time from <b>O(N<sup>^M</sup>)</b> to <b>O(1)</b> { N: max size of owners, M: max level of owners. }.
 - reduced owner_individual_percent calculation time from <b>O(N*M)</b> to <b>O(N)</b> { N: number of owners, M: Level of owners }.
 - reduced owner citizenship, weighted_average etc. calculation time from <b>O(N)</b> to <b>O(M)</b> { N: number of owners with query, M: number of valid owners (we are returning only valid | required information with extra query params) }.
 - added indexing for getting record fast.
 
 ###W Bug fixes
 - issue resolved of server failed to return in huge number of amount record. 
 - removed duplicate working
 - some end points have been decrypted as we can handle their work to a single end point with the help of query.
 		
#### Deprecated Routes

| Route                 | Method        |
| ------------------    |-------------  |
| /all                  | GET           |
| /individual_percent   | GET           |
| /verify_hash          | GET           |
| /new_hash             | PUT           |
| /delete_hash          | POST          |
| /percent_consent      | PUT           |
