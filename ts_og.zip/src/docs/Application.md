###What’s new in Application
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.
 - optimized memory/load time to get record.
 - added indexing for getting record fast.
 
 
 ###Bug fixes
 - issue resolved of server failed to return in huge number of amount record.

#### Deprecated Routes

| Route                 | Method        |
| ------------------    |-------------  |
| /all                  | GET           |
| /app_status/{id}      | GET           |
| app_count             | GET           |
| app_activity/{app_id} | PUT           |
