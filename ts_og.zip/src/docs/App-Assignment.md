###What’s new in App-Assignment
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.
		
#### New Routes

| Route         | Method        |
| ------------  |-------------  |
| /:_id         | DELETE        |

#### Deprecated Routes

| Route         | Method        |
| ------------  |-------------  |
| /delete       | POST          |
| /app_count    | GET           |
| zebra stripes | are neat      |
