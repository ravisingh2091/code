###What’s new in Collateral
 - added new rollback feature (undo/redo option on update and delete).
 - added same format (in array) for all requests to return data.
 - added support of query params for all request.
 
 ###W Bug fixes
 - removed duplicate working
 - some end points have been decrypted as we can handle their work in a single end point with the help of query.
	
#### Deprecated Routes

| Route                 | Method        |
| ------------------    |-------------  |
| /{id}                 | GET           |
| /                     | PUT           |
