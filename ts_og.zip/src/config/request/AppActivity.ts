import FieldsBuilder from "./base";

export default class AppActivity extends FieldsBuilder {

	app_activity: Object = {
		filter: {
			business_info:
			{
				local_field: this.APP_ID,
			    foreign_field: this.APP_ID
		    },
			application:{
				local_field:this.APP_ID,
				foreign_field:this._ID
			}
		}
	};
};
