import FieldsBuilder from "./base";

export default class Facility extends FieldsBuilder {
	facility: Object = {
    post: {
		body: [
			this.getValidation(this.PRODUCTS, true, [], this.ARRAY)
        ]
    },
    delete:{
        body:[
          this.getValidation(this.PRODUCTS, true, [], this.ARRAY)
        ]
      },
    put:{
      body:[
        this.getValidation(this.PRODUCTS, true, [], this.ARRAY)
      ]
    }
	}
};
