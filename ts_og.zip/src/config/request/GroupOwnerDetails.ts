import FieldsBuilder from './base';

export default class GroupOwnerDetails extends FieldsBuilder {
  groupownerdetails: Object = {
    post: {
      body: [
        this.getValidation(this.GROUP_ID),
      ]
    },
    put: {
      body: [
        this.getValidation(this.GROUP_ID),
      ],
      params: [
        this.getValidation(this._ID),
      ]
    },
    delete: {
      body: [
        this.getValidation(this.MULTIPLE_APP_ID),
      ],
      params: [
        this.getValidation(this.GROUP_ID),
      ]
    }
  };
}
