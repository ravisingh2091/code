import FieldsBuilder from "./base";

export default class Assignment extends FieldsBuilder {

	assignment: Object = {
		app: [this.getValidation(this.APP_ID)],
		query: [this.getValidation(this.APP_ID), this.getValidation(this.ROLE_ID), this.getValidation(this.ASSIGNED_TO)],
		model: "assignment",
		body: [
			this.getValidation(this.APP_ID),
			this.getValidation(this.ROLE_ID),
			// this.getValidation(this.ASSIGNED_TO),
			this.getValidation(this.BACKEND_USER_ID),
			this.getValidation(this.ACTION),
			this.getValidation(this.IS_COMPLETED)
		],
		filter: {
			local_field: this.APP_ID,
			foreign_field: this.APP_ID,
		}
	};
};
