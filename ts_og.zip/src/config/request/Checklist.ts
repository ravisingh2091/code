import FieldsBuilder from "./base";

export default class Checklist extends FieldsBuilder {

	checklist: Object = {
		body: [
			this.getValidation(this.APP_ID),
			this.getValidation(this.ROLE_ID),
			this.getValidation(this.OWNER_ID),
			this.getValidation(this.BACKEND_USER_ID),
			this.getValidation(this.CHECKLIST_ID),
			this.getValidation(this.CHECKLIST_ACTION)
		]
	};
};
