import FieldsBuilder from "./base";

export default class Note extends FieldsBuilder {
	note: Object = {
		body: [
			this.getValidation(this.NOTE),
			this.getValidation(this.APP_ID),
			this.getValidation(this.ROLE_ID),
			this.getValidation(this.BACKEND_USER_ID)
		]
	};
};
