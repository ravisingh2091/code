import FieldsBuilder from "./base";

export default class Owner extends FieldsBuilder {

	owner_models: any = {
		hash: this.HASH,
		owner: this.OWNER,
	};

	owner: Object = {
		params: this._ID,
		owner_id: [this.getValidation(this.OWNER_ID)],
		update_percent: [this.getValidation(this.OWNER_ID)],
		app: [this.getValidation(this.APP_ID)],
		application: [this.getValidation(this.APP_ID), this.getValidation(this.USER_ID), this.getValidation(this.OWNERS, true, [], "array")],
		citizenship: {
			model: this.owner_models.owner,
			query: [
				this.getValidation(this._ID),
				this.getValidation(this.USER_ID)
			],
			next: "citizenship"
		},
		hash: {
			model: this.owner_models.hash,
			query: [
				this.getValidation(this.APP_ID),
				this.getValidation(this.HASH_FOR)
			],
			body: [
				this.getValidation(this.APP_ID),
			],
			verify: {
				model: this.owner_models.hash,
				params: [this.getValidation(this.HASH)]
			},
			expire:{
				model: this.owner_models.hash,
				body: [this.getValidation(this.HASH_FOR)]
			}
		},
		weighted_average: {
			query: [this.getValidation(this.APP_ID)],
			body: [
				{
					name: "owners",
					validations: [
						{
							name: "required",
							type: "array",
							field_arr: [
								this.getValidation(this.OWNER_ID),
								this.getValidation(this.SCORE)
							]
						}
					]
				}
			]
		},
		body: [
			this.getValidation(this.OWNERS),
			this.getValidation(this.APP_ID),
			this.getValidation(this.USER_ID)
		],
		patch: {
			params: [this.getValidation(this.APP_ID)],
		}
	};
};
