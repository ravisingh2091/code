import FieldsBuilder from "./base";

export default class Collateral extends FieldsBuilder {
	collateral: Object = {
		body: [
			this.getValidation(this.APP_ID),
			this.getValidation(this.USER_ID),
			this.getValidation(this.COLLATERALS, true, [], this.ARRAY)
		]
	};
};
