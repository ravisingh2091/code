import FieldsBuilder from "./base";

export default class Service extends FieldsBuilder {
	service: Object = {
		business: {
			body: [
				this.getValidation(this.APP_ID),
				this.getValidation(this.USER_ID),
				this.getValidation(this.REF_ID),
				this.getValidation(this.PROVIDER),
				// this.getValidation(this.BACKEND_USER_ID),
				this.getValidation(this.TYPE)
			]
		},
		collateral: {
			body: [
				this.getValidation(this.APP_ID),
				this.getValidation(this.USER_ID),
				this.getValidation(this.REF_ID),
				this.getValidation(this.PROVIDER),
				this.getValidation(this.TYPE),
				this.getValidation(this.COLLATERAL_ID)
			]
		},
		owner: {
			body: [
				this.getValidation(this.APP_ID),
				this.getValidation(this.USER_ID),
				this.getValidation(this.REF_ID),
				this.getValidation(this.PROVIDER),
				this.getValidation(this.TYPE),
				this.getValidation(this.OWNER_ID)
			]
		},
		group_business:{
			body: [
				this.getValidation(this.GROUP_ID),
				this.getValidation(this.USER_ID),
				this.getValidation(this.REF_ID),
				this.getValidation(this.PROVIDER),
				// this.getValidation(this.BACKEND_USER_ID),
				this.getValidation(this.TYPE)
			]
		},
		group_service_owner:{
				body: [
					this.getValidation(this.GROUP_ID),
					this.getValidation(this.USER_ID),
					this.getValidation(this.REF_ID),
					this.getValidation(this.PROVIDER),
					this.getValidation(this.TYPE),
					this.getValidation(this.OWNER_ID)
				]
		}
	};
};
