import FieldsBuilder from './base';

export default class GroupCases extends FieldsBuilder {
  groupcases: Object = {
    post: {
      body: [
        this.getValidation(this.GROUP_Name),
        this.getValidation(this.MULTIPLE_APP_ID),
      ]
    },
    put:{
      body:[
        this.getValidation(this.MULTIPLE_APP_ID),
      ],
      params:[
        this.getValidation(this.GROUP_ID),
      ]
    },
    delete:{
      body:[
        this.getValidation(this.MULTIPLE_APP_ID),
      ],
      params:[
        this.getValidation(this.GROUP_ID),
      ]
    }
  };
}
