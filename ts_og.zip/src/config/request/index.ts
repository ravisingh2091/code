import FieldsBuilder from "./base";

export default class Request extends FieldsBuilder {
	FIELDS: any = this;

	MODIFY_NOT_ALLOWED: Object = {
		OWNER: [this.OWNERSHIP_PERCENT, this.NAME_OF_THE_DIRECT_OWNER, this.OWNER_EMAIL, this.ACTUAL_PERCENT, this.OWNER_TYPE],
		BUSINESS: [this.APP_ID],
	};

	SCHEMA_FIELDS: Object = {
		OWNER: {
			OWNER_TYPE: [this.INDIVIDUAL, this.CORPORATE, this.PARTNERSHIP, this.MAIN_APPLICANT, this.GUARANTOR, this.CO_APPLICANT, this.ENTITY]
		},
		ASSIGNMENT: {
			ACTION: [this.APPROVED, this.DECLINED, this.ESCALATED, this.ASSIGNED, this.UNASSIGNED],
			ACTION_FROM: [this.FRONTEND, this.BACKEND]
		},
		CHECKLIST: {
			CHECKLIST_ACTION: [this.YES, this.NO, this.PENDING, this.COMPLETE, this.NA]
		},
	};
}
