import FieldsBuilder from "./base";

export default class Business extends FieldsBuilder {

	business: Object = {
		body: [this.getValidation(this.APP_ID)],
		filter: {
			application:{
				local_field:this.APP_ID,
				foreign_field:this._ID
			},
			owner_references:{
				local_field:this.APP_ID,
				foreign_field:this.APP_ID
			},
			business_references:{
				local_field:this.APP_ID,
				foreign_field:this.APP_ID
			}
		}

	};
	
};
