import Fields from "./fields";

export default class Constant extends Fields {
	CONSTANT = {
		MAX_BITS: 32
	};
}
