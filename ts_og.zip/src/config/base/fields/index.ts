import Mongo from "../../Mongo";

export default class Fields extends Mongo {
	APP_ID = "app_id";
	PARENT_STATUS_ID = "parent_status_id";
	PRODUCT_ID = "product_id";
	_CONSENT = "consent";
	ROLE_ID = "role_id";
	OWNER = "OWNER";
	HASH = "hash";
	HASH_FOR = "hash_for";
	ACTION_TYPE = "action_type";
	PRODUCT_CONFIG = "product_config";
	ASSIGNED_TO = "assigned_to";
	ASSIGNMENT = "assignment";
	SLUG = "slug";
	SLUG_OR_ORCH_URL = "`slug` or `orch_url`";
	OWNER_ID = "owner_id";
	UPDATED_PERCENT = "updated_percent";
	USER_ID = "user_id";
	COLLATERALS = "collaterals";
	PRODUCTS = "products";
	OWNERSHIP_PERCENT = "ownership_percent";
	OWNER_LEVEL = "owner_level";
	MAXIMUM_OWNERS = "maximum_owners";
	INDIVIDUAL = "individual";
	RECEIVED = "received";
	CORPORATE = "corporate";
	PENDING = "pending";
	PARTNERSHIP = "partnership";
	MAIN_APPLICANT = "main_applicant";
	GUARANTOR = "guarantor";
	CO_APPLICANT = "co_applicant";
	ENTITY = "entity";
	NAME_OF_THE_DIRECT_OWNER = "name_of_the_direct_owner";
	OWNER_EMAIL = "owner_email";
	ACTUAL_PERCENT = "actual_percent";
	PARENT_ID = "parent_id";
	OWNER_TYPE = "owner_type";
	BACKEND_USER_ID = "backend_user_id";
	notes = "notes";
	_ID = "_id";
	GROUP_Name="group_name";
	MULTIPLE_APP_ID="app_id";
	GROUP_ID="group_id";
	PARENT = "parent";
	SERVICES = "services";
	EVENT = "event";
	EVENTS = "events";
	MODEL = "model";
	MIDDLEWARE = "middleware";
	MODELS = "models";
	_DB = "_db";
	CREATED_AT = "created_at";
	UPDATED_AT = "updated_at";
	DELETED_AT = "deleted_at";
	ACTION = "action";
	IS_COMPLETED = "is_completed";
	CHECKLIST_ID = "CHECKLIST_ID";
	CHECKLIST_ACTION = "CHECKLIST_ACTION";
	UPDATE_PERCENT_CONSENT = "update_percent_consent";
	NOTE = "note";
	NOTES = "notes";
	SCORE = "score";
	OWNERS = "owners";
	REF_ID = "ref_id";
	PROVIDER = "provider";
	TYPE = "type";
	COLLATERAL_ID = "collateral_id";
	APPROVED = "approved";
	DECLINED = "declined";
	ESCALATED = "escalated";
	ASSIGNED = "assigned";
	UNASSIGNED = "unassigned";
	OWNER_CONSENT = "owner_consent";
	FRONTEND = "frontend";
	BACKEND = "backend";
	BUSINESS_ADDRESS = "business_address";
	MAIL_ADDRESS = "mail_address";
	VERIFY_HASH = "verify-hash";
	IS_CONSENT_RECEIVED = "is-consent-received";
	CONSENT = "consent";
	IS_DELETED = "is_deleted";
	OTHER = "other";
	YES = "yes";
	NO = "no";
	COMPLETE = "complete";
	NA = "na";
	REQUIRED = "required";
	ARRAY = "array";
	UNDO = "undo";
	REDO = "redo";
	GET = "get";
	POST = "post";
	DELETE = "delete";
	_DELETE = "_delete";
	UPDATE = "update";
	X_DELETE_ALL = "x-delete-all";
	INSERT = "insert";
	FIND_ONE_AND_UPDATE = "findOneAndUpdate";
	MATCH = 'match';
	RECORD_ID = 'record_id';
	PRODUCT_TYPE = 'product_type';
	STATUS_ID = 'status_id';
	X_TOTAL_COUNT = "x-total-count";
	COUNT="count";
	QUERY = "query";
	BODY = "body";
	NEXT = "next";
	PARAMS = "params";
	FILTER = "filter";
	SERVICE_BUSINESS = "service_business";
	SERVICE_COLLATERAL = "service_collateral";
	BUSINESS_REFERENCES = "business_references";
	SERVICE_OWNER = "service_owner";
	GROUP_SERVICE_OWNER = "group_service_owner";
	GROUP_SERVICE_BUSINESS = "group_service_business";

	EXPANDS = {
		owners: "owner_details",
		business: "business_info",
		business_references: "service_business",
		owner_references: "service_owner",
		group_owner_references: "group_service_owner",
		application:"application",
		group_business_references: "group_service_business"
	};

	MODEL_CONFIG = {
		APP_ACTIVITY: "app_activity",
		APPLICATION: 'application',
		APP_STATUS: 'app_status_history',
		ASSIGNMENT: 'app_assignment',
		AUDIT: 'audits',
		BUSINESS: 'business_info',
		CHECKLIST: 'checklist',
		COLLATERAL: 'collateral',
		COUNTER: 'counter',
		FACILITY: 'product',
		GROUP_ASSIGNMENT: 'group_assignment',
		GROUP_CASES: 'group_cases',
		GROUP_OWNER_DETAILS: 'group_owner_details',
		GROUP_SERVICE_BUSINESS: 'group_service_business',
		GROUP_SERVICE_OWNER: 'group_service_owner',
		HASH: 'hash',
		MEMOIZATION_CONFIG: 'MemoizationConfig',
		NOTE: 'notes',
		OWNER: 'owner_details',
		OWNER_WEIGHTED_AVERAGE: 'owners_weighted_avg',
		PRODUCT: 'products',
		REQUEST: 'Request',
		SERVICE_BUSINESS: 'service_business',
		SERVICE_COLLATERAL: 'service_collateral',
		SERVICE_OWNER: 'service_owner',
		SERVICE_PRODUCT: 'service_product',
		SUB_FACILITY: 'sub_product',
		WEIGHTED_AVERAGE: 'WeightedAverage',
		APPMETRIX:"appmetrix"
	  }

	  MAP_CONFIG = {
		APP_ACTIVITY: "app_activity",
		APPLICATION: 'application',
		APP_STATUS: 'app_status',
		ASSIGNMENT: 'assignment',
		AUDIT: 'audit',
		BUSINESS: 'business',
		CHECKLIST: 'checklist',
		COLLATERAL: 'collateral',
		COUNTER: 'counter',
		FACILITY: 'facility',
		GROUP_ASSIGNMENT: 'group_assignment',
		GROUP_CASES: 'group_cases',
		GROUP_OWNER_DETAILS: 'group_owner_details',
		GROUP_SERVICE_BUSINESS: 'group_service_business',
		GROUP_SERVICE_OWNER: 'group_service_owner',
		HASH: 'hash',
		MEMOIZATION_CONFIG: 'memoization_config',
		NOTE: 'note',
		OWNER: 'owners',
		OWNER_WEIGHTED_AVERAGE: 'owner_weighted_average',
		PRODUCT: 'product',
		REQUEST: 'request',
		SERVICE_BUSINESS: 'service_business',
		SERVICE_COLLATERAL: 'service_collateral',
		SERVICE_OWNER: 'service_owner',
		SERVICE_PRODUCT: 'service_product',
		SUB_FACILITY: 'sub_facility',
		WEIGHTED_AVERAGE: 'weighted_average',
		APPMETRIX:"appmetrix"
	  }
}
