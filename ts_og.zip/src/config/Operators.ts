export default class Operators {
	operators: Object = {
		">": "gt",
		">=": "gte",
		"<": "lt",
		"<=": "lte",
		"!": "ne",
	};
}
