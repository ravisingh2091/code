export default class Default {
	Default: Object = {
		MAX_PERCENT: 100,
		HASH_LIMIT: 3,
		MAX_HASH_DAYS_LIMIT: 3,
		MAX_HASH_EXPIRY_HOURS_LIMIT: 24,
		MAX_ALLOWED_COLLATERAL: 5
	}
}
