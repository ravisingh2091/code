import path from "path";

declare var config: any;
export default class App {
	routes: any = "routes/api";
	app_base_dir: any = path.join(__dirname, "..");

	URL: string ;
	IS_DB_STRICT: any = process.env.IS_DB_STRICT || false;
	DATABASE_URL: string = process.env.DATABASE_URL;
	USER_URL: any = {};
	ORCHESTRATOR: string;
	MASTER_URL: string;

	REQUEST_VALIDATION_OPTIONS: any = {
		header: 1,
		body: 1,
		params: 1,
		query: 1,
	};

	constructor() {
		console.log("app config is called ---")
		const env_keys = Object.keys(process.env);
		for (let i = 0; i < env_keys.length; ++i) this[env_keys[i]] = process.env[env_keys[i]];

		this.USER_URL = {
			USERS: process.env.USER_URL + "/api/v1/users",
		};
		this.ORCHESTRATOR = process.env.ORCHESTRATOR_URL + "/v1/tasks/getTaskInfo";
		this.MASTER_URL = process.env.MASTER_URL + "/v1";
		this.URL = process.env.HOST + ":" + process.env.PORT;
	}

	getResponse = function (code_obj, status = "FAILED", message = "FAILED") {
		let resp: any = {};
		if (typeof code_obj === "object") resp = code_obj;
		else resp = {
			code: code_obj,
			status: status,
			message: message
		};
		if (!!!config.IS_DB_STRICT) {
			resp.status = resp.status.toLowerCase();
			resp.message = resp.message.toLowerCase();
		}
		return resp;
	}

	updateUrls(){
		const env_keys = Object.keys(process.env);
		for (let i = 0; i < env_keys.length; ++i) config[env_keys[i]] = process.env[env_keys[i]];
		config.USER_URL = {
			USERS: process.env.USER_URL + "/api/v1/users",
		};
		config.ORCHESTRATOR = process.env.ORCHESTRATOR_URL + "/v1/tasks/getTaskInfo";
		config.MASTER_URL = process.env.MASTER_URL + "/v1";
		config.URL = process.env.HOST + ":" + process.env.PORT;
	}
}
