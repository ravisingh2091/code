export default interface AbstractException {
};
