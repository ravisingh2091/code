export default class Node {
	element: any;
	next;
	constructor(element) {
		this.element = element;
		this.next = null
	}
}
