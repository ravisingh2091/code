declare var services: any;
export default class Base {
	_get(_config, URL) {
		let config = _config
		if (config.headers && process.env.TENANT && process.env.TENANT != '&default&' && process.env.TENANT != 'undefined') {
			config.headers['x-tenant-id'] = process.env.TENANT
		}
		else if (!config.headers && process.env.TENANT && process.env.TENANT != '&default&' && process.env.TENANT != 'undefined') {
			let headers_obj = {
				headers: {
					'x-tenant-id': process.env.TENANT
				}
			}
			config = { ...config, ...headers_obj }

		}
		const options = services.util_services.getOptions({
			url: services.util_services.generateRoute(config, URL),
			...config
		});

		return services.http_services.init(options);
	}
};
