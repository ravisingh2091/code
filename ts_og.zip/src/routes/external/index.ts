import Base from "./base";

declare var config: any;
export default class External extends Base {
	get(config, url) {
		return this._get(config, url);
	}

	getOrchFileds(request, response) {
		/*getting validation fields from orchestrator*/
		let orch_url = config.ORCHESTRATOR, orch_config = {};

		if (request.body.orch_url) orch_url = request.body.orch_url + "&internal=true";
		else {
			orch_config = {
				query: {
					slug: request.body.slug,
					internal: true
				}
			};
		}

		return this.get(orch_config, orch_url);
	}
};
