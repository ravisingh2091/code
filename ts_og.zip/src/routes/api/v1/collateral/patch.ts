import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config;
export default class Patch implements ApiCriteriaBuilder {

	get body(): any {
		return config.collateral.body;
	}
};
