import ApiCriteriaBuilder from '../../../ApiCriteriaBuilder';

declare var config: any;
export default class Put implements ApiCriteriaBuilder {
  get body(): any {
    return config.facility.put.body;
  }
}