import ApiCriteriaBuilder from '../../../ApiCriteriaBuilder';

declare var config: any;
export default class Post implements ApiCriteriaBuilder {

}