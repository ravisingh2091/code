import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config: any;
export default class Delete implements ApiCriteriaBuilder {
	get query(): any {
		return config.owner.hash.query;
	}
	get next(): any {
		return "_delete";
	}
};
