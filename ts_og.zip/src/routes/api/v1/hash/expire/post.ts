import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";
declare var config: any;
export default class Post implements ApiCriteriaBuilder {
    get next(): any {
        return 'expire';
    }
    get body(): any {
		return {};
	}

	get model(): any {
		return config.owner.hash.verify.model;
	}
};
