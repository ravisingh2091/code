import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config: any;
export default class Put implements ApiCriteriaBuilder {
	get model(): any {
		return config.owner.hash.model;
	}

	get body(): any {
		return {};
	}
};
