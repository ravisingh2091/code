import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

declare var config: any;
export default class Get implements ApiCriteriaBuilder {
	get params(): any {
		return config.owner.hash.verify.params;
	}

	get model(): any {
		return config.owner.hash.verify.model;
	}
};
