import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config: any;
export default class Post implements ApiCriteriaBuilder {
	get model(): any {
		return config.owner.hash.model;
	}
};
