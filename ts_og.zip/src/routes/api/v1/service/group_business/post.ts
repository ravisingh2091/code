import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

declare var config: any;
export default class Post implements ApiCriteriaBuilder {

	get headers(): any {
		return {};
	}

	get model(): any {
		return config.FIELDS.GROUP_SERVICE_BUSINESS;
	}

	get body(): any {
		return config.service.group_business.body;
	}
};
