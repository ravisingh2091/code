import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

declare var config: any, middleware: any;
export default class Post implements ApiCriteriaBuilder {

	get headers(): any {
		return {};
	}

	get model(): any {
		return config.FIELDS.SERVICE_BUSINESS;
	}

	get body(): any {
		return config.service.business.body;
	}
};
