import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

declare var config: any;
export default class Get implements ApiCriteriaBuilder {

	get headers(): any {
		return {};
	}

	get model(): any {
		return config.FIELDS.GROUP_SERVICE_OWNER;
	}

	get body(): any {
		return {};
	}
};
