import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

declare var config: any;
export default class Patch implements ApiCriteriaBuilder {

	get headers(): any {
		return {};
	}

	get model(): any {
		return config.FIELDS.SERVICE_OWNER;
	}
};
