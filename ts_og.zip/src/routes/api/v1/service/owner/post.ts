import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

declare var config: any;
export default class Post implements ApiCriteriaBuilder {

	get headers(): any {
		return {};
	}

	get model(): any {
		return config.FIELDS.SERVICE_OWNER;
	}

	get body(): any {
		return config.service.owner.body;
	}
};
