import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

export default class Patch implements ApiCriteriaBuilder {

	get headers(): any {
		return {};
	}

	get body(): any {
		return {};
	}
};
