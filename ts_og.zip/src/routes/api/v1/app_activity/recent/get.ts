import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

export default class Get implements ApiCriteriaBuilder {

	get headers(): any {
		return {};
	}
	get next(): any {
        return 'recent';
    }

	get body(): any {
		return {};
	}
	get model(): any {
		return 'app_activity';
	}
};
