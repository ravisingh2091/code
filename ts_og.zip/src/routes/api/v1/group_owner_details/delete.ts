import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config: any;
export default class DELETE implements ApiCriteriaBuilder {

};