import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config: any;
export default class PUT implements ApiCriteriaBuilder {

};