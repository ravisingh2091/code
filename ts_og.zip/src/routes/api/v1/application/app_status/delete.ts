import ApiCriteriaBuilder from '../../../../ApiCriteriaBuilder';

declare var config: any;
export default class Delete implements ApiCriteriaBuilder {
  get body(): any {
    return {};
  }

  get next(): any {
    return 'delete_app_status';
  }

  get model(): any {
    return 'application';
  }
}
