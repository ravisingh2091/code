import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

export default class Post implements ApiCriteriaBuilder {
	get body(): any {
		return {};
    }

    get next(): any {
        return 'clone';
    }

    get model(): any {
        return 'application';
    }
};
