import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

export default class Get implements ApiCriteriaBuilder {

	get body(): any {
		return {};
	}
};
