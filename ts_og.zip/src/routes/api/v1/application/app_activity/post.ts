import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

export default class Post implements ApiCriteriaBuilder {
};
