import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

export default class Get implements ApiCriteriaBuilder {
	get body(): any {
		return {};
    }

    get next(): any {
        return 'script';
    }

    get model(): any {
        return 'application';
    }
};
