import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

export default class Delete implements ApiCriteriaBuilder {
};
