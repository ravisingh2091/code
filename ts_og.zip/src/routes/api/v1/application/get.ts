import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

export default class Get implements ApiCriteriaBuilder {
    get next():any{
        return "getApplication"
    }
};
