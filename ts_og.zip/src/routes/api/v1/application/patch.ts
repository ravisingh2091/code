import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config: any;
export default class Patch implements ApiCriteriaBuilder {
	/*get permissionDeniedToUpdate(): any {
		return ["user_id", "status_id", "record_id"];
	}*/
};
