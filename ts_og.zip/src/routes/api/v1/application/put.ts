import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config: any;
export default class Put implements ApiCriteriaBuilder {
	get query(): any {
		return config.application.query;
	}
};
