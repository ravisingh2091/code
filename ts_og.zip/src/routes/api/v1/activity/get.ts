import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

export default class Get implements ApiCriteriaBuilder {

	get headers(): any {
		return {};
	}

	get body(): any {
		return {};
	}
};
