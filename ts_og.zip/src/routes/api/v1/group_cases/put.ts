import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config: any;
export default class PUT implements ApiCriteriaBuilder {
    get body(): any {
        return config.groupcases.put.body;
      }
      get query(): any {
		return config.groupcases.put.query;
	}
};