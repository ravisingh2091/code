import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

declare var config: any;
export default class Patch implements ApiCriteriaBuilder {
	get body(): any {
		return {}
	}

    get next(): any {
        return 'status';
    }

    get model(): any {
        return 'group_cases';
    }
};