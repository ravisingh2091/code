import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config: any;
export default class DELETE implements ApiCriteriaBuilder {
    get body(): any {
        return config.groupcases.delete.body;
      }
      get params(): any {
        return config.groupcases.delete.query;
      }
};