import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

declare var config: any;
export default class Get implements ApiCriteriaBuilder {

	get query(): any {
		return config.owner.citizenship.query
	}
	get model(): any {
		return config.owner.citizenship.model;
	}
	get next(): any {
		return config.owner.citizenship.next;
	}
};
