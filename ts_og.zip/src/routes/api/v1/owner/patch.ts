import ApiCriteriaBuilder from "../../../ApiCriteriaBuilder";

declare var config: any;
export default class Patch implements ApiCriteriaBuilder {
	get params(): any {
		return config.owner.patch.params;
	}

	get permissionDeniedToUpdate(): any {
		return config.MODIFY_NOT_ALLOWED.OWNER;
	}
};
