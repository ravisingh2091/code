import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

export default class Post implements ApiCriteriaBuilder {

	get headers(): any {
		return {};
	}

	get body(): any {
		return {};
	}
};
