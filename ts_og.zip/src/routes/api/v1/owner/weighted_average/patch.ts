import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

export default class Patch implements ApiCriteriaBuilder {
};
