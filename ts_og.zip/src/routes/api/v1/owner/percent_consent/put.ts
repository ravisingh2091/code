import ApiCriteriaBuilder from "../../../../ApiCriteriaBuilder";

export default class Put implements ApiCriteriaBuilder {
	get headers(): any {
		return {};
	}

	get body(): any {
		return {};
	}
};
