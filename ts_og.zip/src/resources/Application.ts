declare var services: any, middleware: any, config: any, _db: any;
import External from "../../src/routes/external";

export default class Application {

	static async getApplication(request, response) {
		//console.log("get method is called in Application resource file --",new Date().getTime());

		if (
			request.query.partial == 'true' &&
			request.query['business'] &&
			(request.query['business']['business_name'] ||
				request.query['business']['pan'] ||
				request.query['business']['entity_name'])
		) {
			let business = [];
			if (request.query['business']['pan']) {
				business.push({
					'business.pan': {
						$regex: new RegExp(request.query['business']['pan'], 'gi'),
					},
				});
				delete request.query['business']['pan'];
			}
			if (request.query['business']['entity_name']) {
				business.push({
					'business.entity_name': {
						$regex: new RegExp(request.query['business']['entity_name'], 'gi'),
					},
				});
				delete request.query['business']['entity_name'];
			}
			if (request.query['business']['business_name']) {
				business.push({
					'business.business_name': {
						$regex: new RegExp(
							request.query['business']['business_name'],
							'gi'
						),
					},
				});
				delete request.query['business']['business_name'];
			}
			request.query.partial_search = business;
		}

		if (
			request.query.partial_group_record_id == 'true' &&
			request.query['group_cases'] &&
			(request.query['group_cases']['group_record_id'])
		) {
			let group_cases_record_arr = [];
			if (request.query['group_cases']['group_record_id']) {
				group_cases_record_arr.push({
					'group_cases.group_record': {
						$regex: new RegExp(request.query['group_cases']['group_record_id'], 'gi'),
					},
				});
				delete request.query['group_cases']['group_record_id'];
			}
			
			request.query.partial_group_record = group_cases_record_arr;
		}
		
		if (request.query['business'] && request.query['business']['already_ppp_loan'] == "true") {
			request.query['business']['already_ppp_loan'] = true
		} else if (request.query['business'] && request.query['business']['already_ppp_loan'] == "false") {
			request.query['business']['already_ppp_loan'] = false
		}
		
		return services.collection.find(request, response);
	}

	static async post(request, response) {
		//console.log("post method is called in Application resource file--",new Date().getTime());

		request.headers[config.FIELDS.X_TOTAL_COUNT] = true;
		request.disable_is_deleted = true;
		//const data = await services.collection.find(request, response);
		// //console.log("data ---------------------",data)
		let next_record_obj: any = { query: { name: "application" }, body: { sequence_value: 1 }, options: { new: true }, model: config.MAP_CONFIG.COUNTER, counter: true }
		next_record_obj = await services.collection.modifyObj(request, next_record_obj)

		var sequenceDocument = await services.collection.getNextRecordId(next_record_obj)
		request.body.record_id = sequenceDocument.sequence_value;
		request.body['last_assigned_to'] = "null";
		let result = await services.collection.insert(request, response);
		var id = result._id.toString(), ctr = 18;
		var counter = parseInt(id.slice(ctr, (ctr += 6)), 16);
		var dt = new Date();
		var date = dt.getDate();
		var month = dt.getMonth() +1;
		counter = +(counter + "" + date + "" + month);
		let updateBody = {};
		updateBody['auto_id'] = counter;
		const updateQuery = {
			[config.FIELDS._ID]: services.collection.convertToObjectId(id)
		};
		let updateObj: any = {
			[config.FIELDS._ID]: services.collection.convertToObjectId(id),
			model: config.MAP_CONFIG.APPLICATION, query: updateQuery, body: updateBody,
			headers: { "x-tenant-id": request.headers['x-tenant-id'] }
		};
		updateObj = await services.collection.modifyObj(request, updateObj)
	    return await services.collection.update(updateObj);
		// let updateobj = {
		// 	model: "appmetrix",
		// 	query: { app_id:String(appData["_id"]) },
		// 	body:{assigned_to:0}
		// };
		
		// updateObj = await services.collection.modifyObj(request,updateobj);
		// await services.collection.findOneAndUpdate(updateObj, {});

		// return appData;

	}

	static isApplicationExist(request, app_id = null, user_id = null) {
		//console.log("isApplicationExist method is called in Application resource file--",new Date().getTime());

		const query = {};
		if (!app_id && !user_id) return [];
		if (!!app_id) query[config.FIELDS._ID] = services.collection.convertToObjectId(app_id) || -1;
		if (!!user_id) query[config.FIELDS.USER_ID] = user_id;
		let modifyObj = {
			model: config.MAP_CONFIG.APPLICATION,
			query: query
		};
		modifyObj = services.collection.modifyObj(request, modifyObj)
		return services.collection.find(modifyObj, {});
	}

	static async patch(request, response) {
		//console.log("patch method is called in Application resource file--",new Date().getTime());

		const obj: any = {}, data = request.body;
		if (request.params._id) obj.app_id = request.params._id;
		if (data.parent_status_id) {
			let modifyObj = {
				model: "application",
				body: { parent_status_id: request.body.parent_status_id },
				query: { _id: request.params._id }
			}
			modifyObj = await services.collection.modifyObj(request, modifyObj)
			return await services.collection.findOneAndUpdate(modifyObj, {})
		}
		if (data.status_id) {
			obj.status_id = data.status_id;
			let modifyObj = {
				model: request.model,
				body: { status_id: request.body.status_id },
				multiple_Status: request.body.isMultipleStatus,
				query: { _id: request.params._id }
			}
			modifyObj = await services.collection.modifyObj(request, modifyObj)
			await this.updateStatus(modifyObj, response);
		}
		if (data.assigned_to) {
			let modifyObj = {
				model: "application",
				body: { last_assigned_to:  data.assigned_to },
				query: { _id: request.params._id }
			}
			modifyObj = await services.collection.modifyObj(request, modifyObj)
			await services.collection.findOneAndUpdate(modifyObj, {})
		}
		if (data.assigned_to) obj.assigned_to = data.assigned_to;
		if (data.backend_user_id) obj.backend_user_id = data.backend_user_id;
		if (data.note) obj.note = data.note;
		if (data.action_from) obj.action_from = data.action_from;
		if (data.is_completed) obj.is_completed = data.is_completed;
		if (data.action) obj.action = data.action;
		if (data.role_id) obj.role_id = data.role_id;
		request.body = obj;
		request.model = config.MAP_CONFIG.APP_ACTIVITY;
		return services.collection.insert(request, response);
	}

	static async clone(request, response) {
		//console.log("clone method is called in Application resource file--",new Date().getTime());

		const { match, application, assignments, old_application, ignore } = request.body;
		const ignoreMap = {};
		if (ignore) {
			// create a map where key is the model name and value if the filter
			ignore.forEach((reject) => {
				ignoreMap[reject.type] = reject;
			});
		}
		//console.log(ignoreMap);
		//console.log(config.FIELD_INVALID_CODE);
		if (!match || (match && !Object.keys(match).length)) {
			return new Error(JSON.stringify({
				...config.getResponse(config.FIELD_INVALID_CODE),
				errors: [middleware.response.getErrorMessage(config.FIELDS.MATCH, config.FIELD_REQUIRED_STATUS)]
			}));
		}

		const paramKey = { [config.FIELDS.APP_ID]: config.FIELDS._ID, [config.FIELDS.RECORD_ID]: config.FIELDS.RECORD_ID };

		const query = {};

		if (match) Object.keys(match).forEach((key) => {
			query[paramKey[key]] = match[key]
			if (key === config.FIELDS.APP_ID) {
				query[paramKey[key]] = services.collection.convertToObjectId(match[key]);
			}
		});

		const app = await services.collection.findOne(request,{ model: config.MAP_CONFIG.APPLICATION, query });

		if (!app) return false;

		// update old application data
		if (old_application) {
			const param = { [config.FIELDS.PRODUCT_TYPE]: config.FIELDS.PRODUCT_TYPE, [config.FIELDS.STATUS_ID]: config.FIELDS.STATUS_ID };
			const updateBody = {};
			Object.keys(old_application).forEach((key) => {
				if (old_application[key]) {
					updateBody[param[key]] = old_application[key]
					app[param[key]] = old_application[key];
				}
			});

			const updateQuery = {
				[config.FIELDS._ID]: app[config.FIELDS._ID]
			};

			let updateObj = { model: config.MAP_CONFIG.APPLICATION, query: updateQuery, body: updateBody }
	
			updateObj = services.collection.modifyObj(request, updateObj);
			await services.collection.update(updateObj);
		}

		const copyApp: any = {
			status_id: app.status_id,
			product_type: app.product_type,
			user_id: app.user_id,
			replicated: app
		};

		if (application) {
			if (application.note) {
				copyApp.note = application.note;
			}

			if (application.status_id) {
				copyApp.status_id = application.status_id;
			}

			if (application.backend_user_id) {
				copyApp.backend_user_id = application.backend_user_id;
			}
		}

		let update_Obj = { model: config.MAP_CONFIG.APPLICATION, data: copyApp };
	
		update_Obj = services.collection.modifyObj(request, update_Obj);
		const savedApp = await services.collection.save(request,update_Obj);		Object.keys(config.MAP_CONFIG).forEach(async (key) => {
			const model = config.MAP_CONFIG[key];
			if (model.trim() != config.MAP_CONFIG.APPLICATION.trim() && model.trim() != config.MAP_CONFIG.APP_ACTIVITY.trim()) {
				let update_Obj = { model, query: { app_id: app._id } }

				update_Obj = services.collection.modifyObj(request, update_Obj);
				await services.collection.findAllAndClone(request,update_Obj, savedApp, ignoreMap[model]);
			}
		});

		if (assignments && assignments.length) {
			assignments.forEach(async (assignData) => {
				const data = {
					...assignData,
					app_id: savedApp._id,
					user_id: savedApp.user_id
				};
				let update_Obj ={ model: config.MOMAP_CONFIGDELS.ASSIGNMENT, data }
	
				update_Obj = services.collection.modifyObj(request, update_Obj);
				await services.collection.save(update_Obj);
			});
		}

		return savedApp;
	}

	static updateStatus(request, response, other: any = {}) {
		const options = { new: true, useFindAndModify: true };
		return this.findOneAndUpdateStatus(request, response, { ...other, db: options });
	}

	static async findOneAndUpdateStatus(request, response, other: any = {}) {
		if (!request.query) request.query = {};
		let options = { upsert: true, new: true };
		if (other.db) {
			options = options = other.db;
			delete other.db;
		}

		request.query.is_deleted = services.collection.ne(true);
		const obj = services.collection.getDbQuery(request, other);
		let isMultipleStatus = request.multiple_Status;
		if (isMultipleStatus) {
			let data = await global[request.headers['x-tenant-id']]["_db"][request.model].findById(obj.query, { status_id: 1 });
			let multiple_status = data.status_id;
			if (Array.isArray(multiple_status)) {
				return global[request.headers['x-tenant-id']]["_db"][request.model].findOneAndUpdate(
					obj.db_query,
					{ $push: obj.data },
					options
				);
			} else {
				let multiple_status_id_arr = [multiple_status, obj.data.status_id];
				obj.data.status_id = multiple_status_id_arr;
				return global[request.headers['x-tenant-id']]["_db"][request.model].findOneAndUpdate(
					obj.db_query,
					{ $set: obj.data },
					options
				);
			}
		} else {
			return global[request.headers['x-tenant-id']]["_db"][request.model].findOneAndUpdate(
				obj.db_query,
				{ $set: obj.data },
				options
			);
		}
	}

	static async filter(request, response) {
		return services.collection.filterApplication(request, response);
	}

	static async delete_app_status(request, response) {
		let delete_status_id = request.body.status_id;
		let application = await services.collection.find(request, response);
		let status_obj = application[0].status_id;
		if (typeof status_obj === "string") {
			status_obj = status_obj.split(" ")
		}
		if (typeof delete_status_id === "string")
			delete_status_id = delete_status_id.split(" ")
		for (let i = 0; i < delete_status_id.length; i++) {
			let index = status_obj.indexOf(delete_status_id[i]);
			status_obj.splice(index, 1);
		}
		request.body.status_id = status_obj;
		delete request.body.isMultipleStatus
		return await services.collection.update(request, response);
	}
	static async script(request, response) {
		let auto_id = request.query.auto_id;
		let recordId = request.query.record_id
		let app_id =  request.query.app_id;
		let update_all = request.query.update_all
		response.send({  
			"status": "success",
			"code": 200
		})

		if(auto_id){
			let updateObj = {
				model: "application",
				query: app_id ? {_id:app_id} : {},
			};

			updateObj = services.collection.modifyObj(request, updateObj);
	
			let appData = await services.collection.find(updateObj, {});
			
			appData.map(async (app) => {
				if(!app['auto_id'] || app_id || update_all){
				var id = app._id.toString(), ctr = 18;
				var counter = parseInt(id.slice(ctr, (ctr += 6)), 16);
				var dt = new Date();
				var date = dt.getDate();
				var month = dt.getMonth() +1;
				counter = +(counter + "" + date + "" + month);				
				let updateObj = {
					model: "application",
					query: { _id:id },
					body: {"auto_id":counter }
				};
				updateObj = services.collection.modifyObj(request, updateObj);
				await services.collection.findOneAndUpdate(updateObj, {})
			}
			})

		}else{
			let updateObj = {
				model: "application",
				query: { 
					"fields":"app_assignment,record_id",
					"expands":"app_assignment"
				},
			};
	
			if(recordId){
				updateObj.query['is_record']="true"
				updateObj.query['record_id']= +recordId - 1
			}
			
			updateObj = services.collection.modifyObj(request, updateObj);
			//console.log({updateObj});
	
			let appData = await services.collection.find(updateObj, {});
			// let count=0;
			appData.map(async (app) => {
			
				if (app.app_assignment.length > 0) {
					
					let lastAssignment = app.app_assignment[app.app_assignment.length - 1];
					let app_id = lastAssignment.app_id
					let last_assigned_to = lastAssignment.assigned_to
					
					let updateObj = {
						model: "application",
						query: { _id:app_id },
						body: {last_assigned_to }
					};
					
					updateObj = services.collection.modifyObj(request, updateObj);
					await services.collection.findOneAndUpdate(updateObj, {})
				}else{
					let updateObj = {
						model: "application",
						query: { _id:app._id },
						body: { last_assigned_to:"null" }
					};
	
					updateObj = services.collection.modifyObj(request, updateObj);
					await services.collection.findOneAndUpdate(updateObj, {})
				}
			})
			
		}
		
	}
}
