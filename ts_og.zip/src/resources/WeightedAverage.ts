declare var services: any, middleware: any, config: any;
export default class WeightedAverage {

	static post(request, response) {
		console.log("post method is called in WeightedAverage resource file--",new Date().getTime());

		let weighted_average = 0, count = 0;
		const owners = request.owners_arr;
		for (let i = 0; i < owners.length; ++i) {
			if(owners[i].owner_type === config.OWNER.INDIVIDUAL && owners[i].consent !== config.FIELDS.CONSENT) return middleware.response.throwError("CONSENT_PENDING", config.getApiErrorResponse("CONSENT_PENDING"));
			if(owners[i].owner_type === config.OWNER.INDIVIDUAL && request.body.owners[i].score !== 0) {
				weighted_average = weighted_average + request.body.owners[i].score;
				count++;
			}
		}
		request.model = config.MAP_CONFIG.WEIGHTED_AVERAGE;
		request.body = {
			app_id: owners[owners.length - 1].app_id,
			weighted_average: weighted_average / (count ? count : 1)
		};
		return services.collection.insert(request, response);
	}
}
