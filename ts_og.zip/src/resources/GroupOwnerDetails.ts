export default class GroupOwnerDetails {

}
