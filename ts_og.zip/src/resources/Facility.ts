declare var services: any, config: any;
export default class Facility {
  static async post(request, response) {
    try {
      //console.log("post method is called in facility resource file--",new Date().getTime());
      
      let product = request.body.products;
      let result = [];
      for (product of product) {
        let sub_products = [];
        let sub_product = product['sub_product'];
        delete product['sub_product'];
        request.body = product;
        request.model = config.MAP_CONFIG.FACILITY;
        let data_product = await services.collection.insert(request, response);
        data_product = data_product.toJSON();
        let product_id = String(data_product['_id']);
        for (sub_product of sub_product) {
          sub_product['product_id'] = product_id;
          request.model = "sub_facility";
          request.body = sub_product;
          let sub_product_data = await services.collection.insert(
            request,
            response
          );
          sub_products.push(sub_product_data);
        }
        data_product['sub_product'] = sub_products;
        result.push(data_product);
      }
      return result;
    } catch (error) {
      //console.log(error);
    }
  }

  static async put(request, response) {
    try {
      //console.log("put method is called in facility resource file--",new Date().getTime());
      let { products } = request.body;
      let result = [];
      for (let product of products) {
        let _id = product['_id'];
        let app_id = product['app_id'];
        let sub_products = [];
        let obj = {};
        obj['product_id'] = String(_id);
        obj['app_id'] = String(app_id);
        let sub_product = product['sub_product'];
        if (_id) {
          delete product['sub_product'];
          delete product['_id'];
          delete product['app_id'];
          request.body = product;
          request.params = { _id: String(_id) };
          let { decision } = product;
          request.model = config.MAP_CONFIG.FACILITY;
          let data_product = await services.collection.update(
            request,
            response
          );
          data_product = data_product.toJSON();
          if (sub_product && sub_product.length > 0) {
            for (sub_product of sub_product) {
              request.body = sub_product;
              let _id = sub_product['_id'];
              let sub_product_data;
              if (_id) {
                request.params = { _id: String(_id) };
                request.body = sub_product;
                request.model = "sub_facility";
                sub_product_data = await services.collection.update(
                  request,
                  response
                );
              } else {
                sub_product = { ...sub_product, ...obj };
                request.body = sub_product;
                request.model = "sub_facility";
                sub_product_data = await services.collection.insert(
                  request,
                  response
                );
              }
              sub_products.push(sub_product_data);
            }
            data_product['sub_product'] = sub_products;
          }
          if (decision) {
            request.model = "sub_facility";
            request.params = { product_id: String(_id) };
            request.body = { decision: decision };
            await services.collection.updateMany(request, response);
          } else {
            request.model = "sub_facility"
            request.params = { product_id: String(_id) };
            let sub_product = await services.collection.find(request, response);
            let decision;
            for (let i = 0; i < sub_product.length; i++) {
              let sub_product_decision = sub_product[i]['decision'];
              if (!decision) {
                decision = sub_product_decision;
              } else if (decision != sub_product_decision) {
                break;
              } else {
                if (i === sub_product.length - 1) {
                  request.body = { decision: sub_product_decision };
                  request.params = { _id: String(_id) };
                  request.model = config.MAP_CONFIG.FACILITY;
                  await services.collection.update(request, response);
                }
              }
            }
          }
          result.push(data_product);
        }
      }
      return result;
    } catch (error) {
      //console.log(error);
    }
  }

  static async delete(request, response) {
    try {
      //console.log("delete method is called in facility resource file--",new Date().getTime());

      let products = request.body.products;
      for (let product of products) {
        let _id = product['id'];
        if (_id) {
          request.params = { _id:  services.collection.convertToObjectId(_id) };
          request.model = config.MAP_CONFIG.FACILITY;
          let data = await services.collection.delete(request, response);
          request.model = "sub_facility"
          request.params = { product_id: String(_id) };
          await services.collection.deleteMany(request, response);
        } else {
          let sub_product = product['sub_product'];
          request.model = "sub_facility";
          for (let i = 0; i < sub_product.length; i++) {
            request.params = { _id: sub_product[i] };
            await services.collection.delete(request, response);
          }
        }
      }
      return products;
    } catch (error) {
      //console.log(error);
    }
  }

  static async get(request, response) {
    //console.log("get method is called in facility resource file--",new Date().getTime());

    request.params['facility_flag'] = true;
    return await services.collection.find(request, response);
  }
}
