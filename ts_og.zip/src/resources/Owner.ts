declare var services: any, config: any, middleware: any;
import owner_Validation from "../middleware/validations/Owner";
import { request } from "express";
export default class Owner {
	static async get(request, response) {
    //console.log("get method is called in Owner resource file--",new Date().getTime());

		if (Boolean(request.query.tree) === true) {
			let resp = await services.collection.find({
				model: request.model,
				query: { app_id: request.query.app_id }
			}, response);
			return services.util_services.listToTree(resp, config.FIELDS.OWNERS);
		} else return services.collection.find(request, response);
	}
	static async post(request, response,flag=false) {
    if (!flag) {
		let obj = {
			query: {
				_id: services.collection.convertToObjectId(request.body.app_id),
				user_id: request.body.user_id
			},
			model: config.MAP_CONFIG.APPLICATION
    };
    obj = await services.collection.modifyObj(request,obj)
		const is_app_exist = await services.collection.find(obj, response);
		if (!is_app_exist || !is_app_exist.length) return middleware.response.throwErrorMessage(config.API_RESPONSE.BAD_REQUEST, middleware.response.getErrorMessage(null, config.API_RESPONSE.NOT_FOUND));
   let owners_delete_obj = {
    model: request.model,
    query: { app_id: request.body.app_id }
  }
  owners_delete_obj = await services.collection.modifyObj(request,owners_delete_obj)
    const deleted_owners = await services.collection.deleteMany(owners_delete_obj, {});
  }
		return await Owner.postUtil(request, response, request.body.owners,{
			app_id: request.body[config.FIELDS.APP_ID],
			user_id: request.body[config.FIELDS.USER_ID],
		}, 0, "0", request.body.owners.length, 100 / request.body.owners.length);
	}

	static async postUtil(request, response, data, other, level, parent, child: Number, prev_ownership_percent: Number) {
		let ar: any = [], resp;
		if (data === undefined) return [];
		try {
			for (let i = 0; i < data.length; ++i) {
				let obj = services.util_services.removeUnexpectedKeys(data[i], [config.FIELDS.OWNERS]);
				delete obj[config.FIELDS._ID];
				obj = {
					...other, ...obj,
					parent_id: parent,
					level: level,
					actual_percent: (parent === "0") ? obj.ownership_percent : +(((+prev_ownership_percent * +obj.ownership_percent) / 100 + 0.0001).toFixed(2)),
					other: {
						child_count: child,
						ancestor_1_ownership_percent: +prev_ownership_percent,
					},
				};
				resp = await services.collection[config.MONGO_DOC[config.METHOD.POST]](request, response, { data: obj });
				ar.push(resp);
				if (!!data[i].owners) {
					const res = await Owner.postUtil(request, response, data[i].owners, other, level + 1, resp["id"], data[i].owners.length, obj.actual_percent);
					if (res instanceof Error) return res;
					ar.push(...res);
				}
			}
			return ar;
		} catch (exception) {
			const exception_obj = middleware.response.sendExceptionResponse(exception, {});
			const obj:any = {
				code: config.FIELD_INVALID_CODE,
				status: config.FIELD_INVALID_STATUS,
			};
			obj.errors = exception_obj.errors || exception.message;
			return new Error(JSON.stringify(obj));
		}
	}

	static async citizenship(request, response) {
		delete request.query[config.FIELDS.CONSENT + "!"];
		request.query[config.OWNER.CITIZEN] = config.FIELDS.YES;
		request.query.sum = config.OWNER.ACTUAL_PERCENT;
		return await services.collection.find(request, response);
	}

  static async patch(request, response) {
    //console.log("patch method is called in Owner resource file--",new Date().getTime());
    const data = request.body,
    resp = [];
    const app_id = request.params['app_id'];
    let Owner_ids = [];
  
      if (request.body[config.FIELDS.OWNERS]) {
        for (let i = 0; i < data[config.FIELDS.OWNERS].length; ++i) {
          data[config.FIELDS.OWNERS];
          resp.push(
            await Owner.updateOwnershipPercent(request,
              { _id: data[config.FIELDS.OWNERS][i][config.FIELDS.OWNER_ID] },
              data[config.FIELDS.OWNERS][i],
              data['orch_url'],
              app_id,
              data['user_id']
            )
          );
        }
        
        for(let i=0;i<resp.length;i++){
          if(resp[i])
          Owner_ids.push(resp[i]['_id'])
        }
        let owner_list = await services.collection.find(request, response);
        for(let i=0;i<owner_list.length;i++){
          let flag = false;
          for(let j=0;j<Owner_ids.length;j++){
      
           if(String(Owner_ids[j]) == String(owner_list[i]["_id"])){
              flag = true;
              break;
            }
          }
          if(!flag){
            let obj = {
              model: request.model,
              query: { _id: services.collection.convertToObjectId(owner_list[i]["_id"])}
            }
            obj = await services.collection.modifyObj(request,obj);
            await services.collection.deleteMany(obj, {});
          }
        }
      }else if(request.body['is_deleted'] == false){ 
        request.query = {_id:request.body['owner_id']};
        request.params = {};
        delete request.body['owner_id'];
        return services.collection.update(request, response);
      } else {
        // request.body = {};  
        request.query = {_id:request.body['owner_id']};
        request.params = {};
        delete request.body['owner_id'];      
        request.body.consent = config.FIELDS.RECEIVED;
        return services.collection.update(request, response);
    }
      return resp;
    }
  


    static async updateOwnershipPercent(request,query, obj, orch, app, user) {
      let model = "owner";
      let modifyObj =  { model: model, query: query };
      modifyObj = await services.collection.modifyObj(request,modifyObj)
      let owner = await services.collection.find(
        modifyObj,
          {}
        )
      let  actual_percent = 1;
      owner = !!owner && owner.length ? owner[0] : 1;
      if (
        !!owner[config.FIELDS.PARENT_ID] &&
        owner[config.FIELDS.PARENT_ID] !== 0 &&
        owner[config.FIELDS.ACTUAL_PERCENT] !== undefined
      )
        actual_percent = +owner[config.FIELDS.ACTUAL_PERCENT];
      let updated_owner = {};
      if (obj[config.FIELDS.UPDATED_PERCENT] !== undefined && actual_percent) {
        const updated_ownership_percent =
          obj[config.FIELDS.UPDATED_PERCENT] / actual_percent;
        updated_owner[
          config.FIELDS.OWNERSHIP_PERCENT
        ] = +updated_ownership_percent.toFixed(2);
        updated_owner[config.FIELDS.ACTUAL_PERCENT] =
          obj[config.FIELDS.UPDATED_PERCENT];
      }
  
      delete obj.owner_id;
      let user_id = user;
      let app_id = app;
      let orch_url = orch;
      if (obj) {
        updated_owner = {
          ...obj,
          ...updated_owner,
        };
    }
      if (owner && Object.keys(owner).length > 0) {        
        let modifyObj =   {
          query: query,
          model: model,
          body: updated_owner,
        }
        modifyObj =  await services.collection.modifyObj(request,modifyObj)
        return services.collection.update(
          modifyObj,
          {}
        );
      } else {
        let obj = {};
        obj['owners'] = [updated_owner];
        obj['app_id'] = app_id;
        obj['user_id'] = user_id;
        obj['orch_url'] = orch_url;
        request.body = obj;
        request['model'] = model;
        let result = await owner_Validation.post(request, {}, true);
        return result[0];
      }
    }
  
}
