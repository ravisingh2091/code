import External from "../routes/external";

declare var middleware: any, services: any, _db: any, config: any;
export default class Hash {

	static async get(request, response) {
		//console.log("get method is called in Hash resource file--",new Date().getTime());

		request.params = { encrypted_hash: request.params.hash };
		const hash = await services.collection.find(request, response, { limit: 1 });
		if (!hash.length) return middleware.response.throwErrorMessage(config.API_RESPONSE.NOT_FOUND, middleware.response.getErrorMessage(null, "NOT_FOUND"));

		const current_date = new Date();
		current_date.setHours(current_date.getHours() - +(config.MAX_HASH_EXPIRY_HOURS_LIMIT || config.Default.MAX_HASH_EXPIRY_HOURS_LIMIT ));
		if(hash[0].created_at < current_date) return middleware.response.throwErrorMessage("TOKEN_EXPIRED", middleware.response.getErrorMessage(null, "TOKEN_EXPIRED"));

		request.model = config.MAP_CONFIG.OWNER
		delete request.params.hash;
		request.query._id = hash[0].owner_id;

		if (!request.query._id && hash[0].app_id) {
			request.query._id = hash[0].app_id;
			request.model = config.MAP_CONFIG.APPLICATION;
		}
		let updateObj = {model: request.model, query: {_id: request.query._id}};
		updateObj = await services.collection.modifyObj(request, updateObj)

		let app_data = await services.collection.findOne(updateObj, response);
		if(app_data) app_data = [app_data];
		
		if (!app_data.length) return middleware.response.throwErrorMessage(config.API_RESPONSE.BAD_REQUEST, config.getApiErrorResponse(config.API_RESPONSE.NOT_FOUND));
		if(!!request.headers[config.FIELDS.IS_CONSENT_RECEIVED] === true && app_data[0].consent === config.OWNER.RECEIVED)
			return middleware.response.throwErrorMessage("TOKEN_EXPIRED", middleware.response.getErrorMessage(null, "TOKEN_EXPIRED"));

		if (!!request.headers[config.FIELDS.VERIFY_HASH] === true) {
			request.model = config.MAP_CONFIG.HASH;
			const obj = {
				query: { owner_id: app_data[0]._id },
				data: { hash_verified: true }
			};
			const updated_owner = await services.collection.update(request, response, obj);
			app_data[0].hash_verified = updated_owner.hash_verified;
			let user = await new External().get({}, config.USER_URL.USERS + "/" + app_data[0].user_id);
			if (user.code === 200) {
				user = user.data;
				app_data[0].applicant_name = {
					first: user.first_name,
					last: user.last_name
				};
				app_data[0].email_address = user.email_address;
			}
			return user;
		}
		return app_data;
	}

	static async put(request, response) {
		//console.log("put method is called in Hash resource file--",new Date().getTime());

		const hash = services.security.randomHex(), current_date = new Date();
		current_date.setDate(current_date.getDate() - +(config.MAX_HASH_DAYS_LIMIT || config.Default.MAX_HASH_DAYS_LIMIT ));
		let updateObj ={
			model: request.model,
			query: {
				owner_id: request.params._id,
				"created_at>": Math.floor(+current_date / 1000)
			}
		}
		updateObj = await services.collection.modifyObj(request, updateObj)
		const resp = await services.collection.find(updateObj, response);
		if (resp.length >= +config.HASH_LIMIT) return new Error(JSON.stringify({
			...config.getApiResponse(config.API_RESPONSE.TOO_MANY_REQUEST),
			errors: [middleware.response.getErrorMessage(null, config.API_RESPONSE.TOO_MANY_REQUEST)]
		}));
		request.body = {
			owner_id: request.params._id,
			hash: hash,
			encrypted_hash: services.security.encrypt(hash).encryptedData,
		};
		return services.collection.insert(request, response);
	}

	static async post(request, response) {
		//console.log("post method is called in Hash resource file--",new Date().getTime());

		const hash = services.security.randomHex(), current_date = new Date();
		current_date.setDate(current_date.getDate() - +(config.MAX_HASH_DAYS_LIMIT || config.Default.MAX_HASH_DAYS_LIMIT ));
		let updateObj = {
			model: request.model,
			query: {...request.body}
		}
		updateObj = await services.collection.modifyObj(request, updateObj)

		// Expire previous hash
		await services.collection.delete(updateObj,{});
		request.body = {
			...request.body,
			hash: hash,
			encrypted_hash: services.security.encrypt(hash).encryptedData,
		};
		return services.collection.insert(request, response);
	}

	static async _delete(request, response) { 
		//console.log("delete method is called in Hash resource file--",new Date().getTime());

		request.model = config.MAP_CONFIG.OWNER
		request.query = {
			app_id: request.query.app_id,
			owner_type: config.OWNER.INDIVIDUAL,
		};
		request.query["hash_for!"] = config.OWNER.RECEIVED;

		let owner = await services.collection.find(request, response);
		if (owner.length) return middleware.response.throwErrorMessage("CONSENT_PENDING", config.getApiErrorResponse("CONSENT_PENDING"));

		request.query = {
			app_id: request.query.app_id,
			hash_for: request.query.app_id
		};
		return await services.collection.delete(request, response);
	}
	static async expire(request, response) {
		//console.log("expire method is called in Hash resource file--",new Date().getTime());

		request.query = { encrypted_hash: request.body.hash,hash_for:request.body.hash_for };
		return await services.collection.delete(request, response);
	  }
}
