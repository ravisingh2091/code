declare var services: any, config;
export default class Collateral {
	static async post(request, response) {
		console.log("post method is called in Collateral resource file--",new Date().getTime())
		return this.saveUpdate(request, response);
	}
	static async patch(request, response) {
		console.log("patch method is called in Collateral resource file--",new Date().getTime())

		return this.saveUpdate(request, response);
	}

	static async saveUpdate(request, response) {
		try {
			console.log("save update method is called ---------------------")
			let obj = {
				model: request.model,
				query: { app_id: request.body.app_id, user_id: request.body.user_id },
				headers: {'x-tenant-id' : request.headers['x-tenant-id']}
			}
			console.log("save update method is called -----------------------------",obj);
			const _deleted = await services.collection.deleteMany(obj, {});
			const resp = [], collateral = request.body.collaterals;
			for (let i = 0; i < collateral.length; ++i) {
				const keys = Object.keys(collateral[i]), _id = collateral[i][config.FIELDS._ID];
				if (!keys.length) continue;
				delete collateral[i][config.FIELDS._ID];
				const data = {
					app_id: request.body.app_id,
					user_id: request.body.user_id,
					...collateral[i]
				};
				let request_obj = { model: request.model,headers: {'x-tenant-id' : request.headers['x-tenant-id']} }, callback = config.FIELDS.INSERT;
				console.log("request obj --------------------------",request_obj)
				if (!!_id) {
					request_obj[config.FIELDS.QUERY] = {};
					callback = config.FIELDS.UPDATE;
					request_obj[config.FIELDS.QUERY][config.FIELDS._ID] = services.collection.convertToObjectId(_id) || -1;
				}
				resp.push(await services.collection[callback](request_obj, response, { data: data }));
			}
			return resp;
		} catch (error) {
			console.log("erro----------------------",error)
		}
	}
};
