declare var services: any, middleware: any, config: any, _db: any;
import ApplicationResource from '../resources/Application';

export default class GroupCases {
  // @route    PATCH api/v1/group_cases/status/_id
  // @desc     Update Status of group along with internal application enclosed with group
  static async status(request, response) {
    //console.log("status method is called in GroupCases resource file--",new Date().getTime());

    let groupCaseData = await services.collection.update(request, response);
    let app_id = groupCaseData.app_id;
    let data = request.body;
    for (let i = 0; i < app_id.length; i++) {
      const obj: any = {};
      if (app_id[i]) obj['app_id'] = app_id[i];
      if (request.body.status_id) obj['status_id'] = request.body.status_id;


      let updatedObj  = {
          model: config.MAP_CONFIG.APPLICATION,
          body: { status_id: data.status_id },
          multiple_Status: false,
          query: { _id: app_id[i] },
        }
      updatedObj =  await services.collection.modifyObj(request, updatedObj)
      await ApplicationResource.updateStatus(
        updatedObj,
        response
      );

      if (data.assigned_to) obj.assigned_to = data.assigned_to;
      if (data.backend_user_id) obj.backend_user_id = data.backend_user_id;
      if (data.note) obj.note = data.note;
      if (data.action_from) obj.action_from = data.action_from;
      if (data.is_completed) obj.is_completed = data.is_completed;
      if (data.action) obj.action = data.action;
      if (data.role_id) obj.role_id = data.role_id;
      request.body = obj;
      request.model = config.MAP_CONFIG.APP_ACTIVITY;
      await services.collection.insert(request, response);
    }

    return groupCaseData;
  }
  // @route    PATCH api/v1/group_cases/assign_backened_user/_id
  // @desc     Assign backend user id to the group along with enclosed internal applications
  static async assign_backened_user(request, response) {
    //console.log("assign_backened_user method is called in GroupCases resource file--",new Date().getTime());

    let app_assignment_flag = request.body.app_assignment_flag;
    if (!app_assignment_flag) app_assignment_flag = true;

    let groupCaseData = await services.collection.find(request, response);
    let multiple_app = groupCaseData[0].app_id;
    let group_id = String(groupCaseData[0]._id);
    for (let i = 0; i < multiple_app.length; i++) {
      request.body.app_id = String(multiple_app[i]);
      request.body.group_id = group_id;
      request.model = config.MAP_CONFIG.GROUP_ASSIGNMENT;
      await services.collection.insert(request, response);
      if (app_assignment_flag) {
        request.model = config.MAP_CONFIG.ASSIGNMENT;
        delete request.body.group_id;
        await services.collection.insert(request, response);
      }
    }
    return groupCaseData;
  }
  // @route    POST api/v1/group_cases
  // @desc     Multiple application creation based on number of entities to be mapped with a Group
  static async post(request, response) {
    //console.log("post method is called in GroupCases resource file--",new Date().getTime());

    let obj: any = {};
    let updatedObj  = {
      query: { name: 'group_cases' },
      body: { sequence_value: 1 },
      options: { new: true },
      model: config.MAP_CONFIG.COUNTER,
      counter: true,
    }
  updatedObj =  await services.collection.modifyObj(request, updatedObj)
    var sequenceDocument = await services.collection.getNextRecordId(updatedObj);
    request.body.group_record_id = sequenceDocument.sequence_value;
    let groupData = await services.collection.insert(request, response);
    obj['group_id'] = String(groupData._id);
    request.body = obj;
    request.query['_id'] = groupData.app_id.toString();
    request.model = config.MAP_CONFIG.APPLICATION;
    await services.collection.updateMany(request, response);
    return groupData;
  }
  // @route    GET api/v1/group_cases
  // @desc     entity specific data entities for linked applications of a group.
  static async get(request, response) {
    //console.log("get method is called in GroupCases resource file --",new Date().getTime());

    let group_id = request.query.group_id;
    delete request.query.group_id;
    let group_name = request.query.group_name;
    delete request.query.group_name;
    let group_record_id = request.query.group_record_id;
    delete request.query.group_record_id;
    let partial_record =  request.query.partial_record
    delete request.query.partial_record;

    let obj = {
      query: {},
      model: config.MAP_CONFIG.GROUP_CASES,
    };
    if (group_id)
      obj.query['_id'] = services.collection.convertToObjectId(group_id);
    if (group_name) obj.query['group_name'] = group_name;
    if (group_record_id) obj.query['group_record_id'] = group_record_id;
    if(partial_record) obj.query['partial_record'] = partial_record

    obj =  await services.collection.modifyObj(request, obj)


    let groupData = await services.collection.find(obj, response);

    for (let i = 0; i < groupData.length; i++) {
      request.model = config.MAP_CONFIG.APPLICATION;
      request.query['group_id'] = String(groupData[i]._id);
      let app_data = await services.collection.find(request, response);
      groupData[i]['app_data'] = app_data;
    }
    return groupData;
  }

  // @route    DELETE api/v1/group_cases/{group_id}
  // @desc    delete applications from group
  static async delete(request, response) {
    //console.log("delete method is called in GroupCases resource file --",new Date().getTime());

    let app_id = request.body.app_id;
    const groupData = await services.collection.find(request, response);
    for (let i = 0; i < app_id.length; i++) {
      let index = groupData[0].app_id.indexOf(app_id[0]);
      groupData[0].app_id.splice(index, 1);
    }
    request.body.app_id = groupData[0].app_id;
    let updated_group = await services.collection.update(request, response);
    request.model = config.MAP_CONFIG.APPLICATION;
    for (let i = 0; i < app_id.length; i++) {
      delete request.params;
      request.params = { _id: app_id[i] };
      await services.collection.delete(request, response);
    }

    return updated_group;
  }

  // @route    PUT api/v1/group_cases/{group_id}
  // @desc     add applications in group
  static async put(request, response) {
    //console.log("put method is called in GroupCases resource file--",new Date().getTime());

    const config = services.util_services.getRequestFields(request);
    const groupData = await services.collection.find(request, response);
    let group_app_id = groupData[0].app_id;
    let app_id = config.data.app_id;
    for (let i = 0; i < app_id.length; i++) {
      let index = group_app_id.indexOf(app_id[i]);
      if (index === -1) {
        group_app_id.push(app_id[i]);
      }
    }
    request.body.app_id = group_app_id;
    return await services.collection.update(request, response);
  }
}
