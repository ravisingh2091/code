declare var services: any, config: any;
export default class Business {
	static async post(request, response) {
		try {
			//console.log("post method is called in Business resource file--",new Date().getTime());
			
			let data = request.body;
			const address: any[] = ["line_one", "line_two", "city", "postal_code", "province", "country", "civic_number"];
			if (data.business_address_same_as_registered === config.FIELDS.YES) data = { ...data, ...Business.getRelativeAddress(address, data, config.FIELDS.BUSINESS_ADDRESS + "_") };
			if (data.mail_address_same_as_registered === config.FIELDS.YES) data = { ...data, ...Business.getRelativeAddress(address, data, config.FIELDS.MAIL_ADDRESS) };
			if (data.trade_name_same_as_legal === config.FIELDS.YES) data.trade_name = data.business_name;
			return await services.collection[config.MONGO_DOC[config.METHOD.POST]](request, response);
		} catch (exception) {
			return new Error(JSON.stringify({
				errors: [{
					message: exception.message
				}]
			}));
		}
	}
	static getRelativeAddress(address, data, key, origin: String = "company_") {
		const resp = {};
		for (let i = 0; i < address.length; ++i) resp[key + address[i]] = data[origin + "address_" +  address[i]];
		return resp;
	}
	static async patch(request, response) {
		try {
			//console.log("patch method is called in Business resource file--",new Date().getTime());
			let obj = request.body;
			var nested:any;
			if(obj){
			 nested = Object.keys(obj).filter(function(key) {
				 if(obj[key] && typeof obj[key] === 'object'&& !Array.isArray(obj[key]) ){
					 return key;
				 }
				 return false
			});
			}
			let result =  await services.collection[config.MONGO_DOC[config.METHOD.GET]](request, response);
			if(nested && nested.length>0){
				for(let i=0;i<nested.length;i++){
					let updated_obj = result[0][nested[i]];
					let keys =  Object.keys(request.body[nested[i]]);
					if(typeof updated_obj == "string" || !updated_obj)
					updated_obj = {};

					for(let j=0;j<keys.length;j++){
							updated_obj[keys[j]] = request.body[nested[i]][keys[j]]
					}
					request.body[nested[i]] = updated_obj
				}
			}
			return await services.collection.update(request, response);
		} catch (exception) {
			return new Error(JSON.stringify({
				errors: [{
					message: exception.message
				}]
			}));
		}
	}
}
