import External from "../routes/external";

declare var services: any, middleware: any, config: any;
export default class AppAssignment {
	static async get(request, response) {
		//console.log("get method is called in App Assignment resource file--",new Date().getTime());
		
		let user_ids;
		if (!!request.query.name) {
			user_ids = await new External().get({
				query: { name: request.query.name }
			}, config.USER_URL.USERS);
			user_ids = services.util_services.getKeyValues(user_ids, config.FIELDS._ID);
			if (!user_ids.length) return [];
			delete request.query.name;
		}
		return services.collection.find(request, response);
	}
	static async delete(request, response) {
		//console.log("delete method is called in App Assignment resource file--",new Date().getTime());

		return services.collection.delete(request, response);
	}

	static async post(request, response) {
		//console.log("post method is called in App Assignment resource file--",new Date().getTime());

			request.model = "assignment"
			let result = await services.collection.insert(request,response);
			let assigned_to = request.body.assigned_to;
			let updateObj = {
                model: "application",
				query: { _id:request.body['app_id'] },
				body:{last_assigned_to:assigned_to}
			};
			
			updateObj = await services.collection.modifyObj(request,updateObj);
			await services.collection.findOneAndUpdate(updateObj, {});

			return result;
		}

}
