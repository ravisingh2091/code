import External from "../routes/external";

declare var services: any, middleware: any, config: any;
export default class AppActivity {
	static async recent(request, response) {
		//console.log("recent method is called in App activity resource file--",new Date().getTime());
		
		let assignedApplications=await services.collection.find({ 
			model: config.MAP_CONFIG.ASSIGNMENT, 
			query:{assigned_to:request.params._id},
			groupBy:{
				_id: "$assigned_to"
				  , applications: { $push: "$app_id" }
			  }
		});
		if(assignedApplications.length>0){
        return await services.collection.find({ 
			model: config.MAP_CONFIG.APP_ACTIVITY, 
			query:{
				app_id: { $in: assignedApplications[0].applications },
				limit:request.query.limit,
				child_ref:"business_info,application"
			}
		});
	}
	else{
		return assignedApplications;
	}
	}

}
