declare var services: any, config: any;
export default class Owner {
	static async patch(request, response) {
        console.log("patch request is called -------------------------");
		return await services.collection.findOneAndUpdate(request, response,{deleted:false});
    }
}
