declare var services: any, config: any;
export default class Business {
	static async post(request, response) {
		return;
	}

	static async patch(request, response) {
		return await services.collection.findOneAndUpdate(request, response,{deleted:false});
	}
}
