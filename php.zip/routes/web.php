<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});


$router->group(['prefix'=>'api/v1'], function () use ($router) {
    $router->group(['prefix'=>'applications'], function () use ($router) {
        /** Application Routes: Start */
        $router->post('/', ['uses'=>'v1\ApplicationController@post','as'=>'create_application']);
        $router->get('/', ['uses'=>'v1\ApplicationController@get','as'=>'get_application']);
        $router->get('/app_status/{id}', ['uses'=>'v1\ApplicationController@getAppStatus','as'=>'get_app_status']);
        $router->put('/{id}', ['uses'=>'v1\ApplicationController@put','as'=>'update_application']);
        $router->delete('/{id}', ['uses'=>'v1\ApplicationController@softDelete','as'=>'soft_delete_application']);
        $router->put('/app_status/{id}', ['uses'=>'v1\ApplicationController@updateAppStatus','as'=>'update_app_status']);
        $router->get('/all', ['uses'=>'v1\ApplicationController@getBatch','as'=>'get_applications']);
        $router->post('/all', ['uses'=>'v1\ApplicationController@getBatch','as'=>'get_applications']);
        $router->get('/app_count', ['uses'=>'v1\ApplicationController@getAppCount','as'=>'get_app_count']);
        $router->get('/app_activity/{app_id}', ['uses'=>'v1\ApplicationController@getAppActivity','as'=>'get_app_activity']);
        $router->put('/app_activity/{id}', ['uses'=>'v1\AppActivityController@updateAppActivity','as'=>'update_app_activity']);
        $router->post('/clone', ['uses'=>'v1\ApplicationController@clone','as'=>'clone_application']);
        /** Application Routes: End */
    });
    /** Business Routes: Start */
    $router->group(['prefix'=>'business'], function () use ($router) {
        //@todo check businessStructure id in redish for master data and if not found make http request
        //@todo verify user_id from user service
        $router->post('/', ['uses'=>'v1\BusinessController@post','as'=>'save_business_info', 'middleware'=>['requestMiddleware']]);
        $router->put('/{id}', ['uses'=>'v1\BusinessController@put','as'=>'update_business_info', 'middleware'=>['requestMiddleware']]);
        $router->get('/', ['uses'=>'v1\BusinessController@get','as'=>'get_business_by_app_id']);
        $router->get('/{business_id}', ['uses'=>'v1\BusinessController@getByBusinessId','as'=>'get_business_by_business_id']);
    });
    /** Business Routes: End */
    
    /**Owners routes :start*/
    $router->group(['prefix'=>'owners'], function () use ($router) {
        $router->post('/', ['uses'=>'v1\OwnersController@postBatch','as'=>'save_owners_details','middleware'=>['requestMiddleware']]);
        $router->get('/',['uses'=>'v1\OwnersController@getAll','as'=>'get_owner']);
        $router->get('/all',['uses'=>'v1\OwnersController@getAllOwners','as'=>'get_all_owners']);
        $router->get('/citizenship',['uses'=>'v1\OwnersController@getCitizenshipPercentage','as'=>'get_citizenship_percentage']);
        $router->get('/individual_percent',['uses'=>'v1\OwnersController@getIndividualPercentage','as'=>'get_individual_percentage']);
        $router->get('/weighted_average',['uses'=>'v1\OwnersController@getSavedWeightedAverage','as'=>'get_saved_weighted_average']);
        $router->post('/weighted_average',['uses'=>'v1\OwnersController@getWeightedAverage','as'=>'get_weighted_average']);
        $router->put('/',['uses'=>'v1\OwnersController@updateBatch','as'=>'update_owners']);
        $router->get('/verify/{hash}', ['uses'=>'v1\OwnersController@verifyOwner', 'as'=>'verify_owner]']);
        $router->get('/verify_hash/{hash}', ['uses'=>'v1\OwnersController@verifyHash', 'as'=>'verify_hash]']);
        $router->put('/hash/{owner_id}',['uses'=>'v1\OwnersController@updateAndGetOwnerHash','as'=>'get_new_owner_hash_by_owner_id']);
        $router->put('/new_hash/{owner_id}',['uses'=>'v1\OwnersController@updateAndGetNewHash','as'=>'get_new_owner_hash_by_owner_id']);
        $router->delete('/hash/{app_id}',['uses'=>'v1\OwnersController@deleteOwnerHash','as'=>'delete_owner_hash_at_app_submit']);
        $router->post('/delete_hash',['uses'=>'v1\OwnersController@deleteHash','as'=>'delete_hash']);
        $router->put('/percent_consent',['uses'=>'v1\OwnersController@getUpdateOwnerPercentHash','as'=>'owner_percent_update_consent_']);
        $router->put('/percent_consent/{owner_id}',['uses'=>'v1\OwnersController@updateOwnerPercentConsent','as'=>'update_percent_consent']);
        $router->put('/owner_percent',['uses'=>'v1\OwnersController@updateOwnerPercent','as'=>'update_owner_percent']);
        $router->put('/{id}',['uses'=>'v1\OwnersController@put','as'=>'owner_consent_update']);
        $router->delete('/{id}',['uses'=>'v1\OwnersController@delete','as'=>'delete_owner_by_id']);
        $router->get('/{id}',['uses'=>'v1\OwnersController@getOwner','as'=>'get_a_owner']);
    });    
    /**Owners routes :end*/

    $router->group(['prefix'=>'service'], function () use ($router) {
        $router->post('/business', ['uses'=>'v1\BusinessController@saveReferences','as'=>'save_business_ids']);
        $router->get('/business', ['uses'=>'v1\BusinessController@getReferences','as'=>'get_business_ids']);
        $router->get('/business/all', ['uses'=>'v1\BusinessController@getAllReferences','as'=>'get_all_business_ids']);
        $router->delete('/business/{ref_id}', ['uses'=>'v1\BusinessController@deleteReferences','as'=>'delete_business_reference']);
        $router->post('/owner', ['uses'=>'v1\OwnersController@saveReferences','as'=>'save_owner_ids']);
        $router->get('/owner', ['uses'=>'v1\OwnersController@getReferences','as'=>'get_owner_ids']);
        $router->get('/owner/all', ['uses'=>'v1\OwnersController@getAllReferences','as'=>'get_all_owner_ids']);
        $router->delete('/owner/{ref_id}', ['uses'=>'v1\OwnersController@deleteReferences','as'=>'delete_owner_reference']);
        $router->post('/collateral', ['uses'=>'v1\CollateralController@saveReferences','as'=>'save_collateral_ids']);
        $router->get('/collateral', ['uses'=>'v1\CollateralController@getReferences','as'=>'get_collateral_ids']);
        $router->get('/collateral/all', ['uses'=>'v1\CollateralController@getAllReferences','as'=>'get_all_collateral_ids']);
        $router->get('/business/filter', ['uses'=>'v1\BusinessController@filterReferences','as'=>'filter_business_references']);
        $router->get('/owner/filter', ['uses'=>'v1\OwnersController@filterReferences','as'=>'filter_owner_references']);
    });

    $router->group(['prefix'=>'app_assignment'], function () use ($router) {
        $router->post('/', ['uses'=>'v1\AppAssignmentController@post','as'=>'save_assignments']);
        $router->post('/delete', ['uses'=>'v1\AppAssignmentController@deleteAssignments','as'=>'delete_assignments']);
        $router->get('/', ['uses'=>'v1\AppAssignmentController@getAppAssignments','as'=>'get_assignments']);
        $router->get('/app_count', ['uses'=>'v1\AppAssignmentController@getByRoleId','as'=>'get_assignments_group_by_role_id']);
        $router->post('/all', ['uses'=>'v1\AppAssignmentController@getAppAssignments','as'=>'get_assignments']);
    });

    $router->group(['prefix'=>'checklist'], function () use ($router) {
        $router->post('/', ['uses'=>'v1\ChecklistController@post','as'=>'save_checklist']);
        $router->get('/all', ['uses'=>'v1\ChecklistController@getAllChecklist','as'=>'get_all_checklists']);
        $router->post('/all', ['uses'=>'v1\ChecklistController@getAllChecklist','as'=>'get_all_checklists']);
        $router->get('/{id}', ['uses'=>'v1\ChecklistController@getChecklist','as'=>'get_checklist']);
        $router->put('/{id}', ['uses'=>'v1\ChecklistController@put','as'=>'update_checklist']);
    });

    $router->group(['prefix'=>'checklists'], function () use ($router) {
        $router->put('/', ['uses'=>'v1\ChecklistController@putBatch','as'=>'update_checklist']);
        $router->post('/', ['uses'=>'v1\ChecklistController@postBatch','as'=>'save_checklist']);
    });

    $router->group(['prefix'=>'collateral'], function () use ($router) {
        //@todo check businessStructure id in redish for master data and if not found make http request
        //@todo verify user_id from user service
        $router->post('/', ['uses'=>'v1\CollateralController@postBatch','as'=>'save_collateral_info', 'middleware'=>['requestMiddleware']]);
        $router->put('/', ['uses'=>'v1\CollateralController@updateBatch','as'=>'update_collateral_info', 'middleware'=>['requestMiddleware']]);
        $router->put('/{id}', ['uses'=>'v1\CollateralController@put','as'=>'update_collateral', 'middleware'=>['requestMiddleware']]);
        $router->get('/', ['uses'=>'v1\CollateralController@getAllCollateral','as'=>'get_all_collateral']);
        $router->get('/{id}', ['uses'=>'v1\CollateralController@getCollateral','as'=>'get_collateral']);
    });

    $router->group(['prefix'=>'activity'], function () use ($router) {
        $router->put('/reset', ['uses'=>'v1\AppActivityController@resetAppActivity','as'=>'reset_app_activity']);
        $router->get('/', ['uses'=>'v1\AppActivityController@getAppActivities','as'=>'get_app_activity']);
        $router->post('/all', ['uses'=>'v1\AppActivityController@getAllAppActivities','as'=>'get_all_app_activity']);
    });

    $router->group(['prefix'=>'hash'], function () use ($router) {
        $router->post('/', ['uses'=>'v1\HashController@createHash','as'=>'create_hash']);
        $router->get('/{hash}', ['uses'=>'v1\HashController@verifyHash','as'=>'get_hash']);
        $router->put('/{hash}', ['uses'=>'v1\HashController@expireHash','as'=>'expire_hash']);
    });
    
    $router->group(['prefix'=>'product'], function () use ($router) {
        //@todo check businessStructure id in redish for master data and if not found make http request
        //@todo verify user_id from user service
        $router->post('/', ['uses'=>'v1\ProductController@postBatch','as'=>'save_product_info', 'middleware'=>['requestMiddleware']]);
        $router->put('/', ['uses'=>'v1\ProductController@updateBatch','as'=>'update_product_info', 'middleware'=>['requestMiddleware']]);
        $router->put('/{id}', ['uses'=>'v1\ProductController@put','as'=>'update_product', 'middleware'=>['requestMiddleware']]);
        $router->get('/', ['uses'=>'v1\ProductController@getAllProduct','as'=>'get_all_product']);
        $router->get('/{id}', ['uses'=>'v1\ProductController@getProduct','as'=>'get_product']);
        $router->post('/list', ['uses'=>'v1\ProductController@getAppProducts','as'=>'get_product_list']);
    });

    $router->group(['prefix'=>'notes'], function () use ($router) {
        $router->post('/', ['uses'=>'v1\NotesController@post','as'=>'create_note']);
        $router->get('/', ['uses'=>'v1\NotesController@getNotes','as'=>'get_notes']);
        $router->post('/all', ['uses'=>'v1\NotesController@getAllNotes','as'=>'get_all_notes']);
    });

});

$router->group(['prefix'=>'health'], function () use ($router) {
    $router->get('/', ['uses'=>'v1\HealthCheckController@check','as'=>'health_check']);
    $router->get('/all', ['uses'=>'v1\HealthCheckController@checkAll','as'=>'health_check_all']);
});

$router->group(['prefix'=>'api/v2'], function () use ($router) {
    
    $router->group(['prefix'=>'applications'], function () use ($router) {
        $router->put('/app_status/{id}', ['uses'=>'v2\ApplicationController@updateAppStatus','as'=>'update_app_status']);
    });

    $router->group(['prefix'=>'app_assignment'], function () use ($router) {
        $router->get('/', ['uses'=>'v2\AppAssignmentController@getAppAssignments','as'=>'get_assignments']);
        $router->post('/all', ['uses'=>'v2\AppAssignmentController@getAppAssignments','as'=>'get_assignments']);
    });

});