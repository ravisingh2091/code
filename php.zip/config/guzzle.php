<?php 
/**
 * configure option for Guzzle Http client
 */

return [

    'timeout' => 60,
    'http_verify'=> env('HTTP_VERIFY', false)

];