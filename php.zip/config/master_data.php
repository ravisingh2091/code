<?php 

return [
    'collections'=>[
        'app_status'                    => 'app_statuses',
        'business_facilities'           => 'business_facilities',
        'business_presence'             => 'business_presences',
        'type_of_products_and_services' => 'business_services',
        'business_structure'            => 'business_structures',
        'operation_years'               => 'business_times',
        'type_of_business'              => 'business_types',
        'city'                          => 'cities',
        'currency'                      => 'currencies',
        'time_at_curr_loc_in_year'      => 'current_location_times',
        'document_type'                 => 'document_types',
        'industry'                      => 'industries',
        'jurisdiction_key'              => 'jurisdictions',
        'purpose_of_loan'               => 'loan_purposes',
        'mail_template'                 => 'mail_templates',
        'is_owner_politically_exposed'  => 'political_owners',
        'requested_term'                => 'requested_terms',
        'rationale_for_revenue'         => 'revenues',
        'business_nature'               => 'industries',
        'service_provider'              => 'service_providers'
    ],
    'url'=> [
        'app_status'                    => env('MASTER_URL','').'/v1/app_status',
        'business_facilities'           => env('MASTER_URL','').'/v1/business_facility',
        'business_presence'             => env('MASTER_URL','').'/v1/business_presence',
        'type_of_products_and_services' => env('MASTER_URL','').'/v1/business_service',
        'business_structure'            => env('MASTER_URL','').'/v1/business_structure',
        'operation_years'               => env('MASTER_URL','').'/v1/business_time',
        'type_of_business'              => env('MASTER_URL','').'/v1/business_type',
        'city'                          => env('MASTER_URL','').'/v1/cities',
        'currency'                      => env('MASTER_URL','').'/v1/province',
        'time_at_curr_loc_in_year'      => env('MASTER_URL','').'/v1/current_location_time',
        'document_type'                 => env('MASTER_URL','').'/v1/document_type',
        'industry'                      => env('MASTER_URL','').'/v1/industry',
        'jurisdiction_key'              => env('MASTER_URL','').'/v1/jurisdictions',
        'purpose_of_loan'               => env('MASTER_URL','').'/v1/loan_purpose',
        'mail_template'                 => env('MASTER_URL','').'/v1/mail_templates',
        'is_owner_politically_exposed'  => env('MASTER_URL','').'/v1/political_owner',
        'requested_term'                => env('MASTER_URL','').'/v1/requested_term',
        'rationale_for_revenue'         => env('MASTER_URL','').'/v1/revenue',
        'business_nature'               => env('MASTER_URL','').'/v1/industry/business_nature',
        'service_provider'              => env('MASTER_URL','').'/v1/service_providers'
    ]
];