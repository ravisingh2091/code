<?php
    return [
        'default' => env('DB_CONNECTION', 'mongodb'),
        'connections' => [
            'mongodb' => [ 
                'driver' => env('DB_CONNECTION', 'mongodb'),
                'host' => env('DB_HOST', 'localhost'),
                'port' => env('DB_PORT', 27017),
                'database' => env('DB_DATABASE'),
                'username' => env('DB_USERNAME'),
                'password' => env('DB_PASSWORD'),
                'options' => [
                    'database' => env('DB_DATABASE', 'admin') // sets the authentication database required by mongo 3
                ]
            ],
        ],
        'migrations' => 'migrations',
        'redis' => [
        'cluster' => env('REDIS_CLUSTER', false),
        'default' => [
            'host'     => env('REDIS_HOST', '127.0.0.1'),
            'port'     => env('REDIS_PORT', 6379),
            'database' => env('REDIS_DATABASE', 0),
            'password' => env('REDIS_PASSWORD', null),
        ],
    ]
];