<?php

return [
    'v1' => [
        'MAX_EMAIL_TOKEN_TIME'          => env('MAX_EMAIL_TOKEN_TIME',1),
        'EMAIL_TOKEN_EXPIRE_TIME'       => env('EMAIL_TOKEN_EXPIRE_TIME',24),
        'EMAIL_TOKEN_COUNT'             => env('EMAIL_TOKEN_COUNT',3),
        'HASH_SALT'                     => env('HASH_SALT', '!1@2#3$4%5^6&7*8'),
        'UPDATE_OWNERS_WITH_SAME_EMAIL' => env('UPDATE_OWNERS_WITH_SAME_EMAIL', false)
    ],
];