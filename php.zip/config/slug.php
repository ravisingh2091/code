<?php 
/**
 * Slug array for each request with slug
 * 
 * Each slug key (i.e owners, business etc.) should be same as URL Endpoint (i.e /owners, /business etc.) 
 * */ 
return [
    'v1'=>[
        "business"   => [
            'business-info',
            'application-step1',
            'application-step2-part1',
            'application-step2-part2',
            'manual-business-details',
            'loan_tenure_details',
            'initial-business-save',
            'gross-annual-revenue',
            'category',
            'business-structure',
            'business-confirm',
            'fatca-crs',
            'business-details',
            'app-revenue-update',
            'unsecured-business-exclusion',
            'unsecured-business-detail',
            'unsecured-business-detail-cp',
            'loan_details',
            'backend_business',
            'inbound-business-info',
            'app-adi-package-update',
            'unsecured-business-exclusion-new',
            'pan-verify',
        ],
        "owners"     => [
            'owner-info',
            'application-step3-part1',
            'application-step3-part2',
            'loan_partner_details',
            'owner_consent_slug',
            'applicant_individual',
            'applicant_registered_entity',
            'applicant_nonregistered_entity',
            'business-owners',
            'loan_partner_details_manual',
            'owner-consent',
            'business-owners-solo',
            'backend_owners',
            'inbound-owner-info',
            'pan-verify'
        ],
        "collateral" => [
            'application-step2-part2', 
            'application-step4'
        ],
        "product" => [
            'product-rctl', 
            'product-term-loan',
            'product-line-of-credit',
            'product-credit-card',
            'product-ach',
            'product-credit-card-increase',
            'product-line-of-credit-increase'
        ],
        'owner_update' => [
            'owner-consent',
            'loan_partner_details_manual',
            'owner-consent-update',
            'business-owners',
            'business-owners-solo',
            'backend_owners',
            'pan-verify'
        ]
    ]
];
