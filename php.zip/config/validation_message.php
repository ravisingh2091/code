<?php
/**
 * Slug array for each request with slug
 *
 * Each slug key (i.e owners, business etc.) should be same as URL Endpoint (i.e /owners, /business etc.)
 * */
return [
    'v1'=>[
        'rule_messages' => [
            'pattern' => [
                'type'=>'FIELD_INVALID',
                'message'=> 'The value of the field is invalid.'
            ],
            'regex' => [
                'type'=>'FIELD_INVALID',
                'message'=> 'The value of the field is invalid.'
            ],
            'string' => [
                'type'=>'FIELD_INVALID',
                'message'=> 'The value of the field is invalid.'
            ],
            'filled' => [
                'type'=>'FIELD_INVALID',
                'message'=> 'The value of the field is invalid.'
            ],
            'unique' => [
                'type'=>'FIELD_INVALID',
                'message'=> 'The value of the field is invalid.'
            ],
            'is_valid_char' => [
                'type'=>'FIELD_INVALID',
                'message'=> 'The value of the field is invalid.'
            ],
            'min_length' => [
                'type'=>'FIELD_INVALID',
                'message'=> 'The value of the field is invalid.'
            ],
            'max_length' => [
                'type'=>'FIELD_INVALID',
                'message'=> 'The value of the field is invalid.'
            ],
            'between' => [
                'type'=>'FIELD_INVALID',
                'message'=> 'The value of the field is invalid.'
            ],
            'array' => [
                'type'=>'FIELD_INVALID',
                'message'=> 'The value of the field is invalid.'
            ],
            'required' => [
                'type'=>'FIELD_REQUIRED',
                'message'=> 'This action requires the field to be specified.'
            ]
        ]
    ]
];
