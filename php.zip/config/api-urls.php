<?php 

return [
    'v1'=>[
        'url' => env('API_URL'),
        'user_service' => env('SERVICE_USER_URL'),
        'master_service' => env('MASTER_URL'),
    ]
];