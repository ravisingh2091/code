<?php 

return [
    'v1'=>[
        'business'        => env('FIELDS_URL').'/v1/tasks/getTaskInfo',
        'business_update' => env('FIELDS_URL').'/v1/tasks/getTaskInfo',
        'application'     => env('FIELDS_URL').'/app-fields',
        'profile'         => env('FIELDS_URL'),
        'owners'          => env('FIELDS_URL').'/v1/tasks/getTaskInfo',
        'owner_consent'   => env('FIELDS_URL').'/v1/tasks/getTaskInfo',
        'collateral'      => env('FIELDS_URL').'/v1/tasks/getTaskInfo',
        'product'         => env('FIELDS_URL').'/v1/tasks/getTaskInfo',
    ]
];