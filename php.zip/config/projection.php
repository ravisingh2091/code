<?php 
/**
 * Projection array for each service references
 * 
 * Each projection key (i.e owners ref, business ref etc.) should be same as in db.
 * */ 
return [
    'v1'=>[
        "without_response" => [
            // individaul
            'type'=> 1,
            'ref_id'=> 1,
            'provider'=> 1,
            'app_id'=> 1,
            'user_id'=> 1,
            'created_at'=>1,
            'updated_at'=>1
        ],
        "default" => [
            // Default projection param
            'type'=> 1,
            'ref_id'=> 1,
            'provider'=> 1,
            'app_id'=> 1,
            'user_id'=> 1,
            'created_at'=>1,
            'updated_at'=>1,
            'response'=> 1
        ]
    ]
];