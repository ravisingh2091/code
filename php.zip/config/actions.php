<?php 

return [
    'v1'=> [
        'post'         => 'post',
        'put'          => 'put',
        'get'          => 'get',
        'delete'       => 'delete',
        'save'         => 'save',
        'continue'     => 'continue',
        'update_batch' => 'update_batch',
        'get_batch'    => 'get_batch',
        'post_batch'   => 'post_batch',
    ]
];