<?php

return [
    'v1' => [
        'success'             => 'success',
        'failed'              => 'failed',
        'yes'                 => 'yes',
        'invalid_user_id'     => 'Invalid user id',
        'invalid_app_id'      => 'Invalid app id',
        'invalid_business'    => "Invalid business details",
        'empty_business'      => 'Business Details cannot be empty.',
        'invalid_business_id' => 'Invalid business id',
        'hash_invalid'        => [
            'type'      => 'TOKEN_INVALID',
            'parameter' => 'token',
            'messsage'  => 'The value of the field is invalid.'
        ],
        'limit_reached'       => [
            "type"      => "LIMIT_REACHED",
            "messsage"  => "The rate limit for this action was reached"
        ],
        'not_found' => [
            "type"      => "RESOURCE_NOT_FOUND",
            "messsage"  => "Resource does not exist or has been removed"
        ],
        'unauthorized' => [
            "type"      => "AUTHORIZATION_REQUIRED",
            "messsage"  => "Performing this action on this resource requires authorization"
        ],
        'unique_business_name' => [
            'type'      => 'FIELD_DUPLICATE',
            'parameter' => 'legal_name_of_business',
            'messsage'  => 'The value of the field is already used for another resource.'
        ],
        'slug' => [
            'type'      => 'FIELD_INVALID',
            'parameter' => 'slug',
            'messsage'  => 'The value of the field is invalid.'
        ],
        'orch_url' => [
            'type'      => 'FIELD_INVALID',
            'parameter' => 'orch_url',
            'messsage'  => 'The value of the field is invalid.'
        ],
        'slug_url' => [
            'type'      => 'FIELD_REQUIRED',
            'messsage'  => 'The request requires slug or orch_url to be specified.'
        ],
        'slug_required' => [
            'type'      => 'FIELD_REQUIRED',
            'parameter' => 'slug',
            'messsage'  => 'This action requires the field to be specified.'
        ],
        'match_required' => [
            'type'      => 'FIELD_REQUIRED',
            'parameter' => 'match',
            'messsage'  => 'This action requires the field to be specified.'
        ],
        'match_invalid' => [
            'type'      => 'FIELD_INVALID',
            'parameter' => 'match',
            'messsage'  => 'The value of the field is invalid.'
        ],
        'service_unavailable' => [
            'type'      => 'SERVICE_UNAVAILABLE',
            'parameter' => 'unavailable',
            'messsage'  => 'The server is currently unable to handle the request.'
        ],
        'actions' => [
            'action_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'action_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'action_type.invalid' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'action_type',
                'messsage'  => 'The value of the field is invalid.'
            ]
        ],
        'update_app_status' => [
            'status_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'status_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'status_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'status_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'note.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'note',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'note.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'note',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'note.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'note',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_completed.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'is_completed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_completed.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'is_completed',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'allow_multiple.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'allow_multiple',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'allow_multiple.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'allow_multiple',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'delete_status.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'delete_status',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'delete_status.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'delete_status',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'allow_activity.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'allow_activity',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'allow_activity.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'allow_activity',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        "add_note"=>[
            'note.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'note',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'note.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'note',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'note.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'note',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'business_get' => [
            'business_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'business' => [
            'legal_name_of_business.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'legal_name_of_business',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'legal_name_of_business.unique' => [
                'type'      => 'FIELD_DUPLICATE',
                'parameter' => 'legal_name_of_business',
                'messsage'  => 'The value of the field is already used for another resource.'
            ],
            'legal_name_of_business.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'legal_name_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'legal_name_of_business.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'legal_name_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'legal_name_of_business.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'legal_name_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'legal_name_of_business.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'legal_name_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'legal_name_of_business.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'legal_name_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'legal_name_of_business.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'legal_name_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_number.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_number',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_number.unique' => [
                'type'      => 'FIELD_DUPLICATE',
                'parameter' => 'business_number',
                'messsage'  => 'The value of the field is already used for another resource.'
            ],
            'business_number.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_number.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_number.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_number.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_structure.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_structure',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_structure.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_structure',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_structure.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_structure',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_structure.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_structure',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_structure.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_structure',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_structure.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_structure',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_facility.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_facility',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_facility.required' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_facility',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_line_one.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'company_address_line_one',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_line_one.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_line_one.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_line_one.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_line_one.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_line_one.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_line_one.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_line_two.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'company_address_line_two',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_line_two.is_valid_char' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'company_address_line_two',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_line_two.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_line_two.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_line_two.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_line_two.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_line_two.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_city.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'company_address_city',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_city.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_city.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_city.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_city.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_city.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_city.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_province.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_province.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_province.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'company_address_province',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_province.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_province',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_province.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_province',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_province.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_province',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_state.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'company_address_state',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_state.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_state',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_state.alpha' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_state',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_state.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_state',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_state.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_state',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_state.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_state',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_postal_code.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'company_address_postal_code',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_postal_code.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_postal_code.alpha_num' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_postal_code.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_postal_code.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_postal_code.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_country.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'company_address_country',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_address_country.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_country.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_country.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_country.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_country.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_address_country.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_one.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_address_line_one',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_address_line_one.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_one.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_one.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_one.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_one.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_one.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_two.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_address_line_two',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_address_line_two.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_two.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_two.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_two.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_two.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_line_two.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_city.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_address_city',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_address_city.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_city.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_city.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_city.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_city.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_city.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_province.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_province.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_province.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_address_province',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_address_province.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_province',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_address_province.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_province',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_address_province.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_province',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_address_country.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_address_country',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_address_country.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_country.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_country.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_country.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_country.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_country.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_postal_code.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_address_postal_code',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_address_postal_code.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_postal_code.alpha_num' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_postal_code.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_postal_code.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_postal_code.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_nature.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_nature',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_nature.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_nature',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_nature.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_nature',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_nature.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_nature',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_presence.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_presence',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_presence.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_presence',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_presence.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_presence',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_presence.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_presence',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_one.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'mail_address_line_one',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'mail_address_line_one.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_one.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_one.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_one.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_one.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_one.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_two.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'mail_address_line_two',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'mail_address_line_two.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_two.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_two.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_two.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_two.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_line_two.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_city.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'mail_address_city',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'mail_address_city.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_city.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_city.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_city.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_city.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_city.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_province.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_province.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_province.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'mail_address_province',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'mail_address_province.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_province.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_province.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_country.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'mail_address_country',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'mail_address_country.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_country.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_country.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_country.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_country.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_country.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_postal_code.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'mail_address_postal_code',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'mail_address_postal_code.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_postal_code.alpha_num' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_postal_code.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_postal_code.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_postal_code.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'user_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.unique' => [
                'type'      => 'FIELD_DUPLICATE',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is already used for another resource.'
            ],
            'user_id.unique' => [
                'type'      => 'FIELD_DUPLICATE',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is already used for another resource.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'app_id.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'trade_name_same_as_legal_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'trade_name_same_as_legal_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'trade_name_same_as_legal_name.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'trade_name_same_as_legal_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'trade_name_same_as_legal_name.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'trade_name_same_as_legal_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'trade_name_same_as_legal_name.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'trade_name_same_as_legal_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'trade_name_same_as_legal_name.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'trade_name_same_as_legal_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'trade_name.required'  => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'trade_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'trade_name.regex'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'trade_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'trade_name.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'trade_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'trade_name.string'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'trade_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'trade_name.max_length'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'trade_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'trade_name.min_length'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'trade_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'trade_name.regex'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'trade_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'time_at_curr_loc_in_year.required'  => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'time_at_curr_loc_in_year',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'time_at_curr_loc_in_year.regex'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'time_at_curr_loc_in_year',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'time_at_curr_loc_in_year.integer'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'time_at_curr_loc_in_year',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'time_at_curr_loc_in_year.max_length'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'time_at_curr_loc_in_year',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'time_at_curr_loc_in_year.min_length'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'time_at_curr_loc_in_year',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'time_at_curr_loc_in_year.regex'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'time_at_curr_loc_in_year',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'industry.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'industry',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'industry.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'industry',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'industry.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'industry',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'industry.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'industry',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'industry.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'industry',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'industry.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'industry',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type_of_business.required'  => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'type_of_business',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'type_of_business.regex'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type_of_business.string'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type_of_business.max_length'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type_of_business.min_length'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type_of_business.regex'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type_of_business',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type_of_products_and_services.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'type_of_products_and_services',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'type_of_products_and_services.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type_of_products_and_services',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type_of_products_and_services.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type_of_products_and_services',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type_of_products_and_services.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type_of_products_and_services',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type_of_products_and_services.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type_of_products_and_services',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type_of_products_and_services.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type_of_products_and_services',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'rationale_for_revenue.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'rationale_for_revenue',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'rationale_for_revenue.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'rationale_for_revenue',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'rationale_for_revenue.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'rationale_for_revenue',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'rationale_for_revenue.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'rationale_for_revenue',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'rationale_for_revenue.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'rationale_for_revenue',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'rationale_for_revenue.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'rationale_for_revenue',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'number_of_employees.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'number_of_employees',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'number_of_employees.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'number_of_employees',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'number_of_employees.integer' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'number_of_employees',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'number_of_employees.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'number_of_employees',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'number_of_employees.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'number_of_employees',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'number_of_employees.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'number_of_employees',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_facilities.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_facilities',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_facilities.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_facilities',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_facilities.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_facilities',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_facilities.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_facilities',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_facilities.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_facilities',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_facilities.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_facilities',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'url.required'  => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'website_url',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'url.url'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'website_url',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'url.regex'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'website_url',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'url.max_length'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'website_url',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'url.min_length'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'website_url',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'url.regex'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'website_url',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_owner_politically_exposed.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'is_owner_politically_exposed',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'is_owner_politically_exposed.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'is_owner_politically_exposed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_owner_politically_exposed.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'is_owner_politically_exposed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_owner_politically_exposed.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'is_owner_politically_exposed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_owner_politically_exposed.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'is_owner_politically_exposed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'gross_annual_revenue.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'gross_annual_revenue',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'gross_annual_revenue.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'gross_annual_revenue',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'gross_annual_revenue.integer' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'gross_annual_revenue',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'gross_annual_revenue.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'gross_annual_revenue',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'gross_annual_revenue.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'gross_annual_revenue',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'gross_annual_revenue.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'gross_annual_revenue',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'financing_needed.required' =>  [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'financing_needed',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'financing_needed.regex' =>  [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'financing_needed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'financing_needed.integer' =>  [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'financing_needed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'financing_needed.max_length' =>  [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'financing_needed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'financing_needed.min_length' =>  [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'financing_needed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'financing_needed.regex' =>  [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'financing_needed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'debt_amount_availed.required' =>  [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'debt_amount_availed',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'debt_amount_availed.regex' =>  [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'debt_amount_availed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'debt_amount_availed.integer' =>  [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'debt_amount_availed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'debt_amount_availed.max_length' =>  [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'debt_amount_availed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'debt_amount_availed.min_length' =>  [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'debt_amount_availed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'debt_amount_availed.regex' =>  [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'debt_amount_availed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'purpose_of_loan.required'  => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'purpose_of_loan',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'purpose_of_loan.regex'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'purpose_of_loan',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'purpose_of_loan.string'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'purpose_of_loan',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'purpose_of_loan.max_length'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'purpose_of_loan',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'purpose_of_loan.min_length'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'purpose_of_loan',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'purpose_of_loan.regex'  => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'purpose_of_loan',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'requested_term.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'requested_term',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'requested_term.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'requested_term',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'requested_term.integer' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'requested_term',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'requested_term.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'requested_term',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'requested_term.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'requested_term',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'requested_term.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'requested_term',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_same_as_registered.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_address_same_as_registered',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_address_same_as_registered.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_same_as_registered',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_same_as_registered.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_same_as_registered',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_same_as_registered.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_same_as_registered',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_address_same_as_registered.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_address_same_as_registered',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_same_as_registered.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'mail_address_same_as_registered',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'mail_address_same_as_registered.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_same_as_registered',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_same_as_registered.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_same_as_registered',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_same_as_registered.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_same_as_registered',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'mail_address_same_as_registered.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'mail_address_same_as_registered',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'operation_years.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'operation_years',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'operation_years.integer' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'operation_years',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'operation_years.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'operation_years',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'operation_years.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'operation_years',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'operation_years.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'operation_years',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'jurisdiction_key.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'jurisdiction_key',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'jurisdiction_key.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'jurisdiction_key',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'jurisdiction_key.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'jurisdiction_key',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'jurisdiction_key.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'jurisdiction_key',
                'messsage'  => 'The value of the field is invalid.'
            ],
            //=====HSBC=====
            'company_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'company_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_type.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'entity_incorporated_india.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'entity_incorporated_india',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'entity_incorporated_india.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'entity_incorporated_india',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'entity_incorporated_india.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'entity_incorporated_india',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'entity_incorporated_india.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'entity_incorporated_india',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_vintage_yrs.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_vintage_yrs',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_vintage_yrs.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_vintage_yrs',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'location_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'location_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'location_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'location_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'turnover_range.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'turnover_range',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'turnover_range.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'turnover_range',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'financial_audits_last_two_yrs.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'financial_audits_last_two_yrs',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'financial_audits_last_two_yrs.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'financial_audits_last_two_yrs',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'promoters.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'promoters',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'promoters.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'promoters',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'promoters_indian_residents.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'promoters_indian_residents',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'promoters_indian_residents.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'promoters_indian_residents',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'facility_avail.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'facility_avail',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'facility_avail.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'facility_avail',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_pan.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_pan',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_pan.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_pan',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'no_of_collateral.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'no_of_collateral',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'no_of_collateral.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'no_of_collateral',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'collateral_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'collateral_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'collateral_type.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'collateral_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'construction_status.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'construction_status',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'construction_status.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'construction_status',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'collateral_pincode.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'collateral_pincode',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'collateral_pincode.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'collateral_pincode',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'company_gstn.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'company_gstn',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'company_gstn.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'company_gstn',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'cin.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'cin',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'cin.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'cin',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'registered_date.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'registered_date',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'registered_date.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'registered_date',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'no_of_collaterals.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'no_of_collaterals',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'no_of_collaterals.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'no_of_collaterals',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_location.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_location',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_location.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_location',
                'messsage'  => 'The value of the field is invalid.'
            ],
            //=====HSBC=====
            //=====STANC=====
            'finance_purpose.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'finance_purpose',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'finance_purpose.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'finance_purpose',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'tenure_months.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'tenure_months',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'tenure_months.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'tenure_months',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'tenure_years.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'tenure_years',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'tenure_years.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'tenure_years',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_pincode.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_pincode',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_pincode.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_pincode',
                'messsage'  => 'The value of the field is invalid.'
            ],
            //=====STANC=====
            //===ORIENTAL===
            'business_age.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_age',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_age.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_age',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'creditscore_range.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'creditscore_range',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'creditscore_range.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'creditscore_range',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'finance_purpose.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'finance_purpose',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'finance_purpose.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'finance_purpose',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'loan_amount.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'loan_amount',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'loan_amount.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'loan_amount',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_phone_number.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_phone_number',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'primary_contact_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'primary_contact_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'primary_contact_number.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'primary_contact_number',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            //=====ORIENTAL
        ],
        'application' => [
            'user_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'user_id.unique' => [
                'type'      => 'FIELD_DUPLICATE',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is already used for another resource.'
            ],
            'user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'product_type.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'product_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'owners' => [
            'name_of_the_direct_owner.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'name_of_the_direct_owner',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'name_of_the_direct_owner.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'name_of_the_direct_owner',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'name_of_the_direct_owner.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'name_of_the_direct_owner',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'name_of_the_direct_owner.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'name_of_the_direct_owner',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'name_of_the_direct_owner.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'name_of_the_direct_owner',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'name_of_the_direct_owner.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'name_of_the_direct_owner',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_email.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_email',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_email.email' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_email',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_email.unique' => [
                'type'      => 'FIELD_DUPLICATE',
                'parameter' => 'owner_email',
                'messsage'  => 'The value of the field is already used for another resource.'
            ],
            'owner_email.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_email',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_email.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_email',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_email.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_email',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'ownership_percent.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'ownership_percent',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'ownership_percent.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'ownership_percent.not_in' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'ownership_percent.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'ownership_percent.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'ownership_percent.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_type.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_type.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_type.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_type.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.unique' => [
                'type'      => 'FIELD_DUPLICATE',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is already used for another resource.'
            ],
            'user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            //=====HSBC=====            
            'din.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'din',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'din.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'din',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'pan.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'pan',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'pan.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'pan',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_role.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_role',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_role.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_role',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'policy_checkbox.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'policy_checkbox',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'policy_checkbox.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'policy_checkbox',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'zip.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'zip',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'zip.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'zip',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_line_one.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'primary_residence_address_line_one',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'primary_residence_address_line_one.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_line_two.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'primary_residence_address_line_two',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'primary_residence_address_line_two.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            //=====HSBC=====
            'owners.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owners',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owners.array' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owners.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owners.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owners.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owners.between' => [
                'array' => [
                    'type'      => 'FIELD_INVALID',
                    'parameter' => 'owners',
                    'messsage'  => 'The value of the field is invalid.'
                ]
            ],
            'corporate_owners.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'corporate_owners',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'corporate_owners.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'corporate_owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'corporate_owners.array' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'corporate_owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'corporate_owners.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'corporate_owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'corporate_owners.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'corporate_owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'corporate_owners.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'corporate_owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'corporate_owners.between' => [
                'array' => [
                    'type'      => 'FIELD_INVALID',
                    'parameter' => 'corporate_owners',
                    'messsage'  => 'The value of the field is invalid.'
                ]
            ],
            'email_address.unique' => [
                'type'      => 'FIELD_DUPLICATE',
                'parameter' => 'email_address',
                'messsage'  => 'The value of the field is already used for another resource.'
            ],
            'email_address.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'email_address',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'email_address.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'email_address',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'email_address.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'email_address',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_email.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_email',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_email.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_email',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'name_of_the_direct_owner.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'name_of_the_direct_owner',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'name_of_the_direct_owner.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'name_of_the_direct_owner',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'ownership_percent.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'ownership_percent',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'ownership_percent.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'ownership_percent.not_in' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_type.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'title.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'title',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'title.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'title',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'title.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'title',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'title.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'title',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'gender.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'gender',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'gender.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'gender',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'gender.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'gender',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'gender.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'gender',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_first_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_first_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_first_name.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_first_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_first_name.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_first_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_first_name.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_first_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'middle_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'middle_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'middle_name.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'middle_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'middle_name.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'middle_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'middle_name.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'middle_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'birth_city.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'birth_city',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'birth_city.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'birth_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'birth_city.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'birth_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'birth_city.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'birth_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_line_one.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'primary_residence_address_line_one',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'primary_residence_address_line_one.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_line_one.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_line_one.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_line_one.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_line_two.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'primary_residence_address_line_two',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'primary_residence_address_line_two.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_line_two.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_line_two.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_line_two',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_city.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'primary_residence_address_city',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'primary_residence_address_city.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_city.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_postal_code.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'primary_residence_address_postal_code',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'primary_residence_address_postal_code.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_postal_code.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_province.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'primary_residence_address_province',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'primary_residence_address_province.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_province.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_province',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_country.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'primary_residence_address_country',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'primary_residence_address_country.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'primary_residence_address_country.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'primary_residence_address_country',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_phone_number.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_phone_number',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_phone_number.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_phone_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_phone_number.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_phone_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_phone_number.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_phone_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_phone_number.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_phone_number',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_phone_number.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_phone_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_phone_number.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_phone_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_phone_number.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_phone_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'profession.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'profession',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'profession.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'profession',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_experience.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_experience',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_experience.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_experience',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_experience.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_experience',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'business_experience.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'business_experience',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'canada_citizen.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'canada_citizen',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'canada_citizen.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'canada_citizen',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'politically_owner.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'politically_owner',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'politically_owner.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'politically_owner',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'networth.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'networth',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'networth.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'networth',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'sin.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'sin',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'sin.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'sin',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_last_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_last_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_last_name.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_last_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_last_name.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_last_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_last_name.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_last_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'dob.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'dob',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'dob.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'dob',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'dob.date' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'dob',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'dob.date_format' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'dob',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'consent_agreement.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'consent_agreement',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'consent_agreement.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'consent_agreement',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'consent_guarantee.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'consent_guarantee',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'consent_guarantee.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'consent_guarantee',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'consent_legal.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'consent_legal',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'consent_legal.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'consent_legal',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'relationship_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'relationship_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'title.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'title',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'first_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'first_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'first_name.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'first_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'first_name.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'first_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'paternal_last_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'paternal_last_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'paternal_last_name.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'paternal_last_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'paternal_last_name.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'paternal_last_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'maternal_last_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'maternal_last_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'maternal_last_name.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'maternal_last_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'maternal_last_name.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'maternal_last_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'social_security_number.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'social_security_number',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'social_security_number.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'social_security_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'dob.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'dob',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_email.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_email',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_email.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_email',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'marital_status.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'marital_status',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'ownership_percent.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'ownership_percent',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'ownership_percent.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'ownership_percent.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'home_address_line_one.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'home_address_line_one',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'home_address_line_one.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'home_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'home_address_line_one.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'home_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'home_address_line_two.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'home_address_line_two',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'home_address_city.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'home_address_city',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'home_address_city.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'home_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'home_address_city.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'home_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'home_address_postal_code.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'home_address_postal_code',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'home_address_postal_code.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'home_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'home_address_postal_code.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'home_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'home_address_state.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'home_address_state',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'home_address_state.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'home_address_state',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'home_address_state.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'home_address_state',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'presidential_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'presidential_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'presidential_name.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'presidential_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'presidential_name.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'presidential_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'president_marital_status.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'president_marital_status',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'presidential_city.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'presidential_city',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'secretary_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'secretary_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'secretary_name.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'secretary_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'secretary_name.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'secretary_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'secretary_marital_status.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'secretary_marital_status',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'secretary_city.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'secretary_city',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'submit_consent.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'submit_consent',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_relation_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_relation_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_relation_type.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_relation_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_relation_type.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_relation_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_first_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_first_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_paternal_last_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_paternal_last_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_maternal_last_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_maternal_last_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_social_security_number.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_social_security_number',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_social_security_number.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_social_security_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_dob.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_dob',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_dob.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_dob',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_email_address.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_email_address',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_email_address.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_email_address',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_ownership_percent.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_ownership_percent',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_ownership_percent.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_ownership_percent.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_ownership_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_home_address_line_one.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_home_address_line_one',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_home_address_line_one.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_home_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_home_address_line_one.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_home_address_line_one',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_home_address_line_two.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_home_address_line_two',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_home_address_city.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_home_address_city',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_home_address_city.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_home_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_home_address_city.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_home_address_city',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_home_address_postal_code.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_home_address_postal_code',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_home_address_postal_code.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_home_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_home_address_postal_code.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_home_address_postal_code',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_home_address_state.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'spouse_home_address_state',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'spouse_home_address_state.max_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_home_address_state',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'spouse_home_address_state.min_length' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'spouse_home_address_state',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_secretary_info.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'is_secretary_info',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'is_presidential_info.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'is_presidential_info',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'org_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'org_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_identification_num.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_identification_num',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_entity_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_entity_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'business_owner_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'business_owner_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_phone_number.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_phone_number',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_phone_number.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_phone_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'owners_verify' => [
            'owner_id.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'hash.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'token',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'hash.string' => [
                'type'      => 'TOKEN_INVALID',
                'parameter' => 'token',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'hash.regex' => [
                'type'      => 'TOKEN_INVALID',
                'parameter' => 'token',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'hash_for.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'hash_for',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'hash_for.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'hash_for',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'owners_array' => [
            'owners.array' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owners.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owners',
                'messsage'  => 'This action requires the field to be specified.'
            ],

        ],
        'owners_weighted_average' => [
            'owner_id.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'score.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'score',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'score.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'score',
                'messsage'  => 'This action requires the field to be specified.'
            ],
        ],
        'save_service_ids' => [
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'ref_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'ref_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'ref_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'ref_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'provider.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'provider',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'provider.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'provider',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'backend_user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'backend_user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'type.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'collateral_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'collateral_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'collateral_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'collateral_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'get_batch_apps' => [
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'status_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'status_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'start.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'start',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'per_page.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'per_page',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'record_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'record_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'assigned_to.regex'     => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'assigned_to',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'name.regex'      => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'name',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'update_owners_percent_array' => [
            'owners.array' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owners',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owners.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owners',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'hash_for.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'hash_for',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'hash_for.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'hash_for',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'update_owner_percent' => [
            'owner_id.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'level.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'level',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'level.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'level',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'updated_percent.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'updated_percent',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'updated_percent.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'updated_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'updated_percent.not_in' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'updated_percent',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'get_app_count' => [
            'from_date.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'from_date',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'to_date.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'to_date',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'update_app' => [
            'status_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'status_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'status_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'status_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'backend_user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'backend_user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'backend_user_id.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'backend_user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'action_from.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'action_from',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'action_from.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'action_from',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'note.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'note',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'note.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'note',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'note.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'note',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'action.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'action',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_completed.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'is_completed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_completed.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'is_completed',
                'messsage'  => 'This action requires the field to be specified.'
            ],
        ],
        'delete_owner_hash' => [
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'get_app_activity' => [
            'action_from.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'action_from',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'assignments' => [
            'assigned_to.regex'     => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'assigned_to',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'assigned_to.filled'     => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'assigned_to',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'backend_user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'backend_user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'backend_user_id.required' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'backend_user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'action_from.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'action_from',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'action_from.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'action_from',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'action.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'action',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'action.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'action',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'role_id.regex'     => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'role_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'role_id.required'     => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'role_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_completed.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'is_completed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_completed.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'is_completed',
                'messsage'  => 'This action requires the field to be specified.'
            ],
        ],
        'save_checklist' => [
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_id.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'role_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'role_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'role_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'role_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'checklist_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'checklist_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'checklist_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'checklist_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'backend_user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'backend_user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'backend_user_id.required' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'backend_user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'comment.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'comment',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'comment.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'comment',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'comment.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'comment',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'comment.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'comment',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'checklist_action.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'checklist_action',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'checklist_action.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'checklist_action',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'checklists.array' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'checklists',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'checklists.required' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'checklists',
                'messsage'  => 'This action requires the field to be specified.'
            ],
        ],
        'update_checklist' => [
            'comment.string' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'comment',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'comment.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'comment',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'comment.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'comment',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'comment.is_valid_char' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'comment',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'checklist_action.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'checklist_action',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'checklist_action.filled' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'checklist_action',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'get_checklist' => [
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
        ],
        'get_app_assignment' => [
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'role_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'role_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'assigned_to.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'assigned_to',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'start.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'start',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'per_page.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'per_page',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'name.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'status_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'status_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'record_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'record_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'to_date.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'to_date',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'from_date.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'from_date',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'get_by_role_id' => [
            'role_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'role_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'assigned_to.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'assigned_to',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'from_date.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'from_date',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'to_date.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'to_date',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'update_app_activity' => [
            'is_completed.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'is_completed',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'is_completed.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'is_completed',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.required' => [
                'type' => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'message' => 'This action requires the field to be specified.'
            ],
            'activities.required' => [
                'type' => 'FIELD_REQUIRED',
                'parameter' => 'activities',
                'message' => 'This action requires the field to be specified.'
            ]
        ],
        'collateral_info' => [
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'collaterals.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'collaterals',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'collaterals.array' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'collaterals',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'collateral_type.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'collateral_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'collateral_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'collateral_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'construction_status.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'construction_status',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'construction_status.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'construction_status',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'collateral_pincode.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'collateral_pincode',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'collateral_pincode.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'collateral_pincode',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'property_occupied.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'property_occupied',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'property_occupied.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'property_occupied',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'property_owned.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'property_owned',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'property_owned.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'property_owned',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_first_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_first_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_first_name.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_first_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_last_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_last_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_last_name.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_last_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_phone_number.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_phone_number',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_phone_number.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_phone_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_email.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_email',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_email.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_email',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_pan_no.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_pan_no',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_pan_no.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_pan_no',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_relation_with_applicant.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_relation_with_applicant',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_relation_with_applicant.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_relation_with_applicant',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'location_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'location_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'location_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'location_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'fd_amount.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'fd_amount',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'fd_amount.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'fd_amount',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'update_collateral' => [
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'collateral_type.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'collateral_type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'collateral_type.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'collateral_type',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'construction_status.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'construction_status',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'construction_status.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'construction_status',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'collateral_pincode.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'collateral_pincode',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'collateral_pincode.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'collateral_pincode',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'property_occupied.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'property_occupied',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'property_occupied.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'property_occupied',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'property_owned.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'property_owned',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'property_owned.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'property_owned',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_first_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_first_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_first_name.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_first_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_last_name.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_last_name',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_last_name.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_last_name',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_phone_number.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_phone_number',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_phone_number.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_phone_number',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_email.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_email',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_email.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_email',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_pan_no.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_pan_no',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_pan_no.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_pan_no',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_relation_with_applicant.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_relation_with_applicant',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_relation_with_applicant.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_relation_with_applicant',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'location_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'location_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'location_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'location_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'fd_amount.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'fd_amount',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'fd_amount.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'fd_amount',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'get_collateral' => [
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
        ],
        'create_hash' => [
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'email.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'email',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'hash_for.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'hash_for',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'hash_for.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'hash_for',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'owner_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'owner_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'owner_id.filled' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'owner_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'expiry.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'expiry',
                'messsage'  => 'The value of the field is invalid.'
            ],
        ],
        'create_note' => [
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'app_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'app_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'note.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'note',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'note.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'note',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'role_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'role_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'role_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'role_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
            'backend_user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'backend_user_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'backend_user_id.required' => [
                'type'      => 'FIELD_REQUIRED',
                'parameter' => 'backend_user_id',
                'messsage'  => 'This action requires the field to be specified.'
            ],
        ],
        'filter_references' => [
            'from_date.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'from_date',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'to_date.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'to_date',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'per_page.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'per_page',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'start.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'start',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'type.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'type',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'app_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'app_id',
                'messsage'  => 'The value of the field is invalid.'
            ],
            'user_id.regex' => [
                'type'      => 'FIELD_INVALID',
                'parameter' => 'user_id',
                'messsage'  => 'The value of the field is invalid.'
            ]
        ]
    ]
];
