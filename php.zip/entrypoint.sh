#! /bin/bash
cd /var/www/html/
sed -i "s/app_env/${app_env}/g" /var/www/html/.env
sed -i "s/app_debug/${app_debug}/g" /var/www/html/.env
sed -i "s/app_timezone/${app_timezone}/g" /var/www/html/.env
sed -i "s/log_channel/${log_channel}/g" /var/www/html/.env
sed -i "s/db_provider/${db_provider}/g" /var/www/html/.env
sed -i "s/db_host/${db_host}/g" /var/www/html/.env
sed -i "s/db_port/${db_port}/g" /var/www/html/.env
sed -i "s/db_database/${db_database}/g" /var/www/html/.env
sed -i "s/db_user/${db_user}/g" /var/www/html/.env
sed -i "s/db_password/${db_password}/g" /var/www/html/.env
sed -i "s/cache_driver/${cache_driver}/g" /var/www/html/.env
sed -i "s/queue_driver/${queue_driver}/g" /var/www/html/.env
sed -i "s/redis_host/${redis_host}/g" /var/www/html/.env
sed -i "s/redis_password/${redis_password}/g" /var/www/html/.env
sed -i "s/redis_port/${redis_port}/g" /var/www/html/.env
sed -i "s/orch_url/${orch_url}/g" /var/www/html/.env
sed -i "s/master_url/${master_url}/g" /var/www/html/.env
sed -i "s/user_url/${user_url}/g" /var/www/html/.env
sed -i "s/emailtokenexpiry/${emailtokenexpiry}/g" /var/www/html/.env
/etc/init.d/nginx start && php-fpm
