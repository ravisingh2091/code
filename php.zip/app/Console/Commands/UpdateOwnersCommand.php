<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Update Owners Command
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Console\Commands;

use Exception;
use Illuminate\Console\Command;
use App\Repositories\Models\Owner;

/**
 * Update Owners command to add owner_first_name and owner_last_name
 */
class UpdateOwnersCommand extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $signature = "update:owners";

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = "Update all owners to add first_name and last_name";

    /**
     * Owner Model
     *
     * @var App\Repositories\Models\Owner
     */
    protected $Owner;

    /**
     * @param App\Repositories\Model\Owner $Owner
     */
    public function __construct(Owner $Owner)
    {
        $this->Owner = $Owner;

        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        try {
            $Owners = $this->Owner->select('*')->get();
            
            if (count($Owners->toArray()) == 0) {
                $this->info("No owners exist");
                return;
            }

            foreach ($Owners as $Owner) {
                if(!isset($Owner[config('fields.v1.owner_first_name')])) {
                    $first_name = substr($Owner[Owner::DIRECT_OWNER_NAME], 0, strpos($Owner[Owner::DIRECT_OWNER_NAME], ' '));
                    
                    $Updated_Owner = [
                        config('fields.v1.owner_first_name') => $first_name
                    ];
                    
                    if($this->Owner->where(Owner::ID, $Owner[Owner::ID])->update($Updated_Owner)) {
                        $this->info($Owner[Owner::ID].' -> updated first name');
                    }
                }

                if(!isset($Owner[config('fields.v1.owner_last_name')])) {
                    $last_name = trim(substr($Owner[Owner::DIRECT_OWNER_NAME], strpos($Owner[Owner::DIRECT_OWNER_NAME], ' ')));
                    
                    $Updated_Owner = [
                        config('fields.v1.owner_last_name') => $last_name
                    ];

                    if($this->Owner->where(Owner::ID, $Owner[Owner::ID])->update($Updated_Owner)) {
                        $this->info($Owner[Owner::ID].' -> updated last name');
                    }
                }
            }

            $this->info("All owners have been updated");

        } catch (Exception $e) {
            $this->error("An error occurred");
        }
    }
}