<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Guzzle Http Client Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Libraries;

use Exception;
use GuzzleHttp\Client;
use App\Repositories\Contracts\Http\HttpClientInterface;
use GuzzleHttp\Exception\RequestException;

/**
 * HttpClient class contains definition for http methods
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class HttpClient implements HttpClientInterface
{
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $url
     * @param int $timeout
     *
     * @return string
     */
    public static function get(string $url, $timeout, $custom_header = [])
    {
        $timeout = empty($timeout) ? config('guzzle.timeout') : $timeout;
        try {
            $client = new Client();
            $response = $client->get($url, [
                'verify'  => config('guzzle.http_verify'),
                'timeout' => $timeout,
                'headers' => $custom_header
            ]);
            return ((string)$response->getBody());
        } catch (RequestException $cex) {
            throw $cex;
        } catch (Exception $ex) {
            throw $ex;
        }
    }
}