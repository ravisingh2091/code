<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Libraries;

use App\Repositories\Contracts\Redis\RedisInterface;


/**
 * The Redis class implements methods to set, get and update the redis data
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class Redis implements RedisInterface
{
    /**
     * The clusterConnection connect the redis cluster.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $connection
     *
     * @return string
     */
    public static function clusterConnection(string $connection)
    {
        return app('redis')->connection($connection);
    }

    /**
     * The setKey set the key:value in redis
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param  string  $key
     * @param  string  $value
     *
     * @return string
    */
    public static function setKey(string $key, string $value, $expiration = null)
    {
        app('redis')->set($key, $value);

        if (!is_null($expiration)) {
            self::setExpiration($key, $expiration);
        }
    }

    /**
     * The getValue get the value in redis using key.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $key
     *
     * @return string
     */
    public static function getValue(string $key)
    {
        if (app('redis')->exists($key)) {
            return app('redis')->get($key);
        }

        return;
    }

    /**
     * The setExpiration destroy Redis Key:value
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $key
     * @param int $expiration
     *
     * @return int
     */
    public static function setExpiration(string $key, int $expiration)
    {
        if (app('redis')->exists($key)) {
            return app('redis')->expire($key, $expiration);
        }

        return;
    }
}
