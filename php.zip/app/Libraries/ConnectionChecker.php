<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Libraries;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;

/**
 * The ConnectionChecker class to check the database and redis connection
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ConnectionChecker
{
    /**
     * Method for checking database connection
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $connection
     *
     * @return boolean
     */
    public static function isDatabaseReady(string $connection = null)
    {
        $isReady = true;
        try {
            DB::connection($connection)->getPdo();
        } catch (\Exception $e) {
            $isReady = false;
        }

        return $isReady;
    }

    /**
     * Method for checking redis connection
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $connection
     *
     * @return boolean
     */
    public static function isRedisReady(string $connection = null)
    {
        $isReady = true;
        try {
            $redis = Redis::connection($connection);
            $redis->connect();
            $redis->disconnect();
        } catch (\Exception $e) {
            $isReady = false;
        }

        return $isReady;
    }
}  