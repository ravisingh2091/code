<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   AppAssignment Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v2;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Models\AppAssignment;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\AppAssignment\AppAssignmentInterface;

/**
 * AppAssignment Controller class used for handling AppAssignment info.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class AppAssignmentController extends Controller
{
    protected $fields_data;

    /**
     * @var App\Repositories\Contracts\AppAssignmentInterface;
     */
    protected $AppAssignmentRepository;

    /**
     * @var App\Repositories\Contracts\ErrorRepository
     */
    protected $ErrorRepository;
    
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param AppAssignmentInterface $BusinessRepository
     */
    public function __construct(AppAssignmentInterface $AppAssignmentRepository, ErrorRepository $ErrorRepository)
    {
        $this->AppAssignmentRepository = $AppAssignmentRepository;
        $this->ErrorRepository    = $ErrorRepository;
        
        parent::__construct($AppAssignmentRepository, $ErrorRepository);
    }

    /**
     * Validate Request
     *
     * @param string $action
     * @param Request $Request
     * 
     * @return string
     */
    public function validateRequest(string $action, Request $Request)
    {
        if ($action === config('actions.v1.post')) {
            $this->fields_data = config('fields.v1.save_assignments');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.save_assignments'),
                trans('messages.v1.assignments')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            if($Request->filled(config('fields.v1.assigned_to'))) {
                $Assignment = $this->AppAssignmentRepository->get($Request->only(config('fields.v1.app_id'), config('fields.v1.assigned_to')));
                
                if($Assignment instanceof AppAssignment) {
                    return $this->ErrorRepository->errorMessage('BAD_REQUEST');
                }
            }
        }

        if ($action === config('actions.v1.delete')) {
            $this->fields_data = config('fields.v1.delete_assignments');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.delete_assignments'),
                trans('messages.v1.assignments')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }
        }
    }

    /**
     * Get App Assignments
     *
     * @param string $Request
     * 
     * @return string
     */
    public function getAppAssignments(Request $Request)
    {   
        $prod_config = $this->AppAssignmentRepository->getProductConfig(config('api-urls.v1.master_service'), config('fields.v1.version_v1'));
        $app_filter_params = [];
        
        if ($prod_config) {
            foreach ($prod_config as $config) {
                if ($config->{config('fields.v1.type')} == config('fields.v1.app_filter_params')) {
                    $app_filter_params = isset($config->{config('fields.v1.filter_params')}) ? $config->{config('fields.v1.filter_params')} : [];
                }
            }
        };


        if(!empty($app_filter_params)) {
            return $this->getFilteredAppsFromMasterConfig($Request, $app_filter_params);
        }

        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v2.get_app_assignment'),
            trans('messages.v1.get_app_assignment')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        try {
            $AppAssignments = $this->AppAssignmentRepository->getApplications($Request);

            if (is_array($AppAssignments) && empty($AppAssignments)) {
                $this->AppAssignmentRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->AppAssignmentRepository->getResourceName(),
                    [
                        config('fields.v1.applications')=> [],
                        config('fields.v1.total_apps') => 0
                    ]
                );
            }

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }
        
        return $this->AppAssignmentRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->AppAssignmentRepository->getResourceName(),
            $AppAssignments
        );
    }

    /**
     * Filter apps according to master config
     *
     * @param Request $Request
     * @param array $app_filter_params
     * 
     * @return string
     */
    private function getFilteredAppsFromMasterConfig(Request $Request, array $app_filter_params)
    {
        $validation_rules = [];

        foreach($app_filter_params as $param) {
            if(isset($param->{config('fields.v1.validation')}) && !empty($param->{config('fields.v1.validation')})) {
                $validation_rules[$param->{config('fields.v1.name')}] = $param->{config('fields.v1.validation')};
            }
        }

        $validation_messages = $this->AppAssignmentRepository->bindValidations($validation_rules);

        $validator = Validator::make(
            $Request->all(),
            $validation_rules,
            $validation_messages
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        try {


        
            $app_filter_params = array_filter($app_filter_params, array($this, "getOnlyFilterParams"));

            $AppAssignments = $this->AppAssignmentRepository->getFilteredApps($Request, $app_filter_params);

            if (is_array($AppAssignments) && empty($AppAssignments)) {
                $this->AppAssignmentRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->AppAssignmentRepository->getResourceName(),
                    [
                        config('fields.v1.applications')=> [],
                        config('fields.v1.total_apps') => 0
                    ]
                );
            }

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }
        
        return $this->AppAssignmentRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->AppAssignmentRepository->getResourceName(),
            $AppAssignments
        );
    }

    private function getOnlyFilterParams($arr)
    {
        return $arr->{config('fields.v1.type')} === 'filter';
    }
}