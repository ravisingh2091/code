<?php

/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Application Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v2;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Models\AppActivity;
use App\Repositories\Models\Application;
use App\Repositories\Contracts\Api\ApiInterface;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Contracts\Data\DataInterface;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\Application\ApplicationInterface;

/**
 * Application Controller class used for handling Application info.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ApplicationController extends Controller
{
    protected $fields_data;

    /**
     * @var App\Repositories\Contracts\ApplicationInterface;
     */
    protected $ApplicationRepository;

    /**
     * @var App\Repositories\Contracts\ErrorRepository
     */
    protected $ErrorRepository;

    /**
     * @var App\Repositories\Contracts\DataInterface;
     */
    protected $DataRepository;

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param ApplicationInterface $BusinessRepository
     */
    public function __construct(ApplicationInterface $ApplicationRepository, ErrorRepository $ErrorRepository, DataInterface $DataRepository)
    {
        $this->ApplicationRepository = $ApplicationRepository;
        $this->ErrorRepository    = $ErrorRepository;
        $this->DataRepository = $DataRepository;

        parent::__construct($ApplicationRepository, $ErrorRepository);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param string $action
     * @param Request $Request
     * 
     * @return array
     */
    public function validateRequest(string $action, Request $Request)
    {
        if ($action === config('actions.v1.post')) {

            $output = $this->DataRepository->get(config("workflow-urls.v1.application"), config('fields.v1.application'), $action);

            $this->fields_data = $output['local_fields'] ? $output['fields'] : array_keys($output['fields']);

            array_push($this->fields_data, Application::USER_ID);

            $validator = Validator::make(
                $Request->all(),
                $this->ApplicationRepository->filterValidation(trans('validation_rules.v1.application'), $this->fields_data),
                trans('messages.v1.application')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }
        }

        if ($action === config('actions.v1.get')) {
            if (empty($Request->all())) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.owners')[Application::USER_ID . '.required']]);
            }

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.app_get'),
                trans('messages.v1.application')
            );

            if ($validator->fails()) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
            }
        }

        if ($action === config('actions.v1.get_batch')) {

            // create array for all the present fields
            $validate = [];

            if (!empty($Request->all())) {
                $fields   = config('fields.v1.get_batch_apps');
                foreach (array_keys($Request->all()) as $field) {
                    if (($key = array_search($field, $fields)) !== false) {
                        $validate[$field] = $Request->{$field};
                        unset($fields[$key]);
                    }
                }
            }

            $validator = Validator::make(
                $validate,
                trans('validation_rules.v1.get_batch_apps'),
                trans('messages.v1.get_batch_apps')
            );

            if ($validator->fails()) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
            }
        }

        if ($action === config('actions.v1.put')) {
            $this->fields_data = config('fields.v1.update_app');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.update_app'),
                trans('messages.v1.update_app')
            );

            if ($validator->fails()) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
            }
        }
    }

    /**
     * This routine will validate the incoming PUT request.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param  Request $Request
     *
     * @return array
     */
    protected function validatePutRequest($Request)
    {
    }

    /**
     * Validate ids from master data
     *
     * @param Request $Request
     * 
     * @return void
     */
    private function validateFromMasterData(Request $Request)
    {
        $output = [];

        if ($Request->filled(config('fields.v1.status_id'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.app_status'), $Request->{config('fields.v1.status_id')}, config('master_data.collections.app_status'));
            if (!$found) {
                $output[] = trans('messages.v1.update_app_status')['status_id.regex'];
            }
        }

        return $output;
    }

    /**
     * Update App Status
     *
     * @param Request $Request
     * @param string $app_id
     * 
     * @return void
     */
    public function updateAppStatus(Request $Request, string $app_id)
    {
        if (!$this->ApplicationRepository->get([Application::ID => $app_id])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v2.update_app_status'),
            trans('messages.v1.update_app_status')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }
        if (gettype($Request[config('fields.v1.status_id')]) == 'string') {
            $invalid_status = $this->validateFromMasterData($Request);
            if (!empty($invalid_status)) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [$invalid_status]);
            }
        }


        try {
            $Application = $this->ApplicationRepository->updateMultipleAppStatus($app_id, $Request->only(config('fields.v1.new_update_app_status')));

            if (!$Application instanceof Application) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());

            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ApplicationRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ApplicationRepository->getResourceName(),
            $this->ApplicationRepository->transformResponse($Application, $this->ApplicationRepository->getTransformClass())
        );
    }
}
