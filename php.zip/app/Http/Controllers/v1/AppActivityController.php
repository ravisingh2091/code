<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   AppActivity Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v1;

use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Models\AppActivity;
use App\Repositories\models\Application;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\AppActivity\AppActivityInterface;
use App\Repositories\Contracts\Application\ApplicationInterface;

/**
 * AppActivity Controller class used for handling AppActivity info.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class AppActivityController extends Controller
{
     /**
     * @var App\Repositories\Contracts\AppActivity\AppActivityInterface;
     */
    protected $AppActivityRepository;

     /**
     * @var App\Repositories\Contracts\Application\ApplicationInterface;
     */
    protected $ApplicationRepository;

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param AppActivityInterface $AppActivityRepository
     */
    public function __construct(ErrorRepository $ErrorRepository, AppActivityInterface $AppActivityRepository, ApplicationInterface $ApplicationRepository)
    {
        $this->AppActivityRepository = $AppActivityRepository;
        $this->ErrorRepository    = $ErrorRepository;
        $this->ApplicationRepository = $ApplicationRepository;
       
        parent::__construct($AppActivityRepository, $ErrorRepository);
    }

    /**
     * Update app activity
     *
     * @param Request $Request
     * @param string $activity_id
     * 
     * @return void
     */
    public function updateAppActivity(Request $Request, string $activity_id)
    {
        if(!$this->AppActivityRepository->get([AppActivity::ID => $activity_id])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.update_app_activity'),
            trans('messages.v1.update_app_activity')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        try {
            $AppActivity = $this->AppActivityRepository->update($Request->only(config('fields.v1.update_app_activity')), $activity_id);

            if (is_array($AppActivity) && empty($AppActivity)) {
                $this->AppActivityRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->AppActivityRepository->getResourceName(),
                    []
                );
            }

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }
        
        return $this->AppActivityRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->AppActivityRepository->getResourceName(),
            $AppActivity->toArray()
        );
    }


    /**
     * Reset app activity
     *
     * @param Request $Request
     * 
     * @return void
     */
    public function resetAppActivity(Request $Request)
    {
        if(!$Request->filled(config('fields.v1.app_id'))) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.update_app_activity')['app_id.required']]);
        }
        
        if(!$Request->filled(config('fields.v1.is_completed'))) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.update_app_activity')['is_completed.required']]);
        }

        if(!$Request->filled(config('fields.v1.activities'))) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.update_app_activity')['activities.required']]);
        }

        if(!$this->ApplicationRepository->get([Application::ID => $Request->{config('fields.v1.app_id')}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $AppActivity = $this->AppActivityRepository->reset($Request->only([config('fields.v1.app_id'), config('field.v1.is_completed')]));

            if (is_array($AppActivity) && empty($AppActivity)) {
                return $this->AppActivityRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->AppActivityRepository->getResourceName(),
                    []
                );
            }

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }
        
        return $this->AppActivityRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->AppActivityRepository->getResourceName(),
            $AppActivity->toArray()
        );
    }

     /**
     * Get all app activity
     *
     * @param Request $Request
     * 
     * @return void
     */
    public function getAppActivities(Request $Request)
    {
        if(!$Request->filled(config('fields.v1.app_id'))) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.update_app_activity')['app_id.required']]);
        }

        if(!$this->ApplicationRepository->get([Application::ID => $Request->{config('fields.v1.app_id')}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        if($Request->filled(config('fields.v1.is_completed'))) {
            $Request->merge([config('fields.v1.is_completed') => (int) $Request->{config('fields.v1.is_completed')}]); 
        }

        try {
            $AppActivity = $this->AppActivityRepository->getAll($Request->only([config('fields.v1.app_id'), config('fields.v1.is_completed')]));

            if (is_array($AppActivity) && empty($AppActivity)) {
                return $this->AppActivityRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->AppActivityRepository->getResourceName(),
                    []
                );
            }

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }
        
        return $this->AppActivityRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->AppActivityRepository->getResourceName(),
            $AppActivity->toArray()
        );
    }

    /**
     * Get all app activity
     *
     * @param Request $Request
     * 
     * @return void
     */
    public function getAllAppActivities(Request $Request)
    {
        if(!$Request->filled(config('fields.v1.app_id'))) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.update_app_activity')['app_id.required']]);
        }

        try {
            $app_ids = explode(',', $Request->{config('fields.v1.app_id')});

            $AppActivity = $this->AppActivityRepository->getAllByAppIds($app_ids);

            if (is_array($AppActivity) && empty($AppActivity)) {
                return $this->AppActivityRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->AppActivityRepository->getResourceName(),
                    []
                );
            }

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }
        
        return $this->AppActivityRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->AppActivityRepository->getResourceName(),
            $AppActivity->toArray()
        );
    }

    /**
     * This routine will validate the incoming PUT request.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param  Request $Request
     *
     * @return array
     */
    protected function validateRequest(string $action, Request $Request)
    {
        
    }
}