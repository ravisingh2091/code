<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Hash Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v1;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use App\Repositories\Models\Hash;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Contracts\Hash\HashInterface;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\Owner\OwnersInterface;
use App\Repositories\Contracts\Application\ApplicationInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class HashController extends Controller
{
    /**
     * @var App\Repositories\Entities\Error\ErrorRepository
     */
    protected $ErrorRepository;

    /**
     * @var App\Repositories\Contracts\Hash\HashInterface;
     */
    protected $HashRepository;

    /**
     * @var  App\Repositories\Contracts\Application\ApplicationInterface
     */
    protected $ApplicationRepository;

    /**
     * @var App\Repositories\Contracts\OwnersInterface
     */
    protected $OwnersRepository;

    public function __construct(HashInterface $HashRepository, ErrorRepository $ErrorRepository, ApplicationInterface $ApplicationRepository, OwnersInterface $OwnersRepository)
    {
        $this->HashRepository        = $HashRepository;
        $this->ErrorRepository       = $ErrorRepository;
        $this->ApplicationRepository = $ApplicationRepository;
        $this->OwnersRepository      = $OwnersRepository;
    }


    /**
     * Validate Request
     * 
     * @param $action string
     * @param Request $Request
     *
     * @return array
     */
    public function validateRequest(string $action, Request $Request)
    {

    }

    public function createHash(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.create_hash'),
            trans('messages.v1.create_hash')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        if (!$this->ApplicationRepository->get([Hash::APP_ID => $Request->{Hash::APP_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        if($Request->filled(Hash::OWNER_ID)) {
            if (!$this->OwnersRepository->get([Hash::APP_ID => $Request->{Hash::APP_ID}, Hash::ID => $Request->{Hash::OWNER_ID}])) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }    
        }

        try {
            $Hash = $this->HashRepository->create($Request->only(config('fields.v1.create_hash')));

            if(!$Hash) {
                Log::info($Request->__toString());
                Log::error($Exception->__toString());
            
                return $this->ErrorRepository->errorMessage('ACTION_FAILED');
            }
            
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->HashRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->HashRepository->getResourceName(),
            [
                Hash::HASH => $Hash->{Hash::HASH}
            ]
        );
    }

    /**
     * Verify hash
     *
     * @param string $hash
     *
     * @return string
     */
    public function verifyHash(Request $Request, string $hash)
    {
        $validator = Validator::make(
            [
                Hash::HASH => $hash,
                Hash::HASH_FOR => isset($Request->{Hash::HASH_FOR}) ? $Request->{Hash::HASH_FOR} : ''
            ],
            trans('validation_rules.v1.hash_verify'),
            trans('messages.v1.owners_verify')
        );
        
        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', $validator->errors()->toArray());
        }
        
        try {

            $Hash = $this->HashRepository->get([
                Hash::ENCRYPTED_HASH => $hash,
                Hash::HASH_FOR => isset($Request->{Hash::HASH_FOR}) ? $Request->{Hash::HASH_FOR} : ''
            ]);

            if (!$Hash) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            if (!$this->HashRepository->checkConsentHashExpiry($hash, $Request->{Hash::HASH_FOR}, isset($Hash->{Hash::EXPIRY}) ? $Hash->{Hash::EXPIRY} : '') || !$this->HashRepository->isHashNew($hash, $Request->{Hash::HASH_FOR}) || $this->HashRepository->isHashVerified($hash, $Request->{Hash::HASH_FOR})) {
                return $this->ErrorRepository->errorMessage('TOKEN_EXPIRED');
            }

        } catch (Exception $Exception) {
            Log::info($hash);
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->HashRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->HashRepository->getResourceName(),
            $this->HashRepository->transformResponse($Hash, $this->HashRepository->getTransformClass())
        );
    }

    /**
     * Expire hash
     *
     * @param string $hash
     *
     * @return string
     */
    public function expireHash(Request $Request, string $hash)
    {
        $validator = Validator::make(
            [
                Hash::HASH => $hash,
                Hash::HASH_FOR => isset($Request->{Hash::HASH_FOR}) ? $Request->{Hash::HASH_FOR} : ''
            ],
            trans('validation_rules.v1.hash_verify'),
            trans('messages.v1.owners_verify')
        );
        
        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', $validator->errors()->toArray());
        }
        
        try {

            $Hash = $this->HashRepository->get([
                Hash::ENCRYPTED_HASH => $hash,
                Hash::HASH_FOR => isset($Request->{Hash::HASH_FOR}) ? $Request->{Hash::HASH_FOR} : ''
            ]);

            if (!$Hash) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            $this->HashRepository->update($hash, [Hash::HASH_VERIFIED => true]);

        } catch (Exception $Exception) {
            Log::info($hash);
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->HashRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->HashRepository->getResourceName(),
            []
        );
    }
}

    