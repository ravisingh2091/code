<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   AppAssignment Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v1;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Models\AppAssignment;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\AppAssignment\AppAssignmentInterface;

/**
 * AppAssignment Controller class used for handling AppAssignment info.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class AppAssignmentController extends Controller
{
    protected $fields_data;

    /**
     * @var App\Repositories\Contracts\AppAssignmentInterface;
     */
    protected $AppAssignmentRepository;

    /**
     * @var App\Repositories\Contracts\ErrorRepository
     */
    protected $ErrorRepository;
    
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param AppAssignmentInterface $BusinessRepository
     */
    public function __construct(AppAssignmentInterface $AppAssignmentRepository, ErrorRepository $ErrorRepository)
    {
        $this->AppAssignmentRepository = $AppAssignmentRepository;
        $this->ErrorRepository    = $ErrorRepository;
        
        parent::__construct($AppAssignmentRepository, $ErrorRepository);
    }

    /**
     * Validate Request
     *
     * @param string $action
     * @param Request $Request
     * 
     * @return string
     */
    public function validateRequest(string $action, Request $Request)
    {
        if ($action === config('actions.v1.post')) {
            $this->fields_data = config('fields.v1.save_assignments');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.save_assignments'),
                trans('messages.v1.assignments')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            if($Request->filled(config('fields.v1.assigned_to'))) {
                $Assignment = $this->AppAssignmentRepository->get($Request->only(config('fields.v1.app_id'), config('fields.v1.assigned_to')));
                
                if($Assignment instanceof AppAssignment) {
                    return $this->ErrorRepository->errorMessage('BAD_REQUEST');
                }
            }
        }

        if ($action === config('actions.v1.delete')) {
            $this->fields_data = $Request->delete_all == 1 ? [config('fields.v1.app_id')] : config('fields.v1.delete_assignments');

            $validator = Validator::make(
                $Request->all(),
                $Request->delete_all == 1 ? ['app_id' => trans('validation_rules.v1.delete_assignments.app_id')] :trans('validation_rules.v1.delete_assignments'),
                trans('messages.v1.assignments')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }
        }
    }

    /**
     * Delete assignments
     *
     * @param Request $Request
     * 
     * @return string
     */
    public function deleteAssignments(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.delete'), $Request)) {
            if($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        if(!$this->AppAssignmentRepository->get($Request->only($this->fields_data))) {
            return $this->AppAssignmentRepository->dispatchResponse(
                trans('messages.v1.success'),
                Response::HTTP_OK,
                $this->AppAssignmentRepository->getResourceName()
            );
        }

        try {
            $deleted = $this->AppAssignmentRepository->delete($Request->only($this->fields_data));

        } catch(Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->AppAssignmentRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->AppAssignmentRepository->getResourceName()
        );
    }

    /**
     * Get App Assignments
     *
     * @param string $Request
     * 
     * @return string
     */
    public function getAppAssignments(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.get_app_assignment'),
            trans('messages.v1.get_app_assignment')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        try {
            $AppAssignments = $this->AppAssignmentRepository->getAppAssignment($Request);

            if (is_array($AppAssignments) && empty($AppAssignments)) {
                $this->AppAssignmentRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->AppAssignmentRepository->getResourceName(),
                    [
                        config('fields.v1.applications')=> [],
                        config('fields.v1.total_apps') => 0
                    ]
                );
            }

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }
        
        return $this->AppAssignmentRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->AppAssignmentRepository->getResourceName(),
            $AppAssignments
        );
    }

    /**
     * Get app count according to status belonging to a particular role or for all roles
     *
     * @param Request $Request
     * 
     * @return string
     */
    public function getByRoleId(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.get_by_role_id'),
            trans('messages.v1.get_by_role_id')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        try {
            $AppAssignments = $this->AppAssignmentRepository->getAppAssignmentsByRoleId($Request);

            if (is_array($AppAssignments) && empty($AppAssignments)) {
                return $this->AppAssignmentRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->AppAssignmentRepository->getResourceName(),
                    []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->AppAssignmentRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->AppAssignmentRepository->getResourceName(),
            [ 'apps_by_role' => $AppAssignments]
        );
    }
}
