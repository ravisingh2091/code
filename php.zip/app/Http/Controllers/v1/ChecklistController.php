<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Checklist Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v1;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Repositories\Models\Checklist;
use App\Repositories\Models\Application;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\Checklist\ChecklistInterface;
use App\Repositories\Contracts\Application\ApplicationInterface;

/**
 * Checklist Controller class used for handling Checklist info.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ChecklistController extends Controller
{
    protected $fields_data;

    /**
     * @var App\Repositories\Contracts\ChecklistInterface;
     */
    protected $ChecklistRepository;

    /**
     * @var App\Repositories\Contracts\ErrorRepository
     */
    protected $ErrorRepository;

    /**
     * @var App\Repositories\Contracts\ApplicationInterface;
     */
    protected $ApplicationRepository;
    
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param ChecklistInterface $BusinessRepository
     */
    public function __construct(ChecklistInterface $ChecklistRepository, ErrorRepository $ErrorRepository, ApplicationInterface $ApplicationRepository)
    {
        $this->ChecklistRepository   = $ChecklistRepository;
        $this->ErrorRepository       = $ErrorRepository;
        $this->ApplicationRepository = $ApplicationRepository;
        
        parent::__construct($ChecklistRepository, $ErrorRepository);
    }

    /**
     * Validate Request
     *
     * @param string $action
     * @param Request $Request
     * 
     * @return string
     */
    public function validateRequest(string $action, Request $Request)
    {
        if ($action === config('actions.v1.post')) {
            $this->fields_data = config('fields.v1.save_checklist');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.save_checklist'),
                trans('messages.v1.save_checklist')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            $Application = $this->ApplicationRepository->get([Checklist::APP_ID => $Request->{Checklist::APP_ID}]);

            if(!$Application instanceof Application) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        }

        if ($action === config('actions.v1.post_batch')) {
            $this->fields_data = config('fields.v1.save_multiple_checklist');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.save_multiple_checklist'),
                trans('messages.v1.save_checklist')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            $Application = $this->ApplicationRepository->get([Checklist::APP_ID => $Request->{Checklist::APP_ID}]);

            if(!$Application instanceof Application) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        }

        if ($action === config('actions.v1.put')) {
            $this->fields_data = config('fields.v1.update_checklist');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.update_checklist'),
                trans('messages.v1.update_checklist')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            if(empty($Request->only(config('fields.v1.comment'), config('fields.v1.checklist_action')))) {
                return $this->ErrorRepository->errorMessage('BAD_REQUEST');
            }
        }

        if ($action === config('actions.v1.get')) {
            $this->fields_data = config('fields.v1.get_checklist');
            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.get_checklist'),
                trans('messages.v1.get_checklist')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            // $Application = $this->ApplicationRepository->get([Checklist::APP_ID => $Request->{Checklist::APP_ID}]);

            // if(!$Application instanceof Application) {
            //     return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            // }
        }
    }

    /**
     * Get checklist
     *
     * @param string $id
     * 
     * @return string
     */
    public function getChecklist(string $id)
    {
        try {
            $Checklist = $this->ChecklistRepository->get([Checklist::ID => $id]);

            if(!$Checklist instanceof Checklist) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND'); 
            }

        } catch(Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ChecklistRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ChecklistRepository->getResourceName(),
            $this->ChecklistRepository->transformResponse($Checklist, $this->ChecklistRepository->getTransformClass())
        );
    }

    /**
     * Get all checklists
     *
     * @param Request $Request
     * 
     * @return string
     */
    public function getAllChecklist(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.get'), $Request)) {
            if($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $app_ids = explode(',', $Request->{Checklist::APP_ID});

            $Checklist = $this->ChecklistRepository->getAll($app_ids)->toArray();

            if(!$Checklist) {
                return $this->ChecklistRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ChecklistRepository->getResourceName(),
                    []
                ); 
            }

        } catch(Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ChecklistRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ChecklistRepository->getResourceName(),
            [config('fields.v1.checklists') => $Checklist]
        );
    }

    /**
     * Save multiple checklists
     *
     * @param Request $Request
     * 
     * @return void
     */
    public function putBatch(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.post_batch'), $Request)) {
            if($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $params = $Request->only($this->fields_data);
            unset($params[config('fields.v1.checklists')]);
            $Checklists = [];

            foreach($Request->{config('fields.v1.checklists')} as $checklist) {
                $params = array_merge($params, $checklist);

                $Checklists[] = $this->ChecklistRepository->create($params);
            }

        } catch(Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ChecklistRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->ChecklistRepository->getResourceName(),
            $Checklists
        );
    }

    /**
     * Save multiple checklists
     *
     * @param Request $Request
     * 
     * @return void
     */
    public function postBatch(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.post_batch'), $Request)) {
            if($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $params = $Request->only($this->fields_data);
            unset($params[config('fields.v1.checklists')]);
            $Checklists = [];

            foreach($Request->{config('fields.v1.checklists')} as $checklist) {
                $params = array_merge($params, $checklist);

                $Checklists[] = $this->ChecklistRepository->createChecklist($params);
            }

        } catch(Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ChecklistRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->ChecklistRepository->getResourceName(),
            $Checklists
        );
    }

}
