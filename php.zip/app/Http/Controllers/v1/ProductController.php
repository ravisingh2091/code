<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Product Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v1;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Repositories\Models\Product;
use App\Repositories\Models\Application;
use App\Repositories\Models\ServiceProduct;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Contracts\Data\DataInterface;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\Service\ServiceInterface;
use App\Repositories\Contracts\Product\ProductInterface;
use App\Repositories\Contracts\Application\ApplicationInterface;

/**
 * Product Controller class used for handling Product info.
 *
 * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
 */
class ProductController extends Controller
{
    protected $fields_data;

    /**
     * @var App\Repositories\Contracts\ProductInterface;
     */
    protected $ProductRepository;

    /**
     * @var App\Repositories\Contracts\ApplicationInterface;
     */
    protected $ApplicationRepository;

    /**
     * @var App\Repositories\Contracts\ErrorRepository
     */
    protected $ErrorRepository;

    /**
     * @var  App\Repositories\Contracts\Service\ServiceInterface
     */
    protected $ServiceRepository;

    /**
     * @var  App\Repositories\Contracts\Data\DataInterface
     */
    protected $DataRepository;

    /**
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param ProductInterface $ProductRepository
     */
    public function __construct(ProductInterface $ProductRepository, ErrorRepository $ErrorRepository, ApplicationInterface $ApplicationRepository, ServiceInterface $ServiceRepository, DataInterface $DataRepository)
    {
        $this->ProductRepository     = $ProductRepository;
        $this->ErrorRepository       = $ErrorRepository;
        $this->ApplicationRepository = $ApplicationRepository;
        $this->ServiceRepository     = $ServiceRepository;
        $this->DataRepository        = $DataRepository;
        
        parent::__construct($ProductRepository, $ErrorRepository);
    }

    /**
     * Validate Request
     *
     * @param string $action
     * @param Request $Request
     * 
     * @return string
     */
    public function validateRequest(string $action, Request $Request)
    {
     
        if ($action === config('actions.v1.post') || ($action === config('actions.v1.update_batch'))) {

            if ($errors = $this->isRequestContainsType($Request)) {
                return $errors;
            }

            $orchestration_url = config("workflow-urls.v1.product");
            $headers = [];
            if($Request->filled(config('fields.v1.orch_url'))) {
                $orchestration_url = $Request->get(config('fields.v1.orch_url'));
                $headers['x-region'] = $Request->header('x-region');
            }
            
            $output = $this->ProductRepository->getFields($orchestration_url, config('fields.v1.product_info'), $Request->{config('fields.v1.action_type')}, $Request->{config('fields.v1.slug')}, $headers);
 
            // fields & validation received from orchestration or not
            if(!$output) {
                return $this->ErrorRepository->getValidationError(config('fields.v1.service_unavailable'), trans('messages.v1.service_unavailable'), 'SERVICE_UNAVAILABLE');
            } else if($output['local_fields']) {
                return $this->ErrorRepository->getValidationError(config('fields.v1.service_unavailable'), trans('messages.v1.service_unavailable'), 'SERVICE_UNAVAILABLE'); 
            }

            $global_rules = $output['fields'];

            $validationMessages = $this->ProductRepository->bindValidations($global_rules);
            
            $this->fields_data = config('fields.v1.products'); 
            
            foreach($Request->{config('fields.v1.products_field')} as $Product) {
                $validator = Validator::make(
                    $Product,
                    $global_rules,
                    $validationMessages
                );

                if ($validator->fails()) {
                    return $validator->errors();
                }
            }
        }
        
        if ($action === config('actions.v1.put')) {

            if ($errors = $this->isRequestContainsType($Request)) {
                return $errors;
            }

            $orchestration_url = config("workflow-urls.v1.product");
            $headers = [];
            if($Request->filled(config('fields.v1.orch_url'))) {
                $orchestration_url = $Request->get(config('fields.v1.orch_url'));
                $headers['x-region'] = $Request->header('x-region');
                
            }

            $output = $this->ProductRepository->getFields($orchestration_url, config('fields.v1.update_product'), $Request->{config('fields.v1.action_type')}, $Request->{config('fields.v1.slug')}, $headers);
            
            // fields & validation received from orchestration or not
            if(!$output) {
                return $this->ErrorRepository->getValidationError(config('fields.v1.service_unavailable'), trans('messages.v1.service_unavailable'), 'SERVICE_UNAVAILABLE');
            } else if($output['local_fields']) {
                return $this->ErrorRepository->getValidationError(config('fields.v1.service_unavailable'), trans('messages.v1.service_unavailable'), 'SERVICE_UNAVAILABLE'); 
            }

            $this->fields_data = array_keys($output['fields']);

            $global_rules = $output['fields'];

            $validationMessages = $this->ProductRepository->bindValidations($global_rules);

            $validator = Validator::make(
                $Request->all(),
                $global_rules,
                $validationMessages
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            if(empty($Request->only(config('fields.v1.update_product')))) {
                return $this->ErrorRepository->errorMessage('BAD_REQUEST');
            }
        }

        if ($action === config('actions.v1.get')) {
            $this->fields_data = config('fields.v1.get_product');
        }
    }

    /**
     * The post request creates a new resource
     * 
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param  Request $Request
     *
     * @return string
     */
    public function postBatch(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.post'), $Request)) {
            if($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $Response = $this->ProductRepository->create($Request->only($this->fields_data));
  
            if (!$Response)  throw new BlankDataException(); 

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ProductRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->ProductRepository->getResourceName(),
            $this->ProductRepository->transformResponseArr($Response, $this->ProductRepository->getTransformClass())
        );
    }

    /**
     * The post request creates a new resource
     * 
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param  Request $Request
     *
     * @return string
     */
    public function updateBatch(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.update_batch'), $Request)) {
            if($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $Response = $this->ProductRepository->updateBatch($Request->only($this->fields_data));
            
            if (!$Response)  throw new BlankDataException(); 

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ProductRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->ProductRepository->getResourceName(),
            $this->ProductRepository->transformResponseArr($Response, $this->ProductRepository->getTransformClass())
        );
    }

    /**
     * Get Product
     *
     * @param string $id
     * 
     * @return string
     */
    public function getProduct(string $id)
    {
        try {
            $Product = $this->ProductRepository->get([Product::ID => $id]);

            if(!$Product instanceof Product) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND'); 
            }

        } catch(Exception $Exception) {
            Log::info($id);
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ProductRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ProductRepository->getResourceName(),
            $this->ProductRepository->transformResponse($Product, $this->ProductRepository->getTransformClass())
        );
    }

    /**
     * Get all Products
     *
     * @param Request $Request
     * 
     * @return string
     */
    public function getAllProduct(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.get'), $Request)) return $errors;

        try {
            $Product = $this->ProductRepository->getAll($Request->only($this->fields_data))->toArray();

            if(!$Product) {
                return $this->ProductRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ProductRepository->getResourceName(),
                    []
                ); 
            }

        } catch(Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ProductRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ProductRepository->getResourceName(),
            $this->ProductRepository->transformResponseArr($Product, $this->ProductRepository->getTransformClass())
        );
    }

    /**
     * Save Product References
     *
     * @param Request $Request
     *
     * @return string
     */
    public function saveReferences(Request $Request) 
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.save_product_ids'),
            trans('messages.v1.save_service_ids')
        );
        
        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // check if Product exists by app_id and user_id
        if(!$this->ProductRepository->get([Product::APP_ID => $Request->{Product::APP_ID}, Product::USER_ID => $Request->{Product::USER_ID}, Product::ID => $Request->{ServiceInterface::Product_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        // check if provider and type are valid in master data
        $invalid_provider = $this->validateFromMasterData($Request);

        if(!empty($invalid_provider)) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', [$invalid_provider]);
        }
        
        try {
            $ServiceProduct = $this->ServiceRepository->saveServiceProduct($Request->only(config('fields.v1.save_product_ids')));
            
            if (!$ServiceProduct instanceof ServiceProduct) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->ServiceRepository->getResourceName(),
            $this->ServiceRepository->transformResponse($ServiceProduct, $this->ServiceRepository->getTransformClass())
        );        
    }

    /**
     * Get Product references
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getReferences(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.get_product_ids'),
            trans('messages.v1.save_service_ids')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // check if Product exists by app_id and user_id
        if(!$this->ProductRepository->get([Product::APP_ID => $Request->{Product::APP_ID}, Product::USER_ID => $Request->{Product::USER_ID}, Product::ID => $Request->{ServiceInterface::Product_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $ServiceProduct = $this->ServiceRepository->getServiceProduct($Request->only(config('fields.v1.get_product_ids')));
                  
            if(isset($Servicep->type) && in_array($ServiceProduct->type, config('fields.v1.get_all_reference_types'))) {
                $ServiceProductAll = $this->ServiceRepository->getAllProductReferences($Request->only(config('fields.v1.get_product_ids')));
            }
            
            if (!$ServiceProduct instanceof ServiceProduct) {
                return $this->ServiceRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ServiceRepository->getResourceName(),
                    []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ServiceRepository->getResourceName(),
            isset($ServiceProductAll) ? $ServiceProductAll->toArray():$this->ServiceRepository->transformResponse($ServiceProduct, $this->ServiceRepository->getTransformClass())
        );
    }

    /**
     * Get all references
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getAllReferences(Request $Request)
    {
        $global_rules = trans('validation_rules.v1.owners_get');
        
        $validator = Validator::make(
            $Request->all(),
            $global_rules,
            trans('messages.v1.owners')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // return 404 if application not found
        if (!$this->ApplicationRepository->get([Product::APP_ID => $Request->{Product::APP_ID}, Product::USER_ID=> $Request->{Product::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $ServiceProduct = $this->ServiceRepository->getAllServiceProduct([Product::APP_ID => $Request->{Product::APP_ID}, Product::USER_ID=> $Request->{Product::USER_ID}])->toArray();
                  
            if (!$ServiceProduct) {
                return $this->ServiceRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ServiceRepository->getResourceName(),
                    []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ServiceRepository->getResourceName(),
            $ServiceProduct
        );
    }

    /**
     * Get products by multiple application
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param Request $Request
     * 
     * @return string
     */
    public function getAppProducts(Request $Request)
    {
        $app_id_arr = $Request->toArray();
   
        if (!isset($app_id_arr['app_ids']) || !is_array($app_id_arr['app_ids'])) {
            $app_id_arr['app_ids'] = [];
        }

        try {
            $Product = $this->ProductRepository->getByApplications($app_id_arr['app_ids'])->toArray();

        } catch(Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ProductRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ProductRepository->getResourceName(),
            !$Product ? [] :$this->ProductRepository->transformResponseArr($Product, $this->ProductRepository->getTransformClass())
        );
    }

    /**
     * Validate data from master data
     *
     * @return string
     */
    private function validateFromMasterData(Request $Request) 
    {
        $output = [];

        if ($Request->filled(config('fields.v1.provider'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.service_provider'), $Request->{config('fields.v1.provider')}, config('master_data.collections.service_provider'));
            
            if(!$found || $found->{config('fields.v1.type')} !== $Request->{config('fields.v1.type')}) {
                $output[] = trans('messages.v1.save_service_ids')['provider.regex'];
            }
        }

        return $output;
    }

}
