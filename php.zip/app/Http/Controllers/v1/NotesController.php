<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Notes Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v1;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use App\Repositories\Models\Note;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Repositories\Models\Application;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\Notes\NotesInterface;
use App\Repositories\Contracts\Application\ApplicationInterface;

/**
 * Notes Controller class used for handling Notes info.
 */
class NotesController extends Controller
{
    protected $fields_data;

    /**
     * @var App\Repositories\Contracts\NotesInterface;
     */
    protected $NotesRepository;

    /**
     * @var App\Repositories\Contracts\ErrorRepository
     */
    protected $ErrorRepository;

    /**
     * @var App\Repositories\Contracts\ApplicationInterface;
     */
    protected $ApplicationRepository;
    
    /**
     * @param NotesInterface $NotesRepository
     */
    public function __construct(NotesInterface $NotesRepository, ErrorRepository $ErrorRepository, ApplicationInterface $ApplicationRepository)
    {
        $this->NotesRepository       = $NotesRepository;
        $this->ErrorRepository       = $ErrorRepository;
        $this->ApplicationRepository = $ApplicationRepository;
        
        parent::__construct($NotesRepository, $ErrorRepository);
    }

    /**
     * Validate Request
     *
     * @param string $action
     * @param Request $Request
     * 
     * @return string
     */
    public function validateRequest(string $action, Request $Request)
    {
        if ($action === config('actions.v1.post')) {
            $this->fields_data = config('fields.v1.create_note');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.create_note'),
                trans('messages.v1.create_note')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            $Application = $this->ApplicationRepository->get([Note::APP_ID => $Request->{Note::APP_ID}]);

            if(!$Application instanceof Application) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        }

        if ($action === config('actions.v1.get')) {
            $this->fields_data = config('fields.v1.get_notes');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.get_notes'),
                trans('messages.v1.create_note')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            $Application = $this->ApplicationRepository->get([Note::APP_ID => $Request->{Note::APP_ID}]);

            if(!$Application instanceof Application) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        }

        if ($action === config('actions.v1.get_batch')) {
            $this->fields_data = config('fields.v1.get_notes_all');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.get_notes_all'),
                trans('messages.v1.create_note')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }
        }
    }

    /**
     * Get Notes
     *
     * @param Request $Request
     * 
     * @return string
     */
    public function getNotes(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.get'), $Request)) {
            if($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $Notes = $this->NotesRepository->get($Request->only($this->fields_data))->toArray();

            if(!$Notes) {
                return $this->NotesRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->NotesRepository->getResourceName(),
                    []
                ); 
            }

        } catch(Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->NotesRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->NotesRepository->getResourceName(),
            $Notes
        );
    }

    /**
     * Get Notes
     *
     * @param Request $Request
     * 
     * @return string
     */
    public function getAllNotes(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.get_batch'), $Request)) {
            if($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $app_ids = explode(',', $Request->{Note::APP_ID});

            $Notes = $this->NotesRepository->getAll($app_ids)->toArray();

            if(!$Notes) {
                return $this->NotesRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->NotesRepository->getResourceName(),
                    []
                ); 
            }

        } catch(Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->NotesRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->NotesRepository->getResourceName(),
            $Notes
        );
    }
}
