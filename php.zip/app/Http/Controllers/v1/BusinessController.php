<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Business Info Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v1;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\Models\Business;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Models\ServiceBusiness;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Contracts\Data\DataInterface;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\Service\ServiceInterface;
use App\Repositories\Contracts\Business\BusinessInterface;
use App\Repositories\Contracts\Application\ApplicationInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Business Controller class used for handling business info.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class BusinessController extends Controller
{
    protected $fields_data;

    /**
     * @var App\Repositories\Contracts\BusinessInterface
     */
    protected $BusinessRepository;

    /**
     * @var App\Repositories\Contracts\ErrorRepository
     */
    protected $ErrorRepository;

    /**
     * @var  App\Repositories\Contracts\Application\ApplicationInterface 
     */
    protected $ApplicationRepository;

    /**
     * @var App\Repositories\Contracts\Data\DataInterface 
     */
    protected $DataRepository;

    /**
     * @var  App\Repositories\Contracts\Service\ServiceInterface
     */
    protected $ServiceRepository;

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param BusinessInterface $BusinessRepository
     * @param ErrorRepository $ErrorRepository
     * @param ApplicationInterface $ApplicationRepository
     * @param ServiceInterface $ServiceRepository
     */
    public function __construct(BusinessInterface $BusinessRepository, 
                                ErrorRepository $ErrorRepository, 
                                ApplicationInterface $ApplicationRepository,
                                DataInterface $DataRepository,
                                ServiceInterface $ServiceRepository)
    {
        $this->BusinessRepository    = $BusinessRepository;
        $this->ErrorRepository       = $ErrorRepository;
        $this->ApplicationRepository = $ApplicationRepository;
        $this->DataRepository        = $DataRepository;
        $this->ServiceRepository     = $ServiceRepository;

        parent::__construct($BusinessRepository, $ErrorRepository);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $action
     * @param Request $Request
     *
     * @return string
     */
    protected function validateRequest(string $action, Request $Request)
    {
        if (($action === config('actions.v1.put')) || ($action === config('actions.v1.post'))) {
             
            if ($errors = $this->isRequestContainsType($Request)) {
                return $errors;
            }

            // check orchestration url in the request and slug
            $orchestration_url = config("workflow-urls.v1.business");
            $headers = [];
            if($Request->filled(config('fields.v1.orch_url'))) {
                $orchestration_url = $Request->get(config('fields.v1.orch_url'));
                $headers['x-region'] = $Request->header('x-region');
            }

            //pass type from form data (i.e save, continue)
            $output = $this->BusinessRepository->getFields($orchestration_url, config('fields.v1.business'), $Request->{config('fields.v1.action_type')}, $Request->{config('fields.v1.slug')}, $headers);

            // fields & validation received from orchestration or not
            if(!$output) {
                return $this->ErrorRepository->getValidationError(config('fields.v1.service_unavailable'), trans('messages.v1.service_unavailable'), 'SERVICE_UNAVAILABLE');
            }

            // check if fields are from orchestration and slug is in request
            if(!$output['local_fields'] && !is_null($Request->{config('fields.v1.slug')})) {
                // check if slug is valid or not
                if(isset($output['type']) && (!in_array($output['type'],config('slug.v1.business')))) {
                    return $this->ErrorRepository->getValidationError(config('fields.v1.slug'), trans('messages.v1.slug'));
                }
            }
            
            if(!$output['local_fields']) {
                $this->BusinessRepository->validateVisibleFields($output, $Request);
            }

            $global_rules = $output['fields'];

            $global_rules = array_merge($global_rules, trans('validation_rules.v1.user_app'));
            // validation  build from form_fields
            $validationMessages = $this->BusinessRepository->bindValidations($global_rules);
            
            //set the fields array
            $this->fields_data = array_keys($global_rules);
          
            $validator = Validator::make(
                                $Request->all(),
                                $global_rules,
                                $validationMessages);
            if ($validator->fails()) {
                return $validator->errors();
            }

            if(!$Request->has(config('fields.v1.check_master')) || ($Request->has(config('fields.v1.check_master')) && $Request->{config('fields.v1.check_master')} == true)) {
                $ids = $this->validateFromMasterData($Request);
                if(!empty($ids)) {
                    return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [$ids]);
                }
            }
            
            if ($action === config('actions.v1.post')) {
                //check unique app_id
                if($errors = $this->isAppExist($Request)) {
                    return $this->ErrorRepository->getValidationError(config('fields.v1.app_id'), trans('messages.v1.business')[config('fields.v1.app_id').'.unique']);   
                }
            }

            // validate trade_name
            if ($errors = $this->validateTradeName($Request)) {
                return $errors;
            }
            
            // validate mail_address
            if ($errors = $this->validateBusinessAddress($Request)) {
                return $errors;
            }

            // validate register_address
            if ($errors = $this->validateMailAdress($Request)) {
                return $errors;
            }
            
            // return 404 if application not found
            if (!$this->ApplicationRepository->get($Request->only(Business::APP_ID, Business::USER_ID))) {
                throw new NotFoundHttpException();
            }
        }
      
        if ($action === config('actions.v1.get')) {
            $global_rules = trans('validation_rules.v1.business_get_by_app_id');
            
            $validator = Validator::make(
                $Request->all(),
                $global_rules,
                trans('messages.v1.business'));

            if ($validator->fails()) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
            }
        }
    }

    /**
     * validate if trade name required
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    private function validateTradeName(Request $Request)
    {
        if ($Request->has(config('fields.v1.trade_name_same_as_legal')) && strtolower($Request->{config('fields.v1.trade_name_same_as_legal')}) == 'yes') {
            $Request->merge([config('fields.v1.trade_name') => $Request->{config('fields.v1.business_name')}]); 
        }
    }

    /**
     * validate if business address is required
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     * @param array $global_rules
     * @return string
     */
    private function validateBusinessAddress(Request $Request) 
    {
        if ($Request->has(config('fields.v1.business_address_same_as_registered')) && strtolower($Request->{config('fields.v1.business_address_same_as_registered')}) == 'yes') {
            $Request->merge([config('fields.v1.business_address_line_one')     => $Request->{config('fields.v1.company_address_line_one')}]);
            $Request->merge([config('fields.v1.business_address_line_two')     => $Request->{config('fields.v1.company_address_line_two')}]);
            $Request->merge([config('fields.v1.business_address_city')         => $Request->{config('fields.v1.company_address_city')}]);
            $Request->merge([config('fields.v1.business_address_country')      => $Request->{config('fields.v1.company_address_country')}]);
            $Request->merge([config('fields.v1.business_address_postal_code')  => $Request->{config('fields.v1.company_address_postal_code')}]);
            $Request->merge([config('fields.v1.business_address_province')     => $Request->{config('fields.v1.company_address_province')}]);
            $Request->merge([config('fields.v1.business_address_civic_number') => $Request->{config('fields.v1.company_address_civic_number')}]);
        }
    }

    /**
     * validate if mail address is required
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    private function validateMailAdress(Request $Request)
    {
        if ($Request->has(config('fields.v1.mail_address_same_as_registered')) && strtolower($Request->{config('fields.v1.mail_address_same_as_registered')}) == 'yes') {
            $Request->merge([config('fields.v1.mail_address_line_one')     => $Request->{config('fields.v1.company_address_line_one')}]);
            $Request->merge([config('fields.v1.mail_address_line_two')     => $Request->{config('fields.v1.company_address_line_two')}]);
            $Request->merge([config('fields.v1.mail_address_city')         => $Request->{config('fields.v1.company_address_city')}]);
            $Request->merge([config('fields.v1.mail_address_country')      => $Request->{config('fields.v1.company_address_country')}]);
            $Request->merge([config('fields.v1.mail_address_postal_code')  => $Request->{config('fields.v1.company_address_postal_code')}]);
            $Request->merge([config('fields.v1.mail_address_province')     => $Request->{config('fields.v1.company_address_province')}]);
            $Request->merge([config('fields.v1.mail_address_civic_number') => $Request->{config('fields.v1.company_address_civic_number')}]);
        }
    }

     /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     * 
     * @return array
     */
    public function validateGetRequest($Request)
    {
        if (!$Request->has(Business::USER_ID)) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.owners')[Business::USER_ID.'.required']]);
        }
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     * 
     * @return string
     */
    private function isBusinessExist($Request)
    {   
        if($Request->has(config('fields.v1.business_name'))) {
            $Business = $this->BusinessRepository->getBusiness(config('fields.v1.business_name'), $Request->{config('fields.v1.business_name')});
            if($Business instanceof Business) {
                $result = config('fields.v1.business_name');
                return $result;
            } 
        }

        if($Request->has(config('fields.v1.business_number'))){
            $Business = $this->BusinessRepository->getBusiness(config('fields.v1.business_number'), $Request->{config('fields.v1.business_number')});
            if($Business instanceof Business) {
                $result = config('fields.v1.business_number');
                return $result;
            }
        }
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     * 
     * @return bool
     */
    private function isAppExist($Request)
    {
        $Business = $this->BusinessRepository->get([Business::APP_ID => $Request->{Business::APP_ID}]);
        if($Business instanceof Business) {
            return true;
        }
        return false;
    }

    /**
     * Get Business by business_id
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $business_id
     * 
     * @return string
     */
    public function getByBusinessId(string $business_id)
    {
        $validator = Validator::make(
            [config('fields.v1.biz_id') => $business_id],
            trans('validation_rules.v1.business_get'),
            trans('messages.v1.business_get')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        try {
            $Business = $this->BusinessRepository->get([Business::ID => $business_id]);
                  
            if (!$Business instanceof Business) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        } catch (Exception $Exception) {
            Log::info($business_id);
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->BusinessRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->BusinessRepository->getResourceName(),
            $this->BusinessRepository->transformResponse($Business, $this->BusinessRepository->getTransformClass())
        );
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    private function validateFromMasterData(Request $Request) 
    {
        $output = [];

        if ($Request->filled(config('fields.v1.business_structure'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.business_structure'), $Request->{config('fields.v1.business_structure')}, config('master_data.collections.business_structure'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['business_structure.regex'];
            }
        }
        
        if ($Request->filled(config('fields.v1.business_nature'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.business_nature'), $Request->{config('fields.v1.business_nature')}, config('master_data.collections.business_nature'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['business_nature.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.business_presence'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.business_presence'), $Request->{config('fields.v1.business_presence')}, config('master_data.collections.business_presence'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['business_presence.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.time_at_curr_loc_in_year'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.time_at_curr_loc_in_year'), $Request->{config('fields.v1.time_at_curr_loc_in_year')}, config('master_data.collections.time_at_curr_loc_in_year'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['time_at_curr_loc_in_year.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.industry'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.industry'), $Request->{config('fields.v1.industry')}, config('master_data.collections.industry'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['industry.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.type_of_business'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.type_of_business'), $Request->{config('fields.v1.type_of_business')}, config('master_data.collections.type_of_business'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['type_of_business.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.type_of_products_and_services'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.type_of_products_and_services'), $Request->{config('fields.v1.type_of_products_and_services')}, config('master_data.collections.type_of_products_and_services'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['type_of_products_and_services.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.rationale_for_revenue'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.rationale_for_revenue'), $Request->{config('fields.v1.rationale_for_revenue')}, config('master_data.collections.rationale_for_revenue'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['rationale_for_revenue.regex'];
            }
        }
       
        if ($Request->filled(config('fields.v1.business_facilities'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.business_facilities'), $Request->{config('fields.v1.business_facilities')}, config('master_data.collections.business_facilities'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['business_facilities.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.is_owner_politically_exposed'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.is_owner_politically_exposed'), $Request->{config('fields.v1.is_owner_politically_exposed')}, config('master_data.collections.is_owner_politically_exposed'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['is_owner_politically_exposed.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.purpose_of_loan'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.purpose_of_loan'), $Request->{config('fields.v1.purpose_of_loan')}, config('master_data.collections.purpose_of_loan'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['purpose_of_loan.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.requested_term'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.requested_term'), $Request->{config('fields.v1.requested_term')}, config('master_data.collections.requested_term'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['requested_term.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.operation_years'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.operation_years'), $Request->{config('fields.v1.operation_years')}, config('master_data.collections.operation_years'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['operation_years.regex'];
            }
        }
        
        if ($Request->filled(config('fields.v1.jurisdiction_key'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.jurisdiction_key'), $Request->{config('fields.v1.jurisdiction_key')}, config('master_data.collections.jurisdiction_key'));
            if(!$found) {
                $output[] = trans('messages.v1.business')['jurisdiction_key.regex'];
            }
        }

        if ($Request->filled(config('fields.v1.provider'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.service_provider'), $Request->{config('fields.v1.provider')}, config('master_data.collections.service_provider'));
            
            if(!$found || $found->{config('fields.v1.type')} !== $Request->{config('fields.v1.type')}) {
                $output[] = trans('messages.v1.save_service_ids')['provider.regex'];
            }
        }

        return $output;
    }

    /**
     * Save Business Reference Ids
     * 
     * @param Request $Request
     *
     * @return string
     */
    public function saveReferences(Request $Request) 
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.save_business_ids'),
            trans('messages.v1.save_service_ids')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // check if Application exists by app_id and user_id
        if(!$this->BusinessRepository->get([Business::APP_ID => $Request->{Business::APP_ID}, Business::USER_ID => $Request->{Business::USER_ID}])) { 
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        // check if provider and type are valid in master data
        $invalid_provider = $this->validateFromMasterData($Request);

        if(!empty($invalid_provider)) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', [$invalid_provider]);
        }
        
        try {
            $ServiceBusiness = $this->ServiceRepository->saveServiceBusiness($Request->only(config('fields.v1.save_business_ids')));
                  
            if (!$ServiceBusiness instanceof ServiceBusiness) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->ServiceRepository->getResourceName(),
            $this->ServiceRepository->transformResponse($ServiceBusiness, $this->ServiceRepository->getTransformClass())
        );        
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getReferences(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.get_business_ids'),
            trans('messages.v1.save_service_ids')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // check if Application exists by app_id and user_id
        if(!$this->BusinessRepository->get([Business::APP_ID => $Request->{Business::APP_ID}, Business::USER_ID => $Request->{Business::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $ServiceBusiness = $this->ServiceRepository->getServiceBusiness($Request->only(config('fields.v1.get_business_ids')));
            
            if(isset($ServiceBusiness->type) && in_array($ServiceBusiness->type, config('fields.v1.get_all_reference_types'))) {
                $ServiceBusinessAll = $this->ServiceRepository->getAllReferences($Request->only(config('fields.v1.get_business_ids')));
            }

            if (!$ServiceBusiness instanceof ServiceBusiness) {
                return $this->ServiceRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ServiceRepository->getResourceName(),
                    []
                );
            }
            
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ServiceRepository->getResourceName(),
            isset($ServiceBusinessAll) ? $ServiceBusinessAll->toArray(): $this->ServiceRepository->transformResponse($ServiceBusiness, $this->ServiceRepository->getTransformClass())
        );
    }

    /**
     * Delete references
     *
     * @param string $ref_id
     * 
     * @return string
     */
    public function deleteReferences(string $ref_id)
    {
        try {
            $delete = $this->ServiceRepository->deleteBusinessByRefId($ref_id);

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ServiceRepository->getResourceName(),
            []
        );
    }

    /**
     * Get all references
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getAllReferences(Request $Request)
    {
        $global_rules = trans('validation_rules.v1.owners_get');
        
        $validator = Validator::make(
            $Request->all(),
            $global_rules,
            trans('messages.v1.owners')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // return 404 if application not found
        if (!$this->ApplicationRepository->get([Business::APP_ID => $Request->{Business::APP_ID}, Business::USER_ID=> $Request->{Business::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $ServiceBusiness = $this->ServiceRepository->getAllServiceBusiness([Business::APP_ID => $Request->{Business::APP_ID}, Business::USER_ID=> $Request->{Business::USER_ID}])->toArray();
                  
            if (!$ServiceBusiness) {
                return $this->ServiceRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ServiceRepository->getResourceName(),
                    []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ServiceRepository->getResourceName(),
            $ServiceBusiness
        );
    }
}