<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   HealthCheckController Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v1;

use App\Http\Controllers\Controller;
use App\Repositories\Contracts\HealthCheck\HealthCheckInterface;

/**
 * HealthCheckController class used for checking the health info of service.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class HealthCheckController {

    /**
     * @var App\Repositories\Contracts\HealthCheck
     */
    protected $HealthCheckRepository;

    public function __construct(HealthCheckInterface $HealthCheckRepository) 
    {
        $this->HealthCheckRepository = $HealthCheckRepository;
    }

    /**
     * Get service status
     * 
     * @return string
     */
    public function check() {
        return $this->HealthCheckRepository->check();
    }

    /**
     * Get All the connection's health status
     * 
     * @return string
     */
    public function checkAll() {
        return $this->HealthCheckRepository->checkAll();
    }

}
