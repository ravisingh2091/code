<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Collateral Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v1;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Repositories\Models\Collateral;
use App\Repositories\Models\Application;
use App\Repositories\Models\ServiceCollateral;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Contracts\Data\DataInterface;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\Service\ServiceInterface;
use App\Repositories\Contracts\Collateral\CollateralInterface;
use App\Repositories\Contracts\Application\ApplicationInterface;

/**
 * Collateral Controller class used for handling Collateral info.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class CollateralController extends Controller
{
    protected $fields_data;

    /**
     * @var App\Repositories\Contracts\CollateralInterface;
     */
    protected $CollateralRepository;

    /**
     * @var App\Repositories\Contracts\ApplicationInterface;
     */
    protected $ApplicationRepository;

    /**
     * @var App\Repositories\Contracts\ErrorRepository
     */
    protected $ErrorRepository;

    /**
     * @var  App\Repositories\Contracts\Service\ServiceInterface
     */
    protected $ServiceRepository;

    /**
     * @var  App\Repositories\Contracts\Data\DataInterface
     */
    protected $DataRepository;

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param CollateralInterface $CollateralRepository
     */
    public function __construct(CollateralInterface $CollateralRepository, ErrorRepository $ErrorRepository, ApplicationInterface $ApplicationRepository, ServiceInterface $ServiceRepository, DataInterface $DataRepository)
    {
        $this->CollateralRepository  = $CollateralRepository;
        $this->ErrorRepository       = $ErrorRepository;
        $this->ApplicationRepository = $ApplicationRepository;
        $this->ServiceRepository     = $ServiceRepository;
        $this->DataRepository        = $DataRepository;
        
        parent::__construct($CollateralRepository, $ErrorRepository);
    }

    /**
     * Validate Request
     *
     * @param string $action
     * @param Request $Request
     * 
     * @return string
     */
    public function validateRequest(string $action, Request $Request)
    {
        if ($action === config('actions.v1.post') || ($action === config('actions.v1.update_batch'))) {

            if ($errors = $this->isRequestContainsType($Request)) {
                return $errors;
            }

            $validator = Validator::make(
                $Request->only(config('fields.v1.collaterals')),
                trans('validation_rules.v1.collaterals'),
                trans('messages.v1.collateral_info')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }
            
            $orchestration_url = config("workflow-urls.v1.collateral");
            $headers = [];
            if($Request->filled(config('fields.v1.orch_url'))) {
                $orchestration_url = $Request->get(config('fields.v1.orch_url'));
                $headers['x-region'] = $Request->header('x-region');
            }

            $output = $this->CollateralRepository->getFields($orchestration_url, config('fields.v1.collateral_info'), $Request->{config('fields.v1.action_type')}, $Request->{config('fields.v1.slug')}, $headers);

            // fields & validation received from orchestration or not
            if(!$output) {
                return $this->ErrorRepository->getValidationError(config('fields.v1.service_unavailable'), trans('messages.v1.service_unavailable'), 'SERVICE_UNAVAILABLE');
            }

            if(!$output['local_fields'] && !is_null($Request->{config('fields.v1.slug')})) {
                // check if slug is valid or not
                if(isset($output['type']) && (!in_array($output['type'],config('slug.v1.collateral')))) {
                    return $this->getValidationError(config('fields.v1.slug'), trans('messages.v1.slug'));
                }
            }

            $global_rules = $output['fields'];

            $validationMessages = $this->CollateralRepository->bindValidations($global_rules);

            $this->fields_data = config('fields.v1.collaterals'); 

            $prod_config = $this->CollateralRepository->getProductConfig(env('MASTER_URL'), config('fields.v1.version_v1'));

            if($prod_config) {
                foreach($prod_config as $config) {
                    if($config->{config('fields.v1.type')} == config('fields.v1.max_collateral')) {
                        $max_collateral = $config->{config('fields.v1.value')};
                    }
                }
            }

            $max_collateral = isset($max_collateral) ? $max_collateral : $this->CollateralRepository::MAX_ALLOWED_COLLATERALS;

            if(count($Request->{config('fields.v1.collaterals_field')}) > $max_collateral) {
                return $this->getValidationError(config('fields.v1.collaterals_field'), trans('messages.v1.collateral_info')['collaterals.array']);
            }
            
            foreach($Request->{config('fields.v1.collaterals_field')} as $collateral) {
                
                if(!$output['local_fields']) {
                    $this->CollateralRepository->validateVisibleFields($output, $Request, $collateral);
                    $global_rules = $output['fields'];
                }

                $validator = Validator::make(
                    $collateral,
                    $global_rules,
                    $validationMessages
                );

                if ($validator->fails()) {
                    return $validator->errors();
                }
            }
        }
        
        if ($action === config('actions.v1.put')) {

            if ($errors = $this->isRequestContainsType($Request)) {
                return $errors;
            }

            $orchestration_url = config("workflow-urls.v1.collateral");
            $headers  = [];
            if($Request->filled(config('fields.v1.orch_url'))) {
                $orchestration_url = $Request->get(config('fields.v1.orch_url'));
                $headers['x-region'] = $Request->header('x-region');
            }
            
            $output = $this->CollateralRepository->getFields($orchestration_url, config('fields.v1.update_collateral'), $Request->{config('fields.v1.action_type')}, $Request->{config('fields.v1.slug')}, $headers);
          
            // fields & validation received from orchestration or not
            if(!$output) {
                return $this->ErrorRepository->getValidationError(config('fields.v1.service_unavailable'), trans('messages.v1.service_unavailable'), 'SERVICE_UNAVAILABLE');
            }

            if(!$output['local_fields'] && !is_null($Request->{config('fields.v1.slug')})) {
                // check if slug is valid or not
                if(isset($output['type']) && (!in_array($output['type'],config('slug.v1.collateral')))) {
                    return $this->getValidationError(config('fields.v1.slug'), trans('messages.v1.slug'));
                }
            }

            $this->fields_data = array_keys($output['fields']);

            $global_rules = $output['fields'];

            $validationMessages = $this->CollateralRepository->bindValidations($global_rules);

            $validator = Validator::make(
                $Request->all(),
                $global_rules,
                $validationMessages
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            if(empty($Request->only(config('fields.v1.update_collateral')))) {
                return $this->ErrorRepository->errorMessage('BAD_REQUEST');
            }
        }

        if ($action === config('actions.v1.get')) {
            $this->fields_data = config('fields.v1.get_collateral');

            $validator = Validator::make(
                $Request->all(),
                trans('validation_rules.v1.get_collateral'),
                trans('messages.v1.get_collateral')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }

            if(!$Request->filled(config('fields.v1.collateral_id')) && !$Request->filled(config('fields.v1.app_id'))) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.get_collateral')['app_id.required']]);
            }

        }
    }

    /**
     * The post request creates a new resource
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param  Request $Request
     *
     * @return string
     */
    public function postBatch(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.post'), $Request)) {
            if($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $Response = $this->CollateralRepository->create($Request->only($this->fields_data));
            
            if (!$Response)  throw new BlankDataException(); 

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->CollateralRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->CollateralRepository->getResourceName(),
            $Response
        );
    }

    /**
     * The post request creates a new resource
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param  Request $Request
     *
     * @return string
     */
    public function updateBatch(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.update_batch'), $Request)) {
            if($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $Response = $this->CollateralRepository->updateBatch($Request->only($this->fields_data));
            
            if (!$Response)  throw new BlankDataException(); 

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->CollateralRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->CollateralRepository->getResourceName(),
            $Response
        );
    }

    /**
     * Get collateral
     *
     * @param string $id
     * 
     * @return string
     */
    public function getCollateral(string $id)
    {
        try {
            $Collateral = $this->CollateralRepository->get([Collateral::ID => $id]);

            if(!$Collateral instanceof Collateral) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND'); 
            }

        } catch(Exception $Exception) {
            Log::info($id);
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->CollateralRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->CollateralRepository->getResourceName(),
            $this->CollateralRepository->transformResponse($Collateral, $this->CollateralRepository->getTransformClass())
        );
    }

    /**
     * Get all collaterals
     *
     * @param Request $Request
     * 
     * @return string
     */
    public function getAllCollateral(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.get'), $Request)) return $errors;

        try {
            $Collateral = $this->CollateralRepository->getAll($Request->only($this->fields_data))->toArray();

            if(!$Collateral) {
                return $this->CollateralRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->CollateralRepository->getResourceName(),
                    []
                ); 
            }

        } catch(Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->CollateralRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->CollateralRepository->getResourceName(),
            $Collateral
        );
    }

    /**
     * Save Collateral References
     *
     * @param Request $Request
     *
     * @return string
     */
    public function saveReferences(Request $Request) 
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.save_collateral_ids'),
            trans('messages.v1.save_service_ids')
        );
        
        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // check if Collateral exists by app_id and user_id
        if(!$this->CollateralRepository->get([Collateral::APP_ID => $Request->{Collateral::APP_ID}, Collateral::USER_ID => $Request->{Collateral::USER_ID}, Collateral::ID => $Request->{ServiceInterface::COLLATERAL_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        // check if provider and type are valid in master data
        $invalid_provider = $this->validateFromMasterData($Request);

        if(!empty($invalid_provider)) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', [$invalid_provider]);
        }
        
        try {
            $ServiceCollateral = $this->ServiceRepository->saveServiceCollateral($Request->only(config('fields.v1.save_collateral_ids')));
            
            if (!$ServiceCollateral instanceof ServiceCollateral) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->ServiceRepository->getResourceName(),
            $this->ServiceRepository->transformResponse($ServiceCollateral, $this->ServiceRepository->getTransformClass())
        );        
    }

    /**
     * Get collateral references
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getReferences(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.get_collateral_ids'),
            trans('messages.v1.save_service_ids')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // check if Collateral exists by app_id and user_id
        if(!$this->CollateralRepository->get([Collateral::APP_ID => $Request->{Collateral::APP_ID}, Collateral::USER_ID => $Request->{Collateral::USER_ID}, Collateral::ID => $Request->{ServiceInterface::COLLATERAL_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $ServiceCollateral = $this->ServiceRepository->getServiceCollateral($Request->only(config('fields.v1.get_collateral_ids')));
                  
            if(isset($ServiceCollateral->type) && in_array($ServiceCollateral->type, config('fields.v1.get_all_reference_types'))) {
                $ServiceCollateralAll = $this->ServiceRepository->getAllCollateralReferences($Request->only(config('fields.v1.get_collateral_ids')));
            }
            
            if (!$ServiceCollateral instanceof ServiceCollateral) {
                return $this->ServiceRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ServiceRepository->getResourceName(),
                    []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ServiceRepository->getResourceName(),
            isset($ServiceCollateralAll) ? $ServiceCollateralAll->toArray():$this->ServiceRepository->transformResponse($ServiceCollateral, $this->ServiceRepository->getTransformClass())
        );
    }

    /**
     * Get all references
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getAllReferences(Request $Request)
    {
        $global_rules = trans('validation_rules.v1.owners_get');
        
        $validator = Validator::make(
            $Request->all(),
            $global_rules,
            trans('messages.v1.owners')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // return 404 if application not found
        if (!$this->ApplicationRepository->get([Collateral::APP_ID => $Request->{Collateral::APP_ID}, Collateral::USER_ID=> $Request->{Collateral::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $ServiceCollateral = $this->ServiceRepository->getAllServiceCollateral([Collateral::APP_ID => $Request->{Collateral::APP_ID}, Collateral::USER_ID=> $Request->{Collateral::USER_ID}])->toArray();
                  
            if (!$ServiceCollateral) {
                return $this->ServiceRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ServiceRepository->getResourceName(),
                    []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ServiceRepository->getResourceName(),
            $ServiceCollateral
        );
    }

    /**
     * Validate data from master data
     *
     * @return string
     */
    private function validateFromMasterData(Request $Request) 
    {
        $output = [];

        if ($Request->filled(config('fields.v1.provider'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.service_provider'), $Request->{config('fields.v1.provider')}, config('master_data.collections.service_provider'));
            
            if(!$found || $found->{config('fields.v1.type')} !== $Request->{config('fields.v1.type')}) {
                $output[] = trans('messages.v1.save_service_ids')['provider.regex'];
            }
        }

        return $output;
    }

}
