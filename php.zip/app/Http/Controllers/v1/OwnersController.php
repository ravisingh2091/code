<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Application Owners Controller
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers\v1;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use App\Repositories\Models\Owner;
use App\Http\Controllers\Controller;
use App\Repositories\Models\OwnerHash;
use App\Repositories\Models\ServiceOwner;
use App\Repositories\Contracts\Api\ApiInterface;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Contracts\Data\DataInterface;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Entities\Error\ErrorRepository;
use App\Repositories\Contracts\Owner\OwnersInterface;
use App\Repositories\Contracts\Service\ServiceInterface;
use App\Repositories\Contracts\Application\ApplicationInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Owners Controller class used for handling Owner info.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class OwnersController extends Controller
{
    protected $fields_data;

    protected $validationMessages;

    /**
     * To store unique owner email address from $Request
     *
     * @var array
     */
    protected static $owner_emails = [];

    /**
     * To  maintain owner level
     *
     * @var integer
     */
    protected static $level = 1;

    /**
     * To store owner_emails and there type to check that individual owner does not exist as corporate
     *
     * @var array
     */
    protected static $owner_type_emails = [];

    /**
     * To know if spouse percent is present or not
     *
     * @var boolean
     */
    protected static $is_spouse_percent = false;

    /**
     * To store total spouse percent
     *
     * @var integer
     */
    protected static $spouse_percent_data = 0;

    /**
     * Store minimum total percent
     *
     * @var integer
     */
    protected static $min_total_percent = 0;
    
    /**
     * Store maximum total percent
     *
     * @var integer
     */
    protected static $max_total_percent = 0;

    /**
     * store total owner percent
     *
     * @var float
     */
    protected static $owner_total_percent;

    /**
     * allow duplicate owner emails or not
     *
     * @var boolean
     */
    protected static $allow_duplicate_emails = false;

    /**
     * fields to skip if a condition is met
     *
     * @var array
     */
    protected static $skip_fields;

    /**
     * @var App\Repositories\Contracts\OwnersInterface
     */
    protected $OwnersRepository;

    /**
     * @var App\Repositories\Contracts\ErrorRepository
     */
    protected $ErrorRepository;

    /**
     * @var  App\Repositories\Contracts\Application\ApplicationInterface
     */
    protected $ApplicationRepository;

    /**
     * @var  App\Repositories\Contracts\Data\DataInterface
     */
    protected $DataRepository;

    /**
     * @var  App\Repositories\Contracts\Service\ServiceInterface
     */
    protected $ServiceRepository;

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param OwnersInterface $OwnersRepository
     */
    public function __construct(OwnersInterface $OwnersRepository, ErrorRepository $ErrorRepository, ApplicationInterface $ApplicationRepository, DataInterface $DataRepository, ServiceInterface $ServiceRepository)
    {
        $this->OwnersRepository      = $OwnersRepository;
        $this->ErrorRepository       = $ErrorRepository;
        $this->ApplicationRepository = $ApplicationRepository;
        $this->DataRepository        = $DataRepository;
        $this->ServiceRepository     = $ServiceRepository;

        parent::__construct($OwnersRepository, $ErrorRepository);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param $action string
     * @param Request $Request
     *
     * @return array
     */
    public function validateRequest(string $action, Request $Request)
    {
        if (($action === config('actions.v1.post')) || ($action === config('actions.v1.update_batch'))) {
            if ($errors = $this->isRequestContainsType($Request)) {
                return $errors;
            }
            
            $orchestration_url = config("workflow-urls.v1.owners");
            $headers = [];
            if($Request->filled(config('fields.v1.orch_url'))) {
                $orchestration_url = $Request->get(config('fields.v1.orch_url'));
                $headers['x-region'] = $Request->header('x-region');
            }

            //pass type from form data (i.e save, continue)
            $output = $this->OwnersRepository->getFields($orchestration_url, config('fields.v1.owners'), $Request->{config('fields.v1.action_type')}, $Request->{config('fields.v1.slug')}, $headers);

            // fields & validation received from orchestration or not
            if(!$output) {
                return $this->ErrorRepository->getValidationError(config('fields.v1.service_unavailable'), trans('messages.v1.service_unavailable'), 'SERVICE_UNAVAILABLE');
            }
            
            // check if fields are from orchestration and slug is in request
            if (!$output['local_fields'] && !is_null($Request->{config('fields.v1.slug')})) {
                // check if slug is valid or not
                if (isset($output['type']) && (!in_array($output['type'], config('slug.v1.owners')))) {
                    return $this->ErrorRepository->getValidationError(config('fields.v1.slug'), trans('messages.v1.slug'));
                }
            }

            if(!$output['local_fields']) {
                $this->OwnersRepository->validateVisibleFields($output, $Request);
            }
            
            $global_rules = $output['fields'];
            $owner_validation = $output['fields'];
            $owner_validation = $this->OwnersRepository->createGroupValidation($global_rules);
         
            $rules = [
                config('fields.v1.app_id')       => trans('validation_rules.v1.owners')[config('fields.v1.app_id')],
                config('fields.v1.user_id')      => trans('validation_rules.v1.owners')[config('fields.v1.user_id')],
                config('fields.v1.owners_field') => trans('validation_rules.v1.owners')[config('fields.v1.owners_field')]
            ];
           
            $global_rules = array_merge($global_rules, $rules);
            
            $this->validationMessages = $this->OwnersRepository->bindValidations($global_rules);

            //set the fields array
            $this->fields_data = array_keys($global_rules);

            $inputs =  $Request->all();
            
            $validator = Validator::make(
                $inputs,
                $this->OwnersRepository->filterValidation($global_rules, [Owner::USER_ID,Owner::APP_ID, config('fields.v1.owners_field')]),
                $this->validationMessages
            );
 
            if ($validator->fails()) {
                return $validator->errors();
            }

            // return 404 if application not found
            if (!$this->ApplicationRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])) {
                throw new NotFoundHttpException();
            }

            // return 404 if owner does not exists
            if (($action === config('actions.v1.update_batch')) && !$this->OwnersRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])) {
                throw new NotFoundHttpException();
            }

            if(!$output['allow_multiple_records']) {
                // check if owner already exist for this app_id
                if(($action === config('actions.v1.post')) && $this->isOwnerAlreadyExist($Request->{Owner::APP_ID})) {
                    return $this->ErrorRepository->getValidationError(config('fields.v1.app_id'), trans('messages.v1.owners')[Owner::APP_ID.'.unique']);
                }
            }
            
            if(isset($output['allow_duplicate_email']) && $output['allow_duplicate_email'] == true) {
                self::$allow_duplicate_emails = true;
            }

            if(isset($output['skip_fields']) && (count($output['skip_fields']) > 0)) {
                self::$skip_fields = $output['skip_fields'];
            }
            
            $response = $this->validateOwners($inputs[config('fields.v1.owners_field')], $owner_validation); 
            if  ($response['has_errors'] || isset($response['errors'])) {
                    return $response['errors'];
            } 

            if(!empty(self::$owner_emails)) {
                // to check is owner_emails array has multiple levels or not
                $flag = 0;

                // // check if owner email is duplicate at same level
                foreach(self::$owner_emails as $owner_email) {
                    if(is_array($owner_email)) {
                        $flag = 1;
                        foreach($owner_email as $parent_email) {
                            if(is_array($parent_email)) {
                                if(count($parent_email) !== count(array_unique($parent_email))) {
                                    return $this->ErrorRepository->getValidationError(config('fields.v1.owner_email'),trans('messages.v1.owners')[config('fields.v1.owner_email').'.unique']);
                                }
                            } else{
                                if(count($owner_email) !== count(array_unique($owner_email))) {
                                    return $this->ErrorRepository->getValidationError(config('fields.v1.owner_email'),trans('messages.v1.owners')[config('fields.v1.owner_email').'.unique']);
                                } 
                            }
                        }
                    }
                }

                if(!$flag) {
                    if(count(self::$owner_emails) !== count(array_unique(self::$owner_emails))) {
                        return $this->ErrorRepository->getValidationError(config('fields.v1.owner_email'),trans('messages.v1.owners')[config('fields.v1.owner_email').'.unique']);
                    }
                }
            }

            if(!empty(self::$owner_total_percent)) {
                $total_percent = self::$owner_total_percent;
                if(self::$is_spouse_percent) {
                    $total_percent+= self::$spouse_percent_data;
                }

                // check total percentage is in valid range
                if(!($total_percent >= self::$min_total_percent && $total_percent <= self::$max_total_percent)) {
                    return $this->ErrorRepository->getValidationError(config('fields.v1.ownership_percent'), trans('messages.v1.owners')[config('fields.v1.ownership_percent').'.regex']);
                }
            }
    
            // push user_id and app_id to fields array
            array_push($this->fields_data, config('fields.v1.action_type'));
        }

        if ($action === config('actions.v1.get')) {
            $global_rules = trans('validation_rules.v1.owners_get');
            
            $validator = Validator::make(
                $Request->all(),
                $global_rules,
                trans('messages.v1.owners')
            );

            if ($validator->fails()) {
                return $validator->errors();
            }
        }

        if ($action === config('actions.v1.put')) {
            
            $orchestration_url = config("workflow-urls.v1.owner_consent");
            $headers = [];
            if($Request->filled(config('fields.v1.orch_url'))) {
                $orchestration_url = $Request->get(config('fields.v1.orch_url'));
                $headers['x-region'] = $Request->header('x-region');
            }

            //pass type from form data (i.e save, continue)
            $output = $this->OwnersRepository->getFields($orchestration_url, config('fields.v1.owner_update'), config('actions.v1.continue'), $Request->{config('fields.v1.slug')}, $headers);
          
             // fields & validation received from orchestration or not
            if(!$output) {
                return $this->ErrorRepository->getValidationError(config('fields.v1.service_unavailable'), trans('messages.v1.service_unavailable'), 'SERVICE_UNAVAILABLE');
            }

            // check if fields are from orchestration and slug is in request
            if (!$output['local_fields'] && !is_null($Request->{config('fields.v1.slug')})) {
                // check if slug is valid or not
                if (isset($output['type']) && (!in_array($output['type'], config('slug.v1.owner_update')))) {
                    return $this->ErrorRepository->getValidationError(config('fields.v1.slug'), trans('messages.v1.slug'));
                }
            }
            
            $this->fields_data = array_keys($output['fields']);

            $owner_validation = $this->OwnersRepository->createGroupValidation($output['fields']);

            $this->validationMessages = $this->OwnersRepository->bindValidations($output['fields']);

            $validator = Validator::make(
                $Request->all(),
                $owner_validation,
                $this->validationMessages
            );

            if ($validator->fails()) {
                return $validator->errors();
            }
        }
    }

    /**
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @param array $owners
    * @param array $owner_validation
    * @param int $level
    */
    private function validateOwners(array $owners, array $owner_validation, string $parent_email = '')
    {
        $output = ['has_errors' => false, 'level' => self::$level];

        if ($output['level'] > $this->OwnersRepository::MAX_ALLOWED_LEVEL) {
            //return error cannot exceed max level
            $output['errors'] = $this->ErrorRepository->getValidationError(config('fields.v1.owners_field'), trans('messages.v1.owners')['owners.between']['array']);
            $output['has_errors'] = true;
            return $output;
        }

        $owner_percent_data = array_column($owners, config('fields.v1.ownership_percent'));

        if (!empty($owner_percent_data)) {
            // get product config
            $prod_config = $this->OwnersRepository->getProductConfig(config('api-urls.v1.master_service'), config('fields.v1.version_v1'));

            // get min max total owner percentage from product config
            if ($prod_config) {
                foreach ($prod_config as $config) {
                    if ($config->{config('fields.v1.type')} == config('fields.v1.min_owner_percent')) {
                        $min_owner_percent = $config->{config('fields.v1.value')};
                    }

                    if ($config->{config('fields.v1.type')} == config('fields.v1.max_owner_percent')) {
                        $max_owner_percent = $config->{config('fields.v1.value')};
                    }
                }
            }

            self::$owner_total_percent = array_sum($owner_percent_data);

            self::$min_total_percent = isset($min_owner_percent) ? $min_owner_percent : $this->OwnersRepository::MAX_PERCENT;
            self::$max_total_percent = isset($max_owner_percent) ? $max_owner_percent : $this->OwnersRepository::MAX_PERCENT;
        } else {
            self::$owner_total_percent = [];
        }

        $validations = $owner_validation;

        foreach ($owners as $owner) {
            
            $owner_validation = $validations;

            if (!is_array($owner)) {
                $output['errors'] = $this->ErrorRepository->getValidationError(config('fields.v1.owners_field'), trans('messages.v1.owners')[config('fields.v1.owners_field').'.array']);
                $output['has_errors'] = true;
                return $output;
            }

            if(isset($owner[config('fields.v1.org_type')]) && strtolower($owner[config('fields.v1.org_type')]) == 'business') {
                $rules = array_keys($owner_validation);
                
                if(isset($owner_validation[config('fields.v1.is_secretary_info')]) && isset($owner_validation[config('fields.v1.is_president_info')])) {
                    array_push($owner_validation[config('fields.v1.is_president_info')], config('fields.v1.required'));
                    array_push($owner_validation[config('fields.v1.is_secretary_info')], config('fields.v1.required'));

                    if(isset($owner[config('fields.v1.is_secretary_info')]) && strtolower($owner[config('fields.v1.is_secretary_info')]) == 'yes') {
                        $owner_validation = $this->validateSecretaryPresidentInfo($owner_validation, $rules, config('fields.v1.secretary'));
                    }

                    if(isset($owner[config('fields.v1.is_president_info')]) && strtolower($owner[config('fields.v1.is_president_info')]) == 'yes') {
                        $owner_validation = $this->validateSecretaryPresidentInfo($owner_validation, $rules, config('fields.v1.president'));
                    }
                }
                $owner_validation = $this->removeRequiredRule($owner_validation, config('fields.v1.org_type_business_not_req'));
                $owner_validation = $this->addRequiredRule($owner_validation, config('fields.v1.org_type_business_required'));
            }

            if(isset($owner[config('fields.v1.title')]) && !empty($owner[config('fields.v1.title')]) && $owner[config('fields.v1.title')] != config('fields.v1.owner_title.both.es') && $owner[config('fields.v1.title')] != config('fields.v1.owner_title.both.en')) {
                $rules = array_keys($owner_validation);
                $title_value = $owner[config('fields.v1.title')];

                switch($title_value) {
                    case $title_value == config('fields.v1.owner_title.president.es') || $title_value == config('fields.v1.owner_title.president.en'): {
                        if(isset($owner_validation[config('fields.v1.is_secretary_info')])) {
                            array_push($owner_validation[config('fields.v1.is_secretary_info')], config('fields.v1.required'));
                            if(isset($owner[config('fields.v1.is_secretary_info')]) && strtolower($owner[config('fields.v1.is_secretary_info')]) == 'yes') {
                                $owner_validation = $this->validateSecretaryPresidentInfo($owner_validation, $rules, config('fields.v1.secretary'));
                            }
                        } 
                        break;
                    } 
                    case $title_value == config('fields.v1.owner_title.secretary.es') || $title_value == config('fields.v1.owner_title.secretary.en') : {
                        if(isset($owner_validation[config('fields.v1.is_president_info')])) {
                            array_push($owner_validation[config('fields.v1.is_president_info')], config('fields.v1.required'));
                            if(isset($owner[config('fields.v1.is_president_info')]) && strtolower($owner[config('fields.v1.is_president_info')]) == 'yes') {
                                $owner_validation = $this->validateSecretaryPresidentInfo($owner_validation, $rules, config('fields.v1.president'));
                            }
                        }
                        break;
                    }
                    case $title_value == config('fields.v1.owner_title.none.es') || $title_value == config('fields.v1.owner_title.none.en') : {
                        if(isset($owner_validation[config('fields.v1.is_secretary_info')]) && isset($owner_validation[config('fields.v1.is_president_info')])) {
                            if(!in_array(config('fields.v1.required'), $owner_validation[config('fields.v1.is_president_info')])) {
                                array_push($owner_validation[config('fields.v1.is_president_info')], config('fields.v1.required'));
                            }
                            if(!in_array(config('fields.v1.required'), $owner_validation[config('fields.v1.is_secretary_info')])) {
                                array_push($owner_validation[config('fields.v1.is_secretary_info')], config('fields.v1.required'));
                            }

                            if(isset($owner[config('fields.v1.is_secretary_info')]) && strtolower($owner[config('fields.v1.is_secretary_info')]) == 'yes') {
                                $owner_validation = $this->validateSecretaryPresidentInfo($owner_validation, $rules, config('fields.v1.secretary'));
                            }

                            if(isset($owner[config('fields.v1.is_president_info')]) && strtolower($owner[config('fields.v1.is_president_info')]) == 'yes') {
                                $owner_validation = $this->validateSecretaryPresidentInfo($owner_validation, $rules, config('fields.v1.president'));
                            }
                        }
                        break;
                    }
                }
            }

            if(isset($owner[config('fields.v1.is_owner_via_email')]) && !empty($owner[config('fields.v1.is_owner_via_email')]) && strtolower($owner[config('fields.v1.is_owner_via_email')]) == 'yes') {
                $owner_validation = $this->removeRequiredRule($owner_validation, ( count(self::$skip_fields) > 0 ? (self::$skip_fields) : [] ));
            }

            if((isset($owner[config('fields.v1.marital_status')]) && !empty($owner[config('fields.v1.marital_status')]) && ($owner[config('fields.v1.marital_status')] != config('fields.v1.marital_status_id_en') && $owner[config('fields.v1.marital_status')] != config('fields.v1.marital_status_id_es')))  || !isset($owner[config('fields.v1.marital_status')])) {
                $rules = array_keys($owner_validation);
                
                foreach($rules as $rule) {
                    if(strpos($rule, config('fields.v1.spouse')) !== false) {
                        if(in_array(config('fields.v1.required'), $owner_validation[$rule])) {
                            $index = array_search(config('fields.v1.required'), $owner_validation[$rule]);
                            unset($owner_validation[$rule][$index]);
                        }
                    }
                }
            } else if (isset($owner[config('fields.v1.marital_status')]) && ($owner[config('fields.v1.marital_status')] == config('fields.v1.marital_status_id_en') || $owner[config('fields.v1.marital_status')] == config('fields.v1.marital_status_id_es'))) {
                if(isset($owner[config('fields.v1.spouse_ownership_percent')]) && !empty($owner[config('fields.v1.spouse_ownership_percent')])) {
                    self::$is_spouse_percent = true;
                    self::$spouse_percent_data += $owner[config('fields.v1.spouse_ownership_percent')];
                }
            }

            $validateOwner = Validator::make(
                $owner,
                $owner_validation,
                $this->validationMessages
            );
         
            if ($validateOwner->fails()) {
                $output['errors'] = $validateOwner->errors();
                $output['has_errors'] = true;
                return $output;
            }

            if (isset($owner[config('fields.v1.owner_type')])) {
                if (!preg_match("/^[a-zA-Z0-9\_]+$/", $owner[config('fields.v1.owner_type')]) || !in_array(strtolower($owner[config('fields.v1.owner_type')]), config('fields.v1.allowed_owner_types'))) {
                    $output['errors'] = $this->ErrorRepository->getValidationError(config('fields.v1.owner_type'), trans('messages.v1.owners')[config('fields.v1.owner_type').'.regex']);
                    $output['has_errors'] = true;
                    return $output;
                }
            }

            if(!self::$allow_duplicate_emails) {
                if (isset($owner[config('fields.v1.owner_email')]) && isset($owner[config('fields.v1.owner_type')])) {
                    if (array_key_exists($owner[config('fields.v1.owner_email')], self::$owner_type_emails)) {
                        if ($owner[config('fields.v1.owner_type')] !== config('fields.v1.individual')) {
                            $output['errors'] = $this->ErrorRepository->getValidationError(config('fields.v1.owner_email'), trans('messages.v1.owners')[config('fields.v1.owner_email').'.regex']);
                            $output['has_errors'] = true;
                            return $output;
                        } else if (self::$owner_type_emails[$owner[config('fields.v1.owner_email')]] !== $owner[config('fields.v1.owner_type')]) {
                            $output['errors'] = $this->ErrorRepository->getValidationError(config('fields.v1.owner_email'), trans('messages.v1.owners')[config('fields.v1.owner_email').'.regex']);
                            $output['has_errors'] = true;
                            return $output;
                        }
                    }
        
                    self::$owner_type_emails[$owner[config('fields.v1.owner_email')]] = $owner[config('fields.v1.owner_type')];
        
                    self::$owner_emails[self::$level] = isset(self::$owner_emails[self::$level]) ? self::$owner_emails[self::$level] : [];
                    
                    //storing owner emails at each level
                    if ($owner[config('fields.v1.owner_type')] === config('fields.v1.individual') && $parent_email === '') {
                        array_push(self::$owner_emails[self::$level], $owner[config('fields.v1.owner_email')]);
                    } else {
                        if ($parent_email === '') {
                            array_push(self::$owner_emails[self::$level], $owner[config('fields.v1.owner_email')]);
                        } else {
                            self::$owner_emails[self::$level][$parent_email] = isset(self::$owner_emails[self::$level][$parent_email]) ? self::$owner_emails[self::$level][$parent_email] : [];
                            array_push(self::$owner_emails[self::$level][$parent_email], $owner[config('fields.v1.owner_email')]);
                        }
                    }
                } else if(isset($owner[config('fields.v1.owner_email')]) && !isset($owner[config('fields.v1.owner_type')])) {
                        array_push(self::$owner_emails, $owner[config('fields.v1.owner_email')]);
                }
            }

            if(isset($owner[config('fields.v1.owner_type')])) {
                // if owner_type = corporate
                if ((strtolower($owner[config('fields.v1.owner_type')]) === config('fields.v1.corporate')) || (strtolower($owner[config('fields.v1.owner_type')]) === config('fields.v1.partnership'))) {
                    $validateOwner = Validator::make(
                        $owner,
                        $this->OwnersRepository->filterValidation(trans('validation_rules.v1.owners'), [config('fields.v1.owners_field')]),
                        trans('messages.v1.owners')
                    );
                                        
                    if ($validateOwner->fails()) {
                        $output['errors'] = $validateOwner->errors();
                        $output['has_errors'] = true;
                        return $output;
                    }
                    self::$level++ ;
                    // perform validation recursively
                    $output = array_merge($output, $this->validateOwners($owner[config('fields.v1.owners_field')], $owner_validation, $owner[config('fields.v1.owner_email')]));
                }
            }
        }
        
        self::$level--;
        return $output;
    }

    /**
     * Return updated rules
     *
     * @param array $rules_array
     * @param array $rules
     * @param string $field
     * 
     * @return array
     */
    public function validateSecretaryPresidentInfo(array $rules_array, array $rules, string $field)
    {
        foreach($rules as $rule) {
            if(strpos($rule, $field) !== false) {
                if(!in_array(config('fields.v1.required'), $rules_array[$rule])) {
                    array_push($rules_array[$rule], config('fields.v1.required'));
                }
            }
        }

        return $rules_array;
    }

    /**
     * Remove required rule from fields
     *
     * @param array $rules_array
     * @param array $fields
     * 
     * @return array
     */
    public function removeRequiredRule(array $rules_array, array $fields)
    {
        foreach($fields as $field) {
            if(isset($rules_array[$field]) && in_array(config('fields.v1.required'), $rules_array[$field])) {
                $index = array_search(config('fields.v1.required'), $rules_array[$field]);
                unset($rules_array[$field][$index]);
            }
        }

        return $rules_array;
    }

    /**
     * Add required rule from fields
     *
     * @param array $rules_array
     * @param array $fields
     * 
     * @return array
     */
    public function addRequiredRule(array $rules_array, array $fields)
    {
        foreach($fields as $field) {
            if(isset($rules_array[$field]) && !in_array(config('fields.v1.required'), $rules_array[$field])) {
                array_push($rules_array[$field], config('fields.v1.required'));
            }
        }

        return $rules_array;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return array
     */
    public function validatePutRequest($Request)
    {
        $orchestration_url = config("workflow-urls.v1.business");
        $headers = [];
        if($Request->filled(config('fields.v1.orch_url'))) {
            $orchestration_url = $Request->get(config('fields.v1.orch_url'));
            $headers['x-region'] = $Request->header('x-region');
        }

        $this->fields_data = $this->OwnersRepository->getFields($orchestration_url, config('fields.v1.business'));
        
        array_push($this->fields_data, Owner::USER_ID, Owner::APP_ID);

        $this->fields_data = $this->OwnersRepository->removeFields($this->fields_data);

        $validator = Validator::make(
            $Request->all(),
            $this->OwnersRepository->filterValidation(trans('validation_rules.v1.business_update'), $this->fields_data),
            trans('messages.v1.business')
        );

        if ($validator->fails()) {
            return $validator->errors();
        }
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getAll(Request $Request)
    {
        $global_rules = trans('validation_rules.v1.owners_get');
        
        $validator = Validator::make(
            $Request->all(),
            $global_rules,
            trans('messages.v1.owners')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // return 404 if application not found
        if (!$this->ApplicationRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND', [trans('messages.v1.not_found')]);
        }

        if (!$this->OwnersRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])) {
            return $this->ApiRepository->dispatchResponse(
                trans('messages.v1.success'),
                Response::HTTP_OK,
                $this->ApiRepository->getResourceName(),
                []
            );
        }

        try {
            $Response = $this->OwnersRepository->getAll($Request->only([Owner::APP_ID, Owner::USER_ID]));
            
            if (!$Response) {
                throw new ObjectNotLoadedException();
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }
        
        return $this->ApiRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ApiRepository->getResourceName(),
            $Response
        );
    }

    /**
     * Check if owners already exist on this app_id
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $app_id
     *
     * @return bool
     */
    public function isOwnerAlreadyExist(string $app_id)
    {
        $Owner = $this->OwnersRepository->getOwnerByAppId($app_id);
        if ($Owner instanceof Owner) {
            return true;
        }
        return false;
    }
    
    /**
     * Verify owner hash and return owner
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $hash
     *
     * @return string
     */
    public function verifyOwner(Request $Request, string $hash)
    {
        $validator = Validator::make(
            [OwnerHash::HASH => $hash ],
            trans('validation_rules.v1.owners_verify'),
            trans('messages.v1.owners_verify')
        );
        
        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', $validator->errors()->toArray());
        }
        
        try {
            if (!$this->OwnersRepository->isHashExist($hash)) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            if (!$this->OwnersRepository->checkHashExpiry($hash) || !$this->OwnersRepository->isNew($hash)) {
                return $this->ErrorRepository->errorMessage('TOKEN_EXPIRED');
            }

            $Owner = $this->OwnersRepository->getOwnerByHash($hash, true);
            if(!$Owner instanceof Owner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            if($Request->hasHeader(config('fields.v1.is_consent_received')) && $Request->header(config('fields.v1.is_consent_received')) == true) {
                if($Owner->{Owner::CONSENT} === Owner::RECEIVED) {
                    return $this->ErrorRepository->errorMessage('TOKEN_EXPIRED');
                }
            }

            $applicant = $this->OwnersRepository->getApplicant(config('api-urls.v1.user_service'), config('fields.v1.version_v1'), $Owner->{Owner::USER_ID});
            if (is_array($applicant) && !empty($applicant)) {
                $Owner->{config('fields.v1.applicant_name')} = $applicant[config('fields.v1.applicant_name')];
                $Owner->{config('fields.v1.applicant_email')} = $applicant[config('fields.v1.applicant_email')];
            }
        } catch (Exception $Exception) {
            Log::info($hash);
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            $this->OwnersRepository->transformResponse($Owner, $this->OwnersRepository->getTransformClass())
        );
    }

    /**
     * Get new owner hash by owner_id
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $owner_id
     *
     * @return string
     */
    public function updateAndGetOwnerHash(string $owner_id)
    {
        $validator = Validator::make(
            [OwnerHash::OWNER_ID => $owner_id],
            trans('validation_rules.v1.get_owner_hash'),
            trans('messages.v1.owners_verify')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', $validator->errors()->toArray());
        }

        try {
            $Owner = $this->OwnersRepository->get([Owner::ID => $owner_id]);
            if (!$Owner instanceof Owner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            if (!$this->OwnersRepository->checkEmailTokenCount($owner_id)) {
                $error = $this->ErrorRepository->getValidationError(config('fields.v1.hash'), trans('messages.v1.limit_reached'));
                return $this->ErrorRepository->errorMessage('RATE_LIMIT_REACHED', $error->toArray());
            }

            $UpdatedHash = $this->OwnersRepository->createNewHash($owner_id);
        } catch (Exception $Exception) {
            Log::info($owner_id);
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            [OwnerHash::HASH => $UpdatedHash->{OwnerHash::HASH}]
        );
    }

    /**
     * Get Citizenship Percentage
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getCitizenshipPercentage(Request $Request)
    {
        $global_rules = trans('validation_rules.v1.owners_get');
        
        $validator = Validator::make(
            $Request->all(),
            $global_rules,
            trans('messages.v1.owners')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // return 404 if application not found
        if (!$this->ApplicationRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $citizenship_percentage = $this->OwnersRepository->getCitizenshipPercentage($Request->all());

            if ($citizenship_percentage === false) {
                return $this->ErrorRepository->errorMessage('BAD_REQUEST');
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            [config('fields.v1.citizenship_percentage') => $citizenship_percentage]
        );
    }
    
    /**
     * Get Weighted Average
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getWeightedAverage(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.owners_array'),
            trans('messages.v1.owners_array')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        $owners = $Request->{config('fields.v1.owners_field')};

        foreach ($owners as $owner) {
            $validator = Validator::make(
                $owner,
                trans('validation_rules.v1.owners_weighted_average'),
                trans('messages.v1.owners_weighted_average')
            );
    
            if ($validator->fails()) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
            }

            $Owner = $this->OwnersRepository->get([Owner::ID => $owner[OwnerHash::OWNER_ID]]);
            if (!$Owner instanceof Owner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        }
        
        try {
            $weighted_average = $this->OwnersRepository->getWeightedAverage($owners);
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            [config('fields.v1.weighted_average') => $weighted_average]
        );
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    public function saveReferences(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.save_owner_ids'),
            trans('messages.v1.save_service_ids')
        );
        
        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // check if Application exists by app_id and user_id
        if (!$this->OwnersRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID => $Request->{Owner::USER_ID}, Owner::ID => $Request->{config('fields.v1.owner_id')}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        // check if provider and type are valid in master data
        $invalid_provider = $this->validateFromMasterData($Request);

        if (!empty($invalid_provider)) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', [$invalid_provider]);
        }
        
        try {
            $ServiceOwner = $this->ServiceRepository->saveServiceOwner($Request->only(config('fields.v1.save_owner_ids')));
                  
            if (!$ServiceOwner instanceof ServiceOwner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->ServiceRepository->getResourceName(),
            $this->ServiceRepository->transformResponse($ServiceOwner, $this->ServiceRepository->getTransformClass())
        );
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getReferences(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.get_owner_ids'),
            trans('messages.v1.save_service_ids')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // check if Application exists by app_id and user_id
        if (!$this->OwnersRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID => $Request->{Owner::USER_ID}, Owner::ID => $Request->{config('fields.v1.owner_id')}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $fields = config('fields.v1.get_owner_ids');
            if ($Request->type == 1) {
                array_push($fields, 'type');
                $ServiceOwner = $this->ServiceRepository->getServiceOwner($Request->only($fields));
            } else {
                $ServiceOwner = $this->ServiceRepository->getServiceOwner($Request->only($fields)); 
            }
      
            if (!$ServiceOwner instanceof ServiceOwner) {
      
                return $this->ServiceRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ServiceRepository->getResourceName(),
                    is_array($ServiceOwner) ? $ServiceOwner : []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ServiceRepository->getResourceName(),
            $this->ServiceRepository->transformResponse($ServiceOwner, $this->ServiceRepository->getTransformClass())
        );
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    private function validateFromMasterData(Request $Request)
    {
        $output = [];

        if ($Request->filled(config('fields.v1.provider'))) {
            $found = $this->DataRepository->checkFromMasterData(config('master_data.url.service_provider'), $Request->{config('fields.v1.provider')}, config('master_data.collections.service_provider'));
            
            if (!$found || $found->{config('fields.v1.type')} !== $Request->{config('fields.v1.type')}) {
                $output[] = trans('messages.v1.save_service_ids')['provider.regex'];
            }
        }

        return $output;
    }

    /**
     * Get Individual Percentage
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getIndividualPercentage(Request $Request)
    {
        $global_rules = trans('validation_rules.v1.owners_get');
        
        $validator = Validator::make(
            $Request->all(),
            $global_rules,
            trans('messages.v1.owners')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // return 404 if application not found
        if (!$this->ApplicationRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $individual_percentage = $this->OwnersRepository->getIndividualPercentage($Request->all());
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            [config('fields.v1.individual_percentage') => $individual_percentage]
        );
    }

    /**
     * Update Owner Percent
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getUpdateOwnerPercentHash(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.update_owners_percent_array'),
            trans('messages.v1.update_owners_percent_array')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        if (!$this->ApplicationRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        $owners   = $Request->{config('fields.v1.owners_field')};
        $hash_for = $Request->{config('fields.v1.hash_for')};
        
        // stores current actual total percent of owners at same level which are being updated
        $level_percent = [];

        // contains levels which are being accessed
        $levels = [];

        // stores updated actual total percent of owners at same level which are being updated
        $updated_level_percent = [];

        // stores actual percentage of parent of owners which are being updated
        $parent_percent = [];

        // stores owner_id and new percent
        $updated_percent = [];
        
        foreach ($owners as $owner) {
            $validator = Validator::make(
                $owner,
                trans('validation_rules.v1.update_owner_percent'),
                trans('messages.v1.update_owner_percent')
            );
    
            if ($validator->fails()) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
            }

            $Owner = $this->OwnersRepository->get([
                Owner::APP_ID  => $Request->{Owner::APP_ID},
                Owner::USER_ID => $Request->{Owner::USER_ID},
                Owner::ID      => $owner[OwnerHash::OWNER_ID],
                Owner::LEVEL   => $owner[Owner::LEVEL]
            ]);

            if (!$Owner instanceof Owner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
            
            if (strtolower($Owner->{Owner::OWNER_TYPE}) !== config('fields.v1.individual')) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.update_owner_percent')[config('fields.v1.owner_id').'.regex']]);
            }

            if (!isset($updated_level_percent[$Owner->{Owner::LEVEL}])) {
                $updated_level_percent[$Owner->{Owner::LEVEL}] = 0;
                $updated_level_percent[$Owner->{Owner::LEVEL}] += $owner[config('fields.v1.updated_percent')];
            } else {
                $updated_level_percent[$Owner->{Owner::LEVEL}] += $owner[config('fields.v1.updated_percent')];
            }

            if ($Owner->{config('fields.v1.parent_id')} != '0') {
                $Parent = $this->OwnersRepository->get([Owner::ID => $Owner->{config('fields.v1.parent_id')}]);
                if (!isset($parent_percent[$Parent->{Owner::ID}])) {
                    $parent_percent[$Parent->{Owner::ID}] = $Parent->{Owner::ACTUAL_PERCENT};
                }
            }

            $updated_percent[$owner[OwnerHash::OWNER_ID]] = $owner[config('fields.v1.updated_percent')];
            
            $levels[] = $Owner->{Owner::LEVEL};

            if (!isset($level_percent[$Owner->{Owner::LEVEL}])) {
                $level_percent[$Owner->{Owner::LEVEL}] = 0;
                $level_percent[$Owner->{Owner::LEVEL}] += $Owner->{Owner::ACTUAL_PERCENT};
            } else {
                $level_percent[$Owner->{Owner::LEVEL}] += $Owner->{Owner::ACTUAL_PERCENT};
            }
        }
        
        $levels = array_unique($levels);
        
        // maintain same total percentage at each level
        foreach ($levels as $level) {
            $level_percent[$level]         = round($level_percent[$level], 2);
            $updated_level_percent[$level] = round($updated_level_percent[$level], 2);

            if ($level_percent[$level] != $updated_level_percent[$level]) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.update_owner_percent')[config('fields.v1.updated_percent').'.regex']]);
            }
        }

        foreach ($parent_percent as $k => $parent_per) {
            $Owners = $this->OwnersRepository->getAllOwners([
                Owner::APP_ID                 => $Request->{Owner::APP_ID},
                Owner::USER_ID                => $Request->{Owner::USER_ID},
                config('fields.v1.parent_id') => $k,
            ])->toArray();

            $updated_parent_percent = 0;
            
            foreach ($Owners as $Owner) {
                if ($Owner[Owner::OWNER_TYPE] === config('fields.v1.individual') && array_key_exists($Owner[Owner::ID], $updated_percent)) {
                    $updated_parent_percent += $updated_percent[$Owner[Owner::ID]];
                } else {
                    $parent_per -= $Owner[Owner::ACTUAL_PERCENT];
                }
            }

            $parent_per = round($parent_per, 2);
            $updated_parent_percent = round($updated_parent_percent, 2);

            // maintain total of child percentage equal to parent percentage
            if ($parent_per != $updated_parent_percent) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.update_owner_percent')[config('fields.v1.updated_percent').'.regex']]);
            }
        }

        try {

            $updatePercentConsent = $this->OwnersRepository->addUpdatedPercent($owners);

            if(!$updatePercentConsent) {
                return $this->OwnersRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->OwnersRepository->getResourceName(),
                    []
                );
            }

            $owners_with_hash = $this->OwnersRepository->createConsentHash($owners, $hash_for);
            
            // $this->OwnersRepository->updateOwnerPercent($owners);
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            [
                config('fields.v1.owners_with_hash') => $owners_with_hash
            ]
        );
    }

    /**
     * Delete all owners hash when application is submitted
     *
     * @param string $app_id
     *
     * @return string
     */
    public function deleteOwnerHash(string $app_id)
    {
        $validator = Validator::make(
            [Owner::APP_ID => $app_id],
            trans('validation_rules.v1.delete_owner_hash'),
            trans('messages.v1.delete_owner_hash')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', $validator->errors()->toArray());
        }

        try {
            $Owner = $this->OwnersRepository->get([Owner::APP_ID => $app_id]);

            if (!$Owner instanceof Owner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            $deleteHash = $this->OwnersRepository->deleteAllOwnerHash($app_id);

            if ($deleteHash === []) {
                return $this->ErrorRepository->errorMessage('CONSENT_PENDING');
            }
        } catch (Exception $Exception) {
            Log::info($app_id);
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            []
        );
    }

    /**
     * Get a Owners
     *
     * @param String $id
     *
     * @return string
     */
    public function getOwner(String $id)
    {
        try {
            $Owner = $this->OwnersRepository->get([Owner::ID => $id]);

            if (!$Owner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            $Owner->toArray()
        );
    }

    /**
     * Get All Owners without hierarchy
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getAllOwners(Request $Request)
    {
        $global_rules = trans('validation_rules.v1.owners_get');
        
        $validator = Validator::make(
            $Request->all(),
            $global_rules,
            trans('messages.v1.owners')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // return 404 if application not found
        if (!$this->ApplicationRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $Owners = $this->OwnersRepository->getAllOwners([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])->toArray();

            if (!$Owners) {
                return $this->OwnersRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->OwnersRepository->getResourceName(),
                    []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            $Owners
        );
    }

    /**
     * Get saved weighted average
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getSavedWeightedAverage(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.business_get_by_app_id'),
            trans('messages.v1.owners')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // return 404 if application not found
        if (!$this->ApplicationRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $weighted_average = $this->OwnersRepository->getSavedWeightedAverage($Request->{Owner::APP_ID});

            if (!$weighted_average) {
                return $this->OwnersRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->OwnersRepository->getResourceName(),
                    []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            $weighted_average->toArray()
        );
    }

    /**
     * Get all references
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getAllReferences(Request $Request)
    {
        $global_rules = trans('validation_rules.v1.owners_get');
        
        $validator = Validator::make(
            $Request->all(),
            $global_rules,
            trans('messages.v1.owners')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        // return 404 if application not found
        if (!$this->ApplicationRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        try {
            $ServiceOwner = $this->ServiceRepository->getAllServiceOwner([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])->toArray();
                  
            if (!$ServiceOwner) {
                return $this->ServiceRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ServiceRepository->getResourceName(),
                    []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ServiceRepository->getResourceName(),
            $ServiceOwner
        );
    }

    /**
     * Verify hash and return owner
     *
     * @param string $hash
     *
     * @return string
     */
    public function verifyHash(Request $Request, string $hash)
    {
        $validator = Validator::make(
            [
                OwnerHash::HASH => $hash,
                config('fields.v1.hash_for') => isset($Request->{config('fields.v1.hash_for')}) ? $Request->{config('fields.v1.hash_for')} : ''
            ],
            trans('validation_rules.v1.hash_verify'),
            trans('messages.v1.owners_verify')
        );
        
        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', $validator->errors()->toArray());
        }
        
        try {
            if (!$this->OwnersRepository->isConsentHashExist($hash)) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            if (!$this->OwnersRepository->checkConsentHashExpiry($hash) || !$this->OwnersRepository->isHashNew($hash, $Request->{config('fields.v1.hash_for')}) || $this->OwnersRepository->isHashVerified($hash)) {
                return $this->ErrorRepository->errorMessage('TOKEN_EXPIRED');
            }

            $Info = $this->OwnersRepository->getInfoFromHash($hash);
            
        } catch (Exception $Exception) {
            Log::info($hash);
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            [
                'owner_info' =>  $Info
            ]
        );
    }

    /**
     * Get new hash by owner_id
     *
     * @param Request $Request
     * @param string $owner_id
     *
     * @return string
     */
    public function updateAndGetNewHash(Request $Request, string $owner_id)
    {
        $validator = Validator::make(
            [
                OwnerHash::OWNER_ID => $owner_id,
                config('fields.v1.hash_for') => isset($Request->{config('fields.v1.hash_for')}) ? $Request->{config('fields.v1.hash_for')} : '' 
            ],
            trans('validation_rules.v1.get_new_hash'),
            trans('messages.v1.owners_verify')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', $validator->errors()->toArray());
        }

        try {
            $Owner = $this->OwnersRepository->get([Owner::ID => $owner_id]);
            if (!$Owner instanceof Owner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            if (!$this->OwnersRepository->checkHashPerDayCount($owner_id, $Request->{config('fields.v1.hash_for')})) {
                $error = $this->ErrorRepository->getValidationError(config('fields.v1.hash'), trans('messages.v1.limit_reached'));
                return $this->ErrorRepository->errorMessage('RATE_LIMIT_REACHED', $error->toArray());
            }

            $UpdatedHash = $this->OwnersRepository->createNewConsentHash($owner_id, $Request->{config('fields.v1.hash_for')});
        } catch (Exception $Exception) {
            Log::info($owner_id);
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            [OwnerHash::HASH => $UpdatedHash->{OwnerHash::HASH}]
        );
    }

    /**
     * Update Owner Percent Consent
     *
     * @param string $owner_id
     *
     * @return string
     */
    public function updateOwnerPercentConsent(string $owner_id)
    {
        $validator = Validator::make(
            [
                OwnerHash::OWNER_ID => $owner_id,
            ],
            trans('validation_rules.v1.get_owner_hash'),
            trans('messages.v1.owners_verify')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', $validator->errors()->toArray());
        }

        try {
            $Owner = $this->OwnersRepository->get([Owner::ID => $owner_id]);
            if (!$Owner instanceof Owner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            $this->OwnersRepository->updatePercentConsent($owner_id);

        } catch (Exception $Exception) {
            Log::info($owner_id);
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            []
        );
    }
    
    /**
     * Update owner percent
     *
     * @param Request $Request
     * 
     * @return string
     */
    public function updateOwnerPercent(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.owners_update_percent_array'),
            trans('messages.v1.update_owners_percent_array')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        if (!$this->ApplicationRepository->get([Owner::APP_ID => $Request->{Owner::APP_ID}, Owner::USER_ID=> $Request->{Owner::USER_ID}])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        $owners   = $Request->{config('fields.v1.owners_field')};

        foreach ($owners as $owner) {
            $validator = Validator::make(
                $owner,
                trans('validation_rules.v1.owner_update_percent'),
                trans('messages.v1.update_owner_percent')
            );
    
            if ($validator->fails()) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
            }

            $Owner = $this->OwnersRepository->get([
                Owner::APP_ID  => $Request->{Owner::APP_ID},
                Owner::USER_ID => $Request->{Owner::USER_ID},
                Owner::ID      => $owner[OwnerHash::OWNER_ID],
            ]);

            if (!$Owner instanceof Owner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
            
            if (strtolower($Owner->{Owner::OWNER_TYPE}) !== config('fields.v1.individual')) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.update_owner_percent')[config('fields.v1.owner_id').'.regex']]);
            }

            if($Owner->{config('fields.v1.update_percent_consent')} != Owner::RECEIVED) {
                return $this->ErrorRepository->errorMessage('BAD_REQUEST');
            }
        }

        try {
            $this->OwnersRepository->updateOwnerPercent($owners);

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            []
        );
    }

    /**
     * Delete Hash
     *
     * @param Request $Request
     * @param string $app_id
     * 
     * @return string
     */
    public function deleteHash(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.delete_hash'),
            trans('messages.v1.owners_verify')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('FIELD_INVALID', $validator->errors()->toArray());
        }

        try {
            $app_id = $Request->{Owner::APP_ID};

            $Owner = $this->OwnersRepository->get([Owner::APP_ID => $app_id]);

            if (!$Owner instanceof Owner) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            $deleteHash = $this->OwnersRepository->deleteHash($app_id, $Request->{config('fields.v1.hash_for')});

            if ($deleteHash === []) {
                return $this->ErrorRepository->errorMessage('CONSENT_PENDING');
            }

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
  
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->OwnersRepository->getResourceName(),
            []
        );
    }

    /**
     * Delete references
     *
     * @param string $ref_id
     * 
     * @return string
     */
    public function deleteReferences(string $ref_id)
    {
        try {
            $delete = $this->ServiceRepository->deleteOwnerRefId($ref_id);

        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());
        
            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ServiceRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ServiceRepository->getResourceName(),
            []
        );
    }


}
