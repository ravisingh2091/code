<?php

/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Controller Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Controllers;

use Log;
use Exception;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Repositories\Models\Business;
use Illuminate\Database\Eloquent\Model;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Entities\Error\ErrorRepository;
use Laravel\Lumen\Routing\Controller as BaseController;
use App\Repositories\Exceptions\ObjectNotLoadedException;

/**
 * The Abstract controller defines the body of the CRUD methods.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
abstract class Controller extends BaseController
{
    /**
     * @var App\Repositories\Entities\Api\ApiRepository
     */
    protected $ApiRepository;

    /**
     * @var App\Repositories\Entities\Error\ErrorRepository
     */
    protected $ErrorRepository;

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param App\Repositories\Entities\Api\ApiRepository $API
     * @param App\Repositories\Entities\Error\ErrorRepository $Error
     *
     * @return void
     */
    public function __construct(ApiRepository $API, ErrorRepository $Error)
    {
        $this->ApiRepository   = $API;
        $this->ErrorRepository = $Error;
    }

    /**
     * The post request creates a new resource
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param  Request $Request
     *
     * @return string
     */
    public function post(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.post'), $Request)) {
            if ($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $Response = $this->ApiRepository->create($Request->only($this->fields_data));

            if (!$Response instanceof Model) {
                throw new ObjectNotLoadedException();
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());

            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ApiRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->ApiRepository->getResourceName(),
            $this->ApiRepository->transformResponse($Response, $this->ApiRepository->getTransformClass())
        );
    }

    /**
     * The post request creates a new resource
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param  Request $Request
     *
     * @return string
     */
    public function postBatch(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.post'), $Request)) {
            if ($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $Response = $this->OwnersRepository->create($Request->only($this->fields_data));

            if (!$Response)  throw new BlankDataException();
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());

            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->OwnersRepository->getResourceName(),
            $this->ApiRepository->transformOwners($Response, $this->ApiRepository->getTransformClass())
        );
    }

    /**
     * The post request creates a new resource
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param  Request $Request
     *
     * @return string
     */
    public function updateBatch(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.update_batch'), $Request)) {
            if ($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $Response = $this->OwnersRepository->updateBatch($Request->only($this->fields_data));

            if (!$Response)  throw new BlankDataException();
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());

            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->OwnersRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_CREATED,
            $this->OwnersRepository->getResourceName(),
            $this->ApiRepository->transformOwners($Response, $this->ApiRepository->getTransformClass())
        );
    }


    /**
     * The put request updated the resource
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param  Request $Request
     * @param string $id
     *
     * @return string
     */
    public function put(Request $Request, string $id)
    {
        if (!$this->ApiRepository->get([Business::ID => $id])) {
            return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
        }

        if ($errors = $this->validateRequest(config('actions.v1.put'), $Request)) {
            if ($errors instanceof JsonResponse) {
                return $errors;
            } else {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $errors->toArray());
            }
        }

        try {
            $Response = $this->ApiRepository->update($Request->only($this->fields_data), $id);

            if (!$Response instanceof Model) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());

            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ApiRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ApiRepository->getResourceName(),
            $this->ApiRepository->transformResponse($Response, $this->ApiRepository->getTransformClass())
        );
    }

    /**
     * Fetch Details using App Id and user Id
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    public function get(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.get'), $Request)) return $errors;

        try {
            $Response = $this->ApiRepository->get($Request->only(Business::USER_ID, Business::APP_ID, Business::ALLOW_MULTIPLE_APP, Business::START, Business::PER_PAGE));

            if (is_array($Response) && empty($Response)) {
                return $this->ApiRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ApiRepository->getResourceName(),
                    []
                );
            } else if (
                !is_array($Response) &&
                !$Response instanceof Model
            ) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());

            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ApiRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ApiRepository->getResourceName(),
            $Response instanceof Model ? $this->ApiRepository->transformResponse($Response, $this->ApiRepository->getTransformClass()) : $Response
        );
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    public function getBatch(Request $Request)
    {
        if ($errors = $this->validateRequest(config('actions.v1.get_batch'), $Request)) return $errors;

        try {
            $Response = $this->ApiRepository->getBatch($Request);

            if (is_array($Response) && empty($Response)) {
                return $this->ApiRepository->dispatchResponse(
                    trans('messages.v1.success'),
                    Response::HTTP_OK,
                    $this->ApiRepository->getResourceName(),
                    []
                );
            }
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());

            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ApiRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ApiRepository->getResourceName(),
            $Response
        );
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return string
     */
    protected function isRequestContainsType(Request $Request)
    {
        if (!$Request->has(config('fields.v1.action_type'))) {
            return $this->ErrorRepository->getValidationError(config('fields.v1.action_type'), trans('messages.v1.actions')['action_type.required']);
        }

        if (!ctype_alpha($Request->{config('fields.v1.action_type')}) || !in_array(strtolower($Request->{config('fields.v1.action_type')}), config('fields.v1.actions'))) {
            return $this->ErrorRepository->getValidationError(config('fields.v1.action_type'), trans('messages.v1.actions')['action_type.invalid']);
        }
    }

    /**
     * Delete resource with the passed id
     *
     * @param string $id
     * 
     * @return string
     */
    public function delete(string $id)
    {
        try {
            $Response = $this->ApiRepository->get([Business::ID => $id]);

            if (!$Response instanceof Model) {
                return $this->ErrorRepository->errorMessage('RESOURCE_NOT_FOUND');
            }

            $deleted = $this->ApiRepository->delete([Business::ID => $id]);

            if (!$deleted) throw new Exception;
        } catch (Exception $Exception) {
            Log::info($id);
            Log::error($Exception->__toString());

            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ApiRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ApiRepository->getResourceName(),
            []
        );
    }

    /**
     * Filter services references business/owner app count according to status
     * 
     * @param Request $Request
     *
     * @return string
     */
    public function filterReferences(Request $Request)
    {
        $validator = Validator::make(
            $Request->all(),
            trans('validation_rules.v1.filter_references'),
            trans('messages.v1.filter_references')
        );

        if ($validator->fails()) {
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', $validator->errors()->toArray());
        }

        try {
            $total_apps = $this->ApiRepository->filterReferences($Request);
        } catch (Exception $Exception) {
            Log::info($Request->__toString());
            Log::error($Exception->__toString());

            return $this->ErrorRepository->errorMessage('ACTION_FAILED');
        }

        return $this->ApplicationRepository->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->ApplicationRepository->getResourceName(),
            $total_apps
        );
    }

    /**
     * This routine will validate the incoming request.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $action
     * @param  Request $Request
     *
     * @return array
     */
    abstract protected function validateRequest(string $action, Request $Request);
}
