<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Request Middleware to validate slug 
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Http\Middleware;

use Closure;
use Validator;
use App\Repositories\Entities\Error\ErrorRepository;

class RequestMiddleware
{

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param ErrorRepository $ErrorRepository
     */
    public function __construct(ErrorRepository $ErrorRepository) {
       $this->ErrorRepository =  $ErrorRepository;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(!$request->filled(config('fields.v1.slug')) && !$request->filled(config('fields.v1.orch_url'))) { 
            return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.slug_url')]);
        }

        // check if request has slug and validate the slug
        if($request->filled(config('fields.v1.slug'))) {
            if($error = $this->validateSlug($request->{config('fields.v1.slug')})) {
                return $error;
            }
        
            $urlSegment = $request->segment(3);
            if(!isset($urlSegment)) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.slug')]);
            }

            $slug = config('slug.v1.'.$urlSegment);
            if(!isset($slug) || !in_array($request->{config('fields.v1.slug')}, $slug)) {
                return $this->ErrorRepository->errorMessage('REQUEST_FIELDS_EMPTY', [trans('messages.v1.slug')]);
            }
        } else if($request->filled(config('fields.v1.orch_url'))) {
            if($error = $this->validateUrl($request->{config('fields.v1.orch_url')})) {
                return $error;
            }
        }

        return $next($request);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $slug
     *
     * @return array
     */
    protected function validateSlug($slug)
    {
        if(empty($slug) || !isset($slug)) {
            return $this->ErrorRepository->getValidationError(config('fields.v1.slug'), trans('messages.v1.slug'));
        }
             
        if(!preg_match(str_replace('regex:', '', trans('validation_rules.v1.slug')), $slug)) {
            return $this->ErrorRepository->getValidationError(config('fields.v1.slug'), trans('messages.v1.slug'));
        }
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $url
     *
     * @return array
     */
    protected function validateUrl($url)
    {
        if(!preg_match(str_replace('regex:', '', trans('validation_rules.v1.orch_url')), $url)) {
            return $this->ErrorRepository->getValidationError(config('fields.v1.orch_url'), trans('messages.v1.orch_url'));
        }
    }
}
