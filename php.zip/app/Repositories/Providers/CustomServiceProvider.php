<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   v1 Service Provider
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Providers;

use Validator;
use App\Repositories\Models\Owner;
use App\Repositories\Models\Product;
use App\Repositories\Models\Business;
use App\Repositories\Models\Checklist;
use App\Repositories\Models\Collateral;
use App\Repositories\Models\OwnerHash;
use Illuminate\Support\ServiceProvider;
use App\Repositories\Models\AppActivity;
use App\Repositories\Models\Application;
use App\Repositories\Models\ServiceOwner;
use App\Repositories\Observers\Timestamp;
use App\Repositories\Models\AppAssignment;
use App\Repositories\Models\ServiceBusiness;
use App\Repositories\Exceptions\CustomHandler;
use Illuminate\Contracts\Debug\ExceptionHandler;

/**
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class CustomServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(
            'App\Repositories\Contracts\Api\ApiInterface',
            'App\Repositories\Entities\Api\ApiRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\Application\ApplicationInterface',
            'App\Repositories\Entities\v1\Application\ApplicationRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\Business\BusinessInterface',
            'App\Repositories\Entities\v1\Business\BusinessRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\Owner\OwnersInterface',
            'App\Repositories\Entities\v1\Owner\OwnersRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\Data\DataInterface',
            'App\Repositories\Entities\v1\Data\DataRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\Hash\HashInterface',
            'App\Repositories\Entities\v1\Hash\HashRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\Service\ServiceInterface',
            'App\Repositories\Entities\v1\Service\ServiceRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\AppAssignment\AppAssignmentInterface',
            'App\Repositories\Entities\v1\AppAssignment\AppAssignmentRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\Checklist\ChecklistInterface',
            'App\Repositories\Entities\v1\Checklist\ChecklistRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\AppActivity\AppActivityInterface',
            'App\Repositories\Entities\v1\AppActivity\AppActivityRepository'
        );
        //collateral
        $this->app->bind(
            'App\Repositories\Contracts\Collateral\CollateralInterface',
            'App\Repositories\Entities\v1\Collateral\CollateralRepository'
        );
        //product
        $this->app->bind(
            'App\Repositories\Contracts\Product\ProductInterface',
            'App\Repositories\Entities\v1\Product\ProductRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\HealthCheck\HealthCheckInterface',
            'App\Repositories\Entities\v1\HealthCheck\HealthCheckRepository'
        );
        $this->app->bind(
            'App\Repositories\Contracts\Notes\NotesInterface',
            'App\Repositories\Entities\v1\Notes\NotesRepository'
        );
    }
    
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return void
     */
    public function boot()
    {
        $this->app->bind(
            ExceptionHandler::class,
            CustomHandler::class
        );

        $this->isValidChar();
        $this->maxLength();
        $this->minLength();
        $this->pattern();

        Application::observe(Timestamp::class);
        AppActivity::observe(Timestamp::class);
        Business::observe(Timestamp::class);
        Owner::observe(Timestamp::class);
        OwnerHash::observe(Timestamp::class);
        ServiceBusiness::observe(Timestamp::class);
        ServiceOwner::observe(Timestamp::class);
        AppAssignment::observe(Timestamp::class);
        Checklist::observe(Timestamp::class);
        Collateral::observe(Timestamp::class);
        Product::observe(Timestamp::class);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return void
     */
    private function isValidChar()
    {
        Validator::extend(
            'isValidChar',
            function ($attribute, $value, $parameters, $validator) {
                if(is_array($value)) return false;

                if (!preg_match('/[\p{P}]{2,}|[<>\[\]]+/', $value)) {
                    return true;
                }
                return false;
            }
        );
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return void
     */
    private function maxLength() 
    {
        Validator::extend(
            'maxLength',
            function ($attribute, $value, $parameters, $validator) {
                if(is_array($value)) return false;

                if ((strlen($value) <= (int) $parameters[0])) {
                    return true;
                }
                return false;
            }
        );
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return void
     */
    private function minLength() 
    {
        Validator::extend(
            'minLength',
            function ($attribute, $value, $parameters, $validator) {
                if(is_array($value)) return false;

                if (strlen($value) >= (int) $parameters[0]) {
                    return true;
                }
                return false;
            }
        );
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return void
     */
    private function pattern() 
    {
        Validator::extend(
            'pattern',
            function ($attribute, $value, $parameters, $validator) {
                if(is_array($value)) return false;
                
                if (preg_match($parameters[0], $value)) {
                    return true;
                }
                return false;
            }
        );
    }
}
