<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   AppAssignment Model 
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use DateTime;
use OwenIt\Auditing\Contracts\Auditable;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use App\Repositories\Contracts\AppAssignment\AppAssignmentInterface;

/**
 * AppAssignment Model class used for handling AppAssignments.
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class AppAssignment extends Eloquent implements Auditable
{
    use \OwenIt\Auditing\Auditable;
    
    const ID        = '_id';
    const APP_ID    = 'app_id';
    const ROLE_ID   = 'role_id';
    const assigned_to = 'assigned_to';

    /**
     * The timestamps false is used to disibled model timestamps.
     * created_at is set on the SetCreatedAt observer
     * updated_at is set on the SetUpdatedAt observer
     *
     * @var boolean
     */
    public $timestamps = false;

    /**
     * Collection to be used for this model
     *
     * @var string
     */
    protected $collection = AppAssignmentInterface::COLLECTION;

    /** Guarded array to block the fields */
    protected $guarded = [];

    /**
     * Save App Assignments
     *
     * @param array $attributes
     * 
     * @return string
     */
    public function saveAssignment(array $attributes)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Assignment = $this->create($attributes);

        return $Assignment ? $Assignment : null;
    }

    /**
     * Accessor Method to convert created_at timestamp into ISO8601
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $createdAt
     * @return string
     */
    public function getCreatedAtAttribute($createdAt) 
    {
        return Date(DateTime::ISO8601, (int) (string) $createdAt);
    }

    /**
     * Accessor Method to convert updated_at timestamp into ISO8601
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $updatedAt
     * @return string
     */
    public function getUpdatedAtAttribute($updatedAt) 
    {
        return Date(DateTime::ISO8601, (int) (string) $updatedAt);
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setCreatedAtAttribute($value) 
    {
        $this->attributes[config('fields.v1.created_at')] = time();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setUpdatedAtAttribute($value) 
    {
        $this->attributes[config('fields.v1.updated_at')] = time();
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return object
     */
    public function application() 
    {
       return $this->belongsTo('App\Repositories\Models\Application', self::APP_ID);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return object
     */
    public function business() 
    {
       return $this->hasOne('App\Repositories\Models\Business', self::APP_ID, self::APP_ID);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return object
     */
    public function businessReferences()
    {
       return $this->hasMany('App\Repositories\Models\ServiceBusiness', self::APP_ID, self::APP_ID);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return array
     */
    public function owners() 
    {
       return $this->hasMany('App\Repositories\Models\Owner', self::APP_ID, self::APP_ID);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return array
     */
    public function ownerReferences() 
    {
       return $this->hasMany('App\Repositories\Models\ServiceOwner', self::APP_ID, self::APP_ID);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return array
     */
    public function ownersWeightedAverage() 
    {
       return $this->hasOne('App\Repositories\Models\OwnersWeightedAverage', self::APP_ID, self::APP_ID);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return array
     */
     public function appActivity() 
     {
        return $this->hasMany('App\Repositories\Models\AppActivity', self::APP_ID, self::APP_ID);
     }

     /**
     * Get the collection name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function getCollectionName() 
    {
       return $this->collection;
    }
}