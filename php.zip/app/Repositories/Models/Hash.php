<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Hash Model
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use OwenIt\Auditing\Contracts\Auditable;
use App\Repositories\Contracts\Api\ApiInterface;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

/**
 * Hash Model class used for maintaing hash for different purposes
 *
 * @author Tanuj Chawla <tanuj.chawla@biz2credit.com>
 */
class Hash extends Eloquent implements Auditable
{
    use \OwenIt\Auditing\Auditable;

    const ID                 = '_id';
    const OWNER_ID           = 'owner_id';
    const APP_ID             = 'app_id';
    const USER_ID            = 'user_id';
    const HASH               = 'hash';
    const HASH_FOR           = 'hash_for';
    const HASH_VERIFIED      = 'hash_verified';
    const HASH_LENGTH        = 32;
    const EXPIRY             = 'expiry';
    const EMAIL              = 'email';
    const ENCRYPTED_HASH     = 'encrypted_hash';
    const CREATED_AT         = 'created_at';
    
    /**
     * Collection to be used for this model
     *
     * @var string
     */
    protected $collection = ApiInterface::HASH_COLLECTION;

    /** Guarded array to block the fields */
    protected $guarded = [];

    /**
     * Create New Hash
     * 
     * @param array $owners
     * @param string $hash_for
     *
     * @return array
     */
    public static function createHash(array $owners, string $hash_for)
    {   
        if(empty($owners)) throw new BlankDataException();

        $result = [];

        foreach($owners as $owner) {
            $hash = bin2hex(random_bytes(self::HASH_LENGTH));

            $data_to_save = [
                self::OWNER_ID            => $owner[self::OWNER_ID],
                self::HASH                => $hash,
                self::HASH_FOR            => $hash_for,
                self::HASH_VERIFIED       => false,
                self::ENCRYPTED_HASH      => base64_encode(openssl_encrypt($hash,"AES-128-ECB", config('owner_consent.v1.HASH_SALT'))),
            ];
            
            $result[] = self::create($data_to_save);
        }
        return $result ? $result : null;
    }

    /**
     * Create single hash
     * 
     * @param array $owners
     * @param string $hash_for
     *
     * @return array
     */
    public function saveHash($params)
    {   
        if(empty($params)) throw new BlankDataException();

        $result = [];

        $hash = bin2hex(random_bytes(self::HASH_LENGTH));

        $data_to_save = [
            self::APP_ID              => $params[self::APP_ID],
            self::HASH                => $hash,
            self::HASH_FOR            => $params[self::HASH_FOR],
            self::HASH_VERIFIED       => false,
            self::ENCRYPTED_HASH      => base64_encode(openssl_encrypt($hash,"AES-128-ECB", config('owner_consent.v1.HASH_SALT'))),
        ];

        if(isset($params[self::OWNER_ID]) && !empty($params[self::OWNER_ID])) {
            $data_to_save = array_merge($data_to_save, [
                self::OWNER_ID => $params[self::OWNER_ID]
            ]);
        }

        if(isset($params[self::EMAIL]) && !empty($params[self::EMAIL])) {
            $data_to_save = array_merge($data_to_save, [
                self::EMAIL => $params[self::EMAIL]
            ]);
        }

        if(isset($params[self::USER_ID]) && !empty($params[self::USER_ID])) {
            $data_to_save = array_merge($data_to_save, [
                self::USER_ID => $params[self::USER_ID]
            ]);
        }

        if(isset($params[self::EXPIRY]) && !empty($params[self::EXPIRY])) {
            $data_to_save = array_merge($data_to_save, [
                self::EXPIRY => $params[self::EXPIRY]
            ]);
        }
        
        $result = self::create($data_to_save);

        return $result ? $result : null;
    }

    /**
     * Accessor Method to convert created_at timestamp into ISO8601
     *
     * @param timestamp $createdAt
     * @return string
     */
    public function getCreatedAtAttribute($createdAt)
    {
        $date = new \Carbon\Carbon($createdAt);
        return $date->toIso8601String();
    }

    /**
     * Accessor Method to convert updated_at timestamp into ISO8601
     *
     * @param timestamp $updatedAt
     * @return string
     */
    public function getUpdatedAtAttribute($updatedAt)
    {
        $date = new \Carbon\Carbon($updatedAt);
        return $date->toIso8601String();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setCreatedAtAttribute($value)
    {
        $this->attributes[config('fields.v1.created_at')] = time();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setUpdatedAtAttribute($value)
    {
        $this->attributes[config('fields.v1.updated_at')] = time();
    }

    /**
     * Get the collection name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function getCollectionName() 
    {
       return $this->collection;
    }
}