<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Owner Model
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use OwenIt\Auditing\Contracts\Auditable;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use App\Repositories\Contracts\Owner\OwnersInterface;

/**
 * OwnerHash Model class used for maintaing owner hash
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class OwnerHash extends Eloquent implements Auditable
{
    use \OwenIt\Auditing\Auditable;

    const ID                 = '_id';
    const OWNER_ID           = 'owner_id';
    const HASH               = 'hash';
    const HASH_LENGTH        = 32;
    const ENCRYPTED_HASH     = 'encrypted_hash';
    const CREATED_AT         = 'created_at';
    
    /**
     * Collection to be used for this model
     *
     * @var string
     */
    protected $collection = OwnersInterface::COLLECTION_HASH;

    /** Guarded array to block the fields */
    protected $guarded = [];

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $owners
     *
     * @return array
     */
    public function createOwnerHash(array $owners)
    {   
        if(empty($owners)) throw new BlankDataException();

        $result = [];

        foreach($owners as $owner) {
            $hash = bin2hex(random_bytes(self::HASH_LENGTH));

            $owner_email = isset($owner[config('fields.v1.email_address')]) ? $owner[config('fields.v1.email_address')]: $owner[config('fields.v1.owner_email')];

            $data_to_save = [
                self::OWNER_ID            => $owner[self::ID],
                self::HASH                => $hash,
                self::ENCRYPTED_HASH      => $hash.md5($owner_email),
            ];
            
            $result[] = $this->create($data_to_save);
        }
        return $result ? $result : null;
    }

    /**
     * Accessor Method to convert created_at timestamp into ISO8601
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $createdAt
     * @return string
     */
    public function getCreatedAtAttribute($createdAt)
    {
        $date = new \Carbon\Carbon($createdAt);
        return $date->toIso8601String();
    }

    /**
     * Accessor Method to convert updated_at timestamp into ISO8601
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $updatedAt
     * @return string
     */
    public function getUpdatedAtAttribute($updatedAt)
    {
        $date = new \Carbon\Carbon($updatedAt);
        return $date->toIso8601String();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setCreatedAtAttribute($value)
    {
        $this->attributes[config('fields.v1.created_at')] = time();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setUpdatedAtAttribute($value)
    {
        $this->attributes[config('fields.v1.updated_at')] = time();
    }

    /**
     * Get the collection name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function getCollectionName() 
    {
       return $this->collection;
    }
}
