<?php

/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Business Model
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use DB;
use DateTime;
use Exception;
use Carbon\Carbon;
use App\Repositories\Models\Application;
use OwenIt\Auditing\Contracts\Auditable;
use App\Repositories\Transformer\Transformer;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use App\Repositories\Contracts\Business\BusinessInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Business Model class used for handling business related database operation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class Business extends Eloquent implements Auditable
{
    use \OwenIt\Auditing\Auditable;

    const ID      = '_id';
    const USER_ID = 'user_id';
    const APP_ID  = 'app_id';
    const ALLOW_MULTIPLE_APP  = 'allow_multiple_app';
    const START  = 'start';
    const PER_PAGE  = 'per_page';

    /**
     * The timestamps false is used to disibled model timestamps.
     * created_at is set on the SetCreatedAt observer
     * updated_at is set on the SetUpdatedAt observer
     *
     * @var boolean
     */
    public $timestamps = false;

    /**
     * Collection to be used for this model
     *
     * @var string
     */
    protected $collection = BusinessInterface::COLLECTION;

    /** Guarded array to block the fields */
    protected $guarded = [];

    /**
     * Store the business info 
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $attributes
     *
     * @return string
     */
    public function saveBusinessInfo(array $attributes)
    {
        /**check if business details are provided or not */
        if (empty($attributes)) {
            throw new BlankDataException(trans('messages.v1.empty_business'));
        }

        $result = $this->create($attributes);

        return $result ? $result  : null;
    }

    /**
     * Store the business info 
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $attributes
     * @param string $businessId
     *
     * @return string
     */
    public function updateBusinessInfo(array $attributes, string $businessId)
    {
        $business = self::where([
            self::ID => $businessId,
            self::APP_ID => $attributes[self::APP_ID],
            self::USER_ID => $attributes[self::USER_ID]
        ])->first();

        if (!$business) return false;

        unset($attributes[self::APP_ID]);
        unset($attributes[self::USER_ID]);

        $updated = $business->update($attributes);

        return ($updated == 0 || $updated)  ? $business  : null;
    }

    /**
     * Fetch Business Details using App id and user id
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $params
     *
     * @return string
     */
    public function getBusinessInfo(array $params)
    {
        $business = self::where($params)->first();

        return $business ? $business : null;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $key
     * @param string $value
     *
     * @return string
     */
    public function getBusiness(string $key, string $value)
    {
        $Business = self::where($key, $value)->first();

        return $Business ? $Business : null;
    }

    /**
     * Accessor Method to convert created_at timestamp into ISO8601
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $createdAt
     * @return string
     */
    public function getCreatedAtAttribute($createdAt)
    {
        return Date(DateTime::ISO8601, (int) (string) $createdAt);
    }

    /**
     * Accessor Method to convert updated_at timestamp into ISO8601
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $updatedAt
     * @return string
     */
    public function getUpdatedAtAttribute($updatedAt)
    {
        return Date(DateTime::ISO8601, (int) (string) $updatedAt);
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setCreatedAtAttribute($value)
    {
        $this->attributes[config('fields.v1.created_at')] = time();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setUpdatedAtAttribute($value)
    {
        $this->attributes[config('fields.v1.updated_at')] = time();
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return object
     */
    public function application()
    {
        return $this->belongsTo('App\Repositories\Models\Application', self::APP_ID);
    }

    /**
     * Get the collection name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function getCollectionName()
    {
        return $this->collection;
    }
}
