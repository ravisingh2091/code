<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Request Response Log Model
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use App\Repositories\Contracts\Api\ApiInterface;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

/**
 * Request Response Log Model
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com> 
 */
class RequestResponseLog extends Eloquent 
{
    /**
     * Collection to be used for this model
     *
     * @var string
     */
    protected $collection = ApiInterface::AUDIT_COLLECTION;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'request_url', 
        'method', 
        'request_IP', 
        'request_header', 
        'request_body', 
        'response', 
        'status_code',
    ];

    /**
     * Accessor Method to convert created_at timestamp into ISO8601
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $createdAt
     * @return string
     */
    public function getCreatedAtAttribute($createdAt)
    {
        $date = new \Carbon\Carbon($createdAt);
        return $date->toIso8601String();
    }

    /**
     * Accessor Method to convert updated_at timestamp into ISO8601
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $updatedAt
     * @return string
     */
    public function getUpdatedAtAttribute($updatedAt)
    {   
        $date = new \Carbon\Carbon($updatedAt);
        return $date->toIso8601String();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setCreatedAtAttribute($value)
    { 
        $this->attributes[config('fields.v1.created_at')] = time();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setUpdatedAtAttribute($value)
    {   
        $this->attributes[config('fields.v1.updated_at')] = time();
    }

    /**
     * Get the collection name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function getCollectionName() 
    {
       return $this->collection;
    }

}