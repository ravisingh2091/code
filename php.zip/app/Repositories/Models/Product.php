<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Product Model 
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use DateTime;
use OwenIt\Auditing\Contracts\Auditable;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use App\Repositories\Contracts\Product\ProductInterface;

/**
 * Product Model class used for handling Products.
 * 
 * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
 */
class Product extends Eloquent implements Auditable
{
    use \OwenIt\Auditing\Auditable;
    
    const ID        = '_id';
    const APP_ID    = 'app_id';
    const USER_ID   = 'user_id';

    /**
     * The timestamps false is used to disibled model timestamps.
     * created_at is set on the SetCreatedAt observer
     * updated_at is set on the SetUpdatedAt observer
     *
     * @var boolean
     */
    public $timestamps = false;

    /**
     * Collection to be used for this model
     *
     * @var string
     */
    protected $collection = ProductInterface::COLLECTION;

    /** Guarded array to block the fields */
    protected $guarded = [];

    /**
     * Save Product
     *
     * @param array $attributes
     * 
     * @return string
     */
    public function saveProduct(array $attributes)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Product = $this->create($attributes);

        return $Product ? $Product : null;
    }

    /**
     * Accessor Method to convert created_at timestamp into ISO8601
     * 
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param timestamp $createdAt
     * @return string
     */
    public function getCreatedAtAttribute($createdAt) 
    {
        return Date(DateTime::ISO8601, (int) (string) $createdAt);
    }

    /**
     * Accessor Method to convert updated_at timestamp into ISO8601
     * 
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param timestamp $updatedAt
     * @return string
     */
    public function getUpdatedAtAttribute($updatedAt) 
    {
        return Date(DateTime::ISO8601, (int) (string) $updatedAt);
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     * 
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setCreatedAtAttribute($value) 
    {
        $this->attributes[config('fields.v1.created_at')] = time();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     * 
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setUpdatedAtAttribute($value) 
    {
        $this->attributes[config('fields.v1.updated_at')] = time();
    }

    /**
     * Get the collection name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function getCollectionName() 
    {
       return $this->collection;
    }
}