<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Model
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use Log;
use Jenssegers\Mongodb\Eloquent\Model;

/** 
 * Audit model definition.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class Audit extends Model implements \OwenIt\Auditing\Contracts\Audit
{
    use \OwenIt\Auditing\Audit;

    /**
     * {@inheritdoc}
     */
    protected $guarded = [];

    /**
     * {@inheritdoc}
     */
    protected $casts = [
        'old_values'   => 'json',
        'new_values'   => 'json',
        'auditable_id' => 'integer',
    ];

    /**
     * {@inheritdoc}
     */
    public function auditable()
    {
        return $this->morphTo();
    }

    /**
     * {@inheritdoc}
     */
    public function user()
    {
        return $this->morphTo();
    }

    /**
     * Accessor Method to set created_at timestamp into UNIX time

     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $createdAt

     * @return void
     */
    public function setCreatedAtAttribute($createdAt) 
    {
        $this->attributes[self::CREATED_AT] = time();
    }

    /**
     * Accessor Method to set updated timestamp into UNIX time

     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $updatedAt
     
     * @return void
     */
    public function setUpdatedAtAttribute($updatedAt) 
    {
        $this->attributes[self::UPDATED_AT] = time();
    }

    /**
     * Get the collection name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function getCollectionName() 
    {
       return $this->collection;
    }
}