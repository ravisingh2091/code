<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Owner Model
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use DateTime;
use App\Repositories\Models\OwnerHash;
use App\Repositories\Models\Application;
use OwenIt\Auditing\Contracts\Auditable;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use App\Repositories\Contracts\Owner\OwnersInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Owner Model class used for handling loan Owners.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class Owner extends Eloquent implements Auditable
{
    use \OwenIt\Auditing\Auditable;
    
    const ID                = '_id';
    const USER_ID           = 'user_id';
    const APP_ID            = 'app_id';
    const DIRECT_OWNER_NAME = 'name_of_the_direct_owner';
    const EMAIL_ADDRESS     = 'owner_email';
    const OWNERSHIP_PERCENT = 'ownership_percent';
    const OWNER_TYPE        = 'owner_type';
    const CONSENT           = 'consent';
    const PENDING           = 'pending';
    const RECEIVED          = 'received';
    const LEVEL             = 'level';
    const ACTUAL_PERCENT    = 'actual_percent';
    const DIN               = 'din';
    const PAN               = 'pan';
    const OWNER_ROLE        = 'owner_role';
    const POLICY_CHECK      = 'policy_checkbox';
    const ADDRESS_LINE_ONE  = 'primary_residence_address_line_one';
    const ADDRESS_LINE_TWO  = 'primary_residence_address_line_two';
    const ZIP               =  'zip';

    /**
     * The timestamps false is used to disibled model timestamps.
     * created_at is set on the SetCreatedAt observer
     * updated_at is set on the SetUpdatedAt observer
     *
     * @var boolean
     */
    public $timestamps = false;

    /**
     * Collection to be used for this model
     *
     * @var string
     */
    protected $collection = OwnersInterface::COLLECTION;

    /** Guarded array to block the fields */
    protected $guarded = [];

    /**
     * To  maintain owner level
     *
     * @var integer
     */
    protected static $level = 1;

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $params
     * @param bool $upsert
     *
     * @return string
     */
    public function saveOwner(array $params, bool $upsert)
    {
        if($upsert) {
            $existing_owners_to_delete = $this->fetchExistingOwnersToDelete($params);

            $this->whereIn(self::ID, $existing_owners_to_delete)->delete();
            OwnerHash::whereIn(OwnerHash::OWNER_ID, $existing_owners_to_delete)->delete();
        }

        $result = $this->createOwner($params[config('fields.v1.owners_field')], $params[self::APP_ID], $params[self::USER_ID], $params[config('fields.v1.action_type')], $upsert);

        return $result ? $result  : null;
    }

    /**
     * To find owners which are deleted in new request
     *
     * @param array $params
     * 
     * @return string
     */
    private function fetchExistingOwnersToDelete(array $params)
    {
        $existingOwners = $this->select(self::ID)
                                ->where(self::APP_ID, $params[self::APP_ID])
                                ->where(self::USER_ID, $params[self::USER_ID])
                                ->get()->toArray();
        
        $existingIds = [];

        foreach($existingOwners as $owner) {
            array_push($existingIds, $owner[self::ID]);
        }

        $reqIds = [];
        $reqOwners = $params[config('fields.v1.owners_field')];

        foreach($reqOwners as $owner) {
            if(isset($owner[config('fields.v1.id')])) {
                array_push($reqIds, $owner[config('fields.v1.id')]);
            }
        }

        $idsToDelete = array_diff($existingIds, $reqIds);

        return $idsToDelete;
    }


    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $owners
     * @param string $app_id
     * @param string $user_id
     * @param string $action_type
     * @param bool $upsert
     * @param string $parent_id
     * @param float $ownership_percent
     *
     * @return array
     */
    private function createOwner(array $owners, string $app_id, string $user_id, string $action_type, bool $upsert, string $parent_id = "0", float $ownership_percent = 0)
    {
        $output = [];
        
        foreach ($owners as $owner) {
            $data_to_save = $owner;

            if(isset($data_to_save[config('fields.v1.owners_field')])) {
                unset($data_to_save[config('fields.v1.owners_field')]);
            }
            
            $data_to_save = array_merge($data_to_save, [
                self::LEVEL             => self::$level,
                // self::CONSENT           => $action_type === config('actions.v1.save') ? '' : self::PENDING,
                self::APP_ID            => $app_id,
                self::USER_ID           => $user_id
            ]);

            // if parent id not null attach parent_id to each owner
            // assign parent_id from its previous level owner id
            $data_to_save = array_merge($data_to_save, [config('fields.v1.parent_id')=>$parent_id]);

            $Request = app('request');

            if($Request->hasHeader('ipaddress')) {
                $data_to_save = array_merge($data_to_save, [
                    config('fields.v1.ip_address') => $Request->header('ipaddress')
                ]);
            }
            
            if(isset($owner[self::OWNERSHIP_PERCENT])) {
                if ($parent_id!== "0") {
                    $actual_percent = ($data_to_save[self::OWNERSHIP_PERCENT]/100) * $ownership_percent;
                    $data_to_save   = array_merge($data_to_save, [self::ACTUAL_PERCENT => round($actual_percent, 3)]);
                } else {
                    $actual_percent = $data_to_save[self::OWNERSHIP_PERCENT];
                    $data_to_save   = array_merge($data_to_save, [self::ACTUAL_PERCENT => round($actual_percent, 3)]);
                }
            }

            $result = [];

            if(isset($data_to_save[config('fields.v1.id')]) && $upsert) {
                $Owner = $this->where(self::ID, $data_to_save[config('fields.v1.id')])->first();
                $consent = $Owner->{self::CONSENT};
                $data_to_save = array_merge($data_to_save, [
                    self::CONSENT => $consent
                ]);

                unset($data_to_save[config('fields.v1.id')]);

                $Owner->update($data_to_save);

                $result = $Owner;
            } else {
                $consent = $action_type === config('actions.v1.save') ? '' : self::PENDING;
                $data_to_save = array_merge($data_to_save, [
                    self::CONSENT => $consent
                ]);
                $result = $this->create($data_to_save);
            }

            
            array_push($output, $result);
            if(isset($owner[self::OWNER_TYPE])) {
                if ((strtolower($owner[self::OWNER_TYPE]) === config("fields.v1.corporate")) || (strtolower($owner[self::OWNER_TYPE]) === config("fields.v1.partnership"))) {
                    self::$level++;
                    // now save owner in db
                    $output = array_merge($output, $this->createOwner($owner[config('fields.v1.owners_field')], $app_id, $user_id, $action_type, $upsert, $result->{self::ID}, $result->{self::ACTUAL_PERCENT}));
                    self::$level--;
                }
            }
        }
        return $output;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $params
     *
     * @return string
     */
    public function getOwner(array $params)
    {
        return $this->where($params)->first();
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $params
     *
     * @return string
     */
    public function getAllOwners(array $params)
    {
        return $this->where($params)->get();
    }

    /**
     * Accessor Method to convert created_at timestamp into ISO8601
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $createdAt
     * @return string
     */
    public function getCreatedAtAttribute($createdAt)
    {
        return Date(DateTime::ISO8601, (int) (string) $createdAt);
    }

    /**
     * Accessor Method to convert updated_at timestamp into ISO8601
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $updatedAt
     * @return string
     */
    public function getUpdatedAtAttribute($updatedAt)
    {
        return Date(DateTime::ISO8601, (int) (string) $updatedAt);
    }

    /**
     * Accessor Method to convert consent_clicked_at timestamp into ISO8601
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $updatedAt
     * @return string
     */
    public function getConsentClickedAtAttribute($consentClickedAt)
    {
        return Date(DateTime::ISO8601, (int) (string) $consentClickedAt);
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setCreatedAtAttribute($value)
    {
        $this->attributes[config('fields.v1.created_at')] = time();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setUpdatedAtAttribute($value)
    {
        $this->attributes[config('fields.v1.updated_at')] = time();
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return object
     */
    public function business()
    {
        return $this->hasOne('App\Repositories\Models\Business', self::APP_ID);
    }

    /**
     * Get the collection name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function getCollectionName() 
    {
       return $this->collection;
    }
}
