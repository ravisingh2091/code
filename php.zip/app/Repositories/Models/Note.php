<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Note Model 
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use DateTime;
use Illuminate\Support\Facades\DB;
use OwenIt\Auditing\Contracts\Auditable;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use App\Repositories\Contracts\Notes\NotesInterface;

/**
 * Note Model class used for handling Notes.
 */
class Note extends Eloquent implements Auditable
{
    use \OwenIt\Auditing\Auditable;
    
    const ID        = '_id';
    const APP_ID    = 'app_id';

    // /**
    //  * The timestamps false is used to disibled model timestamps.
    //  * created_at is set on the SetCreatedAt observer
    //  * updated_at is set on the SetUpdatedAt observer
    //  *
    //  * @var boolean
    //  */
    // public $timestamps = false;

    /**
     * Collection to be used for this model
     *
     * @var string
     */
    protected $collection = NotesInterface::COLLECTION;

    /** Guarded array to block the fields */
    protected $guarded = [];

    /**
     * Save Note
     *
     * @param array $attributes
     * 
     * @return string
     */
    public function saveNote(array $attributes)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Note = $this->create($attributes);

        return $Note ? $Note : null;
    }

    /**
     * Accessor Method to convert created_at timestamp into ISO8601
     *
     * @param timestamp $createdAt
     * @return string
     */
    public function getCreatedAtAttribute($createdAt) 
    {
        return Date(DateTime::ISO8601, strtotime($createdAt));
    }

    /**
     * Accessor Method to convert updated_at timestamp into ISO8601
     *
     * @param timestamp $updatedAt
     * @return string
     */
    public function getUpdatedAtAttribute($updatedAt) 
    {
        return Date(DateTime::ISO8601, strtotime($updatedAt));
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setCreatedAtAttribute($value) 
    {
        $this->attributes[config('fields.v1.created_at')] = time();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setUpdatedAtAttribute($value) 
    {
        $this->attributes[config('fields.v1.updated_at')] = time();
    }

    /**
     * Get the collection name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function getCollectionName() 
    {
       return $this->collection;
    }
}