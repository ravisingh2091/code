<?php

/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Application Model 
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use DateTime;
use OwenIt\Auditing\Contracts\Auditable;
use Jenssegers\Mongodb\Eloquent\SoftDeletes;
use App\Repositories\Traits\AutoIncrementID;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use App\Repositories\Contracts\Application\ApplicationInterface;

/**
 * Application Model class used for handling loan applications.
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class Application extends Eloquent implements Auditable
{
   use SoftDeletes;
   use AutoIncrementID;
   use \OwenIt\Auditing\Auditable;

   const ID        = '_id';
   const USER_ID   = 'user_id';
   const STATUS_ID = 'status_id';
   const RECORD_ID = 'record_id';
   const APP_ID    = 'app_id';

   /**
    * The timestamps false is used to disibled model timestamps.
    * created_at is set on the SetCreatedAt observer
    * updated_at is set on the SetUpdatedAt observer
    *
    * @var boolean
    */
   public $timestamps = false;

   /**
    * Collection to be used for this model
    *
    * @var string
    */
   protected $collection = ApplicationInterface::COLLECTION;

   /** Guarded array to block the fields */
   protected $guarded = [];

   /**
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @param array $params
    *
    * @return string
    */
   public function saveApplication(array $params)
   {
      if (empty($params)) {
         throw new Exception('Invalid application details');
      }

      $result = $this->create($params);

      return $result ? $result  : null;
   }

   /**
    * Get applications by user_id
    * 
    * @author Amit kishore <amit.kishore@biz2credit.com>
    * 
    * @param array $params
    * 
    * @return string
    */
   public function getApplication(array $params)
   {
      if (!$params) {
         throw new Exception(trans('messages.v1.invalid_user_id'));
      }

      return $this->where($params)
         ->with('business')
         ->with('businessReferences')
         ->with('owners')
         ->with('ownerReferences')
         ->with('ownersWeightedAverage')
         ->with('appActivity')
         ->with('assignments')
         ->with('products')
         ->first();
   }

   /**
    * Get applications
    * 
    * @author Amit kishore <amit.kishore@biz2credit.com>
    * 
    * @param array $params
    * @param int $start
    * @param int $per_page
    * 
    * @return string
    */
   public function getApplications(array $params, int $start = 0, int $per_page = 20)
   {
      return $this->where($params)->orderBy(self::RECORD_ID, 'desc')
         ->with('business')
         ->with('businessReferences')
         ->with('owners')
         ->with('ownerReferences')
         ->with('ownersWeightedAverage')
         ->with('appActivity')
         ->with('assignments')
         ->with('products')
         ->offset($start)
         ->limit($per_page)
         ->get()
         ->toArray();
   }

   /**
    * Accessor Method to convert created_at timestamp into ISO8601
    * 
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @param timestamp $createdAt
    * @return string
    */
   public function getCreatedAtAttribute($createdAt)
   {
      return Date(DateTime::ISO8601, (int) (string) $createdAt);
   }

   /**
    * Accessor Method to convert updated_at timestamp into ISO8601
    * 
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @param timestamp $updatedAt
    * @return string
    */
   public function getUpdatedAtAttribute($updatedAt)
   {
      return Date(DateTime::ISO8601, (int) (string) $updatedAt);
   }

   /**
    * Mutator mehod to update created at into unix timestamp
    * 
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @param timestamp $value
    *
    * @return void
    */
   public function setCreatedAtAttribute($value)
   {
      $this->attributes[config('fields.v1.created_at')] = time();
   }

   /**
    * Mutator mehod to update created at into unix timestamp
    * 
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @param timestamp $value
    *
    * @return void
    */
   public function setUpdatedAtAttribute($value)
   {
      $this->attributes[config('fields.v1.updated_at')] = time();
   }

   /**
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @return object
    */
   public function business()
   {
      return $this->hasMany('App\Repositories\Models\Business', self::APP_ID);
   }

   /**
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @return object
    */
   public function businessReferences()
   {
      return $this->hasMany('App\Repositories\Models\ServiceBusiness', self::APP_ID);
   }

   /**
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @return array
    */
   public function owners()
   {
      return $this->hasMany('App\Repositories\Models\Owner', self::APP_ID);
   }

   /**
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @return array
    */
   public function ownerReferences()
   {
      return $this->hasMany('App\Repositories\Models\ServiceOwner', self::APP_ID);
   }

   /**
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @return array
    */
   public function ownersWeightedAverage()
   {
      return $this->hasOne('App\Repositories\Models\OwnersWeightedAverage', self::APP_ID);
   }

   /**
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @return array
    */
   public function appActivity()
   {
      return $this->hasMany('App\Repositories\Models\AppActivity', self::APP_ID);
   }

   /**
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @return array
    */
   public function assignments()
   {
      return $this->hasMany('App\Repositories\Models\AppAssignment', self::APP_ID);
   }

   /**
    * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
    *
    * @return array
    */
   public function products()
   {
      return $this->hasMany('App\Repositories\Models\Product', self::APP_ID);
   }

   /**
    * Get the collection name
    * 
    * @author Amit kishore <amit.kishore@biz2credit.com>
    *
    * @return string
    */
   public function getCollectionName()
   {
      return $this->collection;
   }
}
