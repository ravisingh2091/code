<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Service Business Model
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Models;

use DateTime;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Contracts\Service\ServiceInterface;

/**
 * Service Business Model class used for storing third party reference ids
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ServiceBusiness extends Eloquent
{
    const ID                 = '_id';

    /**
     * The timestamps false is used to disibled model timestamps.
     * created_at is set on the SetCreatedAt observer
     * updated_at is set on the SetUpdatedAt observer
     *
     * @var boolean
     */
    public $timestamps = false;
    
    /**
     * Collection to be used for this model
     *
     * @var string
     */
    protected $collection = ServiceInterface::COLLECTION_BUSINESS;

    /** Guarded array to block the fields */
    protected $guarded = [];

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $service_ids
     *
     * @return array
     */
    public function saveServiceIds(array $service_ids)
    {   
        if(empty($service_ids)) throw new BlankDataException();
        
        $result = $this->create($service_ids);
        
        return $result ? $result : null;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $service_ids
     *
     * @return array
     */
    public function getServiceIds(array $service_ids)
    {   
        if(empty($service_ids)) throw new BlankDataException();
        
        $ServiceBusiness = $this->where([
            ServiceInterface::USER_ID  => $service_ids[ServiceInterface::USER_ID],
            ServiceInterface::APP_ID   => $service_ids[ServiceInterface::APP_ID],
            ServiceInterface::PROVIDER => $service_ids[ServiceInterface::PROVIDER]
        ])->orderBy(config('fields.v1.created_at'), 'desc')->first();
        
        return $ServiceBusiness ? $ServiceBusiness : null;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $service_ids
     *
     * @return array
     */
    public function getAllServiceIds(array $service_ids)
    {
        if(empty($service_ids)) throw new BlankDataException();
        
        $ServiceBusiness = $this->where([
            ServiceInterface::USER_ID  => $service_ids[ServiceInterface::USER_ID],
            ServiceInterface::APP_ID   => $service_ids[ServiceInterface::APP_ID],
            ServiceInterface::PROVIDER => $service_ids[ServiceInterface::PROVIDER]
        ])->get();
        
        return $ServiceBusiness ? $ServiceBusiness : null;
    }

    /**
     * Accessor Method to convert created_at timestamp into ISO8601
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $createdAt
     * @return string
     */
    public function getCreatedAtAttribute($createdAt)
    {
        return Date(DateTime::ISO8601, (int) (string) $createdAt);
    }

    /**
     * Accessor Method to convert updated_at timestamp into ISO8601
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $updatedAt
     * @return string
     */
    public function getUpdatedAtAttribute($updatedAt)
    {
        return Date(DateTime::ISO8601, (int) (string) $updatedAt);
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setCreatedAtAttribute($value)
    {
        $this->attributes[config('fields.v1.created_at')] = time();
    }

    /**
     * Mutator mehod to update created at into unix timestamp
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param timestamp $value
     *
     * @return void
     */
    public function setUpdatedAtAttribute($value)
    {
        $this->attributes[config('fields.v1.updated_at')] = time();
    }

    /**
     * Get the collection name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function getCollectionName() 
    {
       return $this->collection;
    }
}
