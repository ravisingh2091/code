<?php
namespace App\Repositories\Validation;

use Illuminate\Validation\ValidationRuleParser;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Illuminate\Contracts\Validation\Rule as RuleContract;

class CustomValidator extends \Illuminate\Validation\Validator
{

    /**
     * Validate a given attribute against a rule.
     *
     * @param  string  $attribute
     * @param  string  $rule
     * @return void
     */
    protected function validateAttribute($attribute, $rule)
    {
        $this->currentRule = $rule;

        [$rule, $parameters] = ValidationRuleParser::parse($rule);
        
        if ($rule == '') {
            return;
        }

        // First we will get the correct keys for the given attribute in case the field is nested in
        // an array. Then we determine if the given rule accepts other field names as parameters.
        // If so, we will replace any asterisks found in the parameters with the correct keys.
        if (($keys = $this->getExplicitKeys($attribute)) &&
            $this->dependsOnOtherFields($rule)
        ) {
            $parameters = $this->replaceAsterisksInParameters($parameters, $keys);
        }

        $value = $this->getValue($attribute);

        // If the attribute is a file, we will verify that the file upload was actually successful
        // and if it wasn't we will add a failure for the attribute. Files may not successfully
        // upload if they are too large based on PHP's settings so we will bail in this case.
        if (
            $value instanceof UploadedFile && !$value->isValid() &&
            $this->hasRule($attribute, array_merge($this->fileRules, $this->implicitRules))
        ) {
            return $this->addFailure($attribute, 'uploaded', []);
        }

        // If we have made it this far we will make sure the attribute is validatable and if it is
        // we will call the validation method with the attribute. If a method returns false the
        // attribute is invalid and we will add a failure message for this failing attribute.
        $validatable = $this->isValidatable($rule, $attribute, $value);

        if ($rule instanceof RuleContract) {
            return $validatable
                ? $this->validateUsingCustomRule($attribute, $value, $rule)
                : null;
        }
        
        if (is_string($rule)) {
            if ($this->checkRegexExists($rule)) {
                $old_rule = explode('Regex:', $rule);
                $rule = 'Regex';
                $parameters[] = $old_rule[1];
            }
        }

        $method = "validate{$rule}";

        if ($validatable && !$this->$method($attribute, $value, $parameters, $this)) {
            $this->addFailure($attribute, $rule, $parameters);
        }
    }

    public function validateRegex($attribute, $value, $parameters)
    {

        if (!count($parameters) && is_array($parameters)) {
            return true;
        }

        if (is_array($value)) {
            $status = true;
            foreach ($value as $key => $v) {
                if (!preg_match($parameters[0], $value[$key])) {
                    $status = false;
                    break;
                }

                if (!$status) {
                    return false;
                }
            }

            return $status;
        }

        if (preg_match($parameters[0], $value)) {
            return true;
        }

        return false;
    }

    private function checkRegexExists($str)
    {
        if (strpos($str, 'Regex:') !== false) {
            return true;
        }
    }
}
