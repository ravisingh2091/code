<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Event Listener
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Listeners;

use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Repositories\Models\RequestResponseLog;
use App\Repositories\Events\AuditRequestResponseEvent;

/**
 * Event listener to audit request response
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class AuditRequestResponseListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  AuditRequestResponseEvent  $event
     * 
     * @return void
     */
    public function handle(AuditRequestResponseEvent $event)
    {
        $Request = app('request');

        $log = [
            'request_url'    => $Request->fullUrl(),
            'method'         => $Request->method(),
            'request_IP'     => $Request->ip(),
            'request_header' => $Request->header(),
            'request_body'   => $Request->all(),
            'response'       => $event->response,
            'status_code'    => $event->response['code'],
        ];

        RequestResponseLog::create($log);
    }
}
