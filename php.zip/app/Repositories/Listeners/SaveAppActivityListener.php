<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Event Listener
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Listeners;

use Illuminate\Queue\InteractsWithQueue;
use App\Repositories\Models\AppActivity;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Repositories\Events\SaveAppActivityEvent;

/**
 * Event listener to save app activity
 */
class SaveAppActivityListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  SaveAppActivityEvent $event
     * 
     * @return void
     */
    public function handle(SaveAppActivityEvent $event)
    {
        $Request = app('request');

        $activity = [
            config('fields.v1.app_id') => $event->app_id,
        ];

        if($Request->filled(config('fields.v1.status_id'))) {
            $activity = array_merge($activity, [
                config('fields.v1.status_id') => $Request->{config('fields.v1.status_id')}
            ]);
        }

        if($Request->filled(config('fields.v1.assigned_to'))) {
            $activity = array_merge($activity, [
                config('fields.v1.assigned_to') => $Request->{config('fields.v1.assigned_to')}
            ]);
        }

        if($Request->filled(config('fields.v1.backend_user_id'))) {
            $activity = array_merge($activity, [
                config('fields.v1.backend_user_id') => $Request->{config('fields.v1.backend_user_id')}
            ]);
        }

        if($Request->filled(config('fields.v1.note'))) {
            $activity = array_merge($activity, [
                config('fields.v1.note') => $Request->{config('fields.v1.note')}
            ]);
        }

        if(!$Request->has(config('fields.v1.action_from'))) {
            $activity = array_merge($activity, [
                config('fields.v1.action_from') => config('fields.v1.frontend')
            ]);
        }

        if($Request->filled(config('fields.v1.action_from'))) {
            $activity = array_merge($activity, [
                config('fields.v1.action_from') => $Request->{config('fields.v1.action_from')}
            ]);
        }

        if($Request->filled(config('fields.v1.is_completed'))) {
            $activity = array_merge($activity, [
                config('fields.v1.is_completed') => $Request->{config('fields.v1.is_completed')}
            ]);
        }

        if($Request->filled(config('fields.v1.action'))) {
            if(array_key_exists(strtolower($Request->{config('fields.v1.action')}), AppActivity::ACTIONS)){
                $activity = array_merge($activity, [
                    config('fields.v1.action') => AppActivity::ACTIONS[strtolower($Request->{config('fields.v1.action')})]
                ]);
            } else {
                $activity = array_merge($activity, [
                    config('fields.v1.action') => $Request->{config('fields.v1.action')}
                ]);
            }
        }

        if($Request->filled(config('fields.v1.role_id'))) {
            $activity = array_merge($activity, [
                config('fields.v1.role_id') => $Request->{config('fields.v1.role_id')}
            ]);
        }

        AppActivity::create($activity);
    }
}
