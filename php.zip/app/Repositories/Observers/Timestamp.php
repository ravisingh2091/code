<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Hook Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */ 

namespace App\Repositories\Observers;

use Illuminate\Database\Eloquent\Model;

/**
 * The Timestamp class creates timestamps
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class Timestamp
{
    /**
     * Sets created_at when creating the Model.
     * Timestamps property should be false on the Model.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Model $Model
     * @return void
     */
    public function creating(Model $Model)
    {
        $Model->setCreatedAt($Model->freshTimestamp());
        $Model->setUpdatedAt($Model->freshTimestamp());
    }

    /**
     * Sets updated_at when updating the Model.
     * Timestamps property should be false on the Model.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Model $Model
     * @return void
     */
    public function updating(Model $Model)
    {
        $Model->setUpdatedAt($Model->freshTimestamp());
    }
}