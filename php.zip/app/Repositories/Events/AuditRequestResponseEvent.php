<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Event Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Events;

use App\Events\Event;

/**
 * Event to be triggered to audit request response
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class AuditRequestResponseEvent extends Event
{
    public $response;

    /**
     * Create a new event instance.
     *
     * @param array $response
     * 
     * @return void
     */
    public function __construct(array $response)
    {
        $this->response = $response;
    }
}