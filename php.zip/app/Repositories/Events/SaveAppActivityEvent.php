<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Event Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Events;

use App\Events\Event;

/**
 * Event to be triggered to save app activity
 */
class SaveAppActivityEvent extends Event
{
    public $app_id;

    /**
     * Create a new event instance.
     *
     * @param string $app_id
     * 
     * @return void
     */
    public function __construct(string $app_id)
    {
        $this->app_id = $app_id;
    }
}