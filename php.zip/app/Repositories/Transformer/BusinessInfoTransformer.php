<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Transform Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Transformer;

use App\Repositories\Models\Business;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Contracts\Business\BusinessInterface;

/**
 * The Business Transformer class transform the response for the API
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class BusinessInfoTransformer
{
    /**
     * The tranform method is using for Fractal transformer.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param App\Repositories\Models\Business $Business
     *
     * @return array
     */
    public function transform(Business $Business)
    {
        $Business->{ApiInterface::RESOURCE_TYPE} = BusinessInterface::RESOURCE_NAME;
        $Business->{ApiInterface::ID} = $Business->{Business::ID};
        $Business->{ApiInterface::RESOURCE_URL} = config('api-urls.v1.url').'/application/v1/business';
        unset($Business->{Business::ID});
        $output = $Business->toArray();
        return $output;
    }

}
