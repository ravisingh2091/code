<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Transform Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Transformer;

use App\Repositories\Models\Product;
use Jenssegers\Mongodb\Eloquent\Model;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Contracts\Product\ProductInterface;

/**
 * Product Transformer class transform the response for the API
 *
 * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
 */
class ProductTransformer
{
    /**
     * The tranform method is using for Fractal transformer.
     * 
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param array $Products| Model $Products
     *
     * @return array
     */
    public function transform($Products)
    {
        $Response = [];
        if (is_array($Products)) {
            foreach($Products as $index => $Product) {
                $Products[$index][ApiInterface::ID] = $Product[Product::ID];
                $Products[$index][ApiInterface::RESOURCE_TYPE] = ProductInterface::RESOURCE_NAME;
                $Products[$index][ApiInterface::RESOURCE_URL] = config('api-urls.v1.url').'/v1/product/'.$Product[Product::ID];
                unset($Products[$index][Product::ID]);
            }
            $Response = $Products;
        }

        if ($Products instanceof Model) {
            $Products->{ApiInterface::ID} = $Products->{Product::ID};
            $Products->{ApiInterface::RESOURCE_TYPE} = ProductInterface::RESOURCE_NAME;
            $Products->{ApiInterface::RESOURCE_URL} = config('api-urls.v1.url').'/application/v1/product/'.$Products->{Product::ID};
            unset($Products->{Product::ID});
            $Response = $Products->toArray();
        }

        return $Response;
    }
}
