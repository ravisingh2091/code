<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Transform Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Transformer;

use App\Repositories\Models\Application;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Contracts\Application\ApplicationInterface;

/**
 * Application Transformer class transform the response for the API
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ApplicationTransformer
{
    /**
     * The tranform method is using for Fractal transformer.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param App\Repositories\Models\Application $Application
     *
     * @return array
     */
    public function transform(Application $Application)
    {
        $Application->{ApiInterface::RESOURCE_TYPE} = ApplicationInterface::RESOURCE_NAME;
        $Application->{ApiInterface::ID} = $Application->{Application::ID};
        $Application->{ApiInterface::RESOURCE_URL} = config('api-urls.v1.url').'/application/v1/applications';
        unset($Application->{Application::ID});
        $output = $Application->toArray();
        return $output;
    }
}
