<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Transform Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Transformer;

use App\Repositories\Models\ServiceCollateral;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Contracts\Service\ServiceInterface;

/**
 * ServiceCollateral Transformer class transform the response for the API
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ServiceCollateralTransformer
{
    /**
     * The tranform method is using for Fractal transformer.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param App\Repositories\Models\ServiceCollateral $ServiceCollateral
     *
     * @return array
     */
    public function transform(ServiceCollateral $ServiceCollateral)
    {
        $ServiceCollateral->{ApiInterface::RESOURCE_TYPE} = ServiceInterface::RESOURCE_NAME;
        $ServiceCollateral->{ApiInterface::ID} = $ServiceCollateral->{ServiceCollateral::ID};
        $ServiceCollateral->{ApiInterface::RESOURCE_URL} = config('api-urls.v1.url').'/application/v1/service/collateral';
        unset($ServiceCollateral->{ServiceCollateral::ID});
        $output = $ServiceCollateral->toArray();
        return $output;
    }
}
