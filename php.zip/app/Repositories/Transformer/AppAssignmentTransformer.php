<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Transform Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Transformer;

use App\Repositories\Models\AppAssignment;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Contracts\AppAssignment\AppAssignmentInterface;

/**
 * AppAssignment Transformer class transform the response for the API
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class AppAssignmentTransformer
{
    /**
     * The tranform method is using for Fractal transformer.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param App\Repositories\Models\AppAssignment $AppAssignment
     *
     * @return array
     */
    public function transform(AppAssignment $AppAssignment)
    {
        $AppAssignment->{ApiInterface::RESOURCE_TYPE} = AppAssignmentInterface::RESOURCE_NAME;
        $AppAssignment->{ApiInterface::ID} = $AppAssignment->{AppAssignment::ID};
        $AppAssignment->{ApiInterface::RESOURCE_URL} = config('api-urls.v1.url').'/application/v1/app_assignment';
        unset($AppAssignment->{AppAssignment::ID});
        $output = $AppAssignment->toArray();
        return $output;
    }
}
