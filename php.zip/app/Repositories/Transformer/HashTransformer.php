<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Transform Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Transformer;

use App\Repositories\Models\Hash;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Contracts\Hash\HashInterface;

/**
 * Hash Transformer class transform the response for the API
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class HashTransformer
{
    /**
     * The tranform method is using for Fractal transformer.
     * 
     * @param App\Repositories\Models\Hash $Hash
     *
     * @return array
     */
    public function transform(Hash $Hash)
    {
        $Hash->{ApiInterface::RESOURCE_TYPE} = HashInterface::RESOURCE_NAME;
        $Hash->{ApiInterface::ID} = $Hash->{Hash::ID};
        $Hash->{ApiInterface::RESOURCE_URL} = config('api-urls.v1.url').'/application/v1/hash';
        unset($Hash->{Hash::ID});
        unset($Hash->{Hash::ENCRYPTED_HASH});
        $output = $Hash->toArray();
        return $output;
    }
}