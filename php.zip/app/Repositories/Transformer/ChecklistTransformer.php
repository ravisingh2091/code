<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Transform Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Transformer;

use App\Repositories\Models\Checklist;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Contracts\Checklist\ChecklistInterface;

/**
 * Checklist Transformer class transform the response for the API
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ChecklistTransformer
{
    /**
     * The tranform method is using for Fractal transformer.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param App\Repositories\Models\Checklist $Checklist
     *
     * @return array
     */
    public function transform(Checklist $Checklist)
    {
        $Checklist->{ApiInterface::RESOURCE_TYPE} = ChecklistInterface::RESOURCE_NAME;
        $Checklist->{ApiInterface::ID} = $Checklist->{Checklist::ID};
        $Checklist->{ApiInterface::RESOURCE_URL} = config('api-urls.v1.url').'/application/v1/checklist';
        unset($Checklist->{Checklist::ID});
        $output = $Checklist->toArray();
        return $output;
    }
}
