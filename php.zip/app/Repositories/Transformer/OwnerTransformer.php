<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Transform Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Transformer;

use App\Repositories\Models\Owner;
use Jenssegers\Mongodb\Eloquent\Model;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Contracts\Owner\OwnersInterface;

/**
 * The Owners Transformer class transform the response for the API
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class OwnerTransformer
{
    /**
     * The tranform method is using for Fractal transformer.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $Owners | Model $owner
     *
     * @return array
     */
    public function transform($Owners)
    {  
        $Response = [];
        if (is_array($Owners)) {
            foreach($Owners as $index => $owner) {
                $Owners[$index][ApiInterface::ID] = $owner[Owner::ID];
                $Owners[$index][ApiInterface::RESOURCE_URL] = config('api-urls.v1.url').'/v1/owners';
                unset($Owners[$index][Owner::ID]);
            }
            $Response = $Owners;
        }

        if ($Owners instanceof Model) {
            $Owners->{ApiInterface::ID} = $Owners->{Owner::ID};
            $Owners->{ApiInterface::RESOURCE_URL} = config('api-urls.v1.url').'/application/v1/owners';
            unset($Owners->{Owner::ID});
            $Response = $Owners->toArray();
        }

        return $Response;
    }
}
