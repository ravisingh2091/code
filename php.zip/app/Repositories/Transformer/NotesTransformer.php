<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Repository Transform Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Transformer;

use App\Repositories\Models\Note;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Contracts\Notes\NotesInterface;

/**
 * Notes Transformer class transform the response for the API
 */
class NotesTransformer
{
    /**
     * The tranform method is using for Fractal transformer.
     *
     * @param App\Repositories\Models\Note $Note
     *
     * @return array
     */
    public function transform(Note $Note)
    {
        $Note->{ApiInterface::RESOURCE_TYPE} = NotesInterface::RESOURCE_NAME;
        $Note->{ApiInterface::ID} = $Note->{Note::ID};
        $Note->{ApiInterface::RESOURCE_URL} = config('api-urls.v1.url').'/application/v1/note';
        unset($Note->{Note::ID});
        $output = $Note->toArray();
        return $output;
    }
}
