<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Notes Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Notes;

/**
 * Notes interface used for Notes related constants and methods declaration.
 */
interface NotesInterface
{
    const RESOURCE_NAME = 'notes';
    const COLLECTION    = 'notes';
}
