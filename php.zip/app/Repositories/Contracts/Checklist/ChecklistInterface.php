<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Checklist Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Checklist;

/**
 * Checklist interface used for Checklist related constants and methods declaration.
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
interface ChecklistInterface
{
    const RESOURCE_NAME             = 'checklist';
    const COLLECTION                = 'checklist';
}
