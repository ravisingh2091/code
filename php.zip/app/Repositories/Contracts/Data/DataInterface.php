<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Data Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Data;

/**
 * DataInterface for handling Data from redis and orchestration/masterdata.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
interface DataInterface
{
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param array $attributes
     *
     * @return string
     */
    public function get(string $url, array $fields, string $action, string $slug = null); 
}
