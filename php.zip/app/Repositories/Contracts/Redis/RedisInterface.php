<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Redis;

/**
 * The RedisInterface interface creates redis constraints.
 *
 * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
 */
interface RedisInterface
{
    /**
     * The setKey routine will help us to set the key:value in redis
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param  string  $key
     * @param  string  $value
     *
     * @return string
    */
    public static function setKey(string $key, string $value, $expiration = null);

    /**
     * The getValue routine will help us to get the value in redis using key
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param string $key
     *
     * @return string
     */
    public static function getValue(string $key);

    /**
     * The setExpiration routine will help us to destroy Redis Key:value
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param string $key
     * @param int $expiration
     *
     * @return boolean
     */
    public static function setExpiration(string $key, int $expiration);
}
