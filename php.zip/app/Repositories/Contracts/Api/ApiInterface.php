<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Api Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Api;

/**
 * The ApiInterface is responsible for storing Api related constants and method declaration.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
Interface ApiInterface 
{
    const ID               = 'id';
    const CODE             = 'code';
    const RESOURCE_URL     = 'resource_url';
    const RESOURCE_TYPE    = 'resource_type';
    const STATUS           = 'status';
    const RESOURCE         = 'resource';
    const DATA             = 'data';
    const ERRORS           = 'errors';
    const VERSION          = 'v1';
    const AUDIT_COLLECTION = 'req_res_log';
    const CREATED_AT       = 'created_at';
    const UPDATED_AT       = 'updated_at';
    const HASH_COLLECTION  = 'hash';
}