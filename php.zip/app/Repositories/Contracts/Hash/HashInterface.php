<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Hash Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Hash;


interface HashInterface
{
    const RESOURCE_NAME = 'hash';
    const COLLECTION    = 'hash';
}
