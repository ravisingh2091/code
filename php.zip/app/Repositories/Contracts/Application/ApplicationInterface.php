<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Application Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Application;

use Illuminate\Http\Request;

/**
 * Application interface used for Application related constants and methods declaration.
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
interface ApplicationInterface 
{
    const RESOURCE_NAME           = 'application';
    const COLLECTION              = 'application';
    const APP_ACTIVITY_COLLECTION = 'app_activity';
    const WEIGHTED_AVG_COLLECTION = 'owners_weighted_avg';
    const START                   = 0;
    const PER_PAGE                = 20;

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param array $attributes
     *
     * @return string
     */
    public function create(array $attributes);    
}
