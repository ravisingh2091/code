<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Business Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Business;

use Illuminate\Http\Request;

/**
 * Business interface for holding business related constants and methods declaration.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
interface BusinessInterface 
{
    const RESOURCE_NAME = 'business';
    const COLLECTION    = 'business_info';
    
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param array $attributes
     *
     * @return string
     */
    public function create(array $attributes);  
    
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param array $attributes
     * @param string $businessId
     *
     * @return string
     */
    public function update(array $attributes, string $businessId); 
}