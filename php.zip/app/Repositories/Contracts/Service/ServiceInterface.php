<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Service Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Service;

use Illuminate\Http\Request;

/**
 * Service Interface for holding Service related constants and methods declaration.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
interface ServiceInterface 
{
    const COLLECTION_OWNER      = 'service_owner';
    const COLLECTION_BUSINESS   = 'service_business';
    const COLLECTION_COLLATERAL = 'service_collateral';
    const COLLECTION_PRODUCT    = 'service_product';
    const RESOURCE_NAME         = 'service';
    const APP_ID                = 'app_id';
    const USER_ID               = 'user_id';
    const REF_ID                = 'ref_id';
    const OWNER_ID              = 'owner_id';
    const COLLATERAL_ID         = 'collateral_id';
    const PROVIDER              = 'provider';
    const PRODUCT_ID            = 'product_id';
    const SERVICE_TYPE          = 'service_type';
    const PER_PAGE              = 'per_page';
    const START                 = 'start';
    const FROM_DATE             = 'from_date';
    const TO_DATE               = 'to_date';
    const TYPE                  = 'type';

    const LIMIT                 = 20;
    const OFFSET                = 0;
}