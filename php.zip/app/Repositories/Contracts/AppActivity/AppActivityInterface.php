<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   AppActivity Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\AppActivity;

/**
 * AppActivity interface used for AppActivity related constants and methods declaration.
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
interface AppActivityInterface 
{
    const RESOURCE_NAME = 'app_activity';
    const COLLECTION    = 'app_activity';
}
