<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Product Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Product;


interface ProductInterface
{
    const RESOURCE_NAME        = 'product';
    const COLLECTION           = 'product';
    const MAX_ALLOWED_PRODUCTS = 5;
}