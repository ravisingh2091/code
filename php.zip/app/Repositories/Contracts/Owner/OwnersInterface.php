<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Owner Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Owner;

use Illuminate\Http\Request;

/**
 * Owner Interface for holding owner related constants and methods declaration.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
interface OwnersInterface 
{
    const RESOURCE_NAME     = 'owners';
    const COLLECTION        = 'owner_details';
    const COLLECTION_HASH   = 'owner_hash';
    const MAX_ALLOWED_LEVEL = 3;
    const MAX_PERCENT       = 100;

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param array $attributes
     *
     * @return string
     */
    public function create(array $attributes);    

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param array $attributes
     * @param string $ownerId
     *
     * @return string
     */
    public function update(array $attributes, string $ownerId);    
}