<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Business Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\HealthCheck;

use Illuminate\Http\Request;

/**
 * HealthCheck interface for holding the service status related information.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
interface HealthCheckInterface 
{
    const RESOURCE_NAME = 'health';
    
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return string
     */
    public function check();  
    
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function checkAll(); 
}