<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Guzzle Http client Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\Http;

/**
 * HttpClient Interface for handling HttpClient related constants and methods declaration.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
interface HttpClientInterface 
{
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $url
     * @param array $parameters
     * @param array $headers
     * @param int $timeout
     *
     * @return string
     */
    public static function get(string $url, $timeout);
}