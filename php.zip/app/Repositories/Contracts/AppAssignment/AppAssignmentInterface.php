<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   AppAssignment Interface
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Contracts\AppAssignment;

/**
 * AppAssignment interface used for AppAssignment related constants and methods declaration.
 * 
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
interface AppAssignmentInterface 
{
    const RESOURCE_NAME = 'app_assignment';
    const COLLECTION    = 'app_assignment';
    const START         = 0;
    const PER_PAGE      = 20;
}
