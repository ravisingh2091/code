<?php

// *************************** DISCLAIMER ***************************
// Adding auto-incrementing id to Mongo using _id is not a good idea
// considering race condition it can cause duplicate key error.
// So, DONT'T USE IT IN _id!!! Instead, create another attribute
// to use as auto-increment ID.

namespace App\Repositories\Traits;

use DB;
use MongoDB\Operation\FindOneAndUpdate;

trait AutoIncrementID
{
    /**
     * Increment the counter and get the next sequence
     *
     * @param $collection
     * 
     * @return mixed
     */
    private static function getID($collection)
    {
        $seq = DB::getCollection('_data_counters')->findOneAndUpdate(
            ['model' => $collection],
            ['$inc' => ['seq' => 1]],
            ['new' => true, 'upsert' => true, 'returnDocument' => FindOneAndUpdate::RETURN_DOCUMENT_AFTER]
        );
        return $seq->seq;
    }

    /**
     * Boot the AutoIncrementID trait for the model.
     *
     * @return void
     */
    public static function bootAutoIncrementID()
    {
        static::creating(function ($model) {
            $model->record_id = self::getID($model->getTable());
        });
    }

    /**
     * Get the casts array.
     *
     * @return array
     */
    public function getCasts()
    {
        return $this->casts;
    }
}