<?php

/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Api Repository class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */


namespace App\Repositories\Entities\Api;

use App\Libraries\HttpClient;
use Illuminate\Support\Facades\Event;
use Jenssegers\Mongodb\Eloquent\Model;
use GuzzleHttp\Exception\RequestException;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Events\AuditRequestResponseEvent;

/**
 * ApiRepository class for handling Api response and transformation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
abstract class ApiRepository implements ApiInterface
{
    /**
     * This variable will hold the fields returned from orchestration for current request.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     */
    protected $field;

    /**
     * This variable will hold the fields that depends on the visible key.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     */
    protected $visible_fields;

    /**
     * This variable will hold the validation rules returned from orchestration for current request.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     */
    protected $validationField;

    /**
     * This routine will provide resource name of the resource.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    abstract public function getResourceName();

    /**
     * This routine will provide classname from which we are transforming our response.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    abstract public function getTransformClass();

    /**
     * The dispatchResponse method is using to create response structure.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $status
     * @param int $code
     * @param string $key (OPTIONAL)
     * @param array $messages (OPTIONAL)
     * 
     * @return string
     */
    public function dispatchResponse(string $status, int $code, string $key = '', array $messages = [])
    {
        $headers = [];

        $response = [
            self::STATUS => $status,
            self::CODE => $code,
        ];

        // check response status code and build response.
        // set two extra headers x-API-VERSION and x-LAST-MODIFIED_AT
        if ($code === 200 || $code === 201) {
            $response[self::DATA]     = $messages;
            $response[self::RESOURCE] = $key;
            $headers = [
                'X-API-VERSION'         => self::VERSION,
                'X-LAST-MODIFIED-AT'    => array_key_exists(self::UPDATED_AT, $messages) ? $messages[self::UPDATED_AT] : null
            ];
        } else {
            unset($response[self::DATA]);
            unset($response[self::RESOURCE]);
            $response[self::ERRORS] = $messages;
        }

        // Event::fire(new AuditRequestResponseEvent($response));
        return response()->json(array_filter($response, [$this, 'allowEmptyData']), $code, $headers);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param mixed $key
     *
     * @return boolean
     */
    private function allowEmptyData($key)
    {
        if (is_array($key) && empty($key)) {
            return true;
        }
        return true;
    }

    /**
     * fetch all the fields from orchestration service
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $url
     * @param array $validation_rules
     *
     * @return array
     */
    public function getFields(string $url, array $fields, string $action, string $slug = null, array $headers = [])
    {
        //HTTP Request to get the fields and override the default fields.
        $output = ['local_fields' => true, 'fields' => $fields, 'type' => $slug, 'allow_multiple_records' => false, 'visible_fields' => []];

        try {
            $url          = is_null($slug) ? $url . '&internal=true' : $url . '?slug=' . $slug . '&internal=true';
            $response     = HttpClient::get($url, config('guzzle.timeout'), $headers);
            $decoded_data = json_decode($response);

            // variable to check if inputType 'Group' is to be merge or not
            $mergeRequest = false;
            $this->visible_fields = [];

            if (isset($decoded_data) && (($decoded_data->status == trans('messages.v1.success')) || ($decoded_data->status == 200))) {
                if (isset($decoded_data->data) && isset($decoded_data->data->info)) {
                    $mergeRequest = (isset($decoded_data->data->info->allow_group) && ($decoded_data->data->info->allow_group == true)) ? true : false;
                    $output['fields'] = $this->parseFieldsArray((array) $decoded_data->data->info->form_fields, strtolower($action), $mergeRequest);
                    $output['local_fields'] = false;
                    $output['type'] = $decoded_data->data->info->slug;
                    $output['visible_fields'] = $this->visible_fields;
                    if (isset($decoded_data->data->info->allow_multiple) && ($decoded_data->data->info->allow_multiple == true)) {
                        $output['allow_multiple_records'] = true;
                    }
                    if (isset($decoded_data->data->info->allow_duplicate_email) && ($decoded_data->data->info->allow_duplicate_email  == true)) {
                        $output = array_merge($output, [
                            'allow_duplicate_email' => true
                        ]);
                    }
                    if (isset($decoded_data->data->info->skip_fields) && (count($decoded_data->data->info->skip_fields) > 0)) {
                        $output = array_merge($output, [
                            'skip_fields' => $decoded_data->data->info->skip_fields
                        ]);
                    }
                } else {
                    // $json = json_decode(file_get_contents(base_path('./public/fields.json')));
                    $output['fields'] = $this->parseFieldsArray((array) $decoded_data->data->form_fields, strtolower($action), $mergeRequest);
                    $output['local_fields'] = false;
                    $output['type'] = isset($decoded_data->data->type) ? $decoded_data->data->type : (isset($decoded_data->data->task_slug) ? $decoded_data->data->task_slug : '');
                    $output['visible_fields'] = $this->visible_fields;
                }
            }
            return $output;
        } catch (RequestException $e) {
            return false;
            // return $output;
        }
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $json
     *
     * @return array
     */
    private function parseFieldsArray(array $fields, string $action, bool $mergeGroup)
    {
        $output = [];

        foreach ($fields as $key => $value) {
            // create field_visible array 
            $this->visibleField($value);

            if (!isset($value->readonly)  || (isset($value->readonly) && $value->readonly == false)) {
                $output[$value->name] = [];
                if (!empty($value->validations)) {
                    $output[$value->name] = $this->getValidationForAction($action, $value->validations);
                }

                if (!empty($value->field_arr) && !$mergeGroup) {
                    $output = array_merge($output, $this->parseFieldsArray($value->field_arr, $action, $mergeGroup));
                } else if (!empty($value->field_arr) && $mergeGroup && ($value->inputType !== 'group')) {
                    $output = array_merge($output, $this->parseFieldsArray($value->field_arr, $action, $mergeGroup));
                } else if (isset($value->inputType) && ($value->inputType === 'group') && $mergeGroup) {
                    $output[$value->name] = array_merge($output[$value->name], $this->parseFieldsArray($value->field_arr, $action, $mergeGroup));
                }
                // else if (!empty($value->group_fields) && !$mergeGroup && $value->multiple == true) {
                //     $output = array_merge($output, $this->parseFieldsArray($value->group_fields, $action, $mergeGroup));
                // } 
            }
        }

        return $output;
    }


    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param object $field
     *
     * @return null
     */
    private function visibleField($field)
    {
        if (isset($field->visible)) {
            array_push($this->visible_fields, [
                'key' => $field->visible->key,
                'value' => $field->visible->value,
                'validate_field' => $field->name
            ]);
        }
    }

    /**
     * This function is used to remove the requried validation from visibile_fields
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $fields
     * @param object $Request
     *
     * @return null
     */
    public function validateVisibleFields(&$fields, $Request, $input_data = null)
    {
        if (isset($fields['visible_fields'])) {
            foreach ($fields['visible_fields'] as $visible_field) {
                // check if $visible_field['value'] is array and then check any value it has matching data in request
                // if yes no then remove validation from $visible_field['validate_field']

                if ($Request->filled($visible_field['key']) || (!is_null($input_data) && isset($input_data[$visible_field['key']]))) {

                    $requestData = !is_null($input_data) ? $input_data[$visible_field['key']] : $Request->get($visible_field['key']);

                    if (is_array($visible_field['value'])) {
                        $valueFound = array_search($requestData, $visible_field['value']);

                        if ($valueFound === false) {
                            $this->remoteValidation($fields, $visible_field);
                        }
                    } else {

                        if ($requestData !== $visible_field['value']) {
                            $this->remoteValidation($fields, $visible_field);
                        }
                    }
                }
            }
        }
    }

    /**
     * This function is used to remove the requried validation and update the form fields
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $fields
     * @param object $Request
     *
     * @return null
     */
    private function remoteValidation(&$fields, $visible_field)
    {
        $validation = $fields['fields'][$visible_field['validate_field']];
        $key = array_search('required', $validation);
        if ($key !== false) {
            array_splice($validation, $key);
            $fields['fields'][$visible_field['validate_field']] = $validation;
        }
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $fieldsArray
     * @param string $fieldName
     *
     * @return array
     */
    public function createGroupValidation(array $fieldsArray, string $fieldName = null)
    {
        $result = [];
        foreach ($fieldsArray as $field => $rules) {
            if ($this->is_assoc($rules)) {
                $tmp = isset($this->field) ? $this->field . '.*.' . $field : $field;
                $result = array_merge($result, $this->createGroupValidation($rules, $tmp));
            } else {
                if (is_null($fieldName)) {
                    // put validatio on array
                    $result[$field] = $rules;
                } else {
                    // put validation with '*'
                    $this->field = $fieldName;
                    $result[$fieldName . '.*.' . $field] = $rules;
                }
            }
        }

        return $result;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $action
     * @param array $validations
     *
     * @return array
     */
    private function getValidationForAction(string $action, array $validations)
    {
        $result = [];

        if (empty(($validations))) return $result;

        foreach ($validations as $validation) {
            if (isset($validation->action) && in_array($action, $validation->action)) {

                if ($validation->name == 'pattern') {
                    $rule = isset($validation->args) ? 'regex:' . $validation->validations : 'regex:' . $validation->validations;
                } else {
                    $rule = isset($validation->args) ? $validation->validations . ':' . $validation->args : $validation->validations;
                }
                array_push($result, $rule);
            }
        }

        return $result;
    }


    /**
     * The transformResponse methos is using to transform response.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param Illuminate\Database\Eloquent\Model $Data
     * @param string $transformer
     * 
     * @return array
     */
    public function transformResponse(Model $Data, $transformer)
    {
        if (!$Data->count()) {
            return new BlankDataException('Data is empty');
        }

        return (new $transformer)->transform($Data);
    }

    /**
     * The transformResponseArr methos is using to transform response.
     * 
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     * 
     * @param array $Data
     * @param string $transformer
     * 
     * @return array
     */
    public function transformResponseArr(array $Data, $transformer)
    {
        if (empty($Data)) {
            return new BlankDataException('Data is empty');
        }

        return (new $transformer)->transform($Data);
    }

    /**
     * The transformOwners methods is using to transform response.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param array $Data
     * @param string $transformer
     * 
     * @return array
     */
    public function transformOwners(array $Data, $transformer)
    {
        if (empty($Data)) {
            return new BlankDataException('Data is empty');
        }

        return (new $transformer)->transform($Data);
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $fields
     *
     * @return array
     */
    public function filterValidation(array $rules, array $fields)
    {
        return array_intersect_key($rules, array_flip($fields));
    }

    /**
     * Get Applicant info
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $url
     * @param string $version
     * @param string $user_id
     * 
     * @return string
     */
    public function getApplicant(string $url, string $version, string $user_id)
    {
        try {
            $user = json_decode(HttpClient::get($url . '/' . $version . '/users/' . $user_id, config('guzzle.timeout')));

            if (isset($user) && $user->status == trans('messages.v1.success')) {
                $applicant = [
                    config('fields.v1.applicant_name') => $user->data->{config('fields.v1.first_name')} . ' ' . $user->data->{config('fields.v1.last_name')},
                    config('fields.v1.applicant_email') => $user->data->{config('fields.v1.email_address')}
                ];

                return $applicant;
            } else {
                return null;
            }
        } catch (RequestException $e) {
            return null;
        }
    }

    /**
     * Get user by name
     *
     * @param string $url
     * @param string $version
     * @param string $name
     * 
     * @return string
     */
    public function getUserByName(string $url, string $version, string $name)
    {
        try {
            $user = json_decode(HttpClient::get($url . '/' . $version . '/customers' . '?name=' . $name, config('guzzle.timeout')));

            if (isset($user) && $user->status == trans('messages.v1.success') && count($user->data) > 0) {
                $Users = $user->data;

                $user_ids = [];

                foreach ($Users as $User) {
                    $user_ids[] = $User->{config('fields.v1.id')};
                }

                return $user_ids;
            } else {
                return null;
            }
        } catch (RequestException $e) {
            return null;
        }
    }

    /**
     * Get Product Configurations
     *
     * @param string $url
     * @param string $version
     * 
     * @return string
     */
    public function getProductConfig(string $url, string $version)
    {
        try {
            $config = json_decode(HttpClient::get($url . '/' . $version . '/product_config', config('guzzle.timeout')));

            if (isset($config) && $config->status == trans('messages.v1.success') && count($config->data) > 0) {
                $prod_config = $config->data;

                return $prod_config;
            } else {
                return null;
            }
        } catch (RequestException $e) {
            return null;
        }
    }

    /**
     * Bind validation rule with validation messages
     * 
     * @param array $formFields
     *
     * @return array
     */
    public function bindValidations(array $formFields)
    {
        return $this->bindValidationMessages($formFields);
    }

    /**
     * Bind validation with messages
     *
     * @param array $formFields
     * @param string $fieldName
     * 
     * @return mixed
     */
    private function bindValidationMessages(array $formFields, string $fieldName =  null)
    {
        $result = [];
        $messages = config('validation_message.v1.rule_messages');

        foreach ($formFields as $field => $rules) {

            if (!empty($rules)) {

                if ($this->is_assoc($rules)) {
                    $tmp = isset($this->validationField) ? $this->validationField . '.*.' . $field : $field;
                    $result = array_merge($result, $this->bindValidationMessages($rules, $tmp));
                } else {
                    foreach ($rules as $k => $rule) {

                        $key = explode(':', $rule);

                        if (isset($key[0]) && array_key_exists($key[0], $messages)) {

                            $ruleKey = $key[0];

                            $tempField = is_null($fieldName) ? $field : $fieldName . '.*.' . $field;

                            if (!is_null($fieldName)) {
                                $this->validationField = $fieldName;
                            }

                            $validation_key = $tempField . '.' . $ruleKey;

                            if ($ruleKey == 'maxLength') {

                                $validation_key = $tempField . '.' . 'max_length';
                            } else if ($ruleKey == 'minLength') {

                                $validation_key = $tempField . '.' . 'max_length';
                            }

                            $validation[$validation_key] = $messages[$ruleKey];

                            $validation[$validation_key]['parameter'] = $tempField;

                            $result = array_merge($result, $validation);
                        }
                    }
                }
            }
        }

        return $result;
    }

    /**
     * Check if array is assositive array 
     *
     * @param array $array
     * 
     * @return bool
     */
    private function is_assoc(array $array)
    {
        return is_array($array) && array_diff_key($array, array_keys(array_keys($array)));
    }

    /**
     * Fetch data by making an http request
     *
     * @param array $params
     * @param [type] $fetch_param
     * 
     * @return string
     */
    public function fetchDataByHTTP(array $params, $fetch_param = null)
    {
        if (empty($params)) return null;

        try {
            switch ($params[config('fields.v1.http_method')]) {
                case 'get': {
                        $url_arr = explode('-', $params[config('fields.v1.fetch_from_http')]);
                        $final_url = config('api-urls.v1.' . $url_arr[0]) . $url_arr[1] . $params[config('fields.v1.query_params')] . '=' . $fetch_param;

                        $response = json_decode(HttpClient::get($final_url, config('guzzle.timeout')));

                        if (isset($response) && $response->status == trans('messages.v1.success') && count($response->data) > 0) {
                            $res_data = $response->data;
                            $ids = [];

                            foreach ($res_data as $data) {
                                $ids[] = $data->{config('fields.v1.id')};
                            }
                            return $ids;
                        } else {
                            return null;
                        }
                    }
                default:
                    return null;
            }
        } catch (RequestException $e) {
            return null;
        }
    }
}
