<?php 

namespace App\Repositories\Entities\v1\Hash;

use App\Repositories\Models\Hash;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Transformer\HashTransformer;
use App\Repositories\Contracts\Hash\HashInterface;

class HashRepository extends ApiRepository implements HashInterface
{
    /**
     * Hash Model
     *
     * @var App\Repositories\Models\Hash
     */
    protected $Hash;

    /**
     * @param App\Repositories\Model\Hash $Hash
     */
    public function __construct(Hash $Hash)
    {
        $this->Hash = $Hash;
    }

    /**
     * Create Hash
     *
     * @param array $params
     * 
     * @return string
     */
    public function create(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $Hash = $this->Hash->saveHash($params);
        
        return $Hash ? $Hash : null;
    }

    /**
     * Get Hash
     * 
     * @param array $params
     * 
     * @return string
     */
    public function get(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $Hash = $this->Hash->where($params)->first();

        return $Hash instanceof Hash ? $Hash : null;
    }

    /**
     * Update Hash
     * 
     * @param string $hash
     * @param array $params
     * 
     * @return string
     */
    public function update(string $hash, array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $Hash = $this->Hash->where(Hash::ENCRYPTED_HASH, $hash)->update($params);

        return $Hash;
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return HashTransformer::class;
    }

    /**
     * Check if hash is expired or not
     * 
     * @param string $hash
     * @param string $hash_for
     * @param string $expiry_hours
     * 
     * @return boolean
     */
    public function checkConsentHashExpiry(string $hash, string $hash_for, string $expiry_hours = '')
    {
        $hash_created_at = $this->getConsentHashCreatedAt($hash, $hash_for);
        
        return $this->checkEmailTokenExpiry($hash_created_at, $expiry_hours);
    }

    /**
     * Get Hash Created At
     * 
     * @param string $hash
     * @param string $hash_for
     * 
     * @return string
     */
    public function getConsentHashCreatedAt(string $hash, string $hash_for)
    {
        $created_at = $this->Hash->select(Hash::CREATED_AT)
                        ->where(Hash::ENCRYPTED_HASH, $hash)
                        ->where(Hash::HASH_FOR, $hash_for)
                        ->first()->toArray();
                        
        return $created_at ? strtotime($created_at[Hash::CREATED_AT]) : null;
    }

    /**
     * Check if hash has expired or not
     * 
     * @param string $token_time
     * @param string $expiry_hours
     * 
     * @return boolean
     */
    public function checkEmailTokenExpiry(string $token_time, string $expiry_hours)
    {
        $expiry = strlen($expiry_hours) > 0 ? $expiry_hours : config('owner_consent.v1.EMAIL_TOKEN_EXPIRE_TIME');
        $after24h = strtotime('+'.$expiry.' hours', $token_time);
        $current_time = time();
        if ($after24h < $current_time) return false;
        return true;
    }


    /**
     * Check if hash is latest in db or not
     *
     * @param string $hash
     * @param string $hash_for
     * 
     * @return boolean
     */
    public function isHashNew(string $hash, string $hash_for)
    {   
        $Hash = Hash::where(Hash::ENCRYPTED_HASH, $hash)->where(Hash::HASH_FOR, $hash_for)->first();
        
        $latest_hash = $this->Hash->select(Hash::ENCRYPTED_HASH)
                            ->where(Hash::APP_ID, $Hash->{Hash::APP_ID});

        if(isset($Hash->{Hash::USER_ID})) {
            $latest_hash = $latest_hash->where(Hash::USER_ID, $Hash->{Hash::USER_ID});
        }

        if(isset($Hash->{Hash::EMAIL})) {
            $latest_hash = $latest_hash->where(Hash::EMAIL, $Hash->{Hash::EMAIL});
        }

        if(isset($Hash->{Hash::OWNER_ID})) {
            $latest_hash = $latest_hash->where(Hash::OWNER_ID, $Hash->{Hash::OWNER_ID});
        }

        $latest_hash = $latest_hash->where(Hash::HASH_FOR, $hash_for)
                            ->orderBy(Hash::CREATED_AT, 'desc')
                            ->first();
        
        if($latest_hash->{Hash::ENCRYPTED_HASH} === $hash) { 
            return true;
        }
    }

    /**
     * Check if Hash is already verified
     *
     * @param string $hash
     * @param string $hash_for
     * 
     * @return boolean
     */
    public function isHashVerified(string $hash, string $hash_for)
    {
        $Hash = $this->Hash->where(Hash::ENCRYPTED_HASH, $hash)
                            ->where(Hash::HASH_FOR, $hash_for)
                            ->first();

        if($Hash->{Hash::HASH_VERIFIED} == true) {
            return true;
        }

        return false;
    }
}