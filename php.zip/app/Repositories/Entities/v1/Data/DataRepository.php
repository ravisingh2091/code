<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Business Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\v1\Data;

use App\Libraries\HttpClient;
use App\Libraries\Redis;
use GuzzleHttp\Exception\RequestException;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Contracts\Data\DataInterface;

 /**
 * BusinessRepository class for handling business info CRUD operation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class DataRepository implements DataInterface
{
    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $url
     * @param array $fields
     * @param string $action
     * @param string $slug
     *
     * @return string
     */
    public function get(string $url, array $fields, string $action, string $slug = null)
    {
        // find details from redis
        $output = ['local_fields'=>true, 'fields'=>$fields, 'type'=> $slug];

        $data = null;
        if (!is_null($slug)) {
            $data = Redis::getValue($slug);
        }
        
        if (!$data || empty($data)) {
            // if data found from redis then return for further processing
            $data = $this->getFields($url, $fields, $action, $slug);
            if (!$data['local_fields']) {
               $output['fields']       = $this->parseFieldsArray((array) $data['fields'], strtolower($action));
               $output['local_fields'] = false;
            }
        } else {
            $output['fields']       = $this->parseFieldsArray((array) $data['fields'], strtolower($action));
            $output['local_fields'] = false;
        }

        return $output;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $url
     * @param array $fields
     * @param string $action
     * @param string $slug
     *
     * @return array
     */
    public function getFields(string $url, array $fields, string $action, string $slug = null)
    {
        //HTTP Request to get the fields and override the default fields.
        $output = ['local_fields'=>true, 'fields'=>$fields, 'type'=> $slug];

        try {
            $url          = is_null($slug) ? $url : $url.'?slug='.$slug;
            $response     = HttpClient::get($url, config('guzzle.timeout'));
            $decoded_data = json_decode($response);
            if (isset($decoded_data) && ($decoded_data->status == trans('messages.v1.success'))) {
                // $json = json_decode(file_get_contents(base_path('./public/fields.json')));
                $output['fields']       = $decoded_data->data->form_fields;
                $output['local_fields'] = false;
                $output['type']         = $decoded_data->data->type;
            }
            return $output;
        } catch(RequestException $e) {
            return $output;
        }
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $json
     *
     * @return array
     */
    private function parseFieldsArray(array $fields, string $action) 
    {
        $output = [];

        foreach ($fields as $key => $value) {
            
            $output[$value->name] = [];
            
            if(!empty($value->validations)) {
                $output[$value->name] = $this->getValidationForAction($action, $value->validations);
            }
            
            if (!empty($value->field_arr)) {
                $output = array_merge($output, $this->parseFieldsArray($value->field_arr, $action));
            }
        }

        return $output;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $action
     * @param array $validations
     *
     * @return array
     */
    private function getValidationForAction(string $action, array $validations) 
    {
        $result = [];
        
        if (empty(($validations))) return $result;
        
        foreach($validations as $validation) {
            if(isset($validation->action) && in_array($action, $validation->action)) {

                if($validation->name == 'pattern') {
                    $rule = isset($validation->args) ? 'regex:'.$validation->validations : 'regex:'.$validation->validations;
                } else {
                    $rule = isset($validation->args) ? $validation->validations.':'.$validation->args : $validation->validations;
                }
                array_push($result, $rule);
            }
        }

        return $result;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $url
     * @param string $id
     * @param string $collectionName
     *
     * @return array
     */
    public function checkFromMasterData(string $url, string $id, string $collectionName) 
    {
        $found = false;
        $key   = $collectionName.'_'.$id;
        $url   = $url.'/'.$id;

        $data = Redis::getValue($key);

        if (!$data || $data == 'null' || empty($data)) {
            // if data found from redis then return for further processing
            $output = $this->getFromMasterData($url);
            if (!empty($output) && isset($output)) {
                $found = $output->{config('fields.v1.id')} === $id ? $output : false;
            }

        } else {
            $decoded = json_decode($data);
            $found = isset($decoded->{config('fields.v1.id')}) && ($decoded->{config('fields.v1.id')} === $id) ? $decoded : false;
        }

        return $found;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $url
     *
     * @return array
     */
    private function getFromMasterData(string $url) 
    {
        $output = [];
        try {
            $response     = HttpClient::get($url, config('guzzle.timeout'));
            $decoded_data = json_decode($response);
            if (isset($decoded_data) && !empty($decoded_data) && isset($decoded_data->data)) {
                $output  = $decoded_data->data;
            }
            return $output;
        } catch(RequestException $e) {
            return $output;
        }
    }
}