<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Collateral Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\v1\Collateral;

use Illuminate\Http\Request;
use App\Repositories\Models\Collateral;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Transformer\CollateralTransformer;
use App\Repositories\Exceptions\ObjectNotLoadedException;
use App\Repositories\Contracts\Collateral\CollateralInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
/**
 * CollateralRepository class for handling Collateral operation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class CollateralRepository extends ApiRepository implements CollateralInterface
{
    /**
     * Collateral Model
     *
     * @var App\Repositories\Models\Collateral
     */
    protected $Collateral;

    /**
     * @param App\Repositories\Model\Collateral $Collateral
     */
    public function __construct(Collateral $Collateral)
    {
        $this->Collateral = $Collateral;
    }

    public function create(array $attributes)
    {
        if(empty($attributes)) throw new BlankDataException();

        $app_id = $attributes[Collateral::APP_ID];
        $user_id = $attributes[Collateral::USER_ID];

        $Collaterals = [];

        foreach($attributes[config('fields.v1.collaterals_field')] as $collateral) {
            $params = array_merge($collateral, [
                Collateral::APP_ID  => $app_id,
                Collateral::USER_ID => $user_id
            ]);
            $Collaterals[] = $this->Collateral->saveCollateral($params);
        }

        if (!$Collaterals) throw new ObjectNotLoadedException();

        return $Collaterals;
    }

    /**
     * Get Collateral
     *
     * @param string $id
     * 
     * @return string
     */
    public function get(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $Collateral = $this->Collateral->where($params)->first();
        
        return $Collateral instanceof Collateral ? $Collateral : false;
    }

    /**
     * Get all collaterals
     *
     * @param array $params
     * 
     * @return string
     */
    public function getAll(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        if(isset($params[config('fields.v1.collateral_id')]) && !empty($params[config('fields.v1.collateral_id')])) {
            $params = array_merge($params, [
                Collateral::ID => $params[config('fields.v1.collateral_id')]
            ]);
            unset($params[config('fields.v1.collateral_id')]);
        }

        $Collateral = $this->Collateral->where($params)->get();
        
        return $Collateral ? $Collateral : false;
    }

    /**
     * Update Collateral
     *
     * @param array $attributes
     * @param string $id
     * 
     * @return string
     */
    public function update(array $attributes, string $id)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Collateral = $this->Collateral->where(Collateral::ID, $id)->first();

        if (!$Collateral instanceof Collateral) return false;

        $Collateral->update($attributes);

        return $Collateral;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $attributes
     *
     * @return string
     */
    public function updateBatch(array $attributes) 
    {   
        // before updating collaterals delete the old collaterals 
        $deleted = $this->Collateral->where([
            Collateral::APP_ID => $attributes[Collateral::APP_ID],
            Collateral::USER_ID => $attributes[Collateral::USER_ID]
        ])->delete();
        
        //insert new collaterals
        if($deleted) {
            return $this->create($attributes);
        }
        
        return false;
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return CollateralTransformer::class;
    }
}