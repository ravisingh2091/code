<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   AppActivity Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\v1\AppActivity;

use App\Repositories\Models\AppActivity;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Contracts\AppActivity\AppActivityInterface;

/**
 * AppActivityRepository class for handling AppActivity operation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class AppActivityRepository extends ApiRepository implements AppActivityInterface
{
    /**
     * AppActivity Model
     *
     * @var App\Repositories\Models\AppActivity
     */
    protected $AppActivity;

    /**
     * @param App\Repositories\Model\AppActivity $AppActivity
     */
    public function __construct(AppActivity $AppActivity)
    {
        $this->AppActivity = $AppActivity;
    }


    /**
     * get Application Activity 
     *
     * @param array $params
     * 
     * @return string
     */
    public function get(array $params)
    {
        $AppActivity = $this->AppActivity->where($params)->first();

        return $AppActivity;
    }

    /**
     * get All Application Activities 
     *
     * @param array $params
     * 
     * @return string
     */
    public function getAll(array $params)
    {
        $AppActivity = $this->AppActivity->where($params)->get();

        return $AppActivity;
    }

    /**
     * get All Application Activities by App ids
     *
     * @param array $app_ids
     * 
     * @return string
     */
    public function getAllByAppIds(array $app_ids)
    {
        $AppActivity = $this->AppActivity->whereIn(config('fields.v1.app_id'), $app_ids)->get();

        return $AppActivity;
    }

    /**
     * Update Activity 
     *
     * @param array $attributes
     * 
     * @return string
     */
    public function update(array $attributes, string $activity_id)
    {
        $AppActivity = $this->AppActivity->where([AppActivity::ID => $activity_id])->first();
        
        if($AppActivity) {
            $AppActivity->update($attributes);
        }

        return $AppActivity;
    }

    /**
     * Reset Activity 
     *
     * @param array $attributes
     * 
     * @return string
     */
    public function reset(array $attributes)
    {
        $AppActivities = $this->AppActivity->whereIn(config('fields.v1.mongo_id'),$attributes[config('fields.v1.activities')])->get();
        
        if(!$AppActivities) {
            return [];
        }

        $AppActivity = $this->AppActivity->whereIn(config('fields.v1.mongo_id'),$attributes[config('fields.v1.activities')])->update([
            AppActivity::IS_COMPLETED  => $attributes[AppActivity::IS_COMPLETED]
        ]);

        return $this->AppActivity->whereIn(config('fields.v1.mongo_id'),$attributes[config('fields.v1.activities')])->get();
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return AppAssignmentTransformer::class;
    }
}