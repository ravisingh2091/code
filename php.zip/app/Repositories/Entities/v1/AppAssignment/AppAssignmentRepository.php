<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   AppAssignment Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\v1\AppAssignment;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Event;
use App\Repositories\Models\Business;
use App\Repositories\Models\Application;
use App\Repositories\Models\AppAssignment;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Events\SaveAppActivityEvent;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Exceptions\ObjectNotLoadedException;
use App\Repositories\Transformer\AppAssignmentTransformer;
use App\Repositories\Contracts\AppAssignment\AppAssignmentInterface;


/**
 * AppAssignmentRepository class for handling AppAssignment operation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class AppAssignmentRepository extends ApiRepository implements AppAssignmentInterface
{
    /**
     * AppAssignment Model
     *
     * @var App\Repositories\Models\AppAssignment
     */
    protected $AppAssignment;

    /**
     * @param App\Repositories\Model\AppAssignment $AppAssignment
     */
    public function __construct(AppAssignment $AppAssignment)
    {
        $this->AppAssignment = $AppAssignment;
    }

    /**
     * Save Assignments 
     *
     * @param array $attributes
     * 
     * @return string
     */
    public function create(array $attributes)
    {
        if(empty($attributes)) throw new BlankDataException();

        $AppAssignment = $this->AppAssignment->saveAssignment($attributes);

        if (!$AppAssignment instanceof AppAssignment){ 
            throw new ObjectNotLoadedException();
        } else { //dd($AppAssignment->{config('fields.v1.app_id')});
            Event::fire(new SaveAppActivityEvent($AppAssignment->{config('fields.v1.app_id')}));
        } 

       return $AppAssignment;
    }

    /**
     * Get assignment record
     *
     * @param array $params
     * 
     * @return string
     */
    public function get(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $AppAssignment = $this->AppAssignment->where($params)->first();

        return $AppAssignment ? $AppAssignment : false;
    }

    public function delete(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $deleted = $this->AppAssignment->where($params)->delete();

        if($deleted) {
            Event::fire(new SaveAppActivityEvent($params[config('fields.v1.app_id')]));
        }

        return $deleted ? $deleted : false;
    }

    /**
     * Get App Assignment
     *
     * @param string $Request
     * 
     * @return string
     */
    public function getAppAssignment(Request $Request)
    {   
        $start    = self::START;
        $per_page = self::PER_PAGE;

        if($Request->filled(config('fields.v1.start'))) {
            $start = (int) $Request->{config('fields.v1.start')};
        }

        if($Request->filled(config('fields.v1.per_page'))) {
            $per_page = (int) $Request->{config('fields.v1.per_page')};
        }

        $AppAssignment = $this->AppAssignment;

        if($Request->filled(config('fields.v1.from_date')) && $Request->filled(config('fields.v1.to_date'))) {
            $apps = Application::select(Application::ID)
                        ->where(config('fields.v1.created_at'), '>=', (int) $Request->{config('fields.v1.from_date')})
                        ->where(config('fields.v1.created_at'), '<=', (int) $Request->{config('fields.v1.to_date')})
                        ->get()
                        ->toArray();

            if(!$apps) return [];

            foreach($apps as $i => $app) {
                $apps[$i] = $app[Application::ID];
            }

            $AppAssignment = $AppAssignment->whereIn(AppAssignment::APP_ID, $apps);
        }

        if($Request->filled(config('fields.v1.app_id'))) {
            if($Request->filled(config('fields.v1.name'))) {
                $user_ids = $this->getUserByName(config('api-urls.v1.user_service').'/backend', config('fields.v1.version_v1'), $Request->{config('fields.v1.name')});
                
                $user_match = $user_ids === null ? false : $this->getUserInfo($Request->{config('fields.v1.app_id')}, $user_ids);
                
                if(!$user_match) {
                    return [];
                } else {
                    $AppAssignment = $AppAssignment->where(AppAssignment::APP_ID, $Request->{config('fields.v1.app_id')});
                }
            } else {
                $AppAssignment = $AppAssignment->where(AppAssignment::APP_ID, $Request->{config('fields.v1.app_id')});
            }
        }

        if($Request->filled(config('fields.v1.name')) && !$Request->filled(config('fields.v1.app_id'))) {
            $user_ids = $this->getUserByName(config('api-urls.v1.user_service').'/backend', config('fields.v1.version_v1'), $Request->{config('fields.v1.name')});
            
            if($user_ids === null) {
                return [];    
            }
            
            $apps = Application::select(Application::ID)->whereIn(Application::USER_ID, $user_ids)->get()->toArray();

            if(!$apps) return [];

            $app_ids = [];

            foreach($apps as $app) {
                $app_ids[] = $app[Application::ID];
            }

            $AppAssignment = $AppAssignment->whereIn(AppAssignment::APP_ID, $app_ids);
        }

        if($Request->filled(config('fields.v1.role_id'))) {
            $AppAssignment = $AppAssignment->where(config('fields.v1.role_id'), $Request->{config('fields.v1.role_id')});
        }

        if($Request->filled(config('fields.v1.assigned_to'))) {
            $AppAssignment = $AppAssignment->where(config('fields.v1.assigned_to'), $Request->{config('fields.v1.assigned_to')});
        }

        if($Request->filled(config('fields.v1.status_id'))) {
            $status_ids = explode(',', $Request->{config('fields.v1.status_id')});

            $apps = Application::select(Application::ID)->whereIn(config('fields.v1.status_id'), $status_ids)->get()->toArray();
            
            if(!$apps) return [];
            
            $app_ids = [];
            
            foreach($apps as $app) {
                $app_ids[] = $app[Application::ID];
            }

            $AppAssignment = $AppAssignment->whereIn(AppAssignment::APP_ID, $app_ids);
        }

        $AppAssignment = $this->getAssignmentByProductType($Request, $AppAssignment);

        if($Request->filled(config('fields.v1.record_id'))) {
            $Application = Application::where(config('fields.v1.record_id'), (int) $Request->{config('fields.v1.record_id')})->first();
            
            if(!$Application instanceof Application) return [];
            
            $AppAssignment = $AppAssignment->where(AppAssignment::APP_ID, $Application->{Application::ID});
        }

        if($Request->filled(config('fields.v1.app_ids')) && is_array($Request->get(config('fields.v1.app_ids'))) && count($Request->get(config('fields.v1.app_ids')))) {

            $apps = Application::select(Application::ID)->whereIn(config('fields.v1.mongo_id'), $Request->{config('fields.v1.app_ids')})->get()->toArray();

            if(!$apps) return [];
            
            $app_ids = [];
            
            foreach($apps as $app) {
                $app_ids[] = $app[Application::ID];
            }

            $AppAssignment = $AppAssignment->whereIn(AppAssignment::APP_ID, $app_ids);
        }
        
        $assignments = $AppAssignment->get()->toArray();
        $assign_ids = [];
        $app_ids = [];
        foreach($assignments as $assign) {
            if(isset($assign[config('fields.v1.app_id')]) && !in_array($assign[config('fields.v1.app_id')], $app_ids)) {
                $app_ids[] = $assign[config('fields.v1.app_id')];
                $assign_ids[] = $assign[config('fields.v1.mongo_id')];
            }
        }
        
        $AppAssignment = $AppAssignment->whereIn(config('fields.v1.mongo_id'), $assign_ids);

        $count = $AppAssignment->count();

        $Query = $AppAssignment->orderBy(config('fields.v1.created_at'), 'desc')
                            ->with('application')
                            ->with('business')
                            ->with('owners');

        $this->buildProjection($Request, $Query);

        $AppAssignments = $Query->with('ownersWeightedAverage')
                                ->with('appActivity')
                                ->offset($start)
                                ->limit($per_page)
                                ->get()
                                ->toArray();

        $AppAssignments = array_merge([config('fields.v1.applications')=> $AppAssignments], [config('fields.v1.total_apps') => $count]);

        if (!$AppAssignments || empty($AppAssignments)) return [];

        return $AppAssignments;
    }

    /**
     * @param Request $Request
     * @param AppAssignment $AppAssignment
     * 
     * @return Object
     */
    private function getAssignmentByProductType(Request $Request, $AppAssignment) {
        if($Request->filled(config('fields.v1.product_type'))) {
            $product_types = explode(',', $Request->{config('fields.v1.product_type')});
            if($Request->filled(config('fields.v1.product_exists'))) {
                // return applications where product_type key has conditon on product_exists
                $apps = Application::select(Application::ID)->whereIn(config('fields.v1.product_type'), $product_types)->get()->toArray();
                $product_exists = $Request->get(config('fields.v1.product_exists')) == '1' ? true: false;
                if(!$product_exists) {
                    $apps_without_product = Application::select(Application::ID)->where(config('fields.v1.product_type'), 'exists', $product_exists)->get()->toArray();
                    $apps = array_merge($apps, $apps_without_product);
                }
            } else {
                $apps = Application::select(Application::ID)->whereIn(config('fields.v1.product_type'), $product_types)->get()->toArray();
            }

            if(!$apps) return [];
            
            $app_ids = [];
            
            foreach($apps as $app) {
                $app_ids[] = $app[Application::ID];
            }

            $AppAssignment = $AppAssignment->whereIn(AppAssignment::APP_ID, $app_ids);

        } else if($Request->filled(config('fields.v1.product_exists'))) {
            $exists = $Request->get(config('fields.v1.product_exists'));

            $product_exists = $exists == '1' ? true: false;
            // return applications where product_type key has conditon on product_exists
            $apps = Application::select(Application::ID)->orWhere(config('fields.v1.product_type'), 'exists', $product_exists)->get()->toArray();
           
            if(!$apps) return [];
            
            $app_ids = [];
            
            foreach($apps as $app) {
                $app_ids[] = $app[Application::ID];
            }

            $AppAssignment = $AppAssignment->whereIn(AppAssignment::APP_ID, $app_ids);
        }

        return $AppAssignment;
    }

    /**
     * @param Request $Request
     * @param AppAssignment $AppAssignment
     * 
     * @return array
     */
    private function getAssignmentByProductTypeV2(Request $Request) {
        $app_ids = [];
        if($Request->filled(config('fields.v1.product_type'))) {
            $product_types = explode(',', $Request->{config('fields.v1.product_type')});
            if($Request->filled(config('fields.v1.product_exists'))) {
                // return applications where product_type key has conditon on product_exists
                $apps = Application::select(Application::ID)->whereIn(config('fields.v1.product_type'), $product_types)->get()->toArray();
                $product_exists = $Request->get(config('fields.v1.product_exists')) == '1' ? true: false;
                if(!$product_exists) {
                    $apps_without_product = Application::select(Application::ID)->where(config('fields.v1.product_type'), 'exists', $product_exists)->get()->toArray();
                    $apps = array_merge($apps, $apps_without_product);
                }
            } else {
                $apps = Application::select(Application::ID)->whereIn(config('fields.v1.product_type'), $product_types)->get()->toArray();
            }

            if(!$apps) return [];
            foreach($apps as $app) {
                $app_ids[] = $app[Application::ID];
            }

        } else if($Request->filled(config('fields.v1.product_exists'))) {
            $exists = $Request->get(config('fields.v1.product_exists'));

            $product_exists = $exists == '1' ? true: false;
            // return applications where product_type key has conditon on product_exists
            $apps = Application::select(Application::ID)->orWhere(config('fields.v1.product_type'), 'exists', $product_exists)->get()->toArray();
           
            if(!$apps) return [];
            
            foreach($apps as $app) {
                $app_ids[] = $app[Application::ID];
            }
        }

        return $app_ids;
    }

    /**
     * @param array $match_ids
     * @param string $key
     * 
     * @return array
     */
    private function filterUniqueIds(array $match_ids, string $key = AppAssignment::APP_ID) {
        $AssignmentModel = new AppAssignment();
        $filteredApp = $AssignmentModel->whereIn($key, $match_ids)->get()->toArray();
        $appIds = [];
        $ids = [];
        foreach($filteredApp as $filtered) {
            if(!in_array($filtered[config('fields.v1.app_id')], $appIds)) {
                $ids[] = $filtered[config('fields.v1.mongo_id')];
            }

            $appIds[] = $filtered[config('fields.v1.app_id')];
        }

        return $ids;
    }

    /**
     * @param string $Request
     * @param object $Query
     * 
     * @return object
     */
    private function buildProjection(Request $Request, &$Query) {
        if($Request->filled('references')) {
            $serviceRefs = explode(',',$Request->references);
            if(count($serviceRefs) == 2) {
                foreach($serviceRefs as $serviceRef) {
                    $this->runProjectionQuery($Query, $serviceRef);
                }
            } else if(count($serviceRefs) == 1) {
                if($serviceRefs[0] === 'businessReferences') {
                    $this->runProjectionQuery($Query, 'businessReferences');
                    $Query->with('ownerReferences');
                } else {
                    $this->runProjectionQuery($Query, 'ownerReferences');
                    $Query->with('businessReferences');
                }

            } 
        } else {
            $Query->with('businessReferences');
            $Query->with('ownerReferences');
        }
    }

    /**
     * @param object $Query
     * @param string $service
     * 
     * @return object
     */
    private function runProjectionQuery(&$Query, $service) {
        $Query->with([$service => function($qry) {
            $qry->project(config('projection.v1.without_response'));
        }]);
    }

    /**
     * Return application where user_id matches with fetched application app_id
     *
     * @param string $app_id
     * @param array $user_ids
     * 
     * @return string
     */
    private function getUserInfo(string $app_id, array $user_ids)
    {
        $Application = Application::where(Application::ID, $app_id)->first();

        if(!$Application instanceof Application) return false;
        
        if(array_search($Application->{Application::USER_ID}, $user_ids) !== false) return true;
    }

    /**
     * Get app count according to status belonging to a particular role or for all roles
     *
     * @param Request $Request
     * 
     * @return string
     */
    public function getAppAssignmentsByRoleId(Request $Request)
    {
        if($Request->filled(config('fields.v1.role_id')) && !$Request->filled(config('fields.v1.assigned_to'))) {
            $count_by_status_id = $this->getAppsForField($Request, config('fields.v1.role_id'));

            if(is_array($count_by_status_id) && empty($count_by_status_id)) return [];

            return $count_by_status_id;
        } else if($Request->filled(config('fields.v1.assigned_to')) && !$Request->filled(config('fields.v1.role_id'))) {
            $count_by_status_id = $this->getAppsForField($Request, config('fields.v1.assigned_to'));

            if(is_array($count_by_status_id) && empty($count_by_status_id)) return [];

            return $count_by_status_id;
        } else {
            if($Request->filled(config('fields.v1.from_date')) && $Request->filled(config('fields.v1.to_date'))) {
                $app_assignments = $this->AppAssignment->select(config('fields.v1.app_id'), config('fields.v1.role_id'))
                                        ->where(config('fields.v1.created_at'), '>=', (int) $Request->{config('fields.v1.from_date')})
                                        ->where(config('fields.v1.created_at'), '<=', (int) $Request->{config('fields.v1.to_date')})
                                        ->get()
                                        ->toArray();

            } else {
                $app_assignments = $this->AppAssignment->select(config('fields.v1.app_id'), config('fields.v1.role_id'))->get()->toArray();
            }
            // dd($app_assignments);
            if(empty($app_assignments)) return [];

            $apps_by_roles = [];

            foreach($app_assignments as $app_assignment) {
                if(array_key_exists($app_assignment[config('fields.v1.role_id')], $apps_by_roles)) {
                    if(!in_array($app_assignment[config('fields.v1.app_id')], $apps_by_roles[$app_assignment[config('fields.v1.role_id')]])) {
                        array_push($apps_by_roles[$app_assignment[config('fields.v1.role_id')]], $app_assignment[config('fields.v1.app_id')]);
                    }
                } else {
                    $apps_by_roles[$app_assignment[config('fields.v1.role_id')]] = [];
                    array_push($apps_by_roles[$app_assignment[config('fields.v1.role_id')]], $app_assignment[config('fields.v1.app_id')]);
                }
            }

            //building an array with count of apps belonging to statuses belonging to a role_id
            $count_by_status_id = [];

            foreach($apps_by_roles as $k => $app_by_role) {
                $count_by_status_id[$k] = [];
                $status_ids = [];

                foreach($app_by_role as $app_id) {
                    $Application = Application::select(Application::STATUS_ID)->where(Application::ID, $app_id)->first();
                    if($Application instanceof Application && $Application->{Application::STATUS_ID} != null) {
                        $status_ids = $this->getAppCountByStatus($Application->{Application::STATUS_ID}, $status_ids);
                    }
                }
                $count_by_status_id[$k] = $status_ids;
            }
            return $count_by_status_id;
        }
    }

    /**
     * Get Count of applications for each status_id
     *
     * @param string $status_id
     * @param array $status_ids
     * 
     * @return array
     */
    private function getAppCountByStatus(string $status_id, array $status_ids)
    {
        if(array_key_exists($status_id, $status_ids)) {
            $status_ids[$status_id]++;  
        } else {
            $status_ids[$status_id] = 1;
        }
        return $status_ids;
    }

    /**
     * Get count by status_id of apps filtering by different fields
     *
     * @param Request $Request
     * @param string $field
     * 
     * @return array
     */
    private function getAppsForField(Request $Request,string $field)
    {
        if($Request->filled(config('fields.v1.from_date')) && $Request->filled(config('fields.v1.to_date'))) {
            $app_assignments = $this->AppAssignment->distinct(config('fields.v1.app_id'))
                                    ->where(config('fields.v1.created_at'), '>=', (int) $Request->{config('fields.v1.from_date')})
                                    ->where(config('fields.v1.created_at'), '<=', (int) $Request->{config('fields.v1.to_date')})
                                    ->where($field, $Request->{$field})
                                    ->get()
                                    ->toArray();
        } else {
            $app_assignments = $this->AppAssignment->distinct(config('fields.v1.app_id'))->where($field, $Request->{$field})->get()->toArray();
        }

        if(empty($app_assignments)) return [];

        //building an array with count of apps belonging to statuses belonging to a role_id
        $count_by_status_id[$Request->{$field}] = [];
        $status_ids = [];

        foreach($app_assignments as $app_assignment) {
            $Application = Application::select(Application::STATUS_ID)->where(Application::ID, $app_assignment[0])->first();
            if($Application instanceof Application && $Application->{Application::STATUS_ID} != null) {
                $status_ids = $this->getAppCountByStatus($Application->{Application::STATUS_ID}, $status_ids);
            }
        }

        $count_by_status_id[$Request->{$field}] = $status_ids;

        return $count_by_status_id;
    }

    /**
     * Get App Assignment
     *
     * @param string $Request
     * 
     * @return string
     */
    public function getApplications(Request $Request)
    {   
        $start    = self::START;
        $per_page = self::PER_PAGE;

        if($Request->filled(config('fields.v1.start'))) {
            $start = (int) $Request->{config('fields.v1.start')};
        }

        if($Request->filled(config('fields.v1.per_page'))) {
            $per_page = (int) $Request->{config('fields.v1.per_page')};
        }

        $app_ids = [];

        if($Request->filled(config('fields.v1.app_id'))) {
            if($Request->filled(config('fields.v1.name'))) {
                $user_ids = $this->getUserByName(config('api-urls.v1.user_service').'/backend', config('fields.v1.version_v1'), $Request->{config('fields.v1.name')});
                
                $user_match = $user_ids === null ? false : $this->getUserInfo($Request->{config('fields.v1.app_id')}, $user_ids);
                
                if(!$user_match) {
                    return [];
                } else {
                    $app_ids[] = $Request->{config('fields.v1.app_id')};
                }
            } else {
                $app_ids[] = $Request->{config('fields.v1.app_id')};
            }
        }
        
        if($Request->filled(config('fields.v1.product_type')) || $Request->filled(config('fields.v1.product_exists'))) {
            $ids = $this->getAssignmentByProductTypeV2($Request);
            if(count($app_ids) > 0) {
                $app_ids = array_intersect($app_ids, $ids);
            } else {
                $app_ids = $ids;
            }

            if(count($app_ids) == 0) return [];
        }

        if($Request->filled(config('fields.v1.app_ids')) && is_array($Request->get(config('fields.v1.app_ids'))) && count($Request->get(config('fields.v1.app_ids')))) {
            $ids = $Request->get(config('fields.v1.app_ids'));
            if(count($app_ids) > 0) {
                $app_ids = array_intersect($app_ids, $ids);
            } else {
                $app_ids = $ids;
            }

            if(count($app_ids) == 0) return [];
        }

        if($Request->filled(config('fields.v1.from_date')) && $Request->filled(config('fields.v1.to_date'))) {
            $apps = Application::select(Application::ID)
                        ->where(config('fields.v1.created_at'), '>=', (int) $Request->{config('fields.v1.from_date')})
                        ->where(config('fields.v1.created_at'), '<=', (int) $Request->{config('fields.v1.to_date')})
                        ->get()
                        ->toArray();

            if(!$apps) return [];

            foreach($apps as $i => $app) {
                $apps[$i] = $app[Application::ID];
            }

            if(count($app_ids) > 0) {
                $app_ids = array_intersect($app_ids, $apps);
            } else {
                $app_ids = $apps;
            }

            if(count($app_ids) == 0) return [];
        }

        if($Request->filled(config('fields.v1.name')) && !$Request->filled(config('fields.v1.app_id'))) {
            $user_ids = $this->getUserByName(config('api-urls.v1.user_service').'/backend', config('fields.v1.version_v1'), $Request->{config('fields.v1.name')});
            
            if($user_ids === null) {
                return [];    
            }
            
            $apps = Application::select(Application::ID)->whereIn(Application::USER_ID, $user_ids)->get()->toArray();

            if(!$apps) return [];

            foreach($apps as $i => $app) {
                $apps[$i] = $app[Application::ID];
            }

            if(count($app_ids) > 0) {
                $app_ids = array_intersect($app_ids, $apps);
            } else {
                $app_ids = $apps;
            }

            if(count($app_ids) == 0) return [];
        }

        if($Request->filled(config('fields.v1.role_id'))) {
            $distinct_apps = $this->AppAssignment->distinct(config('fields.v1.app_id'))->where(config('fields.v1.role_id'), $Request->{config('fields.v1.role_id')})->get()->toArray();
            
            if(count($distinct_apps) > 0) {
                foreach ($distinct_apps as $k => $app) {
                    $distinct_apps[$k] = $app[0];
                }

                if(count($app_ids) > 0){
                    $app_ids = array_intersect($app_ids, $distinct_apps);
                } else {
                    $app_ids = $distinct_apps;
                }

                if(count($app_ids) == 0) return [];
            } else {
                return [];
            }
        }

        if($Request->filled(config('fields.v1.assigned_to'))) {
            if(strpos($Request->{config('fields.v1.assigned_to')}, ',')) {
                $assigned_to_ids = explode(',', $Request->{config('fields.v1.assigned_to')});
                $distinct_apps = $this->AppAssignment->distinct(config('fields.v1.app_id'))->whereIn(config('fields.v1.assigned_to'), $assigned_to_ids)->get()->toArray();
                if(count($distinct_apps) > 0) {
                    foreach ($distinct_apps as $k => $app) {
                        $distinct_apps[$k] = $app[0];
                    }

                    if(count($app_ids) > 0){
                        $app_ids = array_intersect($app_ids, $distinct_apps);
                    } else {
                        $app_ids = $distinct_apps;
                    }

                    if(count($app_ids) == 0) return [];
                } else {
                    return [];
                }
            } else {
                $distinct_apps = $this->AppAssignment->distinct(config('fields.v1.app_id'))->where(config('fields.v1.assigned_to'), $Request->{config('fields.v1.assigned_to')})->get()->toArray();
                if(count($distinct_apps) > 0) {
                    foreach ($distinct_apps as $k => $app) {
                        $distinct_apps[$k] = $app[0];
                    }

                    if(count($app_ids) > 0){
                        $app_ids = array_intersect($app_ids, $distinct_apps);
                    } else {
                        $app_ids = $distinct_apps;
                    }

                    if(count($app_ids) == 0) return [];
                } else {
                    return [];
                }
            }
        }

        if($Request->filled(config('fields.v1.status_id'))) {
            $status_ids = explode(',', $Request->{config('fields.v1.status_id')});

            $apps = Application::select(Application::ID)->whereIn(config('fields.v1.status_id'), $status_ids)->get()->toArray();
            
            if(!$apps) return [];
            
            foreach($apps as $i => $app) {
                $apps[$i] = $app[Application::ID];
            }

            if(count($app_ids) > 0) {
                $app_ids = array_intersect($app_ids, $apps);
            } else {
                $app_ids = $apps;
            }

            if(count($app_ids) == 0) return [];
        }

        if($Request->filled(config('fields.v1.record_id'))) {
            $Application = Application::where(config('fields.v1.record_id'), (int) $Request->{config('fields.v1.record_id')})->first();
            
            if(!$Application instanceof Application) return [];
            
            if (count($app_ids) > 0) {
                $app_ids = array_intersect($app_ids, [$Application->{Application::ID}]);
            } else {
                $app_ids = [$Application->{Application::ID}];
            }

            if(count($app_ids) == 0) return [];
        }

        if($Request->filled(config('fields.v1.business_pan'))) {
            $Application = Business::select(config('fields.v1.app_id'))->where(config('fields.v1.business_pan'), 'like', '%'.$Request->{config('fields.v1.business_pan')}.'%')->get()->toArray();

            if(!$Application) return [];

            foreach($Application as $i => $app) {
                $Application[$i] = $app[config('fields.v1.app_id')];
            }

            if(count($app_ids) > 0) {
                $app_ids = array_intersect($app_ids, $Application);
            } else {
                $app_ids = $Application;
            }
            if(count($app_ids) == 0) return [];
        }

        if($Request->filled(config('fields.v1.business_name'))) {
            $Application = Business::select(config('fields.v1.app_id'))->where(config('fields.v1.business_name'), 'like', '%'.$Request->{config('fields.v1.business_name')}.'%')->get()->toArray();

            if(!$Application) return [];

            foreach($Application as $i => $app) {
                $Application[$i] = $app[config('fields.v1.app_id')];
            }

            if(count($app_ids) > 0) {
                $app_ids = array_intersect($app_ids, $Application);
            } else {
                $app_ids = $Application;
            }

            if(count($app_ids) == 0) return [];
        }

        if($Request->filled('business_name')) {
            $Application = Business::select(config('fields.v1.app_id'))->where('business_name', 'like', '%'.$Request->business_name.'%')->get()->toArray();

            if(!$Application) return [];
            
            foreach($Application as $i => $app) {
                $Application[$i] = $app[config('fields.v1.app_id')];
            }

            if(count($app_ids) > 0) {
                $app_ids = array_intersect($app_ids, $Application);
            } else {
                $app_ids = $Application;
            }

            if(count($app_ids) == 0) return [];
        }

        $app_ids = array_unique($app_ids);

        $AppAssignments = new Application();
        $app_count = 0;
        
        if(count($app_ids) > 0) {
            $AppAssignments = $AppAssignments->whereIn(Application::ID, $app_ids);
            $app_count = $AppAssignments->count();
        } else {
            $app_count = $AppAssignments->count();
        }

        $AppAssignments = $AppAssignments->orderBy($Request->filled(config('fields.v1.sort_by')) ? $Request->{config('fields.v1.sort_by')} : config('fields.v1.created_at'), $Request->filled(config('fields.v1.order_by')) ? $Request->{config('fields.v1.order_by')} : 'desc')
                            ->with('assignments')
                            ->with('business')
                            ->with('businessReferences')
                            ->with('owners')
                            ->with('ownerReferences')
                            ->with('ownersWeightedAverage')
                            ->with('appActivity')
                            ->offset($start)
                            ->limit($per_page)
                            ->get()
                            ->toArray();
        
        $count = $app_count;

        $AppAssignments = array_merge([config('fields.v1.applications')=> $AppAssignments], [config('fields.v1.total_apps') => $count]);

        if (!$AppAssignments || empty($AppAssignments)) return [];

        return $AppAssignments;
    }

    /**
     * Filter apps by master product config
     *
     * @param Request $Request
     * @param array $filter_params
     * 
     * @return string
     */
    public function getFilteredApps(Request $Request, array $filter_params)
    {
        $start    = $Request->filled(config('fields.v1.start')) ? (int) $Request->{config('fields.v1.start')} : self::START;
        $per_page = $Request->filled(config('fields.v1.per_page')) ? (int) $Request->{config('fields.v1.per_page')} : self::PER_PAGE;

        $app_ids = [];
        $ex_app_ids = [];

        if($Request->filled(config('fields.v1.from_date')) && $Request->filled(config('fields.v1.to_date'))) {
            $apps = Application::select(Application::ID)
                        ->where(config('fields.v1.created_at'), '>=', (int) $Request->{config('fields.v1.from_date')})
                        ->where(config('fields.v1.created_at'), '<=', (int) $Request->{config('fields.v1.to_date')})
                        ->get()
                        ->toArray();

            if(!$apps) return [];

            foreach($apps as $i => $app) {
                $apps[$i] = $app[Application::ID];
            }

            $app_ids = $this->getArrayIntersection($app_ids, $apps);

            if(count($app_ids) == 0) return [];
        }
        foreach($filter_params as $param) {
            if($Request->filled($param->{config('fields.v1.name')})) {
                if(isset($param->{config('fields.v1.filter_collection')})) {
                    $collection = $this->loadCollectionClass($param->{config('fields.v1.filter_collection')});

                    if(isset($param->{config('fields.v1.distinct')})) {
                        $distinct_apps = [];

                        if(isset($param->{config('fields.v1.explode')})) {
                            $values = explode($param->{config('fields.v1.explode')}, $Request->{$param->{config('fields.v1.name')}});
                            $distinct_apps = $collection->distinct($param->{config('fields.v1.distinct')})->whereIn($param->{config('fields.v1.name')}, $values)->get()->toArray();
                        } else {
                            $where_op = isset($param->{config('fields.v1.where_operator')}) ? $param->{config('fields.v1.where_operator')} : '=';
                            $match_param = $Request->{$param->{config('fields.v1.name')}};
                            if($where_op === 'like') {
                                $match_param = '%'.$match_param.'%';
                            }
                            $distinct_apps = $collection->distinct($param->{config('fields.v1.distinct')})->where($param->{config('fields.v1.name')}, $where_op, $match_param)->get()->toArray();
                        }

                        if(count($distinct_apps) > 0) {
                            foreach ($distinct_apps as $k => $app) {
                                $distinct_apps[$k] = $app[0];
                            }

                            $app_ids = $this->getArrayIntersection($app_ids, $distinct_apps);

                            if(count($app_ids) == 0) return [];
                        } else {
                            return [];
                        }
                    } else if(isset($param->{config('fields.v1.select')})) {
                        $apps = [];

                        if(isset($param->{config('fields.v1.explode')})) {
                            $values = explode($param->{config('fields.v1.explode')}, $Request->{$param->{config('fields.v1.name')}});
                            $apps = $collection->select($param->{config('fields.v1.select')})->whereIn($param->{config('fields.v1.name')}, $values)->get()->toArray();
                        } else {
                            $where_op = isset($param->{config('fields.v1.where_operator')}) ? $param->{config('fields.v1.where_operator')} : '=';
                            $match_param = $param->{config('fields.v1.name')} == config('fields.v1.record_id') ? (int) $Request->{$param->{config('fields.v1.name')}} : $Request->{$param->{config('fields.v1.name')}};
                            if($where_op === 'like') {
                                // will do exact match but case insensitive
                                if(isset($param->{config('fields.v1.case_insensitive')}) && $param->{config('fields.v1.case_insensitive')} === true) {
                                    
                                } 
                                else  if(isset($param->{config('fields.v1.starts_with')}) && $param->{config('fields.v1.starts_with')} === true) {
                                    $match_param = $match_param.'%';
                                }
                                else {
                                    $match_param = '%'.$match_param.'%';
                                }
                            }
                            $apps = $collection->select($param->{config('fields.v1.select')})->where($param->{config('fields.v1.name')}, $where_op, $match_param)->get()->toArray();
                        }

                        if(count($apps) > 0) {
                            foreach ($apps as $k => $app) {
                                $apps[$k] = $app[$param->{config('fields.v1.select')}];
                            }

                            $app_ids = $this->getArrayIntersection($app_ids, $apps);

                            if(count($app_ids) == 0) return [];
                        } else {
                            return [];
                        }
                    }

                } else if(isset($param->{config('fields.v1.fetch_from_http')})) {
                    $ids = $this->fetchDataByHTTP((array)$param, $Request->{$param->{config('fields.v1.query_params')}});

                    if(empty($ids))  return [];

                    $collection = $this->loadCollectionClass($param->{config('fields.v1.match_collection')});
                    $apps = $collection->select($param->{config('fields.v1.select')})->whereIn($param->{config('fields.v1.match_param')}, $ids)->get()->toArray();

                    if(count($apps) > 0) {
                        foreach ($apps as $k => $app) {
                            $apps[$k] = $app[$param->{config('fields.v1.select')}];
                        }

                        $app_ids = $this->getArrayIntersection($app_ids, $apps);

                        if(count($app_ids) == 0) return [];
                    } else {
                        return [];
                    }

                }else if(isset($param->{config('fields.v1.value_type')}) && $param->{config('fields.v1.value_type')} =='exclude'){
                    array_push($ex_app_ids,$Request->{$param->{config('fields.v1.name')}});
                }else if (isset($param->{config('fields.v1.value_type')})  && $param->{config('fields.v1.value_type')} =='array'){
                    
                   foreach($Request->{$param->{config('fields.v1.name')}} as $value){
                        array_push($app_ids, $value);
                   }

                } else {
                    array_push($app_ids, $Request->{$param->{config('fields.v1.name')}});
                }
            }
            
        }

        $app_ids = array_unique($app_ids);

        $AppAssignments = new Application();
        $app_count = 0;
        
        if(count($app_ids) > 0) {
            $AppAssignments = $AppAssignments->whereIn(Application::ID, $app_ids);
            $app_count = $AppAssignments->count();
        } else {
            $app_count = $AppAssignments->count();
        }

        if(count($ex_app_ids) > 0){
            $AppAssignments=  $AppAssignments->whereNotIn(Application::ID,$ex_app_ids);
        }
        $AppAssignments = $AppAssignments->orderBy($Request->filled(config('fields.v1.sort_by')) ? $Request->{config('fields.v1.sort_by')} : config('fields.v1.created_at'), $Request->filled(config('fields.v1.order_by')) ? $Request->{config('fields.v1.order_by')} : 'desc')
                            ->with('assignments')
                            ->with('business')
                            ->with('businessReferences')
                            ->with('owners')
                            ->with('ownerReferences')
                            ->with('ownersWeightedAverage')
                            ->with('appActivity')
                            ->offset($start)
                            ->limit($per_page)
                            ->get()
                            ->toArray();
        
        $count = $app_count;

        $AppAssignments = array_merge([config('fields.v1.applications')=> $AppAssignments], [config('fields.v1.total_apps') => $count]);

        if (!$AppAssignments || empty($AppAssignments)) return [];

        return $AppAssignments;
    }

    /**
     * Dynamically load Eloquent(Model) Class
     *
     * @param string $collectionName
     * 
     * @return Object
     */
    private function loadCollectionClass(string $collectionName)
    {
        $collectionClass = 'App\Repositories\Models\\'.$collectionName;
        if (!class_exists($collectionClass)) {
            throw new ObjectNotLoadedException;
        }

        return new $collectionClass;
    }

    /**
     * Get array intersection
     *
     * @param array $arr1
     * @param array $arr2
     * 
     * @return array
     */
    private function getArrayIntersection(array $arr1, array $arr2)
    {
        if(count($arr1) > 0){
            $arr1 = array_intersect($arr1, $arr2);
        } else {
            $arr1 = $arr2;
        }

        return $arr1;
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return AppAssignmentTransformer::class;
    }
}