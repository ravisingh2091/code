<?php 

namespace App\Repositories\Entities\v1\Owner;

use Request;
use Carbon\Carbon;
use App\Repositories\Models\Hash;
use App\Repositories\Models\Owner;
use App\Repositories\Models\OwnerHash;
use App\Repositories\Models\Application;
use App\Repositories\Models\ServiceOwner;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Models\OwnersWeightedAverage;
use App\Repositories\Transformer\OwnerTransformer;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Contracts\Owner\OwnersInterface;
use App\Repositories\Contracts\Service\ServiceInterface;

/**
 * Owner Repository class for handling owner related CRUD operation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class OwnersRepository extends ApiRepository implements OwnersInterface 
{
    /**
     * Owner Model
     *
     * @var App\Repositories\Models\Owner
     */
    protected $Owner;

    /**
     * OwnerHash Model
     *
     * @var App\Repositories\Models\OwnerHash
     */
    protected $OwnerHash;

    /**
     * ServiceBusiness Interface
     *
     * @var App\Repositories\Contracts\Service\ServiceInterface
     */
    protected $ServiceInterface;


    /**
     * @param App\Repositories\Model\Owner $Owner
     */
    public function __construct(Owner $Owner, OwnerHash $OwnerHash, ServiceInterface $ServiceInterface)
    {
        $this->Owner = $Owner;
        $this->OwnerHash = $OwnerHash;
        $this->ServiceInterface = $ServiceInterface;
    }   

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $params
     *
     * @return void
     */
    public function get(array $params) 
    {
        if(empty($params)) throw new BlankDataException();

        $Owner = $this->Owner->getOwner($params);
        
        return $Owner ? $Owner : null;
    }

    /**
     * Delete owner 
     *
     * @param string $id
     * 
     * @return bool
     */
    public function delete(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $deleted = $this->Owner->where($params)->delete();

        if($deleted) {
            ServiceOwner::where(OwnerHash::OWNER_ID, $params[Owner::ID])->delete();
        }

        return $deleted ? true : false;
    }

    /**
     * Get All Owners without tree
     *
     * @param array $params
     *
     * @return void
     */
     public function getAllOwners(array $params)
     {
         if(empty($params)) throw new BlankDataException();
 
         $Owners = $this->Owner->getAllOwners($params);
         
         return $Owners ? $Owners : null;
     }

    /**
     * Get Owner By App Id
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $appId
     * 
     * @return Owner
     */
    public function getOwnerByAppId(string $appId)
    {
        if(empty($appId)) throw new BlankDataException();

        $Owner = $this->Owner->getOwner([Owner::APP_ID => $appId]);

        return $Owner instanceof Owner ? $Owner : null;
    }

    /** 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param array $attributes
     * @param bool $upsert
     * 
     * @return string
     */
    public function create(array $attributes, bool $upsert = true)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Owners = $this->Owner->saveOwner($attributes, $upsert);
        
        if (!$Owners) throw new ObjectNotLoadedException();

        //filtering owners whose hash already exist

        $filteredOwners = [];

        foreach($Owners as $Owner) {
            $OwnerHash =  $this->OwnerHash->where(OwnerHash::OWNER_ID, $Owner->{Owner::ID})->first();
            if(!$OwnerHash) {
                array_push($filteredOwners, $Owner);
            }
        }

        if(count($filteredOwners) > 0) {
            $Owner_Hash = $this->OwnerHash->createOwnerHash($filteredOwners);

            if (!is_array($Owner_Hash) || empty($Owner_Hash)) {
                $idList = array_column($filteredOwners, Owner::ID);
                $this->Owner->whereIn(Owner::ID, $idList)->delete();
                throw new ObjectNotLoadedException();
            }
        }
        
        foreach($Owners as $k => $owner) { 
                $hash = $this->OwnerHash->where(OwnerHash::OWNER_ID, $owner->{Owner::ID})->orderBy(config('fields.v1.created_at'), 'desc')->first();
                $Owners[$k] = array_merge($owner->toArray(), [OwnerHash::HASH => $hash->{OwnerHash::HASH}]);
        }
            
        return $Owners;  
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param array $attributes
     * @param string $ownerId
     *
     * @return string
     */
    public function update(array $attributes, string $ownerId)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Owner = $this->Owner->where(Owner::ID, $ownerId)->first();

        if (!$Owner instanceof Owner) return false;

        $Request = app('request');
        
        if($Owner->{Owner::CONSENT} === Owner::PENDING) {

            $fields = [];

            if(!$Request->hasHeader('update-without-consent')) {
                $fields = array_merge($fields, [ Owner::CONSENT => Owner::RECEIVED ]);
            }

            if(isset($attributes[config('fields.v1.owner_first_name')]) && isset($attributes[config('fields.v1.owner_last_name')])) {
                $name = $attributes[config('fields.v1.owner_first_name')].' '.$attributes[config('fields.v1.owner_last_name')];

                $fields = array_merge($fields, [ Owner::DIRECT_OWNER_NAME => $name ]);
            }
            
            $attributes = array_merge($attributes, $fields);
        }

        if(!isset($Owner->{config('fields.v1.consent_ip_address')})) {
            if($Request->hasHeader('ipaddress')) {
                $attributes = array_merge($attributes, [
                    config('fields.v1.consent_ip_address') => $Request->header('ipaddress')
                ]);
            }
        }
        
        $Owner->update($attributes);

        if(isset($Owner->{Owner::EMAIL_ADDRESS}) && config('owner_consent.v1.UPDATE_OWNERS_WITH_SAME_EMAIL')) {
            // Update Owners with same Email ID
            $params = [
                Owner::APP_ID        => $Owner->{Owner::APP_ID},
                Owner::USER_ID       => $Owner->{Owner::USER_ID},
                Owner::EMAIL_ADDRESS => $Owner->{Owner::EMAIL_ADDRESS}
            ];

            $owners = $this->Owner->where($params)->get()->toArray();

            foreach($owners as $owner) {
                $this->Owner->where(Owner::ID, $owner[Owner::ID])->update($attributes);
            }
        }
        
        return $Owner;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $attributes
     *
     * @return string
     */
    public function updateBatch(array $attributes) 
    {   
        $Owners = $this->Owner->select(Owner::ID)->where([
            Owner::APP_ID => $attributes[Owner::APP_ID],
            Owner::USER_ID => $attributes[Owner::USER_ID]
        ])->get()->toArray();
        
        $Owners= array_column($Owners, Owner::ID);
        
        // before updating the tree delete the old tree of owners
        $deleted = $this->Owner->where([
            Owner::APP_ID => $attributes[Owner::APP_ID],
            Owner::USER_ID => $attributes[Owner::USER_ID]
        ])->delete();

        $Request = app('request');
        
        $skipDeleteHash = $Request->filled('skip_hash_delete');
        if(!$skipDeleteHash) {
            $delete_hash = $this->OwnerHash->whereIn(OwnerHash::OWNER_ID, $Owners)->delete();
        }
            
        //insert new owners
        if($deleted && ( $skipDeleteHash || $delete_hash)) {
            return $this->create($attributes, false);
        }
        
        return false;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $attributes
     *
     * @return array
     */
    public function getAll(array $attributes) 
    {
        $Owners = $this->Owner->where($attributes)->get();

        return $Owners ? $this->generateOwnerTree($Owners->toArray()) : false;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $Owners
     * @param string $parentId
     *
     * @return array
     */
    private function generateOwnerTree(array $Owners, $parentId = "0")
    {
        $result = array();
        foreach ($Owners as $Owner) {
            $Owner[config('fields.v1.id')] = $Owner[config('fields.v1.mongo_id')];
            unset($Owner[config('fields.v1.mongo_id')]);
            if (!array_key_exists('parent_id', $Owner)) {
                $Owner['parent_id'] = "0";
            }
            if ($Owner['parent_id'] == $parentId) {
                $children = $this->generateOwnerTree($Owners, $Owner[config('fields.v1.id')]);
                if ($children) {
                    $Owner[config('fields.v1.owners_field')] = $children;
                }
                $result[] = $Owner;
            }
        }

        return $result;
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return OwnerTransformer::class;
    }

    /**
     * Check if hash has expired or not
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param string $token_time
     * 
     * @return boolean
     */
    public function checkEmailTokenExpiry(string $token_time)
    {
        $after24h = strtotime('+'.config('owner_consent.v1.EMAIL_TOKEN_EXPIRE_TIME').' hours', $token_time);
        $current_time = time();
        if ($after24h < $current_time) return false;
        return true;
    }
    
    /**
     * Check if allowed attempts per day have been reached
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $ownerId
     * 
     * @return Boolean
     */
    public function checkEmailTokenCount(string $ownerId)
    {
        $date_time = Carbon::now()->subDays(config('owner_consent.v1.MAX_EMAIL_TOKEN_TIME'));
        
        $count = $this->OwnerHash->where([[OwnerHash::OWNER_ID, '=', $ownerId], [OwnerHash::CREATED_AT, '>', strtotime($date_time)]])->count();
        
        if($count < config('owner_consent.v1.EMAIL_TOKEN_COUNT')) return true;

        return false;
    }

    /**
     * Get latest owner hash by owner id
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $hash
     * @param bool $new
     * 
     * @return Owner
     */
    public function getOwnerByHash(string $hash, bool $new = false)
    {
        $owner_id = $this->OwnerHash->select(OwnerHash::OWNER_ID)
                        ->where(OwnerHash::ENCRYPTED_HASH, $hash)
                        ->first();

        $Owner = $this->get([Owner::ID => $owner_id->{OwnerHash::OWNER_ID}]);

        if(!$Owner instanceof Owner) return null;

        $owner_email = isset($Owner[config('fields.v1.email_address')]) ? $Owner[config('fields.v1.email_address')]: $Owner[config('fields.v1.owner_email')];

        $owners = $this->Owner->where([
            Owner::APP_ID        => $Owner->{Owner::APP_ID},
            Owner::USER_ID       => $Owner->{Owner::USER_ID},
            Owner::EMAIL_ADDRESS => $owner_email
        ])->get()->toArray();
        
        if(count($owners) > 1) {
            $Owner->{Owner::OWNERSHIP_PERCENT} = 0;

            foreach($owners as $owner) {
                $Owner->{Owner::OWNERSHIP_PERCENT} += $owner[Owner::ACTUAL_PERCENT];
            }
        }

        if($new == true) {
            $consent_time = time();
            $Owner->update([config('fields.v1.consent_clicked_at') => $consent_time]);
            
            $Request = app('request');

            if($Request->hasHeader('ipaddress')) {
                $Owner->update([
                    config('fields.v1.consent_ip_address') => $Request->header('ipaddress')
                ]);
            }
        }

        $app_info = Application::select(Application::RECORD_ID, config('fields.v1.created_at'))
                    ->where(Application::ID, $Owner->{Owner::APP_ID})
                    ->first();
        
        $Owner->{Application::RECORD_ID}             = $app_info->{Application::RECORD_ID};
        $Owner->{config('fields.v1.app_created_at')} = $app_info->{config('fields.v1.created_at')};

        return $Owner;
    }

    /**
     * Create New Owner Hash
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $ownerId
     * 
     * @return string
     */
    public function createNewHash(string $ownerId)
    {
        $Owner = $this->Owner->where(Owner::ID, $ownerId)->first();

        $Hash = $this->OwnerHash->createOwnerHash([$Owner->toArray()]);

        if(!$Hash) throw new ObjectNotLoadedException();

        $Request = app('request');

        if($Request->filled('consent_pending') && $Request->consent_pending === 'false') {
            return $Hash[0];
        }

        if($Owner->{Owner::CONSENT} === Owner::RECEIVED) {
            $Owner->update([ Owner::CONSENT => Owner::PENDING ]);
        }

        return $Hash[0];
    }

    /**
     * Check if hash is expired or not
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $hash
     * 
     * @return boolean
     */
    public function checkHashExpiry(string $hash)
    {
        $hash_created_at = $this->getHashCreatedAt($hash);
        
        return $this->checkEmailTokenExpiry($hash_created_at);
    }

    /**
     * Get Hash Created At
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $hash
     * 
     * @return string
     */
    public function getHashCreatedAt(string $hash)
    {
        $created_at = $this->OwnerHash->select(OwnerHash::CREATED_AT)
                        ->where(OwnerHash::ENCRYPTED_HASH, $hash)
                        ->first()->toArray();
                        
        return $created_at ? strtotime($created_at[OwnerHash::CREATED_AT]) : null;
    }

    /**
     * Check if hash exists in db
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $hash
     * 
     * @return boolean
     */
    public function isHashExist(string $hash)
    {
        $Owner_Hash = $this->OwnerHash->where(OwnerHash::ENCRYPTED_HASH, $hash)->first();

        if($Owner_Hash instanceof OwnerHash) {
            return true;
        }
    }

    /**
     * Check if hash is latestin db or not
     *
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param string $hash
     * 
     * @return boolean
     */
    public function isNew(string $hash)
    {   
        $Owner = $this->getOwnerByHash($hash);
        
        $latest_hash = $this->OwnerHash->select(OwnerHash::ENCRYPTED_HASH)
                                       ->where(OwnerHash::OWNER_ID, $Owner->{Owner::ID})
                                       ->orderBy(OwnerHash::CREATED_AT, 'desc')
                                       ->first();
        
        if($latest_hash->{OwnerHash::ENCRYPTED_HASH} === $hash) { 
            return true;
        }
    }

    /**
     * Get Ownership percentage
     *
     * @param array $Owner
     * 
     * @return float
     */
    public function getOwnerPercent(array $Owner)
    {
        if(strtolower($Owner[Owner::OWNER_TYPE]) === config('fields.v1.individual')) {
            if($Owner[config('fields.v1.parent_id')] == 0) {
                $owner_percent = $Owner[Owner::OWNERSHIP_PERCENT];
                return (float)$owner_percent;
            } else {
                $parent_percent = $this->getParentPercent($Owner[config('fields.v1.parent_id')]);
                $owner_percent = $Owner[Owner::OWNERSHIP_PERCENT] * ($parent_percent/100) ;
                return $owner_percent;
            }
        } else {
            return null;
        }
    }

    /**
     * Get Parent Percent Recursively
     *
     * @param string $parent_id
     * 
     * @return float
     */
    public function getParentPercent(string $parent_id) {
        $Parent = $this->get([Owner::ID => $parent_id]);
        if($Parent->{config('fields.v1.parent_id')} == 0) {
            return $Parent->{Owner::OWNERSHIP_PERCENT};
        } else {
            $parent_percent = $Parent->{Owner::OWNERSHIP_PERCENT} * ($this->getParentPercent($Parent->{config('fields.v1.parent_id')})/100);
            return $parent_percent;
        }
    }

    /**
     * Get Citizenship Percentage
     *
     * @param array $request
     * 
     * @return string
     */
    public function getCitizenshipPercentage(array $request)
    {
        $Owners = $this->Owner->getAllOwners([Owner::APP_ID => $request[Owner::APP_ID], Owner::USER_ID => $request[Owner::USER_ID]])->toArray();

        $owner_percent = [];
        
        foreach($Owners as $Owner) {
            if(strtolower($Owner[Owner::OWNER_TYPE]) === config('fields.v1.individual') && $Owner[Owner::CONSENT] !== Owner::RECEIVED) {
                return false;
            }
            if (strtolower($Owner[Owner::OWNER_TYPE] === config('fields.v1.individual'))) {
                $owner_percent[$Owner[Owner::ID]] = isset($Owner[Owner::ACTUAL_PERCENT]) ? $Owner[Owner::ACTUAL_PERCENT] : $this->getOwnerPercent($Owner); 
            }
        }

        $owner_ids = array_keys($owner_percent);
        $canadian_owners = [];

        foreach($owner_ids as $owner_id) {
            $Owner = $this->get([Owner::ID => $owner_id]);
            if(strtolower($Owner->{config('fields.v1.canada_citizen')}) === trans('messages.v1.yes')) {
                $canadian_owners[] = $Owner->{Owner::ID};
            }
        }

        if(empty($canadian_owners)) {
            return 0;
        }
        
        $citizenship_percent = 0;

        foreach($canadian_owners as $canadian_owner) {
            $percent = $owner_percent[$canadian_owner];
            $citizenship_percent = $citizenship_percent + $percent;
        }

        return $citizenship_percent;
    }

    /**
     * Get Weighted Average
     *
     * @param array $owners
     * 
     * @return string
     */
    public function getWeightedAverage(array $owners)
    {   
        $weighted_average = 0;
        $app_id = '';
        $total_score = 0;

        $count = 0;

        foreach($owners as $owner) {
            $Owner = $this->get([Owner::ID => $owner[OwnerHash::OWNER_ID]]);
            if($Owner->{Owner::OWNER_TYPE} === config('fields.v1.individual') && $Owner->{Owner::CONSENT} !== Owner::RECEIVED){
                return 0;
            }
            if(strtolower($Owner->{Owner::OWNER_TYPE} === config('fields.v1.individual')) && $owner[config('fields.v1.score')] != 0){
                // $owner_percent = isset($Owner->{Owner::ACTUAL_PERCENT}) ? $Owner->{Owner::ACTUAL_PERCENT} : $this->getOwnerPercent($Owner->toArray());
                $total_score = $total_score + $owner[config('fields.v1.score')];
                $count++;
            }
            $app_id = $Owner->{Owner::APP_ID};
        }

        $weighted_average = ($total_score > 0 && $count > 0) ? $total_score/$count : 0;

        $params = [
            Owner::APP_ID => $app_id,
            config('fields.v1.weighted_average') => round($weighted_average)
        ];

        OwnersWeightedAverage::create($params);
        
        return round($weighted_average);
    }

    /**
     * Get Citizenship Percentage
     *
     * @param array $request
     * 
     * @return string
     */
    public function getIndividualPercentage(array $request)
    {
        $Owners = $this->Owner->getAllOwners([Owner::APP_ID => $request[Owner::APP_ID], Owner::USER_ID => $request[Owner::USER_ID]])->toArray();

        $owner_percent = [];
        
        foreach($Owners as $Owner) {
            if(strtolower($Owner[Owner::OWNER_TYPE]) === config('fields.v1.individual')) {
                $owner_percent[$Owner[Owner::ID]] = isset($Owner[Owner::ACTUAL_PERCENT]) ? round($Owner[Owner::ACTUAL_PERCENT], 2) : round($this->getOwnerPercent($Owner), 2);
            }
        }
        return $owner_percent;
    }

    /**
     * Update OwnerShip Percent
     *
     * @param array $owners
     * 
     * @return boolean
     */
    public function updateOwnerPercent(array $owners)
    {
        foreach($owners as $owner) {
            $Owner = $this->get([Owner::ID => $owner[OwnerHash::OWNER_ID]]);
            if($Owner->{config('fields.v1.parent_id')} != 0) {
                $Parent = $this->get([Owner::ID => $Owner->{config('fields.v1.parent_id')}]);
                $updated_ownership_percent = ($owner[config('fields.v1.updated_percent')]/$Parent->{Owner::ACTUAL_PERCENT}) * 100;
                
                $update_params = [
                    Owner::OWNERSHIP_PERCENT => round($updated_ownership_percent, 2),
                    Owner::ACTUAL_PERCENT    => $owner[config('fields.v1.updated_percent')]
                ];

                $update_params = $this->getOwnershipUpdateParams($Owner, $update_params);

                $this->Owner->where(Owner::ID, $owner[OwnerHash::OWNER_ID])->update($update_params);
            } else {
                $updated_ownership_percent = $owner[config('fields.v1.updated_percent')];
                
                $update_params = [
                    Owner::OWNERSHIP_PERCENT => $updated_ownership_percent,
                    Owner::ACTUAL_PERCENT    => $updated_ownership_percent
                ];

                $update_params = $this->getOwnershipUpdateParams($Owner, $update_params);

                $this->Owner->where(Owner::ID, $owner[OwnerHash::OWNER_ID])->update($update_params);
            }
            
        }

        return $this; 
    }

    /**
     * Get Ownership Log as update params
     *
     * @param Owner $Owner
     * @param array $update_params
     * 
     * @return array
     */
    public function getOwnershipUpdateParams(Owner $Owner, array $update_params)
    {
        $ownership_log = [];

        if(isset($Owner->{config('fields.v1.ownership_updated_log')})) {
            $ownership_log = $Owner->{config('fields.v1.ownership_updated_log')};
            array_push($ownership_log, (object)[
                Owner::OWNERSHIP_PERCENT                      => $Owner->{Owner::OWNERSHIP_PERCENT},
                Owner::ACTUAL_PERCENT                         => $Owner->{Owner::ACTUAL_PERCENT},
                config('fields.v1.updated_percent')           => $update_params[Owner::ACTUAL_PERCENT],
                config('fields.v1.updated_ownership_percent') => $update_params[Owner::OWNERSHIP_PERCENT],
                config('fields.v1.updated_at')                => time()
            ]);
        } else {
            array_push($ownership_log, (object)[
                Owner::OWNERSHIP_PERCENT                      => $Owner->{Owner::OWNERSHIP_PERCENT},
                Owner::ACTUAL_PERCENT                         => $Owner->{Owner::ACTUAL_PERCENT},
                config('fields.v1.updated_percent')           => $update_params[Owner::ACTUAL_PERCENT],
                config('fields.v1.updated_ownership_percent') => $update_params[Owner::OWNERSHIP_PERCENT],
                config('fields.v1.updated_at')                => time()
            ]);
        }

        $update_params = array_merge($update_params, [
            config('fields.v1.ownership_updated_log') => $ownership_log
        ]);

        return $update_params;
    }

    /**
     * Delete all owners hash when application is submitted
     *
     * @param string $app_id
     * 
     * @return void
     */
    public function deleteAllOwnerHash(string $app_id)
    {
        $Owners = $this->Owner->where([Owner::APP_ID => $app_id])->get();
        $owner_ids = [];

        foreach($Owners as $Owner) {
            if($Owner->{Owner::CONSENT} !== Owner::RECEIVED && strtolower($Owner->{Owner::OWNER_TYPE}) === config('fields.v1.individual')) {
                return [];
            }

            $owner_ids[] = $Owner->{Owner::ID};
        }

        $this->OwnerHash->whereIn(OwnerHash::OWNER_ID, $owner_ids)->delete();
    }

    /**
     * Get saved weighted average
     *
     * @param string $app_id
     * 
     * @return string
     */
    public function getSavedWeightedAverage(string $app_id)
    {
        $Owners_Weighted_Average = OwnersWeightedAverage::where(Owner::APP_ID, $app_id)
                                    ->orderBy(config('fields.v1.created_at'), 'desc')
                                    ->first();

        $weighted_average = ($Owners_Weighted_Average instanceof OwnersWeightedAverage) ? $Owners_Weighted_Average : false;

        return $weighted_average;
    }

    /**
     * Create New Consent Hash for all owners
     *
     * @param array $owners
     * @param string $hash_for
     * 
     * @return void
     */
    public function createConsentHash(array $owners, string $hash_for)
    {
        if(empty($owners)) throw new BlankDataException();

        $Owners_with_hash = Hash::createHash($owners, $hash_for);

        if(!$Owners_with_hash) return false;

        foreach($Owners_with_hash as $Hash) {
            unset($Hash[Hash::ENCRYPTED_HASH]);
        }

        return $Owners_with_hash;
    }

    /**
     * Add updated percent and it's consent
     *
     * @param array $owners
     * 
     * @return bool
     */
    public function addUpdatedPercent(array $owners)
    {
        if(empty($owners)) throw new BlankDataException();

        foreach($owners as $owner) {
            $updated = $this->Owner->where(Owner::ID, $owner[OwnerHash::OWNER_ID])->update([
                config('fields.v1.update_percent_consent') => Owner::PENDING,
                config('fields.v1.updated_percent') => $owner[config('fields.v1.updated_percent')]
            ]);

            if (!$updated) {
                $Owner = $this->Owner->where(Owner::ID, $owner[OwnerHash::OWNER_ID])->first();
                if(!($Owner->{config('fields.v1.updated_percent')} && $Owner->{config('fields.v1.update_percent_consent')} && $Owner->{config('fields.v1.update_percent_consent')} == Owner::PENDING)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Check if allowed attempts per day have been reached
     * 
     * @param string $ownerId
     * @param string $hash_for
     * 
     * @return Boolean
     */
    public function checkHashPerDayCount(string $ownerId, string $hash_for)
    {
        $date_time = Carbon::now()->subDays(config('owner_consent.v1.MAX_EMAIL_TOKEN_TIME'));
        
        $count = Hash::where([[Hash::OWNER_ID, '=', $ownerId], [Hash::HASH_FOR, '=', $hash_for], [Hash::CREATED_AT, '>', strtotime($date_time)]])->count();
        
        if($count < config('owner_consent.v1.EMAIL_TOKEN_COUNT')) return true;

        return false;
    }

    /**
     * Create New Consent Hash for one owner
     * 
     * @param string $ownerId
     * @param string $hash_for
     * 
     * @return string
     */
    public function createNewConsentHash(string $ownerId, string $hash_for)
    {
        $Owner = $this->Owner->where(Owner::ID, $ownerId)->get()->toArray();

        $Owner[0][Hash::OWNER_ID] = $Owner[0][Owner::ID];

        $Hash = Hash::createHash($Owner, $hash_for);

        if(!$Hash) throw new ObjectNotLoadedException();

        unset($Hash[0]->{Hash::ENCRYPTED_HASH});

        return $Hash[0];
    }

    /**
     * Check if hash exists in db
     * 
     * @param string $hash
     * 
     * @return boolean
     */
    public function isConsentHashExist(string $hash)
    {
        $Hash = Hash::where(Hash::ENCRYPTED_HASH, $hash)->first();

        if($Hash instanceof Hash) {
            return true;
        }
    }

    /**
     * Check if hash is expired or not
     * 
     * @param string $hash
     * 
     * @return boolean
     */
    public function checkConsentHashExpiry(string $hash)
    {
        $hash_created_at = $this->getConsentHashCreatedAt($hash);
        
        return $this->checkEmailTokenExpiry($hash_created_at);
    }

    /**
     * Get Hash Created At
     * 
     * @param string $hash
     * 
     * @return string
     */
    public function getConsentHashCreatedAt(string $hash)
    {
        $created_at = Hash::select(Hash::CREATED_AT)
                        ->where(Hash::ENCRYPTED_HASH, $hash)
                        ->first()->toArray();
                        
        return $created_at ? strtotime($created_at[Hash::CREATED_AT]) : null;
    }

    /**
     * Check if hash is latest in db or not
     *
     * @param string $hash
     * @param string $hash_for
     * 
     * @return boolean
     */
    public function isHashNew(string $hash, string $hash_for)
    {   
        $Hash = Hash::where(Hash::ENCRYPTED_HASH, $hash)->first();
        
        $latest_hash = Hash::select(Hash::ENCRYPTED_HASH)
                            ->where(Hash::OWNER_ID, $Hash->{Hash::OWNER_ID})
                            ->where(Hash::HASH_FOR, $hash_for)
                            ->orderBy(Hash::CREATED_AT, 'desc')
                            ->first();
        
        if($latest_hash->{Hash::ENCRYPTED_HASH} === $hash) { 
            return true;
        }
    }

    /**
     * Check if Hash is already verified
     *
     * @param string $hash
     * 
     * @return boolean
     */
    public function isHashVerified(string $hash)
    {
        $Hash = Hash::where(Hash::ENCRYPTED_HASH, $hash)->first();

        if($Hash->{Hash::HASH_VERIFIED} == true) {
            return true;
        }

        return false;
    }

    /**
     * Update percent consent to received
     *
     * @param string $owner_id
     * 
     * @return void
     */
    public function updatePercentConsent(string $owner_id)
    {
        $updated = $this->Owner->where(Owner::ID, $owner_id)->update([
            config('fields.v1.update_percent_consent') => Owner::RECEIVED
        ]);
    }

    /**
     * Get Owner info from hash
     *
     * @param string $hash
     * 
     * @return string
     */
    public function getInfoFromHash(string $hash)
    {
        $OwnerFromHash = Hash::select(Hash::OWNER_ID)
                        ->where(Hash::ENCRYPTED_HASH, $hash)
                        ->first();

        $Owner = $this->Owner->select(Owner::APP_ID, Owner::USER_ID, Owner::ID)
                            ->where(Owner::ID, $OwnerFromHash->{Hash::OWNER_ID})
                            ->first();

        if($Owner) {
            $OwnerFromHash->update([
                Hash::HASH_VERIFIED => true
            ]);
        }

        return $Owner ? $Owner : [];
    }

    /**
     * Delete Hash
     *
     * @param string $app_id
     * @param string $hash_for
     * 
     * @return string
     */
    public function deleteHash(string $app_id, string $hash_for)
    {
        $Owners = $this->Owner->where([Owner::APP_ID => $app_id])->get();
        $owner_ids = [];

        foreach($Owners as $Owner) {
            if(isset($Owner->{$hash_for}) && $Owner->{$hash_for} !== Owner::RECEIVED && strtolower($Owner->{Owner::OWNER_TYPE}) === config('fields.v1.individual')) {
                return [];
            }

            $owner_ids[] = $Owner->{Owner::ID};
        }

        Hash::whereIn(Hash::OWNER_ID, $owner_ids)->where(Hash::HASH_FOR, $hash_for)->delete();
    }

    /**
    * Filter service owner
    * 
    * @param Request $Request 
    *
    * @return array
    */
   public function filterReferences(Request $Request)
   {
       return $this->ServiceInterface->filterReferences($Request, new ServiceOwner());
   }
}