<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Notes Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\v1\Notes;

use Illuminate\Http\Request;
use App\Repositories\Models\Note;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Transformer\NotesTransformer;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Contracts\Notes\NotesInterface;
use App\Repositories\Exceptions\ObjectNotLoadedException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * NotesRepository class for handling Notes operation.
 */
class NotesRepository extends ApiRepository implements NotesInterface
{
    /**
     * Note Model
     *
     * @var App\Repositories\Models\Note
     */
    protected $Note;

    /**
     * @param App\Repositories\Model\Note $Note
     */
    public function __construct(Note $Note)
    {
        $this->Note = $Note;
    }

    /**
     * Create Note
     *
     * @param array $attributes
     * 
     * @return string
     */
    public function create(array $attributes)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Note = $this->Note->saveNote($attributes);

        if(!$Note instanceof Note) throw new ObjectNotLoadedException();

        return $Note;
    }

    /**
     * Get notes
     *
     * @param string $id
     * 
     * @return string
     */
    public function get(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $Notes = $this->Note->where($params)->get();
        
        return $Notes ? $Notes : false;
    }

    /**
     * Get All notes
     *
     * @param array $app_ids
     * 
     * @return string
     */
    public function getAll(array $app_ids)
    {
        if(empty($app_ids)) throw new BlankDataException();

        $Notes = $this->Note->whereIn(Note::APP_ID, $app_ids)->get();
        
        return $Notes ? $Notes : false;
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return NotesTransformer::class;
    }
}