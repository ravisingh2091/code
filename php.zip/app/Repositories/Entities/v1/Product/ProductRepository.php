<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Product Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\v1\Product;

use Illuminate\Http\Request;
use App\Repositories\Models\Product;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Transformer\ProductTransformer;
use App\Repositories\Exceptions\ObjectNotLoadedException;
use App\Repositories\Contracts\Product\ProductInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
/**
 * ProductRepository class for handling Product operation.
 *
 * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
 */
class ProductRepository extends ApiRepository implements ProductInterface
{
    /**
     * Product Model
     *
     * @var App\Repositories\Models\Product
     */
    protected $Product;

    /**
     * @param App\Repositories\Model\Product $Product
     */
    public function __construct(Product $Product)
    {
        $this->Product = $Product;
    }

    public function create(array $attributes)
    {
        if(empty($attributes)) throw new BlankDataException();

        $app_id = $attributes[Product::APP_ID];
        $user_id = $attributes[Product::USER_ID];

        $Products = [];
        
        foreach($attributes[config('fields.v1.products_field')] as $Product) {
            $params = array_merge($Product, [
                Product::APP_ID  => $app_id,
                Product::USER_ID => $user_id
            ]);
            $Products[] = $this->Product->saveProduct($params);
        }

        if (!$Products) throw new ObjectNotLoadedException();

        return $Products;
    }

    /**
     * Get Product
     *
     * @param string $id
     * 
     * @return string
     */
    public function get(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $Product = $this->Product->where($params)->first();
        
        return $Product instanceof Product ? $Product : false;
    }

    /**
     * Get all Products
     *
     * @param array $params
     * 
     * @return string
     */
    public function getAll(array $params)
    {
        if(isset($params[config('fields.v1.product_id')]) && !empty($params[config('fields.v1.product_id')])) {
            $params = array_merge($params, [
                Product::ID => $params[config('fields.v1.product_id')]
            ]);
            unset($params[config('fields.v1.product_id')]);
            
        }
        
        $Product = $this->Product->where($params)->get();
        
        return $Product ? $Product : false;
    }

    /**
     * Update Product
     *
     * @param array $attributes
     * @param string $id
     * 
     * @return string
     */
    public function update(array $attributes, string $id)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Product = $this->Product->where(Product::ID, $id)->first();

        if (!$Product instanceof Product) return false;

        $Product->update($attributes);

        return $Product;
    }

    /**
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param array $attributes
     *
     * @return string
     */
    public function updateBatch(array $attributes) 
    {   
        // before updating Products delete the old Products 
        $deleted = $this->Product->where([
            Product::APP_ID => $attributes[Product::APP_ID],
            Product::USER_ID => $attributes[Product::USER_ID]
        ])->delete();
        
        //insert new Products
        if($deleted) {
            return $this->create($attributes);
        }
        
        return false;
    }

    /**
     * Get Products using multiple application
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     *
     * @param array $params
     * 
     * @return string
     */
    public function getByApplications(array $params)
    {
        $Product = $this->Product->whereIn('app_id', $params)->get();
        
        return $Product ? $Product : false;
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * @author Rabindra Gupta <rabindra.gupta@biz2credit.com>
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return ProductTransformer::class;
    }
}