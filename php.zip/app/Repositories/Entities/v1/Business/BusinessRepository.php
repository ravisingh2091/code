<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Business Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\v1\Business;

use Validator;
use Illuminate\Http\Request;
use App\Repositories\Models\Business;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Models\ServiceBusiness;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Contracts\Service\ServiceInterface;
use App\Repositories\Exceptions\ObjectNotLoadedException;
use App\Repositories\Transformer\BusinessInfoTransformer;
use App\Repositories\Contracts\Business\BusinessInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * BusinessRepository class for handling business info CRUD operation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class BusinessRepository extends ApiRepository implements BusinessInterface
{
    /**
     * Business Model
     *
     * @var App\Repositories\Models\Business
     */
    protected $Business;

    /**
     * ServiceBusiness Interface
     *
     * @var App\Repositories\Contracts\Service\ServiceInterface
     */
    protected $ServiceInterface;


    /**
     * @param App\Repositories\Model\Business $Business
     */
    public function __construct(Business $Business, ServiceInterface $ServiceInterface)
    {
        $this->Business = $Business;
        $this->ServiceInterface = $ServiceInterface;
    }

    /**
     * @param array $attributes
     *
     * @return string
     */
    public function create(array $attributes)
    {
       if(empty($attributes)) throw new BlankDataException();

       $Business = $this->Business->saveBusinessInfo($attributes);

       if (!$Business instanceof Business) throw new ObjectNotLoadedException(); 

       return $Business;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $attributes
     * @param string $businessId
     *
     * @return string
     */
    public function update(array $attributes, string $businessId)
    {
       if(empty($attributes) || empty($businessId)) throw new BlankDataException();

       $Business = $this->Business->updateBusinessInfo($attributes, $businessId);

       return $Business;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $fields_data
     *
     * @return array
     */
    public function removeFields(array $fields_data)
    {
        $business_key = array_search(config('fields.v1.business_name'), $fields_data);
        if ($business_key || $business_key == 0) {
            unset($fields_data[$business_key]);
        }

        return $fields_data;
    }

    /**
     * Fetch Business Details using App Id and user Id
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $params
     *
     * @return string
     */
    public function get(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $Business = $this->Business->getBusinessInfo($params);

        return $Business instanceof Business ? $Business : [];
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $key
     * @param string $value
     *
     * @return string
     */
    public function getBusiness(string $key, string $value)
    {
        $Business = $this->Business->getBusiness($key, $value);
        
        return $Business;
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return BusinessInfoTransformer::class;
    }

    /**
    * Filter service business
    * 
    * @param Request $Request 
    *
    * @return array
    */
   public function filterReferences(Request $Request)
   {
      return $this->ServiceInterface->filterReferences($Request, new ServiceBusiness());
   }
}