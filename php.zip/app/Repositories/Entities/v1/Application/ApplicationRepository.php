<?php

/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Business Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\v1\Application;

use MongoDB\BSON\ObjectID;
use Illuminate\Http\Request;
use App\Repositories\Models\Business;
use Illuminate\Support\Facades\Event;
use App\Repositories\Models\Application;
use App\Repositories\Models\AppActivity;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Events\SaveAppActivityEvent;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Transformer\AppActivityTransformer;
use App\Repositories\Transformer\ApplicationTransformer;
use App\Repositories\Exceptions\ObjectNotLoadedException;
use App\Repositories\Contracts\Application\ApplicationInterface;

/**
 * ApplicationRepository class for handling Application operation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ApplicationRepository extends ApiRepository implements ApplicationInterface
{
    /**
     * Application Model
     *
     * @var App\Repositories\Models\Application
     */
    protected $Application;

    /**
     * Application Model
     *
     * @var App\Repositories\Models\AppActivity
     */
    protected $AppActivity;

    /**
     * @param App\Repositories\Model\Application $Application
     */
    public function __construct(Application $Application, AppActivity $AppActivity)
    {
        $this->Application = $Application;
        $this->AppActivity = $AppActivity;
    }

    /**
     * @param array $attributes
     *
     * @return string
     */
    public function create(array $attributes)
    {
        if (empty($attributes)) throw new BlankDataException();

        $Application = $this->Application->saveApplication($attributes);

        if (!$Application instanceof Application) throw new ObjectNotLoadedException();

        return $Application;
    }

    /**
     * Fetch Application Details using App Id and user Id
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param array $params
     *
     * @return string
     */
    public function get(array $params)
    {
        if (empty($params)) throw new BlankDataException();

        if (isset($params[config('fields.v1.app_id')])) {
            $params[Application::ID] = $params[config('fields.v1.app_id')];
            unset($params[config('fields.v1.app_id')]);
        }

        if (isset($params['allow_multiple_app']) && ($params['allow_multiple_app'] == 'true' || $params['allow_multiple_app'] == 1)) {
            $start = isset($params['start']) ? $params['start'] : 0;
            $per_page = isset($params['per_page']) ? $params['per_page'] : 20;

            unset($params['allow_multiple_app']);
            unset($params['start']);
            unset($params['per_page']);

            $Applications = $this->Application->getApplications($params, $start, $per_page);
            if (empty($Applications)) return [];

            foreach ($Applications as $key => $Application) {
                $Business = Business::where([Business::APP_ID => $Application[Application::ID]])->first();

                $Applications[$key][config('fields.v1.business_id')] = $Business instanceof Business ? $Business->{Business::ID} : null;
            }
            return $Applications;
        } else {
            $Application = $this->Application->getApplication($params);
            if (!$Application) return [];

            $Business = Business::where([Business::APP_ID => $Application->{Application::ID}])->first();

            $Application->{config('fields.v1.business_id')} = $Business instanceof Business ? $Business->{Business::ID} : null;
            return $Application;
        }
    }

    /**
     * Delete an application
     *
     * @param array $params
     * 
     * @return string
     */
    public function delete(array $params)
    {
        if (empty($params)) throw new BlankDataException();

        if (isset($params[config('fields.v1.app_id')])) {
            $params[Application::ID] = $params[config('fields.v1.app_id')];
            unset($params[config('fields.v1.app_id')]);
        }

        return $this->Application->where($params)->delete();
    }

    /**
     * Update Application
     *
     * @param array $attributes
     * @param string $app_id
     * 
     * @return string
     */
    public function update(array $attributes, string $app_id)
    {
        if (empty($attributes)) throw new BlankDataException();

        $Application = $this->Application->where(Application::ID, $app_id)->first();

        if (!$Application instanceof Application) return false;

        if ($Application->update($attributes)) {
            Event::fire(new SaveAppActivityEvent($app_id));
        }

        return $Application;
    }

    /**
     * Update Application Status
     *
     * @param string $app_id
     * @param array $params
     * 
     * @return void
     */
    public function updateAppStatus(string $app_id, array $params,$only_add_note=false)
    {
        if(!$only_add_note){
            if (empty($params)) throw new BlankDataException();
        }

        $params[Application::UPDATED_AT] = time();

        $updated = $this->Application->where(Application::ID, $app_id)->update($params);

        if ($updated === 0 || $updated) {
            Event::fire(new SaveAppActivityEvent($app_id));
            // $params = array_merge($params, [config('fields.v1.app_id') => $app_id]);
            // $this->AppActivity->create($params);
        }

        $Application = ($updated === 0 || $updated) ? $this->Application->where(Application::ID, $app_id)->first() : null;

        return $Application;
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param Request $Request
     *
     * @return array
     */
    public function getBatch(Request $Request)
    {
        $start    = self::START;
        $per_page = self::PER_PAGE;
        $Application = $this->Application;

        if ($Request->filled(config('fields.v1.app_id'))) {

            if ($Request->filled(config('fields.v1.name'))) {
                $user_ids = $this->getUserByName(config('api-urls.v1.user_service') . '/backend', config('fields.v1.version_v1'), $Request->{config('fields.v1.name')});

                $user_match = $user_ids === null ? false : $this->getUserInfo($Request->{config('fields.v1.app_id')}, $user_ids);

                if (!$user_match) {
                    return [];
                } else {
                    $Application = $Application->where(Application::ID, $Request->{config('fields.v1.app_id')});
                }
            } else {
                $Application = $Application->where(Application::ID, $Request->{config('fields.v1.app_id')});
            }
        }

        if ($Request->filled(config('fields.v1.name')) && !$Request->filled(config('fields.v1.app_id'))) {
            $user_ids = $this->getUserByName(config('api-urls.v1.user_service') . '/backend', config('fields.v1.version_v1'), $Request->{config('fields.v1.name')});

            if ($user_ids === null) {
                return [];
            }

            $Application = $Application->whereIn(Application::USER_ID, $user_ids);
        }

        if ($Request->filled(config('fields.v1.start'))) {
            $start = (int) $Request->{config('fields.v1.start')};
        }

        if ($Request->filled(config('fields.v1.per_page'))) {
            $per_page = (int) $Request->{config('fields.v1.per_page')};
        }

        if ($Request->filled(config('fields.v1.record_id'))) {
            $Application = $Application->where(config('fields.v1.record_id'), (int) $Request->{config('fields.v1.record_id')});
        }

        if ($Request->filled(config('fields.v1.user_id'))) {
            $Application = $Application->where(config('fields.v1.user_id'), $Request->{config('fields.v1.user_id')});
        }

        if ($Request->filled(config('fields.v1.status_id'))) {
            $Application = $Application->where(config('fields.v1.status_id'), $Request->{config('fields.v1.status_id')});
        }

        if ($Request->filled(config('fields.v1.app_ids')) && is_array($Request->get(config('fields.v1.app_ids'))) && count($Request->get(config('fields.v1.app_ids')))) {
            $Application = $Application->whereIn(config('fields.v1.mongo_id'), $Request->{config('fields.v1.app_ids')});
        }

        if ($Request->filled(config('fields.v1.product_type'))) {
            $product_types = explode(',', $Request->{config('fields.v1.product_type')});
            if ($Request->filled(config('fields.v1.product_exists'))) {
                // return applications where product_type key has conditon on product_exists
                $Application = $Application->whereIn(config('fields.v1.product_type'), $product_types);
                $product_exists = $Request->get(config('fields.v1.product_exists')) == '1' ? true : false;
                if (!$product_exists) {
                    $Application = $Application->orWhere(config('fields.v1.product_type'), 'exists', $product_exists);
                }
            } else {
                $Application = $Application->whereIn(config('fields.v1.product_type'), $product_types);
            }
        } else if ($Request->filled(config('fields.v1.product_exists'))) {
            $exists = $Request->get(config('fields.v1.product_exists'));

            $product_exists = $exists == '1' ? true : false;
            // return applications where product_type key has conditon on product_exists
            $Application = $Application->orWhere(config('fields.v1.product_type'), 'exists', $product_exists);
        }

        if ($Request->filled(config('fields.v1.assigned_to'))) {
            $Application = $Application->where(config('fields.v1.assigned_to'), $Request->{config('fields.v1.assigned_to')});
        }

        $business_ref_filter = [];
        $business_reference_type =  [];
        $business_reference_filter = false;
        if ($Request->filled(config('fields.v1.business_reference_from_date')) && $Request->filled(config('fields.v1.business_reference_to_date'))) {
            array_push($business_ref_filter, (int) $Request->{config('fields.v1.business_reference_from_date')}, (int) $Request->{config('fields.v1.business_reference_to_date')});
            $business_reference_filter = true;
        }

        if ($Request->filled(config('fields.v1.business_reference_type'))) {
            $business_reference_type = explode(',', $Request->get(config('fields.v1.business_reference_type')));
            //    $business_reference_filter = true;
        }

        $owner_ref_filter = [];
        $owner_reference_type =  [];
        $owner_reference_filter = false;
        if ($Request->filled(config('fields.v1.owner_reference_from_date')) && $Request->filled(config('fields.v1.owner_reference_to_date'))) {
            array_push($owner_ref_filter, (int) $Request->{config('fields.v1.owner_reference_from_date')}, (int) $Request->{config('fields.v1.owner_reference_to_date')});
            $owner_reference_filter = true;
        }

        if ($Request->filled(config('fields.v1.owner_reference_type'))) {
            $owner_reference_type =  explode(',', $Request->get(config('fields.v1.owner_reference_type')));
            // $owner_reference_filter = true;
        }

        $count = 0;

        $Applications = [];

        if (count($business_reference_type) || count($business_ref_filter) || count($owner_reference_type) || count($owner_ref_filter)) {
            $Applications = $Application
                ->orderBy(Application::RECORD_ID, 'desc')
                ->with('business')
                ->with(['businessReferences' => function ($query) use ($business_ref_filter, $business_reference_type) {
                    if (count($business_reference_type)) {
                        $query->whereIn('type', $business_reference_type);
                    }

                    if (count($business_ref_filter)) {
                        $query->whereBetween('created_at', $business_ref_filter);
                    }
                }])
                ->with('owners')
                ->with(['ownerReferences' => function ($query) use ($owner_ref_filter, $owner_reference_type) {
                    if (count($owner_reference_type)) {
                        $query->whereIn('type', $owner_reference_type);
                    }

                    if (count($owner_ref_filter)) {
                        $query->whereBetween('created_at', $owner_ref_filter);
                    }
                }])
                ->with('ownersWeightedAverage')
                ->with('assignments')
                ->with('appActivity')
                ->get()
                ->filter(function ($item, $index) use ($business_reference_filter, $owner_reference_filter) {
                    if (!$business_reference_filter && !$owner_reference_filter) {
                        return $item;
                    }

                    if ($business_reference_filter && !$owner_reference_filter && $item->businessReferences && count($item->businessReferences)) {
                        return $item;
                    }

                    if ($owner_reference_filter && !$business_reference_filter && $item->ownerReferences && count($item->ownerReferences)) {
                        return $item;
                    }

                    return ($item->businessReferences && count($item->businessReferences)) || ($item->ownerReferences && count($item->ownerReferences));
                })
                ->slice($start, $per_page, true)
                // ->offset($start)
                // ->limit($per_page)
                ->toArray();

            $Applications = array_values($Applications);

            $count = count($Applications);
        } else {
            $count = $Application->count();

            $Applications = $Application
                ->orderBy(Application::RECORD_ID, 'desc')
                ->with('business')
                ->with('businessReferences')
                ->with('owners')
                ->with('ownerReferences')
                ->with('ownersWeightedAverage')
                ->with('assignments')
                ->with('appActivity')
                ->offset($start)
                ->limit($per_page)
                ->get()
                ->toArray();
        }



        $Applications = array_merge([config('fields.v1.applications') => $Applications], [config('fields.v1.total_apps') => $count]);

        if (!$Applications || empty($Applications)) return [];

        return $Applications;
    }

    /**
     * Return application where user_id matches with fetched application app_id
     *
     * @param string $app_id
     * @param array $user_ids
     * 
     * @return string
     */
    private function getUserInfo(string $app_id, array $user_ids)
    {
        $Application = $this->Application->where(Application::ID, $app_id)->first();

        if (!$Application instanceof Application) return false;

        if (array_search($Application->{Application::USER_ID}, $user_ids) !== false) return true;
    }

    /**
     * Get app count according to status
     * 
     * @param Request $Request 
     *
     * @return string
     */
    public function getAppCount(Request $Request)
    {
        $total_apps_query = $this->Application->raw(function ($collection) use ($Request) {

            if ($Request->filled(config('fields.v1.from_date')) && $Request->filled(config('fields.v1.to_date'))) {
                $conditions[] = [
                    config('fields.v1.created_at') => ['$gte' => (int) $Request->{config('fields.v1.from_date')}],
                ];
                $conditions[] = [
                    config('fields.v1.created_at') => ['$lte' => (int) $Request->{config('fields.v1.to_date')}]
                ];

                return $collection->aggregate([
                    [
                        '$match' => ['$and' => $conditions],
                    ],
                    [
                        '$unwind'=>'$status_id'
                    ],
                    [
                        '$group' => [
                            Application::ID => array(config('fields.v1.status_id') => '$status_id'),
                            'count' => ['$sum' => 1]
                        ],
                    ]
                ]);
            }

            return $collection->aggregate([
                [
                    '$unwind'=>'$status_id'
                ],
                [
                    '$group' => [
                        Application::ID => array(config('fields.v1.status_id') => '$status_id'),
                        'count' => ['$sum' => 1]
                    ],
                ]
            ]);
        })->toArray();

        $total_apps = [];
        foreach ($total_apps_query as $query) {
            $status = $query[Application::ID]->jsonSerialize();
            $total_apps[] = [
                config('fields.v1.status_id') => $status->{config('fields.v1.status_id')},
                'count' => $query['count']
            ];
        }

        return $total_apps;
    }

    /**
     * Get App Activity
     *
     * @param string $app_id
     * 
     * @return string
     */
    public function getAppActivity(Request $Request, string $app_id)
    {
        $AppActivity = $this->AppActivity->where(config('fields.v1.app_id'), $app_id);

        if ($Request->filled(config('fields.v1.action_from'))) {
            $AppActivity = $AppActivity->where(config('fields.v1.action_from'), $Request->{config('fields.v1.action_from')});
        }

        $AppActivity = $AppActivity->orderBy(config('fields.v1.created_at'), 'desc')
            ->get()->toArray();

        return $AppActivity ? $AppActivity : [];
    }

    /**
     * Get App Status by app_id
     *
     * @param string $app_id
     * 
     * @return string
     */
    public function getAppStatus(string $app_id)
    {
        $Application = $this->Application->select(Application::STATUS_ID)
            ->where(Application::ID, $app_id)
            ->first();

        return ($Application && $Application->{Application::STATUS_ID}) ? $Application->{Application::STATUS_ID} : false;
    }

    /**
     * New Update Application Status
     *
     * @param string $app_id
     * @param array $params
     * 
     * @return void
     */
    public function updateMultipleAppStatus(string $app_id, array $params)
    {
        if (empty($params)) throw new BlankDataException();

        $updated = 0;

        if (isset($params[config('fields.v1.allow_multiple')]) && $params[config('fields.v1.allow_multiple')] == 'true') {
            $App = $this->Application->where(Application::ID, $app_id)->first();
            $status_id_arr = [];

            if ($App->{config('fields.v1.status_id')} && !is_array($App->{config('fields.v1.status_id')})) {
                array_push($status_id_arr, $App->{config('fields.v1.status_id')}, $params[config('fields.v1.status_id')]);
            } else if ($App->{config('fields.v1.status_id')} && is_array($App->{config('fields.v1.status_id')})) {
                $status_id_arr = $App->{config('fields.v1.status_id')};
                array_push($status_id_arr, $params[config('fields.v1.status_id')]);
            } else {
                $status_id_arr = $params[config('fields.v1.status_id')];
            }

            $updated = $this->Application->where(Application::ID, $app_id)->update([
                config('fields.v1.status_id') => $status_id_arr
            ]);
        } else if (isset($params[config('fields.v1.delete_status')]) && $params[config('fields.v1.delete_status')] == 'true') {
            $App = $this->Application->where(Application::ID, $app_id)->first();
            $status_id_arr = [];
            if (gettype($App->{config('fields.v1.status_id')}) == 'string') {
                $status_id_arr = in_array($App->{config('fields.v1.status_id')}, $params[config('fields.v1.status_id')]) ? "" :  $App->{config('fields.v1.status_id')};
            } else {
                $status_id_arr = array_values(array_diff($App->{config('fields.v1.status_id')}, $params[config('fields.v1.status_id')]));
                $status_id_arr =  count($status_id_arr) ? $status_id_arr : "";
            }
            $updated = $this->Application->where(Application::ID, $app_id)->update([
                config('fields.v1.status_id') => $status_id_arr
            ]);
        } else {
            $updated = $this->Application->where(Application::ID, $app_id)->update([
                config('fields.v1.status_id') => $params[config('fields.v1.status_id')]
            ]);
        }

        if ($updated === 0 || $updated) {
            if (!isset($params[config('fields.v1.allow_activity')]) || $params[config('fields.v1.allow_activity')] == 'true') {
                Event::fire(new SaveAppActivityEvent($app_id));
            }
        }

        $Application = ($updated === 0 || $updated) ? $this->Application->where(Application::ID, $app_id)->first() : null;

        return $Application;
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return ApplicationTransformer::class;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getAppActivityTransformClass()
    {
        return AppActivityTransformer::class;
    }

    /**
     * Clone Application
     *
     * @param array $params
     * 
     * @return object
     */
    public function clone(array $params)
    {

        if (!isset($params['match']) || ($params['match'] && !count(array_keys($params['match'])))) {
            // return error
            return $this->dispatchResponse(
                trans('messages.v1.failed'),
                Response::HTTP_BAD_REQUEST,
                $this->getResourceName(),
                [config('fields.v1.match') => trans('messages.v1.match_required')]
            );
        }

        $ignoreMap = [];
        if (isset($params['ignore'])) {
            // create a map where key is the model name and value if the filter
            foreach ($params['ignore'] as $ignore) {
                $ignoreMap[$ignore['type']] = $ignore;
            }
        }

        $match = $params['match'];

        $application = isset($params['application']) ? $params['application'] : [];
        $assignments = isset($params['assignments']) ? $params['assignments'] : [];
        $old_application = isset($params['old_application']) ? $params['old_application'] : [];
        $ignore = isset($params['ignore']) ? $params['ignore'] : [];


        $paramKey = [config('fields.v1.app_id') => config('fields.v1.mongo_id'), config('fields.v1.record_id') => config('fields.v1.record_id')];

        $query = [];
        $keys = array_keys($match);
        foreach ($keys as $key) {
            $query[$paramKey[$key]] = $match[$key];
            if ($key === config('fields.v1.app_id')) {
                $query[$paramKey[$key]] = new ObjectID($match[$key]);
            }
        }

        $app =  $this->Application->where($query)->get()->first();
        if (!$app) return false; // resource not found error

        // 	// update old application data
        $param = [config('fields.v1.product_type') => config('fields.v1.product_type'), config('fields.v1.status_id') => config('fields.v1.status_id')];

        $updateBody = [];
        $keys = array_keys($old_application);
        foreach ($keys as $key) {
            if ($old_application[$key]) {
                $updateBody[$param[$key]] = $old_application[$key];
                $app[$param[$key]] = $old_application[$key];
            }
        }
        $updated =  $this->update($updateBody, $app->{config('fields.v1.mongo_id')}); // update old application

        $copyApp = [
            config('fields.v1.status_id') => $app->{config('fields.v1.status_id')},
            config('fields.v1.user_id') => $app->{config('fields.v1.user_id')},
            // config('fields.v1.user_id') => $app->{config('fields.v1.user_id')},
            'replicated' => $app->toArray()
        ];

        if (isset($app->{config('fields.v1.product_type')})) {
            $copyApp[config('fields.v1.product_type')] = $app->{config('fields.v1.product_type')};
        }

        // if(isset($app->{config('fields.v1.status_id')})) {
        //     $copyApp[config('fields.v1.status_id')] = $app->{config('fields.v1.status_id')};
        // }

        if (isset($application[config('fields.v1.note')])) {
            $copyApp[config('fields.v1.note')] = $application[config('fields.v1.note')];
        }

        if (isset($application[config('fields.v1.status_id')])) {
            $copyApp[config('fields.v1.status_id')] = $application[config('fields.v1.status_id')];
        }

        if (isset($application[config('fields.v1.backend_user_id')])) {
            $copyApp[config('fields.v1.backend_user_id')] = $application[config('fields.v1.backend_user_id')];
        }

        if (isset($application[config('fields.v1.renewals_flag')])) {
            $copyApp[config('fields.v1.renewals_flag')] = $application[config('fields.v1.renewals_flag')];
        }

        if (isset($application[config('fields.v1.copy_flag')])) {
            $copyApp[config('fields.v1.copy_flag')] = $application[config('fields.v1.copy_flag')];
        }


        $savedApp = $this->Application->create($copyApp);

        $path = app()->path . '/Repositories/Models';
        $classes = $this->getClasses($path, 'App\Repositories\Models\\');


        foreach ($classes as $class) {
            $model = new $class;
            if (!$model instanceof $this->Application &&  !$model instanceof $this->AppActivity) {
                $collection_name = $model->getCollectionName();
                $ignoreParams = [];
                if (isset($ignoreMap[$collection_name])) {
                    $ignoreMatches = $ignoreMap[$collection_name];
                    $ignoreParams = [$ignoreMatches['match_key'] => ['$nin' => $ignoreMatches['match']]];
                }
                // { model, query: { app_id: app._id }}, savedApp, $ignoreMap[$collection_name]
                $all_records =  $model->where([config('fields.v1.app_id') => $app->{config('fields.v1.mongo_id')}])->where($ignoreParams)->project(["_id" => 0])->get()->toArray();
                if (count($all_records)) {
                    $dataToSave = [];
                    foreach ($all_records as $record) {
                        $copied = [
                            'copied' => true,
                            "created_at" => (int)date("U", strtotime($record['created_at'])),
                            "updated_at" => (int)date("U", strtotime($record['updated_at']))
                        ];
                        $record[config('fields.v1.app_id')] = $savedApp->{config('fields.v1.mongo_id')};
                        $dataToSave[] = array_merge($record, $copied);
                    }
                    $savedRecords = \DB::table($collection_name)->raw(function ($collection) use ($dataToSave) {
                        return $collection->insertMany($dataToSave);
                    });
                }
            }
        }


        if (count($assignments)) {
            $dataToSave = [];
            foreach ($assignments as $assignment) {
                $appData = [
                    config('fields.v1.app_id') => $savedApp->{config('fields.v1.mongo_id')},
                    config('fields.v1.user_id') => $savedApp->{config('fields.v1.user_id')}
                ];

                $dataToSave[] = array_merge($appData, $assignment);
            }

            $savedRecords = \DB::table('app_assignment')->raw(function ($collection) use ($dataToSave) {
                return $collection->insertMany($dataToSave);
            });
        }

        return $this->dispatchResponse(
            trans('messages.v1.success'),
            Response::HTTP_OK,
            $this->getResourceName(),
            [$savedApp]
        );
    }


    /**
     * This method will scan the dir and will return the file name
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @param string $path
     * 
     * @return array
     */
    private function getClasses($path, $nameSpace)
    {
        $out = [];
        $results = scandir($path);
        foreach ($results as $result) {
            if ($result === '.' or $result === '..') continue;
            $filename = $result;
            // $filename = $path . '/' . $result;
            if (is_dir($filename)) {
                $out = array_merge($out, $this->getClasses($filename, $nameSpace));
            } else {
                $out[] = (isset($nameSpace) ? $nameSpace : '') . substr($filename, 0, -4);
            }
        }
        return $out;
    }
}
