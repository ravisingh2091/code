<?php 

namespace App\Repositories\Entities\v1\HealthCheck;

use App\Libraries\ConnectionChecker;
use Symfony\Component\HttpFoundation\Response;
use App\Repositories\Contracts\HealthCheck\HealthCheckInterface;

class HealthCheckRepository implements HealthCheckInterface
{
    public function __constructor() { }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return array
     */
    public function check() {
      
        // get db connection
        $db_connection = ConnectionChecker::isDatabaseReady();

        // get redis connection connection
        $redis_connection = ConnectionChecker::isRedisReady();

        return [
            'status' => $db_connection && $redis_connection ? 'healthy': 'unhealthy'
        ];
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @return array
     */
    public function checkAll() {
        // get db connection
        $db_connection = ConnectionChecker::isDatabaseReady();

        // get redis connection connection
        $redis_connection = ConnectionChecker::isRedisReady();

        return [
            'database' => $db_connection ? 'healthy': 'unhealthy',
            'redis' => $redis_connection ? 'healthy': 'unhealthy'
        ];
    }
}