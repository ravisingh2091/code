<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Service Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\v1\Service;

use Illuminate\Http\Request;
use App\Repositories\Models\ServiceOwner;
use App\Repositories\Models\ServiceBusiness;
use App\Repositories\Models\ServiceCollateral;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Contracts\Service\ServiceInterface;
use App\Repositories\Exceptions\ObjectNotLoadedException;
use App\Repositories\Transformer\ServiceOwnerTransformer;
use App\Repositories\Transformer\ServiceBusinessTransformer;
use App\Repositories\Transformer\ServiceCollateralTransformer;

/**
 * ServiceRepository class for handling Service operation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ServiceRepository extends ApiRepository implements ServiceInterface
{   
    //to call the current instance transformer
    protected $transformClass;

    /**
     * Service Business Model
     *
     * @var App\Repositories\Models\ServiceBusiness
     */
    protected $ServiceBusiness;

    /**
     * Service Owner Model
     *
     * @var App\Repositories\Models\ServiceOwner
     */
    protected $ServiceOwner;

    /**
     * Service Collateral Model
     *
     * @var App\Repositories\Models\ServiceCollateral
     */
    protected $ServiceCollateral;

    /**
     * @param App\Repositories\Model\ServiceOwner $ServiceOwner
     * @param App\Repositories\Model\ServiceBusiness $ServiceBusiness
     * @param App\Repositories\Model\ServiceCollateral $ServiceCollateral
     */
    public function __construct(ServiceOwner $ServiceOwner, ServiceBusiness $ServiceBusiness, ServiceCollateral $ServiceCollateral)
    {
        $this->ServiceOwner      = $ServiceOwner;
        $this->ServiceBusiness   = $ServiceBusiness;
        $this->ServiceCollateral = $ServiceCollateral;
    }

    /**
     * @param array $attributes
     *
     * @return string
     */
    public function saveServiceBusiness(array $attributes)
    {
       if(empty($attributes)) throw new BlankDataException();
        
       $ServiceBusiness = $this->ServiceBusiness->saveServiceIds($attributes);

       if (!$ServiceBusiness instanceof ServiceBusiness) throw new ObjectNotLoadedException();

       $this->transformClass = ServiceBusinessTransformer::class;

       return $ServiceBusiness;
    }

    /**
     * @param array $attributes
     *
     * @return string
     */
    public function saveServiceOwner(array $attributes)
    {
       if(empty($attributes)) throw new BlankDataException();
        
       $ServiceOwner = $this->ServiceOwner->saveServiceIds($attributes);

       if (!$ServiceOwner instanceof ServiceOwner) throw new ObjectNotLoadedException();
       
       $this->transformClass = ServiceOwnerTransformer::class;

       return $ServiceOwner;
    }

    /**
     * @param array $attributes
     *
     * @return string
     */
    public function saveServiceCollateral(array $attributes)
    {
       if(empty($attributes)) throw new BlankDataException();
        
       $ServiceCollateral = $this->ServiceCollateral->saveServiceIds($attributes);

       if (!$ServiceCollateral instanceof ServiceCollateral) throw new ObjectNotLoadedException();
       
       $this->transformClass = ServiceCollateralTransformer::class;

       return $ServiceCollateral;
    }

    /**
     * @param array $attributes
     *
     * @return string
     */
    public function getServiceBusiness(array $attributes)
    {
       if(empty($attributes)) throw new BlankDataException();
        
       $ServiceBusiness = $this->ServiceBusiness->getServiceIds($attributes);
        
       if (!$ServiceBusiness instanceof ServiceBusiness) return false;

       $this->transformClass = ServiceBusinessTransformer::class;

       return $ServiceBusiness;
    }

    /**
     * @param array $attributes
     *
     * @return string
     */
    public function getServiceOwner(array $attributes)
    {
       if(empty($attributes)) throw new BlankDataException();
        
       $ServiceOwner = $this->ServiceOwner->getServiceIds($attributes);
       
       $this->transformClass = ServiceOwnerTransformer::class;

       return $ServiceOwner;
    }

    /**
     * @param array $attributes
     *
     * @return string
     */
    public function getServiceCollateral(array $attributes)
    {
       if(empty($attributes)) throw new BlankDataException();
        
       $ServiceCollateral = $this->ServiceCollateral->getServiceIds($attributes);

       if (!$ServiceCollateral instanceof ServiceCollateral) return false;
       
       $this->transformClass = ServiceCollateralTransformer::class;

       return $ServiceCollateral;
    }

    /**
     * @param array $attributes
     *
     * @return string
     */
    public function getAllReferences(array $attributes)
    {
       if(empty($attributes)) throw new BlankDataException();
        
       $ServiceBusiness = $this->ServiceBusiness->getAllServiceIds($attributes);
        
       $this->transformClass = ServiceBusinessTransformer::class;

       return $ServiceBusiness;
    }

    /**
     * @param array $attributes
     *
     * @return string
     */
    public function getAllCollateralReferences(array $attributes)
    {
       if(empty($attributes)) throw new BlankDataException();
        
       $ServiceCollateral = $this->ServiceCollateral->getAllServiceIds($attributes);
        
       $this->transformClass = ServiceCollateralTransformer::class;

       return $ServiceCollateral;
    }

    /**
     * Get All collateral references for an app_id and user_id
     *
     * @param array $params
     * 
     * @return string
     */
    public function getAllServiceCollateral(array $params)
    {
       if(empty($params)) throw new BlankDataException();

       $ServiceCollateral = $this->ServiceCollateral->where($params)->get();

       if (!$ServiceCollateral) return false;
       
       $this->transformClass = ServiceCollateralTransformer::class;

       return $ServiceCollateral;
    }

    public function deleteBusinessByRefId(string $ref_id)
    {
       $this->ServiceBusiness->where(ServiceInterface::REF_ID, $ref_id)->delete();
    }

    /**
     * Get All owner references
     *
     * @param array $params
     * 
     * @return string
     */
    public function getAllServiceOwner(array $params)
    {
       if(empty($params)) throw new BlankDataException();

       $ServiceOwner = $this->ServiceOwner->where($params)->get();

       if (!$ServiceOwner) return false;
       
       $this->transformClass = ServiceOwnerTransformer::class;

       return $ServiceOwner;
    }

    /**
     * Get All business references
     *
     * @param array $params
     * 
     * @return string
     */
    public function getAllServiceBusiness(array $params)
    {
       if(empty($params)) throw new BlankDataException();

       $ServiceBusiness = $this->ServiceBusiness->where($params)->get();

       if (!$ServiceBusiness) return false;
       
       $this->transformClass = ServiceBusinessTransformer::class;

       return $ServiceBusiness;
    }

    /**
     * Delete Owner reference
     *
     * @param string $ref_id
     * 
     * @return string
     */
    public function deleteOwnerRefId(string $ref_id)
    {
       $this->ServiceOwner->where(ServiceInterface::REF_ID, $ref_id)->delete();
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return $this->transformClass;
    }

     /**
    * Filter service business/owner
    * 
    * @param Request $Request 
    *
    * @return array
    */
    public function filterReferences(Request $Request, $serviceModel)
    {
         $total_apps_query = $serviceModel->raw(function ($collection) use ($Request) {
         
         $QueryConditions = [];
         $conditions = [];
 
         if ($Request->filled(config('fields.v1.from_date')) && $Request->filled(config('fields.v1.to_date'))) {
             $conditions[] = [
                config('fields.v1.created_at') => ['$gte' => (int) $Request->{config('fields.v1.from_date')}],
             ];
             $conditions[] = [
                config('fields.v1.created_at') => ['$lte' => (int) $Request->{config('fields.v1.to_date')}]
             ];
         }
 
 
         if($Request->filled(ServiceInterface::TYPE)) {
             $conditions[] = [
                 ServiceInterface::TYPE => $Request->get(ServiceInterface::TYPE)
             ];
         }
 
         if($Request->filled(ServiceInterface::APP_ID)) {
             $conditions[] = [
                 ServiceInterface::APP_ID => $Request->get(ServiceInterface::APP_ID)
             ];
         }
 
         if($Request->filled(ServiceInterface::USER_ID)) {
             $conditions[] = [
                 ServiceInterface::USER_ID => $Request->get(ServiceInterface::USER_ID)
             ];
         }
 
         if(count($conditions)) {
             $QueryConditions[] =  [
                 '$match' => ['$and' => $conditions]
            ];
         }
 
         $per_page = ServiceInterface::LIMIT;
         $start = ServiceInterface::OFFSET;
 
         if($Request->filled(ServiceInterface::PER_PAGE)) {
            $per_page = $Request->get(ServiceInterface::PER_PAGE);
         }
         
         if($Request->filled(ServiceInterface::START)) {
            $start = $Request->get(ServiceInterface::START);
         }

         $QueryConditions[] = [
            '$limit' => $per_page
        ];

         $QueryConditions[] = [
            '$skip' => $start
        ];
 
         return $collection->aggregate($QueryConditions);
          
       })->toArray();
 
       return $total_apps_query;
    }
}