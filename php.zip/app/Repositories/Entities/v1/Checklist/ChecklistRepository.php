<?php 
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Checklist Repository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\v1\Checklist;

use Illuminate\Http\Request;
use App\Repositories\Models\Checklist;
use App\Repositories\Contracts\Api\ApiInterface;
use App\Repositories\Entities\Api\ApiRepository;
use App\Repositories\Exceptions\BlankDataException;
use App\Repositories\Exceptions\ObjectNotLoadedException;
use App\Repositories\Transformer\ChecklistTransformer;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use App\Repositories\Contracts\Checklist\ChecklistInterface;

/**
 * ChecklistRepository class for handling Checklist operation.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ChecklistRepository extends ApiRepository implements ChecklistInterface
{
    /**
     * Checklist Model
     *
     * @var App\Repositories\Models\Checklist
     */
    protected $Checklist;

    /**
     * @param App\Repositories\Model\Checklist $Checklist
     */
    public function __construct(Checklist $Checklist)
    {
        $this->Checklist = $Checklist;
    }

    public function create(array $attributes)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Checklist = $this->Checklist->saveChecklist($attributes);

        if(!$Checklist instanceof Checklist) throw new ObjectNotLoadedException();

        return $Checklist;
    }

    /**
     * Create Checklists
     *
     * @param array $attributes
     * 
     * @return string
     */
    public function createChecklist(array $attributes)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Checklist = $this->Checklist->create($attributes);

        if(!$Checklist instanceof Checklist) throw new ObjectNotLoadedException();

        return $Checklist;
    }

    /**
     * Get checklist
     *
     * @param string $id
     * 
     * @return string
     */
    public function get(array $params)
    {
        if(empty($params)) throw new BlankDataException();

        $Checklist = $this->Checklist->where($params)->first();
        
        return $Checklist instanceof Checklist ? $Checklist : false;
    }

    /**
     * Get all checklists
     *
     * @param array $app_ids
     * 
     * @return string
     */
    public function getAll(array $app_ids)
    {
        if(empty($app_ids)) throw new BlankDataException();

        $Checklist = $this->Checklist->whereIn(Checklist::APP_ID, $app_ids)->orderby(Checklist::ID, -1)->get();
        
        return $Checklist ? $Checklist : false;
    }

    /**
     * Update Checklist
     *
     * @param array $attributes
     * @param string $id
     * 
     * @return string
     */
    public function update(array $attributes, string $id)
    {
        if(empty($attributes)) throw new BlankDataException();

        $Checklist = $this->Checklist->where(Checklist::ID, $id)->first();

        if (!$Checklist instanceof Checklist) return false;

        $Checklist->update($attributes);

        return $Checklist;
    }

    /**
     * This method provides the resource name of the resource.
     * 
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getResourceName()
    {
        return self::RESOURCE_NAME;
    }

    /**
     * This method returns the classname from which we are transforming our response.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     * 
     * @return string
     */
    public function getTransformClass()
    {
        return ChecklistTransformer::class;
    }
}