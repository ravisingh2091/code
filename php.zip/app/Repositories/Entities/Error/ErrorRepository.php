<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   ErroRepository Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Entities\Error;

use Validator;
use ReflectionClass;
use Illuminate\Support\Facades\Event;
use App\Repositories\Events\AuditRequestResponseEvent;

/** 
 * The ErrorRepository class is responsible to respond all Error.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ErrorRepository
{
    const FIELD_REQUIRED                = 400;
    const FIELD_INVALID                 = 400;
    const FIELD_EMPTY                   = 400;
    const REQUEST_FIELDS_EMPTY          = 400;
    const RESOURCE_NOT_FOUND            = 404;
    const ACTION_FAILED                 = 500;
    const AUTHENTICATION_FAILED         = 401;
    const AUTHORIZATION_REQUIRED        = 401;
    const DELETION_FAILED               = 500;
    const SERVICE_UNAVAILABLE           = 503;
    const FIELD_DUPLICATE               = 400;
    const FORMAT_NOT_ACCEPTABLE         = 406;
    const HTTPS_REQUIRED                = 400;
    const METHOD_NOT_SUPPORTED          = 405;
    const RATE_LIMIT_REACHED            = 429;
    const URL_VERSION_MISSING           = 400;
    const VERSION_NOT_SUPPORTED         = 426;
    const TOKEN_EXPIRED                 = 401;
    const CONSENT_RECEIVED              = 400;
    const BAD_REQUEST                   = 400;
    const CONSENT_PENDING               = 400;
    
    /**
     * List of status codes.
     *
     * @var array
     */
    public static $statusCodes = [
        'FIELD_REQUIRED'         => 'This action requires the field to be specified',
        'FIELD_INVALID'          => 'The value of the field is invalid',
        'FIELD_EMPTY'            => 'The value of the field cannot be empty',
        'REQUEST_FIELDS_EMPTY'   => 'This action requires resource parameters (i.e., resource fields) to be specified',
        'RESOURCE_NOT_FOUND'     => 'Resource does not exist or has been removed',
        'ACTION_FAILED'          => 'The server failed to perform this action for unknown internal reason',
        'AUTHENTICATION_FAILED'  => 'Used authentication credentials are invalid',
        'AUTHORIZATION_REQUIRED' => 'Performing this action on this resource requires authorization',
        'DELETION_FAILED'        => 'The resource could not be deleted',
        'FIELD_DUPLICATE'        => 'The value of the field is already used for another resource',
        'FORMAT_NOT_ACCEPTABLE'  => 'Server is not capable of returning the requested format (only JSON is supported)',
        'HTTPS_REQUIRED'         => 'Sensitive information is to be sent - server requires HTTPS',
        'METHOD_NOT_SUPPORTED'   => 'HTTP method is not supported or is not allowed for the resource',
        'RATE_LIMIT_REACHED'     => 'The rate limit for this action was reached',
        'URL_VERSION_MISSING'    => 'Base URL must include REST API version',
        'VERSION_NOT_SUPPORTED'  => 'REST API version not supported by the app',
        'TOKEN_EXPIRED'          => 'The token provided has been expired.',
        'CONSENT_RECEIVED'       => 'The resource has already received the required action.',
        'BAD_REQUEST'            => 'This was a malformed request.',
        'CONSENT_PENDING'        => 'The resource has not yet received the required action.',
        'SERVICE_UNAVAILABLE'    => 'The server is currently unable to handle the request.'
    ];

    /**
     * The getClassConstantName method is providing errorCodeName using errorCode.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param int $code
     *
     * @return string
     */
    private function getErrorCode($constrant)
    {
        $ErrorClass = new ReflectionClass(__CLASS__);
        $constants = $ErrorClass->getConstants();
        $code = 500;
        foreach ($constants as $name => $value) {
            if ($name == $constrant) {
                $code = $value;
                break;
            }
        }

        return $code;
    }

    /**
     * The errorMessage method is using to create error response structure.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param int $code
     * @param array $errors (OPTIONAL)
     *
     * @return string
     */
    public function errorMessage(string $constrant, $errors = [])
    {
        $response = [
            'status' => trans('messages.v1.failed')
        ];
        $error_all=[];
        
        if (array_key_exists($constrant, self::$statusCodes)) {
            $response['code'] =  $this->getErrorCode($constrant);
        }

        if (is_array($errors) && !empty($errors)) {
            foreach ($errors as $error) {
                $error_all = array_merge($error_all, $error);
            }
            $response['errors'] = $error_all;
        } else {
            $error_all[]         = ['type' => $constrant, 'message' => self::$statusCodes[$constrant]];
            $response ['errors'] = $error_all;
        }

        // Event::fire(new AuditRequestResponseEvent($response));
        return response()->json($response, $this->getErrorCode($constrant));
    }

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param string $key
     * @param array $message
     *
     * @return array
     */
    public function getValidationError(string $key, array $message, string $errorCode = null) 
    {
        $validator = Validator::make([], []); // Empty data and rules fields
        $validator->errors()->add($key, $message);
        return $errorCode ? $this->errorMessage($errorCode, [$message]) : $validator->errors();
    }
}
