<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Exception Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Exceptions;

use RuntimeException;

/** 
 * Http unprocessable entity exception definition.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class ObjectNotLoadedException extends RuntimeException
{
    
}
