<?php
/**
 * Laravel Framework Lumen (5.7.1) (Laravel Components 5.7.*)
 *
 * @category   Exception Class
 * @package    Lumen
 * @copyright  ©Biz2Credit.com 2018. All rights reserved.
 */

namespace App\Repositories\Exceptions;

use Exception;
use Illuminate\Auth\AuthenticationException;
use App\Repositories\Exception\BlankDataException;
use Illuminate\Auth\Access\AuthorizationException;
use App\Repositories\Entities\Error\ErrorRepository;
use Illuminate\Http\Exceptions\HttpResponseException;
use App\Repositories\Exception\ObjectNotLoadedException;
use Laravel\Lumen\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\HttpKernel\Exception\HttpException;
use App\Repositories\Exceptions\ResourceConflictException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;

/**
 * Custom repository exception handler.
 *
 * @author Amit kishore <amit.kishore@biz2credit.com>
 */
class CustomHandler extends ExceptionHandler
{
    /**
     * @var App\Repositories\Entities\Error\ErrorRepository
     */
    protected $ErrorRepository;

    /**
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param App\Repositories\Entities\Error\ErrorRepository $Error
     */
    public function __construct(ErrorRepository $Error)
    {
        $this->ErrorRepository = $Error;
    }

    /**
     * A list of the exception types that should not be reported.
     *
     * @var array
     */
    protected $dontReport = [
        \Symfony\Component\HttpKernel\Exception\HttpException::class,
        \Illuminate\Database\Eloquent\ModelNotFoundException::class,
        \Illuminate\Validation\ValidationException::class,
    ];

    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @param  \Exception  $exception
     * @return void
     */
    public function report(Exception $exception)
    {
        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     * @author Amit kishore <amit.kishore@biz2credit.com>
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Exception  $Exception
     *
     * @return App\Repositories\Entities\Error\ErrorRepository
     */
    public function render($request, Exception $Exception)
    {
        $status = 'ACTION_FAILED';
        if ($Exception instanceof HttpResponseException) {
            $status = 'ACTION_FAILED';
        } elseif ($Exception instanceof MethodNotAllowedHttpException) {
            $status = 'METHOD_NOT_SUPPORTED';
            $Exception = new MethodNotAllowedHttpException([], 'METHOD_NOT_SUPPORTED', $Exception);
        } elseif ($Exception instanceof NotFoundHttpException) {
            $status = 'RESOURCE_NOT_FOUND';
            $Exception = new NotFoundHttpException('RESOURCE_NOT_FOUND', $Exception);
        } elseif ($Exception instanceof AuthorizationException) {
            $status = 'AUTHORIZATION_REQUIRED';
            $Exception = new AuthorizationException('AUTHORIZATION_REQUIRED', $status);
        } elseif ($Exception instanceof \Dotenv\Exception\ValidationException && $Exception->getResponse()) {
            $status = 'REQUEST_FIELDS_EMPTY';
            $Exception = new \Dotenv\Exception\ValidationException('REQUEST_FIELDS_EMPTY', $status, $Exception);
        } elseif ($Exception instanceof BlankDataException) {
            $Exception = new BlankDataException($status, $Exception);
        } elseif ($Exception instanceof ObjectNotLoadedException) {
            $Exception = new ObjectNotLoadedException($status, $Exception);
        } elseif ($Exception instanceof ResourceConflictException) {
            $status = 'FIELD_DUPLICATE';
        } elseif ($Exception) {
            $code = $this->ErrorRepository::ACTION_FAILED;
            $Exception = new HttpException($code, $status);
        }

        return $this->ErrorRepository->errorMessage($status);
    }
}
