$(document).ready(function() {
    $(document).on("click", ".button", function () {
        var clickedButton = $(this);
        this.remove();
        $('.button-wrap').append(clickedButton);
            $('.button-wrap').height(
            $('.one h3').innerHeight() + $('.two h3').innerHeight() + $('.three h3').innerHeight() + $('.four h3').innerHeight() + $('.five h3').innerHeight()   + $('.six h3').innerHeight()   + $('.seven h3').innerHeight()   + $('.eight h3').innerHeight()   + $('.nine h3').innerHeight()   + $('.ten h3').innerHeight() + $('.button-wrap .button:last-child()').height()        
        );
    });
});

  $(document).ready(function(e){
     $('.button-wrap').height(
        $('.one h3').innerHeight() + $('.two h3').innerHeight() + $('.three h3').innerHeight() + $('.four h3').innerHeight() + $('.five h3').innerHeight()   + $('.six h3').innerHeight()   + $('.seven h3').innerHeight()   + $('.eight h3').innerHeight()   + $('.nine h3').innerHeight()   + $('.ten h3').innerHeight() + $('.button-wrap .button:last-child()').height()       
     );
  });

  document.body.addEventListener('mousedown', function() {
    document.body.classList.add('using-mouse');
  });
  
  document.body.addEventListener('keydown', function() {
    if(event.keyCode == '9'){
        document.body.classList.remove('using-mouse');
    }    
  });