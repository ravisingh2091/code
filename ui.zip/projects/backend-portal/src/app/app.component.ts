import { Component } from '@angular/core';
import { ToasterConfig } from 'angular2-toaster';

import { ApplicationService } from '@shared/services/application.service';
import { ServiceProvidorService } from './shared/services/service-providor.service';
import { SLUG } from '@shared/constants/slug';
import { AppStateFacade } from './+state/app.facade';
import { storeMasterData } from './utils/+state/utils.action'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(
    private api: ApplicationService,
    private appFacade: AppStateFacade,
    private servProvider:ServiceProvidorService) { }
  config: ToasterConfig =
    new ToasterConfig({
      timeout: 7000,
      limit: 1
    });

    ngOnInit(): void {

      this.servProvider.setproviderData();
      this.api.getTaskInfo({slug: SLUG.storeMasterData}).subscribe((res) => {
        this.appFacade.dispatch(storeMasterData({ masterData: res.response_data }))
      })
    }
}
