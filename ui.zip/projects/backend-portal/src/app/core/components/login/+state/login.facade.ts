import { Injectable } from '@angular/core';

import { select, Store, Action } from '@ngrx/store';

import * as fromLogin from './login.reducer';
import * as LoginSelectors from './login.selector';

@Injectable()
export class LoginFacade {
  loaded$ = this.store.pipe(select(LoginSelectors.getLoginLoaded));
  allLoginState$ = this.store.pipe(select(LoginSelectors.getAllLogin));
  submitLoginState$ = this.store.pipe(select(LoginSelectors.getLoginResponseState));
  constructor(private store: Store<fromLogin.LoginPartialState>) {}

  dispatch(action: Action) {
    this.store.dispatch(action);
  }
}
