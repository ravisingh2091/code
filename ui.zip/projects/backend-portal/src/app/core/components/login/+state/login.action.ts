import { createAction, props } from '@ngrx/store';

export const loadLogin = createAction('[Login] Load Login',
  props<{ slug: string }>()
);

export const loadLoginSuccess = createAction(
  '[Login] Load Login Success',
  props<{ login: any }>()
);

export const formSubmit = createAction(
  '[Login] form submitted',
  props<{ payload: any }>()
);

export const formSubmitCompleted = createAction(
  '[Login] form submit completed',
  props<{ login: any }>()
);

export const loadLoginFailure = createAction(
  '[Login] Load Login Failure',
  props<{ error: any }>()
);

// export const addUserData = createAction(
//   '[Login] form submitted',
//   props<{ userData: any }>()
// );
