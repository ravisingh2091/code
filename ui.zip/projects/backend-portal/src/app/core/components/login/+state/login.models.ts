/**
 * Interface for the 'Login' data
 */
export interface LoginEntity {
  loaded: boolean; // has the api been loaded
  error?: any; // last none error (if any)
  loading?: boolean;
  taskInfo?: any;
  response?: any;
}
 