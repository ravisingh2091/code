import { createFeatureSelector, createSelector, State } from '@ngrx/store';
import {
  LOGIN_FEATURE_KEY
} from './login.reducer';
import { LoginEntity } from './login.models';

// Lookup the 'Login' feature state managed by NgRx
export const getLoginState = createFeatureSelector<LoginEntity>(
  LOGIN_FEATURE_KEY
);

export const getLoginLoaded = createSelector(
  getLoginState,
  (state: LoginEntity) => state.loaded
);

export const getLoginError = createSelector(
  getLoginState,
  (state: LoginEntity) => state.error
);

export const getAllLogin = createSelector(getLoginState,
  getLoginState,
  getLoginLoaded,
  (state: LoginEntity, isloaded) => (!state.response && isloaded) ? state.taskInfo : null

);

export const getLoginResponseState = createSelector(
  getLoginState,
  getLoginLoaded,
  (state: LoginEntity) => state.response
);
