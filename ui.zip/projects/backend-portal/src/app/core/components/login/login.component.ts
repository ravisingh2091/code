import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { CommonService } from '@shared/services/common.service';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { LoginFacade } from './+state/login.facade';
import * as loginActions from './+state/login.action';
import { addBackendUserDetails } from '@utils/+state/utils.action';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {

  loginForm: FormGroup;
  loginConfig: FormFieldInterface[] = [];
  slug: string;
  rememberMeChecked = false;
  loginSubscription: Subscription;
  submitloginSubscription: Subscription;

  constructor(
    private loginFacade: LoginFacade, private formGenerate: FormGenerateService,
    private common: CommonService) {
    this.loginFacade.dispatch(loginActions.loadLogin({ slug: 'backend-login' }));
  }

  ngOnInit(): void {
    this.common.loginEmit = false;
    this.loginSubscription = this.loginFacade.allLoginState$
      .subscribe((login: any) => {
        if (login) {
          this.slug = login.task_slug;
          this.loginConfig = login.form_fields;
          this.loginForm = this.formGenerate.createControl(this.loginConfig);
        }
      });

    this.submitloginSubscription = this.loginFacade.submitLoginState$
      .subscribe((login: any) => {
        if (login) {
          if (login.signin) {
            this.loginFacade.dispatch(addBackendUserDetails({ userData: { ...login.signin.data.data } }));
            this.common.navigate(login.nextTask.value);
          }
        }
      });
  }

  toForgot = (): void => {
    this.common.navigate('forgot-password');
  }

  onLogIn = (): void => {
    if (!this.loginForm.invalid) {
      this.loginFacade.dispatch(loginActions.formSubmit({ payload: { slug: this.slug, ...this.loginForm.value } }));
    } else {
      this.formGenerate.validateAllFormFields(this.loginForm);
    }
  }

  ngOnDestroy() {
    this.loginSubscription.unsubscribe();
    this.submitloginSubscription.unsubscribe();
  }


}
