import { Injectable, Inject } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { fetch } from '@nrwl/angular';
import { map } from 'rxjs/operators';
import * as LoginActions from './login.action';
import { ApplicationService } from '@shared/services/application.service';

@Injectable()
export class LoginEffects {
  loadLogin$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(LoginActions.loadLogin),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        run: action => {
          return this.applicationService.getTaskInfo({
            slug: action.slug
          }).pipe(
            map((data: any) => {
              return LoginActions.loadLoginSuccess({ login: data });
            })
          );
        },
        onError: (action, error) => {
          console.error('Error', error);
          return LoginActions.loadLoginFailure({ error });
        }
      })
    );
  });

  formSubmit$ = createEffect(() =>
    this.actions$.pipe(
      ofType(LoginActions.formSubmit),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        run: action => {
          const headers = {
            Authorization: 'Basic ' + btoa(`${action.payload.email_address}:${action.payload.password}`)
          };
          return this.applicationService.saveTaskInfo(null, {
            slug: action.payload.slug
          }, headers).pipe(
            map((data: any) => {
              return LoginActions.formSubmitCompleted({ login: data });
            })
          );

          // Your custom service 'load' logic goes here. For now just return a success action...
        },
        onError: (action, error) => {
          console.error('Error', error);
          return LoginActions.loadLoginFailure({ error });
        }
      })
    )
  );

  constructor(
    private actions$: Actions,
    private applicationService: ApplicationService
  ) { }
}
