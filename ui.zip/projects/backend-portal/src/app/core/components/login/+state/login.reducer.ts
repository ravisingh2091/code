import { createReducer, on, Action } from '@ngrx/store';
import * as LoginActions from './login.action';
import { LoginEntity } from './login.models';

export const LOGIN_FEATURE_KEY = 'login';

export interface LoginPartialState {
  readonly [LOGIN_FEATURE_KEY]: LoginEntity;
}

export const initialState: LoginEntity = {
  // set initial required properties
  loaded: false,
  taskInfo: undefined,
  loading: false
};

const loginReducer = createReducer(
  initialState,
  on(LoginActions.loadLogin, state => ({
    ...state,
    response: null,
    loading: true
  })),
  on(LoginActions.loadLoginSuccess, (state, { login }) => ({
    ...state,
    loaded: true,
    response: null,
    taskInfo: login
  })),
  on(LoginActions.formSubmit, (state) => ({
    ...state,
    loaded: false,
    loading: true
  })),
  on(LoginActions.formSubmitCompleted, (state, { login }) => ({
    ...state,
    loaded: true,
    loading: false,
    response: login
  })),
  on(LoginActions.loadLoginFailure, (state, { error }) => ({ ...state, error }))
);

export function reducer(state: LoginEntity | undefined, action: Action) {
  return loginReducer(state, action);
}
