import { createReducer, on, Action } from '@ngrx/store';

import * as ResetPasswordActions from './reset-password.action';
import { ResetPasswordEntity } from './reset-password.models';

export const RESETPASSWORD_FEATURE_KEY = 'resetPassword';

export interface ResetPasswordPartialState {
  readonly [RESETPASSWORD_FEATURE_KEY]: ResetPasswordEntity;
}


export const initialState: ResetPasswordEntity = {
  // set initial required properties
  loaded: false,
  taskInfo: undefined,
  loading: false
};

const resetPasswordReducer = createReducer(
  initialState,
  on(ResetPasswordActions.loadResetPassword, state => ({
    ...state,
    loaded: false,
    error: null
  })),
  on(
    ResetPasswordActions.loadResetPasswordSuccess, (state, { resetPassword }) => ({
      ...state,
      loaded: true,
      response: null,
      taskInfo: resetPassword
    })
  ),
  on(
    ResetPasswordActions.ResetPasswordSubmit, (state, { formData }) => ({
      ...state,
      loaded: false,
      loading: true,
      formData: formData
    })
  ),
  on(
    ResetPasswordActions.ResetPasswordComplete, (state, { resetPassword }) => ({
      ...state,
      loaded: true,
      response: resetPassword
    })
  ),
  on(
    ResetPasswordActions.ResetPasswordResponse, (state) => ({
      ...state,
      loaded: false,
      response: undefined
    })
  ),
  on(ResetPasswordActions.loadResetPasswordFailure, (state, { error }) => ({
    ...state,
    error
  }))
);

export function reducer(state: ResetPasswordEntity | undefined, action: Action) {
  return resetPasswordReducer(state, action);
}
