import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { fetch } from '@nrwl/angular';
import { map } from 'rxjs/operators';
import * as ResetPasswordActions from './reset-password.action';
import { ApplicationService } from '../../../../shared/services/application.service';

@Injectable()
export class ResetPasswordEffects {

  constructor(
    private actions$: Actions,
    private applicationService: ApplicationService
  ) { }

  loadResetPassword$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ResetPasswordActions.loadResetPassword),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        run: action => {
          return this.applicationService.getTaskInfo({
            slug: action.slug, hash: action.hash
          }).pipe(
            map((data: any) => {
          // Your custom service 'load' logic goes here. For now just return a success action...
          return ResetPasswordActions.loadResetPasswordSuccess({ resetPassword : data });
        }))
      },

        onError: (action, error) => {
          console.error('Error', error);
          return ResetPasswordActions.loadResetPasswordFailure({ error });
        }
      })
    )
  );

  submitResetPassword$ = createEffect(() =>
  this.actions$.pipe(
    ofType(ResetPasswordActions.ResetPasswordSubmit),
    fetch({
      id: () => {
        return (new Date()).getTime().toString();
      },
      run: action => {
        return this.applicationService.saveTaskInfo(
          {token: action.formData.token, email_address: action.formData.email_address, password: action.formData.password},
          { slug: action.slug},
          null).pipe(
          map((data: any) => {
            return ResetPasswordActions.ResetPasswordComplete({ resetPassword: data });
          })
        );
        // Your custom service 'load' logic goes here. For now just return a success action...
      },
      onError: (action, error) => {
        console.error('Error', error);
        return ResetPasswordActions.loadResetPasswordFailure({ error });
      }
    })
  )
);
}
