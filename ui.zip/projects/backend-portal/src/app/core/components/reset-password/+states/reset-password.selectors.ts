import { createFeatureSelector, createSelector, State } from '@ngrx/store';
import {
  RESETPASSWORD_FEATURE_KEY,
  ResetPasswordPartialState,
} from './reset-password.reducer';
import { ResetPasswordEntity } from './reset-password.models';

// Lookup the 'ResetPassword' feature state managed by NgRx
export const getResetPasswordState = createFeatureSelector<ResetPasswordEntity>(RESETPASSWORD_FEATURE_KEY);


export const getResetPasswordLoaded = createSelector(
  getResetPasswordState,
  (state: ResetPasswordEntity) => state.loaded
);

export const getResetCheckHash = createSelector(
  getResetPasswordState,
  (state: ResetPasswordEntity,getResetPasswordLoaded) => (getResetPasswordLoaded && !state.response) ? state.taskInfo : null
);

export const getResetPasswordError = createSelector(
  getResetPasswordState,
  (state: ResetPasswordEntity) => state.error
);

export const getAllResetPassword = createSelector(
  getResetPasswordState,
  getResetPasswordLoaded,
  (state: ResetPasswordEntity,getResetPasswordLoaded) => (getResetPasswordLoaded && !state.response) ? state.taskInfo : null
  );

export const getSubmittedPassword = createSelector(
    getResetPasswordState,
    getResetPasswordLoaded,
    (state: ResetPasswordEntity,getResetPasswordLoaded) => (getResetPasswordLoaded && !state.response) ? state.taskInfo : null
    );

export const getResetPasswordResponse = createSelector(
  getResetPasswordState,
  (state: ResetPasswordEntity) => state.response ? state.response : null
);
