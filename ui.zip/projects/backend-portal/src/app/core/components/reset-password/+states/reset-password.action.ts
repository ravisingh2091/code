import { createAction, props } from '@ngrx/store';
import { ResetPasswordEntity } from './reset-password.models';

export const loadResetPassword = createAction(
  '[ResetPassword] Load ResetPassword',
  props<{ slug: String, hash: String }>()
);

export const loadResetPasswordSuccess = createAction(
  '[ResetPassword] Load ResetPassword Success',

  props<{ resetPassword: any }>()
);

export const loadResetPasswordFailure = createAction(
  '[ResetPassword] Load ResetPassword Failure',
  props<{ error: any }>()
);

export const ResetPasswordSubmit = createAction(
  '[ResetPassword] ResetPassword Submit',
  props<{ slug: String, formData: any }>()
);

export const ResetPasswordComplete = createAction(
  '[ResetPassword] ResetPassword Complete',
  props<{ resetPassword: any }>()
);

export const ResetPasswordResponse = createAction(
  '[ResetPassword] Reset ResetPassword Response',
  props<{  } | any>() //@TODO
);

