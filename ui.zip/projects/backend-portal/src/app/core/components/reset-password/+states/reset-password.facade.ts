import { Injectable } from '@angular/core';

import { select, Store, Action } from '@ngrx/store';

import * as fromResetPassword from './reset-password.reducer';
import * as ResetPasswordSelectors from './reset-password.selectors';

@Injectable()
export class ResetPasswordFacade {
  loaded$ = this.store.pipe(
    select(ResetPasswordSelectors.getResetPasswordLoaded)
  );
  allResetPassword$ = this.store.pipe(
    select(ResetPasswordSelectors.getAllResetPassword)
  );
  submitPassword$ = this.store.pipe(
    select(ResetPasswordSelectors.getSubmittedPassword)
  );

  constructor(
    private store: Store<fromResetPassword.ResetPasswordPartialState>
  ) {}

  dispatch(action: Action) {
    this.store.dispatch(action);
  }
}
