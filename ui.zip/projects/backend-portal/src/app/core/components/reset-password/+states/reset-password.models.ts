/**
 * Interface for the 'ForgotPassword' data
 */
export interface ResetPasswordEntity {
  loaded: boolean; // has the api been loaded
  error?: any; // last none error (if any)
  loading?: boolean;
  taskInfo?: any;
  response?: any;
}
