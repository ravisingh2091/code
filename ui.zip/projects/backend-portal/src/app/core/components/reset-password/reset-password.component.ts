import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { ResetPasswordFacade } from './+states/reset-password.facade';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { CommonService } from '@shared/services/common.service';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Store } from '@ngrx/store';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { ResetPasswordSubmit, loadResetPassword } from './+states/reset-password.action';
import { SLUG } from '../../../shared/constants/slug';
import { ApplicationService } from '@shared/services/application.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  resetPasswordForm: FormGroup;
  resetPasswordConfig: FormFieldInterface[] = [];
  resetPasswordSubscription: Subscription;
  resetPasswordSubmitSubscription: Subscription;
  resetCheckHashSubsciption: Subscription;
  slug: string;
  email: string;
  hash: string;
  constructor(
    private resetPasswordFacade: ResetPasswordFacade,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private common: CommonService,
    private api: ApplicationService,
    private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.resetPasswordSubscription = this.resetPasswordFacade.allResetPassword$
      .subscribe((resetState: any) => {
        if (resetState) {
          this.slug = resetState.task_slug;
          this.email = resetState.response_data.check_hash.data.data.email_address;
          this.resetPasswordConfig = resetState.form_fields;
          this.resetPasswordForm = this.formGenerate.createControl(this.resetPasswordConfig);
        }
      });

    // this.resetPasswordSubmitSubscription = this.resetPasswordFacade.submitPassword$
    //   .subscribe(response => {
    //     if (response?.check_hash?.) {
    //       this.common.navigate('backend-login');
    //     }
    //   });
    this.route.params.forEach((params: Params) => {
      this.hash = params.id;
      this.resetPasswordFacade.dispatch(loadResetPassword({ slug: SLUG.resetPassword, hash: this.hash }));
    });
  }

  backToLogin(): void {
    this.common.navigate('backend-login');
  }

  onSubmit(): void {
    if (!this.resetPasswordForm.invalid) {
      this.resetPasswordForm.value.token = this.hash;
      this.resetPasswordForm.value.email_address = this.email;
      this.resetPasswordForm.value.password = this.resetPasswordForm.value.new_password;
      const data = { ...this.resetPasswordForm.value };
      // this.resetPasswordFacade.dispatch(ResetPasswordSubmit({ slug: SLUG.resetPassword, formData: data }));
      this.api.saveTaskInfo(
        {token: data.token, email_address: data.email_address, password: data.password},
        { slug: SLUG.resetPassword},
        null).subscribe((res)=>{
          if(res){
            this.common.navigate('backend-login');
          }
        })
    } else {
      this.formGenerate.validateAllFormFields(this.resetPasswordForm);
    }

  }

}
