import { createFeatureSelector, createSelector, State } from '@ngrx/store';
import {
  FORGOTPASSWORD_FEATURE_KEY,
  ForgotPasswordPartialState,
} from './forget-password.reducer';
import { ForgotPasswordEntity } from './forget-password.models';

// Lookup the 'ForgotPassword' feature state managed by NgRx
export const getForgotPasswordState = createFeatureSelector<ForgotPasswordEntity>(FORGOTPASSWORD_FEATURE_KEY);


export const getForgotPasswordLoaded = createSelector(
  getForgotPasswordState,
  (state: ForgotPasswordEntity) => state.loaded
);

export const getForgotPasswordError = createSelector(
  getForgotPasswordState,
  (state: ForgotPasswordEntity) => state.error
);

export const getAllForgotPassword = createSelector(
  getForgotPasswordState,
  getForgotPasswordLoaded,
  (state: ForgotPasswordEntity,getForgotPasswordLoaded) => (getForgotPasswordLoaded && !state.response) ? state.taskInfo : null
  );

export const getForgotPasswordResponse = createSelector(
  getForgotPasswordState,
  (state: ForgotPasswordEntity) => state.response ? state.response : null
);
