import { Injectable } from '@angular/core';

import { select, Store, Action } from '@ngrx/store';

import * as fromForgotPassword from './forget-password.reducer';
import * as ForgotPasswordSelectors from './forget-password.selectors';

@Injectable()
export class ForgotPasswordFacade {
  loaded$ = this.store.pipe(
    select(ForgotPasswordSelectors.getForgotPasswordLoaded)
  );
  allForgotPassword$ = this.store.pipe(
    select(ForgotPasswordSelectors.getAllForgotPassword)
  );

  forgotPasswordResposne$ = this.store.pipe(select(ForgotPasswordSelectors.getForgotPasswordResponse));
  constructor(
    private store: Store<fromForgotPassword.ForgotPasswordPartialState>
  ) { }

  dispatch = (action: Action): void => {
    this.store.dispatch(action);
  }
}
