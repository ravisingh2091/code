import { Component, OnInit } from '@angular/core';
import { ForgotPasswordFacade } from './+state/forget-password.facade';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { CommonService } from '@shared/services/common.service';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Store } from '@ngrx/store';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { ForgotPasswordSubmit, ResetForgotPasswordResponse, loadForgotPassword } from './+state/forget-password.actions';
import { SLUG } from '@shared/constants/slug';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {

  forgotPasswordForm: FormGroup;
  forgotPasswordConfig: FormFieldInterface[] = [];
  forgotPasswordSubscription: Subscription;
  forgotPasswordResponseSubscription: Subscription;
  slug: string;

  constructor(
    private forgotPasswordFacade: ForgotPasswordFacade,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private common: CommonService) {
    this.forgotPasswordFacade.dispatch(loadForgotPassword({ slug: SLUG.forgotPassword }));
  }

  ngOnInit(): void {
    this.forgotPasswordSubscription = this.forgotPasswordFacade.allForgotPassword$
      .subscribe((forgotState: any) => {
        if (forgotState) {
          this.slug = forgotState.task_slug;
          this.forgotPasswordConfig = forgotState.form_fields;
          this.forgotPasswordForm = this.formGenerate.createControl(this.forgotPasswordConfig);
        }
      });

    this.forgotPasswordResponseSubscription = this.forgotPasswordFacade.forgotPasswordResposne$
      .subscribe(forgotState => {
        if (forgotState) {
          this.common.navigate('backend-login');
          // this.forgotPasswordFacade.dispatch(ResetForgotPasswordResponse({} | any));
        }
      });
  }

  backToLogin = (): void => {
    this.common.navigate('backend-login');
  }

  onSubmit = (): void => {
    if (!this.forgotPasswordForm.invalid) {
      this.forgotPasswordFacade.dispatch(ForgotPasswordSubmit({ slug: this.slug, formData: this.forgotPasswordForm.value }));
    } else {
      this.formGenerate.validateAllFormFields(this.forgotPasswordForm);
    }
  }

}
