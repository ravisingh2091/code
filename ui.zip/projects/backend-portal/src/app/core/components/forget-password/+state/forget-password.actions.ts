import { createAction, props } from '@ngrx/store';
import { ForgotPasswordEntity } from './forget-password.models';

export const loadForgotPassword = createAction(
  '[ForgotPassword] Load ForgotPassword',
  props<{ slug: String }>()
);

export const loadForgotPasswordSuccess = createAction(
  '[ForgotPassword] Load ForgotPassword Success',

  props<{ forgotPassword: any }>()
);

export const loadForgotPasswordFailure = createAction(
  '[ForgotPassword] Load ForgotPassword Failure',
  props<{ error: any }>()
);

export const ForgotPasswordSubmit = createAction(
  '[ForgotPassword] ForgotPassword Submit',
  props<{ slug: String, formData: any }>()
);

export const ForgotPasswordComplete = createAction(
  '[ForgotPassword] ForgotPassword Complete',
  props<{ forgotPassword: any }>()
);

export const ResetForgotPasswordResponse = createAction(
  '[ForgotPassword] Reset ForgotPassword Response',
  props<{} | any>() // @TODO
);

