import { createReducer, on, Action } from '@ngrx/store';

import * as ForgotPasswordActions from './forget-password.actions';
import { ForgotPasswordEntity } from './forget-password.models';

export const FORGOTPASSWORD_FEATURE_KEY = 'forgotPassword';

export interface ForgotPasswordPartialState {
  readonly [FORGOTPASSWORD_FEATURE_KEY]: ForgotPasswordEntity;
}


export const initialState: ForgotPasswordEntity = {
  // set initial required properties
  loaded: false,
  taskInfo: undefined,
  loading: false
};

const forgotPasswordReducer = createReducer(
  initialState,
  on(ForgotPasswordActions.loadForgotPassword, state => ({
    ...state,
    loaded: false,
    error: null
  })),
  on(
    ForgotPasswordActions.loadForgotPasswordSuccess, (state, { forgotPassword }) => ({
      ...state,
      loaded: true,
      response: null,
      taskInfo: forgotPassword
    })
  ),
  on(
    ForgotPasswordActions.ForgotPasswordSubmit, (state, { formData }) => ({
      ...state,
      loaded: false,
      loading: true
    })
  ),
  on(
    ForgotPasswordActions.ForgotPasswordComplete, (state, { forgotPassword }) => ({
      ...state,
      loaded: true,
      response: forgotPassword
    })
  ),
  on(
    ForgotPasswordActions.ResetForgotPasswordResponse, (state) => ({
      ...state,
      loaded: false,
      response: undefined
    })
  ),
  on(ForgotPasswordActions.loadForgotPasswordFailure, (state, { error }) => ({
    ...state,
    error
  }))
);

export function reducer(state: ForgotPasswordEntity | undefined, action: Action) {
  return forgotPasswordReducer(state, action);
}
