import { Injectable } from '@angular/core';

import { select, Store, Action } from '@ngrx/store';

import * as fromChangePassword from './change-password.reducer';
import * as changePasswordSelectors from './change-password.selectors';

@Injectable()
export class ChangePasswordFacade {
  loaded$ = this.store.pipe(
    select(changePasswordSelectors.getChangePasswordLoaded)
  );
  allChangePassword$ = this.store.pipe(
    select(changePasswordSelectors.getAllChangePassword)
  );

  changePasswordResposne$ = this.store.pipe(select(changePasswordSelectors.getChangePasswordResponse));
  constructor(
    private store: Store<fromChangePassword.ChangePasswordPartialState>
  ) {}

  dispatch(action: Action) {
    this.store.dispatch(action);
  }
}
