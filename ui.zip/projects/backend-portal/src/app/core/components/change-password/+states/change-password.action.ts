import { createAction, props } from '@ngrx/store';
import { ChangePasswordEntity } from './change-password.models';

export const loadChangePassword = createAction(
  '[ChangePassword] Load ChangePassword',
  props<{ slug: String }>()
);

export const loadChangePasswordSuccess = createAction(
  '[ChangePassword] Load ChangePassword Success',

  props<{ changePassword: any }>()
);

export const loadChangePasswordFailure = createAction(
  '[ChangePassword] Load ChangePassword Failure',
  props<{ error: any }>()
);

export const ChangePasswordSubmit = createAction(
  '[ChangePassword] ChangePassword Submit',
  props<{ slug: String, formData: any }>()
);

export const ChangePasswordComplete = createAction(
  '[ChangePassword] ChangePassword Complete',
  props<{ changePassword: any }>()
);

export const ResetChangePasswordResponse = createAction(
  '[ChangePassword] Reset ChangePassword Response',
  props<{  } | any>() //@TODO
);

