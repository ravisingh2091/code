import { Component, OnInit, OnDestroy } from '@angular/core';
import { ChangePasswordFacade } from './+states/change-password.facade';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { CommonService } from '@shared/services/common.service';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { ChangePasswordSubmit, ResetChangePasswordResponse, loadChangePassword } from './+states/change-password.action';
import { take } from 'rxjs/operators';


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit, OnDestroy {

  changePasswordForm: FormGroup;
  changePasswordConfig: FormFieldInterface[] = [];
  changePasswordSubscription: Subscription;
  changePasswordResponseSubscription: Subscription;
  rootStateSubscription: Subscription;
  backendUserID: string;
  slug: string;
  logoSource: any = '../assets/images/logo.svg';
  logoSource1: any = '../assets/images/transunionLogo.svg';
  infoIcon: any = '../assets/images/information.svg';

  constructor(
    private forgotPasswordFacade: ChangePasswordFacade,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private common: CommonService) {
    this.forgotPasswordFacade.dispatch(loadChangePassword({ slug: 'change-password' }));
  }

  ngOnInit(): void {
    this.changePasswordSubscription = this.forgotPasswordFacade.allChangePassword$
      .subscribe((changeState: any) => {
        if (changeState) {
          this.slug = changeState.task_slug;
          this.changePasswordConfig = changeState.form_fields;
          this.changePasswordForm = this.formGenerate.createControl(this.changePasswordConfig);
        }
      });

    this.changePasswordResponseSubscription = this.forgotPasswordFacade.changePasswordResposne$
      .subscribe(changeState => {
        if (changeState) {
          // this.forgotPasswordFacade.dispatch(ResetChangePasswordResponse({}));
        }
      });

    this.rootStateSubscription = this.store
      .pipe(
        select('app'),
        take(1)
      ).subscribe(rootState => {
        if (rootState) {
          this.backendUserID = rootState.backendUserData.id;
        }
      });
  }

  back = (): void => {
    this.common.navigate('user-listing');
  }

  onSubmit = (): void => {
    if (!this.changePasswordForm.invalid) {
      const payload = {
        ...this.changePasswordForm.value,
        user_id: this.backendUserID
      };
      this.forgotPasswordFacade.dispatch(ChangePasswordSubmit({ slug: this.slug, formData: payload }));
    } else {
      this.formGenerate.validateAllFormFields(this.changePasswordForm);
    }

  }

  ngOnDestroy(): void {
    this.rootStateSubscription.unsubscribe();
  }

}
