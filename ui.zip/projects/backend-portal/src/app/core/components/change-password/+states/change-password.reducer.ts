import { createReducer, on, Action } from '@ngrx/store';

import * as ChangePasswordActions from './change-password.action';
import { ChangePasswordEntity } from './change-password.models';

export const CHANGEPASSWORD_FEATURE_KEY = 'changePassword';

export interface ChangePasswordPartialState {
  readonly [CHANGEPASSWORD_FEATURE_KEY]: ChangePasswordEntity;
}


export const initialState: ChangePasswordEntity = {
  // set initial required properties
  loaded: false,
  taskInfo: undefined,
  loading: false
};

const changePasswordReducer = createReducer(
  initialState,
  on(ChangePasswordActions.loadChangePassword, state => ({
    ...state,
    loaded: false,
    error: null
  })),
  on(
    ChangePasswordActions.loadChangePasswordSuccess, (state, { changePassword }) => ({
      ...state,
      loaded: true,
      response: null,
      taskInfo: changePassword
    })
  ),
  on(
    ChangePasswordActions.ChangePasswordSubmit, (state, { formData }) => ({
      ...state,
      loaded: false,
      loading: true
    })
  ),
  on(
    ChangePasswordActions.ChangePasswordComplete, (state, { changePassword }) => ({
      ...state,
      loaded: true,
      response: changePassword
    })
  ),
  on(
    ChangePasswordActions.ResetChangePasswordResponse, (state) => ({
      ...state,
      loaded: false,
      response: undefined
    })
  ),
  on(ChangePasswordActions.loadChangePasswordFailure, (state, { error }) => ({
    ...state,
    error
  }))
);

export function reducer(state: ChangePasswordEntity | undefined, action: Action) {
  return changePasswordReducer(state, action);
}
