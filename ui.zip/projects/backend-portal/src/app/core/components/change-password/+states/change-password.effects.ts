import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { fetch } from '@nrwl/angular';
import { map } from 'rxjs/operators';
import * as ChangePasswordActions from './change-password.action';
import { ApplicationService } from '../../../../shared/services/application.service';

@Injectable()
export class ChangePasswordEffects {
  loadChangePassword$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ChangePasswordActions.loadChangePassword),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        run: action => {
          return this.applicationService.getTaskInfo({
            slug: action.slug
          }).pipe(
            map((data: any) => {
              // Your custom service 'load' logic goes here. For now just return a success action...
              return ChangePasswordActions.loadChangePasswordSuccess({ changePassword: data });
            }))
        },

        onError: (action, error) => {
          console.error('Error', error);
          return ChangePasswordActions.loadChangePasswordFailure({ error });
        }
      })
    )
  );

  submitChangePassword$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ChangePasswordActions.ChangePasswordSubmit),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        run: action => {
          return this.applicationService
            .saveTaskInfo(action.formData, {
              slug: action.slug
            }, null).pipe(
              map((data: any) => {
                return ChangePasswordActions.ChangePasswordComplete({ changePassword: data });
              })
            );
          // Your custom service 'load' logic goes here. For now just return a success action...
        },
        onError: (action, error) => {
          console.error('Error', error);
          return ChangePasswordActions.loadChangePasswordFailure({ error });
        }
      })
    )
  );

  constructor(
    private actions$: Actions,
    private applicationService: ApplicationService
  ) { }
}
