import { createFeatureSelector, createSelector, State } from '@ngrx/store';
import {
  CHANGEPASSWORD_FEATURE_KEY,
  ChangePasswordPartialState,
} from './change-password.reducer';
import { ChangePasswordEntity } from './change-password.models';

// Lookup the 'ChangePassword' feature state managed by NgRx
export const getChangePasswordState = createFeatureSelector<ChangePasswordEntity>(CHANGEPASSWORD_FEATURE_KEY);


export const getChangePasswordLoaded = createSelector(
  getChangePasswordState,
  (state: ChangePasswordEntity) => state.loaded
);

export const getChangePasswordError = createSelector(
  getChangePasswordState,
  (state: ChangePasswordEntity) => state.error
);

export const getAllChangePassword = createSelector(
  getChangePasswordState,
  getChangePasswordLoaded,
  (state: ChangePasswordEntity,getChangePasswordLoaded) => (getChangePasswordLoaded && !state.response) ? state.taskInfo : null
  );

export const getChangePasswordResponse = createSelector(
  getChangePasswordState,
  (state: ChangePasswordEntity) => state.response ? state.response : null
);
