import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxMaskModule } from 'ngx-mask';
import { EffectsModule } from '@ngrx/effects';
import { SharedModule } from '@shared/shared.module';
import * as fromLogin from './components/login/+state/login.reducer';
import * as fromForgetPassword from './components/forget-password/+state/forget-password.reducer';
import * as changePassword from './components/change-password/+states/change-password.reducer';
import * as resetPassword from './components/reset-password/+states/reset-password.reducer';
import { ForgotPasswordFacade } from './components/forget-password/+state/forget-password.facade';
import { ForgetPasswordComponent } from './components/forget-password/forget-password.component';
import { LoginComponent } from './components/login/login.component';
import { LoginFacade } from './components/login/+state/login.facade';
import { Store } from '@ngrx/store';
import { StoreModule } from '@ngrx/store';
import { LoginEffects } from './components/login/+state/login.effects';
import { ForgotPasswordEffects } from './components/forget-password/+state/forget-password.effects';
import { ResetPasswordEffects } from './components/reset-password/+states/reset-password.effects';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { ChangePasswordFacade } from './components/change-password/+states/change-password.facade';
import { ResetPasswordFacade } from './components/reset-password/+states/reset-password.facade';
import { ChangePasswordEffects } from './components/change-password/+states/change-password.effects';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { DataPersistence } from '@nrwl/angular';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,

    StoreModule.forFeature(fromLogin.LOGIN_FEATURE_KEY, fromLogin.reducer),
    StoreModule.forFeature(fromForgetPassword.FORGOTPASSWORD_FEATURE_KEY, fromForgetPassword.reducer),
    StoreModule.forFeature(changePassword.CHANGEPASSWORD_FEATURE_KEY, changePassword.reducer),
    StoreModule.forFeature(resetPassword.RESETPASSWORD_FEATURE_KEY, resetPassword.reducer),
    EffectsModule.forFeature([LoginEffects]),
    EffectsModule.forFeature([ForgotPasswordEffects]),
    EffectsModule.forFeature([ChangePasswordEffects]),
    EffectsModule.forFeature([ResetPasswordEffects]),
    // StoreModule.forFeature(changeForgetPassword.CHANGEPASSWORD_FEATURE_KEY, changeForgetPassword.reducer),
    BrowserAnimationsModule,
    NgxMaskModule.forRoot()
  ],
  declarations: [
    LoginComponent,
    ForgetPasswordComponent,
    ChangePasswordComponent,
    ResetPasswordComponent
  ],
  providers: [LoginFacade, ForgotPasswordFacade, Store, ChangePasswordFacade, ResetPasswordFacade, DataPersistence],
  exports: [
    SharedModule,
    LoginComponent,
    ForgetPasswordComponent,
    ResetPasswordComponent,
    ChangePasswordComponent,
    BrowserAnimationsModule
  ],
})

export class CoreModule { }
