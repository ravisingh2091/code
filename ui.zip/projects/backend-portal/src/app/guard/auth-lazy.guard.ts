import { LoginFacade } from './../core/components/login/+state/login.facade';
import { CommonService } from '@shared/services/common.service';
import { Observable, Subscription } from 'rxjs';
import { OnDestroy, Injectable } from '@angular/core';
import { CanActivate, CanLoad, Route, UrlSegment, UrlTree } from '@angular/router';
import { get } from 'lodash-es';

@Injectable({
  providedIn: 'root'
})

export class AuthLazyGuard implements CanLoad, CanActivate, OnDestroy {
  tokenSubscription: Subscription;
  userData = null;
  constructor(private loginFacade: LoginFacade, private common: CommonService) {
    this.tokenSubscription = this.loginFacade.submitLoginState$.subscribe(response => {
      this.userData = get(response, 'signin.data', null);
    });
  }

  canActivate(): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    if (!this.userData) {
      this.common.navigate('backend-login');
      this.common.loginEmit = false;
      return false;
    }
    this.common.loginEmit = true;
    return true;
  }

  canLoad(route: Route, segments: UrlSegment[]): boolean | Observable<boolean> | Promise<boolean> {
    if (!this.userData) {
      this.common.navigate('backend-login');
      this.common.loginEmit = false;
      return false;
    }
    this.common.loginEmit = true;
    return true;
  }


  ngOnDestroy(): void {
    this.tokenSubscription.unsubscribe();
  }
}
