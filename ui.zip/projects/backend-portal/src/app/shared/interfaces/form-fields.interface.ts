export interface FormFieldInterface {
    form_field?: any;
    name: string;
    type: string;
    label?: string;
    masterKey: boolean;
    value?: string;
    options?: Array<any>;
    form_field_validations?: [];
    validations?: any;
    order: number;
    slider?: any;
    event?: any;
    show_field?: boolean;
    visible?: any;
    css?: any;
    max_limit: number;
    group_fields?: any;
    multiple?: boolean;
    total: string;
    autoCompleteList: [];
    format?: any;
    config?: any;
}
