export interface ServiceProvidersInterface {
    id: string;
    type: string;
    value: string;
}