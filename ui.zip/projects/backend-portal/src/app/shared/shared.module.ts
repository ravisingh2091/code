import { NgModule, Injector, APP_INITIALIZER } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LOCATION_INITIALIZED } from '@angular/common';

// Third party imports
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateModule, TranslateLoader, TranslateService } from '@ngx-translate/core';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { ToasterModule } from 'angular2-toaster';

// Custom module
import { UtilsModule } from '../utils/utils.module';

// Components
import { HeaderComponent } from './components/header/header.component';
import { HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';

// Environment
import { environment } from '@env/environment';

// Interceptors
import { HttpServiceInterceptor } from './interceptors/http-service.interceptor';
import { LoaderInterceptors } from './interceptors/loader.interceptor';
import { ErrorsInterceptor } from './interceptors/error.interceptor';
import { LoaderComponent } from './components/loader/loader.component';
import { AlertDialog } from './components/alert-dialog/alert-dialog.component';

export function HttpLoaderFactory(httpClient: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(httpClient, './assets/i18n/', '.json');
}

export function appInitializerFactory(translateService: TranslateService, injector: Injector): () => Promise<any> {
  return () => new Promise<any>((resolve: any) => {
    const locationInitialized = injector.get(LOCATION_INITIALIZED, Promise.resolve(null));
    locationInitialized.then(() => {
      translateService.setDefaultLang(environment.appLang);
      resolve(null);
    });
  });
}

@NgModule({
  declarations: [
    HeaderComponent,
    LoaderComponent,
    AlertDialog
  ],
  imports: [
    CommonModule,
    BsDatepickerModule.forRoot(),
    CollapseModule.forRoot(),
    PopoverModule.forRoot(),
    ProgressbarModule.forRoot(),
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    BsDropdownModule.forRoot(),
    AccordionModule.forRoot(),
    PaginationModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      },
      isolate: false
    }),
    ToasterModule.forRoot(),
    UtilsModule
  ],
  exports: [
    HeaderComponent,
    BsDatepickerModule,
    CollapseModule,
    PopoverModule,
    ProgressbarModule,
    TabsModule,
    ModalModule,
    BsDropdownModule,
    AccordionModule,
    PaginationModule,
    UtilsModule,
    TranslateModule,
    LoaderComponent,
    ToasterModule,
    AlertDialog
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: HttpServiceInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptors, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorsInterceptor, multi: true },
    { provide: APP_INITIALIZER, useFactory: appInitializerFactory, deps: [TranslateService, Injector], multi: true },
  ]
})
export class SharedModule { }
