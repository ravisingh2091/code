import { CommonService } from '@shared/services/common.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alert-dialog',
  templateUrl: './alert-dialog.component.html',
  styleUrls: ['./alert-dialog.component.scss']
})
export class AlertDialog implements OnInit {
  // onClose: Subject<boolean>;
  constructor(private bsModalRef: BsModalRef,
    private common : CommonService) { }

  ngOnInit(): void {
  }

  close(val): void {
    // this.onClose.next(val);
    if (val === 'yes') {
      this.common.navigate('income-expense');
    }
    this.bsModalRef.hide();
  }

}
