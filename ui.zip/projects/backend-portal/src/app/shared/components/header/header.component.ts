import { Component, OnInit, Inject, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { CommonService } from '../../services/common.service';
import { HEADERLIST } from '../../constants/headerList';
import { Store, select } from '@ngrx/store';
import { FormGroup, FormBuilder } from '@angular/forms';
import { onLogout } from '@utils/+state/utils.action';

import { ApplicationService } from '@shared/services/application.service';
import { take, switchMap } from 'rxjs/operators';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {

  headerForm: FormGroup;
  isLogin = false;
  isActive = true;
  isCollapsed = true;
  path: string;
  logoSource: any = 'assets/images/logo.svg';
  logoSource1: any = 'assets/images/transunionLogo.svg';
  infoIcon: any = 'assets/images/information.svg';
  bodyHTML: any = this.document.getElementsByTagName('body');
  headerList = HEADERLIST;
  sessionID: any;
  rootStateSubscription: Subscription;

  constructor(
    @Inject(DOCUMENT) private document: Document, private common: CommonService,
    private changeDetection: ChangeDetectorRef, private fb: FormBuilder, private store: Store<any>,
    private api: ApplicationService
  ) { }

  ngOnInit(): void {
    this.headerForm = this.fb.group({
      search: [null]
    });
    this.common.loginObservable
      .subscribe(data => {
        this.path = this.common.currentUrl;
        this.isLogin = data;
        this.changeDetection.detectChanges();
      });
  }

  navigate(path): void {
    // console.log(path)
    this.common.navigate(path);
  }

  logout(): void {
    this.rootStateSubscription = this.store
      .pipe(
        select('app'),
        take(1),
        switchMap(rootState => {
          if (rootState) {
            if (rootState.backendUserData) {
              this.sessionID = rootState.backendUserData.id;
            }
          }
          return this.api.saveTaskInfo({ id: this.sessionID }, {
            slug: 'logout'
          });
        })
      ).subscribe((res: any) => {
        if (res && res.nextTask) {
          this.store.dispatch(onLogout({}));
          this.common.navigate('backend-login');
        }
      });
  }

  ngOnDestroy(): void {
    if (this.rootStateSubscription) {
      this.rootStateSubscription.unsubscribe();
    }
  }

}
