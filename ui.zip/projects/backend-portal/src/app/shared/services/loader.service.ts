import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class LoaderService {

  private isLoading = new Subject<boolean>();
  showCount = 0;
  hideCount = 0;

  constructor() { }

  show = (): void => {
    this.isLoading.next(true);
    this.showCount++;
  }

  hide = (): void => {
    this.hideCount++;
    if (this.hideCount === this.showCount) {
      this.isLoading.next(false);
      this.hideCount = 0;
      this.showCount = 0;
    }
  }

  get loading(): Observable<boolean> {
    return this.isLoading.asObservable();
  }

}
