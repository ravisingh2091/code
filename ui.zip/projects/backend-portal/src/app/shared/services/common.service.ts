import { Injectable, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { ToasterService, Toast, BodyOutputType } from 'angular2-toaster';

import { Subject, Observable, BehaviorSubject } from 'rxjs';
import { BACKEND_PORTAL } from '../constants/routes';
@Injectable({
  providedIn: 'root'
})
export class CommonService {

  private loginSubject = new Subject();
  private errorSubject = new Subject();
  private customerFooterSubject = new Subject();
  private selectedinnerTabSubject = new Subject();
  private nextButtonSubject=new Subject();
  private nextsubscriptionSubject=new Subject();
  private selectedMainTabSubject = new Subject();
  private masterDataSubject$ = new BehaviorSubject<any>(null);
  private _formSubmit: EventEmitter<any> = new EventEmitter<any>();
  private _goBack: EventEmitter<any> = new EventEmitter<any>();
  private _businessInfo: EventEmitter<any> = new EventEmitter<any>();
  private _fileUpload: EventEmitter<any> = new EventEmitter<any>();
  private _fileDelete: EventEmitter<any> = new EventEmitter<any>();
  gstApiSubject = new BehaviorSubject<any>(null);


  masterDataObj = {};

  constructor(private router: Router, private toasterService: ToasterService) { }

  set formSubmit(val: { action: string }) {
    this._formSubmit.emit(val);
  }

  get formSubmitGet(): Observable<any> {
    return this._formSubmit;
  }

  set goBack(val:any) {
    this._goBack.emit(val);
  }

  get goBackGet(): Observable<any> {
    return this._goBack;
  }

  set businessInfoFormSubmit(val: any) {
    this._businessInfo.emit(val);
  }

  get businessInfoFormGet(): Observable<any> {
    return this._businessInfo;
  }

  set businessInfoFileUpload(val: any) {
    this._fileUpload.emit(val);
  }

  get businessInfoFileUploadGet(): Observable<any> {
    return this._fileUpload;
  }
  set fileDelete(val: any) {
    this._fileDelete.emit(val);
  }

  get fileDeleteGet(): Observable<any> {
    return this._fileDelete;
  }
  /**
   * function to get login status
   */
  get loginObservable(): Observable<any> {
    return this.loginSubject.asObservable();
  }

  /**
   * function set login status
   */
  set loginEmit(val) {
    this.loginSubject.next(val);
  }
  /**
   * function to get login status
   */
  get customerFooterObservable(): Observable<any> {
    return this.customerFooterSubject.asObservable();
  }

  /**
   * function set login status
   */
  set customerFooterEmit(val) {
    this.customerFooterSubject.next(val);
  }

  /**
   * function to get login status
   */
  get errorObservable(): Observable<any> {
    return this.errorSubject.asObservable();
  }

  /**
   * function set login status
   */
  set sendErrorMsg(val) {
    this.errorSubject.next(val);
  }

  /**
   * function to get inner nav bar key name
   */
  get selectedInnerTabObservable(): Observable<any> {
    return this.selectedinnerTabSubject.asObservable();
  }

  /**
   * function to set inner nav bar key name
   */
  set innerTabEmit(val) {
    this.selectedinnerTabSubject.next(val);
  }

  /**
   * function to get main nav bar key name
   */
  get selectedMainTabObservable(): Observable<any> {
    return this.selectedMainTabSubject.asObservable();
  }

  /**
   * function to set main nav bar key name
   */
  set mainTabEmit(val) {
    this.selectedMainTabSubject.next(val);
  }

  get currentUrl(): string {
    return this.router.url;
  }

  get routeEvent(): Observable<any> {
    return this.router.events;
  }

  /**
   * function to get master data observable
   */
  get masterData(): Observable<any> {
    this.masterDataObj = {};
    return this.masterDataSubject$.asObservable();
  }

  /**
   * function to send data
   */
  sendMasterData = (val: any): void => {
    this.masterDataObj = { ...this.masterDataObj, ...val };
    this.masterDataSubject$.next({ ...this.masterDataObj });
  }

  /**
   * function to send master data
   * @param fields: Fields
   * @param responseData: response data
   * @param fieldName: field name
   */
  sendMasterDataToFields = (fields, responseData, fieldName?: string): void => {
    if (fieldName) {
      this.sendMasterData({
        [fieldName]: responseData
      });
    } else {
      for (const val of fields) {
        if (val.type === 'group') {
          this.sendMasterDataToFields(val.group_fields, responseData);
        } else {
          if (val.masterKey) {
            const key = val.config && val.config.masterKey ? val.config.masterKey : val.name;
            this.sendMasterData({
              [val.name]: responseData[key]
            });
          }
        }
      }
    }
  }

  /**
   * function to navigate routes
   * @param path route path
   * @param id data to pass as route param
   */
  navigate = (path: string, id?: any): void => {
    if (BACKEND_PORTAL[path]) {
      if (id) {
        this.router.navigate([BACKEND_PORTAL[path], ...id]);
      } else {
        this.router.navigate([BACKEND_PORTAL[path]]);
      }
    }
  }

  /**
   * function to store data in storage
   * @param key: key to save data corresponding to
   * @param data: data to save
   */
  storeDataInStorage = (key: string, data: any, storage?: Storage) => {
    storage = storage || sessionStorage;
    storage.setItem(key, JSON.stringify(data));
  }

  /**
   * function to get data from storage
   * @param key: key to get data corresponding to
   */
  getDataFromStorage = (key: string, storage?: Storage) => {
    storage = storage || sessionStorage;
    return JSON.parse(storage.getItem(key));
  }

  /**
   * function to get data from storage
   * @param key: key to delete data corresponding to
   */
  deleteDataFromStorage = (key: string, storage?: Storage) => {
    storage = storage || sessionStorage;
    return storage.removeItem(key);
  }

  /**
   * function to show toaster
   */
  popToast(type: string, title: string, body: string): any {
    const toast: Toast = {
      type,
      title,
      body,
      bodyOutputType: BodyOutputType.TrustedHtml
    };
    return this.toasterService.pop(toast);
  }

  storeAppStatus(data: any) {
    this.storeDataInStorage('app_status', data);
  }

  getAppStatus(key: string) {
    const appStatus = this.getDataFromStorage('app_status');
    return appStatus.find((status) => status.value === key);
  }


  get NextButtonObservable(): Observable<any> {
    return this.nextButtonSubject.asObservable();
  }

  /**
   * function set login status
   */
  set NextButtonEmit(val) {
    this.nextButtonSubject.next(val);
  }
  

  get nextsubscriptionObservable(): Observable<any> {
    return this.nextsubscriptionSubject.asObservable();
  }

  /**
   * function set login status
   */
  set nextsubscriptionEmit(val) {
    this.nextsubscriptionSubject.next(val);
  }

  getAppType(key: string) {
    const appType = this.getDataFromStorage('app_type');
    return appType.find((status) => status.value === key);
  }
}
