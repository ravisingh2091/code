import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { FormGenerateService } from './form-generate.service';
import { environment } from '@env/environment';

@Injectable({
  providedIn: 'root'
})
export class ApplicationService {

  constructor(
    private http: HttpClient, private formGenerate: FormGenerateService
  ) { }

  /**
   * function to get task info
   * @param params: query params
   */
  getTaskInfo = (params: any, headers?: any): Observable<any> => {
    if (params.hasOwnProperty('stub') && environment.stub) {
      delete params.stub;
    }

    return this.http
      .get(environment.orchUrl + 'v2/tasks', { params, headers })
      .pipe(
        map((response: any) => {
          if (response.data) {
            response.data.form_fields.sort(this.formGenerate.compareValues('order'));
            return response.data;
          }
          return null;
        })
      );
  }

  /**
   * function to save task info
   * @param payload: data to send in payload
   * @param params: query params
   * @param headers: headers if any
   */

  saveTaskInfo = (payload: any, params: any, headers?: any): Observable<any> => {

    if (payload && payload.hasOwnProperty('stub') && environment.stub) {
      delete payload.stub;
    }

    return this.http
            .post(environment.orchUrl + 'v2/tasks', payload, { params, headers })
            .pipe(
              map((response: any) => {
                return response.data.response_data;
              })
            );
  }
}
