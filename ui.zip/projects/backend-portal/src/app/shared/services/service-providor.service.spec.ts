import { TestBed } from '@angular/core/testing';

import { ServiceProvidorService } from './service-providor.service';

describe('ServiceProvidorService', () => {
  let service: ServiceProvidorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServiceProvidorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
