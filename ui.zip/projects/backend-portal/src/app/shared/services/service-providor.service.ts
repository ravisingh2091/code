import { Injectable, EventEmitter } from '@angular/core';

import { ServiceProvidersInterface } from '../interfaces/service-providor.interface';
import { ApplicationService } from '@shared/services/application.service';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ServiceProvidorService {
  provider_id: string;
  data: any;
  providerData: any;
  constructor(
    private api: ApplicationService) { }



/**
 * function to set form data
 * @param slug: slug
 */

 
setproviderData(): void {
  this.api.getTaskInfo({
      slug: 'service-provider'
  }).subscribe(res => {
      if (res ?.response_data ?.service_provider ?.data ?.data ) {
          this.providerData = res.response_data.service_provider.data.data;
      }
  });
}

getProviderData(serviceType: string):ServiceProvidersInterface {
  if (this.providerData ?.length ) {
      return this.providerData.find(elem => elem.type === serviceType);
  }
}


/**
 * function to set form data
 * @param type: string
 */


}
