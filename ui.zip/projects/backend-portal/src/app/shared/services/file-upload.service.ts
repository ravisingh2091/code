import { Injectable } from '@angular/core';
import { Subject, Observable, of, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpRequest, HttpEventType, HttpResponse, HttpParams } from '@angular/common/http';
import { environment } from '@env/environment';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  fileEvent = new Subject<any[]>();
  uploadedFiles = [];
  private filesUploaded:Subject<{doc_id:string, type:string, name: string, progress: Observable<number>,size:number,created_at:string,_id:string}> = new Subject<{doc_id:string, type:string, name: string, progress: Observable<number>,size:number,created_at:string,_id:string}>();

  constructor(private http: HttpClient) { }

  public uploadFile(files: File[],params:any,body): { [key: string]: { progress: Observable<number> } } {

    // this will be the our resulting map
    const status: { [key: string]: { progress: Observable<number>, size: any, doc_id: BehaviorSubject<String>, _id: BehaviorSubject<String> }} = {};

    for (const file of files) {

        // create a new multipart-form for every file
        const formData: FormData = new FormData();
        formData.append('file',  file);
        formData.append('filekey', 'data');
        formData.append('response_to_be_saved', JSON.stringify({name:file.name,size:file.size,type: "ownership"}));
        Object.keys(body).forEach(key=>{
          formData.append(key,body[key]);
        })
  let httpParms=new HttpParams();
  Object.keys(params).forEach(key=>{
    httpParms=httpParms.append(key, params[key]);
  })

        // create a http-post request and pass the form
        // tell it to report the upload progress
        let req = new HttpRequest('POST', environment.orchUrl + 'v2/tasks' +'?slug='+params.slug, formData, {
            reportProgress: true
        });

        if (!req.headers.has('Content-Type')) {
            req = req.clone({ headers: req.headers.delete('Content-Type','application/json') });
        }
        // create a new progress-subject for every file
        const progress = new Subject<number>();
        const doc_id = new BehaviorSubject<string>('');
        const _id = new BehaviorSubject<string>('');

        // send the http-request and subscribe for progress-updates

        this.http.request(req).subscribe({next:(event: any) => {

            if (event && event.type === HttpEventType.UploadProgress) {

                // calculate the progress percentage
                const percentDone = Math.round(100 * event.loaded / event.total);
                // pass the percentage into the progress-stream
                progress.next(percentDone);
            } else if (event instanceof HttpResponse) {


                doc_id.next(event.body.data.response_data.upload_document.data.data.doc_id);
                _id.next(event.body.data.response_data.upload_document_reference.data.data._id);
                doc_id.complete();
                _id.complete();
                this.filesUploaded.next({_id: event.body.data.response_data.upload_document_reference.data.data._id ,doc_id:event.body.data.response_data.upload_document.data.data.doc_id, name: file.name, type: "ownership", progress: of(100),size:file.size,...event.body.data.response_data.upload_document_reference.data.data});

              progress.complete();
            }


        },
      error:(error:any)=>{
        doc_id.next("error");
        doc_id.complete();
        _id.next("error");
        _id.complete();
        this.filesUploaded.next({doc_id:'error', name: file.name, progress: of(100),size:file.size, type: "ownership", created_at:"",_id:"error"});

      progress.error(error);
      }});

        // Save every progress-observable in a map of all observables
        status[file.name] = {
            progress: progress.asObservable(),
            size: this.calculateSize(file.size),
            doc_id: doc_id,
            _id: _id          };
    }

    // return the map of progress.observables
    return status;
}
calculateSize(size: number) {
  let filesize = null;
  if (size < 1000) {
      filesize = `${size} bytes`;
  } else if (size < 1000 * 1000) {
      filesize = `${size / 1000} kb`;
  } else if (size < 1000 * 1000 * 1000) {
      filesize = `${size / 1000 / 1000} mb`;
  } else {
      filesize = `${size / 1000 / 1000 / 1000} gb`;
  }
  return filesize;
}


filesUploadedListener() {
  return this.filesUploaded.asObservable();
}
  /**
   * function to check whether file is allowed or not
   * @param files
   * @param allowedFileExt
   * @param size
   */
  isFileAllowed(files: File[], allowedFileExt: any[], fileSize: number): { [key: string]: string } | boolean {
    let allowedFile = this.getContentType(allowedFileExt);

    for (const file of files) {
      let allowedfileextjoin = allowedFileExt.join(", ")
      if (!file.type) {
        let contentType = {
          type: this.getFileContent(file.name)
        };
        if (!this.isFileValid(contentType, allowedFile)) {
          return { type: " Only  " + allowedfileextjoin + "  are allowed." };
        }
      } else {
        if (!this.isFileValid(file, allowedFile)) {
          return { type: " Only  " + allowedfileextjoin + "  are allowed." };
        }
      }
      if (!this.isFileSizeValid(file, fileSize)) {
        return { size: "INVALID_FILE_SIZE" + fileSize + 'MB' };
      }
    }
    return false;
  }

  /**
   * function to get content type of a file
   * @param allowedFileExt
   */
  getContentType(allowedFileExt: any) {
    let allowedFile = [];
    if (typeof (allowedFileExt) == "string") {
      allowedFile.push("application/pdf");
      return allowedFile;
    }
    allowedFileExt.forEach(element => {
      switch (true) {
        case element == 'txt':
          allowedFile.push("text/plain")
          break;
        case element == 'jpg' || element == 'jpeg':
          allowedFile.push("image/jpeg")
          break;
        case element == 'png':
          allowedFile.push("image/png")
          break;
        case element == 'gif':
          allowedFile.push("image/gif")
          break;
        case element == 'tif':
          allowedFile.push("image/tiff")
          break;
        case element == 'pdf':
          allowedFile.push("application/pdf")
          break;
        case element == 'doc':
          allowedFile.push("application/msword")
          break;
        case element == 'docx':
          allowedFile.push("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
          break;
        case element == 'ppt':
          allowedFile.push("application/vnd.ms-powerpoint")
          break;
        case element == 'pptx':
          allowedFile.push("application/vnd.openxmlformats-officedocument.presentationml.presentation")
          break;
        case element == 'xls':
          allowedFile.push("application/vnd.ms-excel")
          break;
        case element == 'xlsx':
          allowedFile.push("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
          break;
        default:
          break;
      }
    });
    return allowedFile;
  }
  /**
   * function to get content type of file
   * @param filename
   */
  getFileContent(filename: any) {
    let fileExtArr = filename.split('.');
    let fileExt = fileExtArr[fileExtArr.length - 1];
    let contentType = '';
    switch (fileExt) {
      case 'txt':
        contentType = "text/plain";
        break;
      case 'jpg' || 'jpeg':
        contentType = "image/jpeg";
        break;
      case 'png':
        contentType = "image/png";
        break;
      case 'gif':
        contentType = "image/gif";
        break;
      case 'tif':
        contentType = "image/tiff";
        break;
      case 'pdf':
        contentType = "application/pdf";
        break;
      case 'doc':
        contentType = "application/msword";
        break;
      case 'docx':
        contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        break;
      case 'ppt':
        contentType = "application/vnd.ms-powerpoint";
        break;
      case 'pptx':
        contentType = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
        break;
      case 'xls':
        contentType = "application/vnd.ms-excel";
        break;
      case 'xlsx':
        contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      default:
        break;
    }
    return contentType;
  }
  /**
   * function to validate file type
   * @param file
   * @param allowedFile
   */
  isFileValid(file: any, allowedFile: any) {
    return allowedFile.indexOf(file.type) > -1;
  }
  /**
   * function to validate file size
   * @param file
   * @param size
   */
  isFileSizeValid(file: File, size: number) {
    return file.size < size * 1024 * 1024;
  }
}
