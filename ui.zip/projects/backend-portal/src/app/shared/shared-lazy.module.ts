import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Third party imports
import { TranslateModule } from '@ngx-translate/core';
import { NgxMaskModule } from 'ngx-mask';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { Ng5SliderModule } from 'ng5-slider';

// Custom module
import { UtilsModule } from '../utils/utils.module';

// Components
import { FooterComponent } from './components/footer/footer.component';

@NgModule({
    declarations: [
        FooterComponent
    ],
    imports: [
        CommonModule,
        UtilsModule,
        TranslateModule.forChild(),
        NgxMaskModule.forChild(),
        ProgressbarModule,
        TabsModule,
        BsDatepickerModule,
        CollapseModule,
        PopoverModule,
        ModalModule,
        BsDropdownModule,
        AccordionModule,
        PaginationModule,
        Ng5SliderModule,
    ],
    exports: [
        UtilsModule,
        NgxMaskModule,
        TranslateModule,
        FooterComponent,
        ProgressbarModule,
        TabsModule,
        BsDatepickerModule,
        CollapseModule,
        PopoverModule,
        ModalModule,
        BsDropdownModule,
        AccordionModule,
        PaginationModule,
        Ng5SliderModule
    ]
})
export class SharedLazyModule { }
