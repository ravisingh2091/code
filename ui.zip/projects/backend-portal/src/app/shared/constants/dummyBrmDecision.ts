export const DUMMY_BRM2_RESPONSE = {
  "Status": "Success",
  "ResponseInfo": {
    "ApplicationId": 15046646,
    "SolutionSetInstanceId": "20e6d9ef-9b39-4204-8cc3-db6c526804c8"
  },
  "Fields": {
    "Applicants": {
      "Applicant": [
        {
          "Services": {
            "Service": [
              {
                "Id": "VBR007",
                "Operations": {
                  "Operation": [
                    {
                      "Id": "VBR007P001",
                      "Params": {
                        "Param": [
                          {
                            "Name": "SCY005P006",
                            "Value": "RAWRESPONSE"
                          },
                          {
                            "Name": "OutstandingBalance",
                            "Value": "600000"
                          },
                          {
                            "Name": "SFB006P002",
                            "Value": "RAWRESPONSE"
                          },
                          {
                            "Name": "BankStatement_Taxes",
                            "Value": "20"
                          },
                          {
                            "Name": "Industry",
                            "Value": "Retail"
                          },
                          {
                            "Name": "Location",
                            "Value": "Mumbai"
                          },
                          {
                            "Name": "TurnOver",
                            "Value": "5000000"
                          },
                          {
                            "Name": "DeclaredIncome",
                            "Value": ""
                          },
                          {
                            "Name": "DeclaredEMI",
                            "Value": ""
                          },
                          {
                            "Name": "VariableType",
                            "Value": "All"
                          }
                        ]
                      },
                      "Data": {
                        "Response": {
                          "Variables": {
                            "BankStatement": {
                              "Average_BankTransfer_Inflows": "",
                              "Average_CashDeposits": "",
                              "Average_CardSettlement_Inflows": "",
                              "Average_UPI_Inflows": "",
                              "Total_Inflows": "",
                              "Average_BankTransfer_Outflows": "",
                              "Average_Cashwithdrawals": "",
                              "Average_UPI_Outflows": "",
                              "Total_Outflows": "",
                              "NetCash_Inflows": "",
                              "Average_EMIPayments": "",
                              "Available_Cashflow": "",
                              "GrossProfit_BasisAvailable_CashFlow": "",
                              "Average_EMI_Payments": "",
                              "Pre_Tax_Available": "",
                              "Taxes_Percentage": "",
                              "Headroom_for_EMI": "",
                              "Tenor": "10",
                              "Rate_Of_Interest": "4",
                              "LoanLimit_Available_BankStatement": "",
                              "Eligible_Amounts": {
                                "Eligibility_Amount_BankStatement": "1000000",
                                "Maximum_Bank_Limit_BankStatement": "1000000",
                                "FinalEligibility_BankStatement": "1000000"
                              }
                            },
                            "GST": {
                              "GST_Sales": {
                                "Average_B2C_Sales": "",
                                "Average_B2B_Sales": "",
                                "Average_B2B_CreditNotes": "",
                                "Total_Sales_Percent_Of_B2BcreditNote_B2B_Sales": "",
                                "Total_Sales": ""
                              },
                              "GST_Purchases": {
                                "Average_Total_Purchases": "",
                                "Average_Debit_Notes": "",
                                "Percent_Debit_Notes_Purchases": "",
                                "Total_Purchases": ""
                              },
                              "NetRevenue": "",
                              "MPBF_Approach": {
                                "GST_Sales": "",
                                "MPBF_Factor": "",
                                "MPBF": "",
                                "Outstanding_Balance": "",
                                "Available_Loan_Eligibility_GST": ""
                              },
                              "FOIR_Approach": {
                                "Gross_Profit_Basis_GST": "",
                                "FOIR_Percent": "",
                                "FOIR": "",
                                "Tenure": "",
                                "RateOfInterest": "",
                                "LoanLimit_Available_GST": ""
                              },
                              "Eligible_Amounts": {
                                "Eligibility_With_MPBF": "1000000",
                                "Eligibility_With_Foir": "1000000",
                                "Maximum_Allowed_GST": "1000000",
                                "Maximum_Bank_Limit_GST": "1000000",
                                "FinalEligibility_GST": "1000000"
                              }
                            },
                            "DeclaredIncome": {
                              "FinalEligibility_DeclaredIncome": ""
                            },
                            "Maximum_Eligible_Amount_Of_GST_BankStatement": "",
                            "Maximum_Eligible_Amount_Of_GST_BankStatement_DeclaredIncome": ""
                          }
                        }
                      }
                    }
                  ]
                }
              }
            ]
          }
        }
      ]
    },
    "ApplicationData": {
      "Services": {
        "Service": [
          {
            "Id": "VBR007",
            "Skip": "N",
            "Consent": "true",
            "EnableSimulation": "false"
          }
        ]
      }
    }
  }
}
