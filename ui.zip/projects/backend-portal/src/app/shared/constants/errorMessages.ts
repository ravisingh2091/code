export const ERROR_MESSAGES = {
    400: {
        'verify-otp': {
            FIELD_INVALID: 'Invalid OTP.',
            RUNTIME_ERROR: 'Please try after Sometime',
        },
        'business-info':{
          FAILED: 'Error while submitting business info',
          REQUEST_FIELDS_EMPTY: 'This action requires resource parameters (i.e., resource fields) to be specified',
          RESOURCE_NOT_FOUND: 'Resource does not exist or has been removed',
          ACTION_FAILED: 'The server failed to perform this action for unknown internal reason',
          company_name_reference: 'There was an error while verifying your pan.',
          company_name_reference_update: 'There was an error while verifying your pan.'
        },
        'gst-transaction-otp': {
            FAILED: 'invalid request',
        },
        'create-user':{
            FIELD_REQUIRED:'Value of Field is required',
            RUNTIME_ERROR: 'Please try after sometime.',
            FAILED: 'Error while Creating User',
            RESOURCE_NOT_FOUND : ' Invalid Request ',
            FIELD_DUPLICATE :'The value of the field is already used for another resource',
            check_email: {
                true: 'Email already exists'
            },
            check_phone: {
                true: 'Phone number already registered'
            }
        },
        'saved-gst-details':{
            FAILED: 'The value of the field is invalid.',
            RESOURCE_NOT_FOUND : ' Invalid Request '
        },
        'tu-brm1-call': {
            FAILED: 'The value of the field is invalid.',
            TU_ERROR: 'There is some technical error while computing bureau decision, please try after sometime or contact platform admin',
            RESOURCE_NOT_FOUND: ' Invalid Request ',
            RUNTIME_ERROR: 'Please try after Sometime',
            FIELD_NOT_FOUND: 'The value of the field is invalid.',
            REQUEST_PARAMETERS_NOT_FOUND: "Request parameters not found.",
            RESPONSE_NOT_FOUND: "Error while getting the response.",
            DB_RESPONSE_NOT_FOUND: "Error while getting the Database response.",
            TENTANT_ERROR: "Error while setting tenant details.",
            NOT_FOUND: "Bad request."
        },
        'owners-details': {
            FAILED: 'Unable to save owner details for this application',
            RESOURCE_NOT_FOUND: ' Invalid Request ',
            RUNTIME_ERROR: 'Please try after Sometime',
        },
        'income-expense': {
            FAILED: 'Unable to save income expanse details',
            FIELD_REQUIRED: 'Not all required fields are provided',
            RUNTIME_ERROR: 'Please try after Sometime',
            RESOURCE_NOT_FOUND: ' Invalid Request '
        },
        'customer-offer': {
            FAILED: 'Unable to save offer details',
            FIELD_REQUIRED: 'Not all required fields are provided',
            RUNTIME_ERROR: 'Please try after Sometime',
            RESOURCE_NOT_FOUND: ' Invalid Request '
        },
        'update-user':{
            RUNTIME_ERROR: 'Please try after sometime.',
            FIELD_REQUIRED:'value of Field is required',
            FAILED: 'error while updating user',
            RESOURCE_NOT_FOUND : ' Invalid Request ',
            check_email: {
                true: 'Email already exists'
            },
            check_phone: {
                true: 'Phone number already registered'
            }
        },
        RESOURCE_NOT_FOUND: 'Invalid Request',
        FIELD_INVALID: 'The value of the field is invalid.',
        RUNTIME_ERROR: 'Please try after sometime.',
        REQUEST_PARAMETERS_NOT_FOUND: 'Invalid request parameters',
        FIELD_REQUIRED: 'Please fill all the required values',
    },
    403: {
        SESSION_EXPIRED: 'Your session expired.',
        PERMISSIONS_DENIED: 'Please enter correct Username or Password.',
        OTP_EXPIRED: 'The OTP(e.g. phone number) is valid but has expired',
        'verify-otp': {
          OTP_EXPIRED: 'The OTP is valid but has expired',
        }
    },
    404:{
      'update-user': {
        RESOURCE_NOT_FOUND: 'Error while Updating Customer'
      }
    },
    429: {
        RATE_LIMIT_REACHED: 'Otp limit exceeded. Please try after 15 minutes'
    },
    440: {
        error: 'Your session expired.'
    },
    454: {
        SESSION_LOADING_FAILED: 'Please enter correct Username or Password.'
    },
    500: {
        ACTION_FAILED: 'Unable to perform this action due to unknown reasons.'
    },
    503: {
        error: 'Service timeout.'
    },
    200: {
        'create-user': {
            check_email: {
                true: 'Email already exists'
            },
            check_phone: {
                true: 'Phone number already registered'
            }
        },
        'update-user':{
            check_email: {
                true: 'Email already exists'
            },
            check_phone: {
                true: 'Phone number already registered'
            }
        },
        'business-info':{
          company_name: 'Please try with a different PAN'
        },
    }
};
