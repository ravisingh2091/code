export const product = [
  {
    "_id": "5ecce4341c565b89dc8ce6d2",
    "value": "Unsecured Business Loan",
    "code": 180,
    "loan_type": "ULT",
    "rate": 15,
    "tenure": 24
  }
]
