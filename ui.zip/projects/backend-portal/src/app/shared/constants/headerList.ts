export const HEADERLIST = [
    {

        name: 'Dashboard',
        slug: 'dashboard',
        path: 'dashboard'
    },
    {

        name: 'Customer',
        slug: 'user-listing',
        path: 'customer'
    },
    // {

    //     name: 'Application',
    //     slug: 'application-listing',
    //     path: 'application'
    // }

];
