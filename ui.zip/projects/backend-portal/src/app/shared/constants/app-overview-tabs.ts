export const APP_REVIEW_TABS = {
    appOverview: 'app-overview',
    underwriter: 'underwriter',
    offer: 'offer-details'
};
