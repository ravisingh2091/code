export const APP_STATUS = {
    incomplete: 'Incomplete',
    submitted: 'Submitted',
    manualReview: 'Manual review',
    approved: 'Approved',
    declined: 'Declined',
    offers: 'Offers',
    funded: 'Funded'
}
