export const BRM_JOURNEY_STATES = [{
    name: 'business-info',
    url: 'customer/business-info',
    order: 0
}, {
    name: 'owners-details',
    url: 'customer/owners-details',
    order: 1
}, {
    name: 'collect-info',
    url: 'customer/collect-info',
    order: 2
}, {
    name: 'income-expense',
    url: 'customer/income-expense',
    order: 3
}, {
    name: 'financial-details',
    url: 'customer/financial-details',
    order: 4
}, {
    name: 'customer-offer',
    url: 'customer/offer',
    order: 5
}];
