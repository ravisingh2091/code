import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { CommonService } from '../services/common.service';
import { ERROR_MESSAGES } from '../constants/errorMessages';
import { onLogout } from '@utils/+state/utils.action';
import { Store } from '@ngrx/store';

@Injectable()
export class ErrorsInterceptor implements HttpInterceptor {

  constructor(private common: CommonService, private store: Store<any>) { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request)
      .pipe(
        map((res: HttpResponse<any>) => {
          if (!request.url.includes('en.json')) {
            const slug = request.params.get('slug');
            if (res.body && res.body.data && res.body.data.response_data) {
              const { response_data: response } = res.body.data;
              if (response.nextTask) {
                if (response.nextTask && response.nextTask.value !== 'error') {
                  if (response.nextTask.value === 'invalid') {
                    for (const data in response) {
                      if (ERROR_MESSAGES[response[data].status] && typeof response[data].errors === 'string') {
                        this.common.popToast('error', 'Error', ERROR_MESSAGES[response[data].status].error);
                        throw response;
                      }
                    }
                  }
                } else {
                  for (const data in response) {

                    if (response[data].status == 200 || response[data].status == 201) {
                      this.handle2xxErrors(response, data, slug)
                    } else {
                      if (response.nextTask.value === 'invalid') {
                        if (ERROR_MESSAGES[response[data].status] && typeof response[data].errors === 'string') {
                          this.common.popToast('error', 'Error', ERROR_MESSAGES[response[data].status].error);
                          throw response;
                        }
                      }
                      else if (ERROR_MESSAGES[response[data].status] && response[data].errors && response[data].errors.errors
                        && Array.isArray(response[data].errors.errors)) {
                        this.processErrorArray(response, data, slug);
                      } else if (ERROR_MESSAGES[response[data].status] && ERROR_MESSAGES[response[data].status][slug]) {
                        this.common.sendErrorMsg = ERROR_MESSAGES[response[data].status][slug] || ERROR_MESSAGES[response[data].status];
                      } else {
                        this.common.popToast('error', 'Error', 'Please try after some-time');
                        throw response;
                      }
                    }
                  }
                }
              }
            }
          }
          this.common.sendErrorMsg = null;
          return res;
        }),
        catchError(error => {
          // Client Side Error
          if (error && error.error instanceof ErrorEvent) {
          } else {  // Server Side Error
            if (error && error.error) {
              const err = error.error;
              if (ERROR_MESSAGES[err.status]) {
                this.common.popToast('error', 'Error', ERROR_MESSAGES[err.status].error);
                if (err.status === 440) {
                  this.store.dispatch(onLogout({}));
                  this.common.navigate('backend-login');
                }
              } else {
                this.common.popToast('error', 'Error', 'Please try after some-time');
              }
            }
            return throwError(error.error || error);
          }
        })
      );
  }

  handle2xxErrors(response, data, slug) {
    if ((data === 'check_phone' || data === 'check_email') && response[data].status === 200 && slug) {
      if (response[data] && response[data].data && response[data].data.data) {
        const check = response[data].data.data.isExists;
        if (ERROR_MESSAGES[response[data].status][slug][data][check]) {
          this.common.popToast('error', 'Error', ERROR_MESSAGES[response[data].status][slug][data][check]);
          throw response;
        }
      }
    } else if ((data === 'company_name') && response[data].status === 200 && slug && Object.keys(response[data].data.data.result).length === 0) {
      this.common.popToast('error', 'Error', ERROR_MESSAGES[response[data].status][slug][data]);
      throw response;
    } else if(data == 'company_name_reference_update' || data == 'company_name_reference'){
      this.common.popToast('error','Error',ERROR_MESSAGES[response[data].status][slug][data]);
      throw response;
    } else if (data == 'update_user'){
      this.common.popToast('error','Error',ERROR_MESSAGES[response[data].status][slug][data]);
      throw response;
    }
    else if (ERROR_MESSAGES[response[data].status] && response[data].errors && response[data].errors.errors
      && Array.isArray(response[data].errors.errors)) {
      for (const err of response[data].errors.errors) {
        if (ERROR_MESSAGES[response[data].status][slug]) {
          this.common.popToast('error', 'Error', ERROR_MESSAGES[response[data].status][slug][err.type][err.parameter]
            || ERROR_MESSAGES[response[data].status][slug][err.type]);
          throw response;
        } else {
          this.common.popToast('error', 'Error', ERROR_MESSAGES[response[data].status][err.type]);
          this.common.sendErrorMsg = ERROR_MESSAGES[response[data].status][err.type];
          if (response[data].status === 403 && response[data].errors.errors[0].type === 'SESSION_EXPIRED') {
           
            this.store.dispatch(onLogout({}));
            this.common.navigate('backend-login');
          }
          if(response[data].status === 504){
            this.common.popToast('error', 'Error', response[data].errors.message || 'The upstream server is timing out');
          }
          if(response[data].status === 502){
            this.common.popToast('error', 'Error', response[data].errors.message || 'The upstream server is timing out');
          }
          throw response;
        }
      }
    } else if (ERROR_MESSAGES[response[data].status] && ERROR_MESSAGES[response[data].status][slug]) {
      this.common.sendErrorMsg = ERROR_MESSAGES[response[data].status][slug] || ERROR_MESSAGES[response[data].status];
    } else {
      this.common.popToast('error', 'Error', 'Please try after some-time');
      throw response;
    }
  }

  processErrorArray(response, data, slug) {
    for (const err of response[data].errors.errors) {
      if (ERROR_MESSAGES && ERROR_MESSAGES[response[data].status] && ERROR_MESSAGES[response[data].status][slug]) {
        this.common.popToast('error', 'Error', ERROR_MESSAGES[response[data].status][slug][err.type][err.parameter]
          || ERROR_MESSAGES[response[data].status][slug][err.type]);
      } else {
        this.common.sendErrorMsg = ERROR_MESSAGES[response[data].status][err.type];
        this.handleSessionExpire(response, data)

        if (response[data].status === 504 || response[data].status === 502) {
          this.common.popToast('error', 'Error', response[data].errors.message || 'The upstream server is timing out');
        } else {
          this.common.popToast('error', 'Error', ERROR_MESSAGES[response[data].status][err.type]);
        }
      }

      throw response;
    }
  }

  handleSessionExpire(response, data) {
    if (response[data].status === 403 && response[data].errors.errors[0].type === 'SESSION_EXPIRED') {
      this.store.dispatch(onLogout({}));
      this.common.navigate('backend-login');
    }
  }
}
