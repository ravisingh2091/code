import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import { switchMap, take } from 'rxjs/operators';
import { Store } from '@ngrx/store';


@Injectable()
export class HttpServiceInterceptor implements HttpInterceptor {

  constructor(private store: Store<any>) { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const timeStamp = (new Date().getTime()) + '';
    let params = request.params;
    let headers = request.headers.append('X-REGION', environment.region).append('x-tenant-id', environment.tenantID);

    if (request.method.toUpperCase() === 'GET') {
      params = request.params.set('timestamp', timeStamp);
    }

    return this.store.select('app')
      .pipe(
        take(1),
        switchMap((state) => {
          if (state.backendUserData) {
            headers = headers.append('X-SESSION-ID', state.backendUserData.id);
          }
          if (state.appID) {
            headers = headers.append('app_id', state.appID);
          }
          request = request.clone({
            params,
            headers
          });
          return next.handle(request);
        }));
  }
}
