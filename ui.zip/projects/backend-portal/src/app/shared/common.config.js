export const config = {
  version : 'v1',
  layout_type: 'v1',
  date: {
    format: 'MMM d, y, h:mm:ss a',
    timezone: 'EDT'
  },
  conditions: {
    user: {
      // max: -1,
      max: 15,
      block_registry: 'user-role',
      message: "You have exceeded the number of users as per your current plan. Please contact support for further assistance."
    },
    role: {
      // max: -1,
      max: 10,
      block_registry: 'new-role',
      message: "You have exceeded the number of roles as per your current plan. Please contact support for further assistance."
    }
  },
  layout: {
    main_header: {
      rowClass: ['row', 'justify-content-md-center'],
      columnClass: ['col-10'],
      childRowClass: ['row'],
      actionTitle: ['col-7', 'mt-2'],
      filterClass: ['col-7'],
      actionButtonClass: ['col-5', 'text-right']
    },
    main_body: {
      rowClass: ['row', 'justify-content-md-center'],
      columnClass: ['col-10'],
    },
    action_title_header: {
      title: 'User Management',
      row_class: ["row", "mt-2", "mb-2"],
      title_wrapper_class: ["col-7", "pt-2"],
    },
    action_button: {
      button_wrapper_class: [],
      buttons: [
        {
          id: 1,
          parent_id: null,
          title: 'Add New User',
          page_title: 'Add new user',
          registry: 'user-role',
          group: 0,
          next_group: 1,
          button_class: ["btn", "btn-primary-line", "mr-2"],
        },
        {
          id: 2,
          title: 'Back to User Management',
          registry: 'user-list',
          page_title: 'User Management',
          group: 1,
          next_group: 0,
          button_class: ["btn", "btn-primary-line", "mr-2"],
        },
        {
          id: 3,
          parent_id: 0,
          title: 'Role Management',
          registry: 'role-list',
          page_title: 'Role Management',
          group: 0,
          next_group: 2,
          button_class: ["btn", "btn-primary-line", "mr-2"],
        },
        {
          id: 4,
          title: 'Back To User Management',
          registry: 'user-list',
          page_title: 'User Management',
          group: 2,
          next_group: 0,
          button_class: ["btn", "btn-primary-line", "mr-2"],
        },
        {
          id: 5,
          parent_id: 3,
          title: 'Add New Role',
          registry: 'new-role',
          page_title: 'Add new role',
          group: 2,
          next_group: 3,
          button_class: ["btn", "btn-primary-line", "mr-2"],
        },
        {
          id: 6,
          title: 'Back User Management',
          registry: 'user-list',
          page_title: 'User Management',
          group: 3,
          next_group: 0,
          button_class: ["btn", "btn-primary-line", "mr-2"],
        },
        {
          id: 7,
          parent_id: 5,
          title: 'Back To Role Management',
          registry: 'role-list',
          page_title: 'Add new role',
          group: 3,
          next_group: 2,
          button_class: ["btn", "btn-primary-line", "mr-2"],
        },
      ]
    },

    filter_records: {
      'user-list': {
        formClass: [],
        formGroupClass: ["form-group"],
        labelClass: [],
        label: 'Search by  Name/Email/Role',
        searchIconClass: [],
        inputClass: [],
        placeholder: 'Search by  Name/Email/Role',
        filterKeys: ["name", "email_address", "roles.role_name"],
      },
      'role-list': {
        formClass: [],
        formGroupClass: ["form-group"],
        labelClass: [],
        label: 'Search by Role Name',
        searchIconClass: [],
        inputClass: [],
        placeholder: 'Search by Role Name',
        filterKeys: ["role_name", "role_slug"],
      }
    },
    default_component: {
      title: 'User Management',
      page_title: 'User Management',
      registry: 'user-list'
    },
    main_content: {
      style: {
        classes: [],
        css: ``
      },
      create_user: {
        style: {
          classes: [],
          css: ``
        },
        query : {
          slug: "acl-create-user",
        },
        field_config: {
          name: {
            label: 'Name',
            label_class: '',
            field_group_class: ['form-group'],
            column_class: ['col-12', 'mb-3'],
            placeholder: 'Enter Name'
          },
          email_address: {
            label: 'E-mail Address',
            label_class: '',
            field_group_class: ['form-group'],
            column_class: ['col-12', 'mb-3'],
            placeholder: 'Enter Email Address'
          },
          phone: {
            label: 'Mobile',
            label_class: '',
            field_group_class: ['form-group'],
            column_class: ['col-12', 'mb-3'],
            placeholder: 'Enter Mobile Number'
          },
          role: {
            label: 'Role',
            label_class: [],
            field_group_class: ['form-group'],
            column_class: ['col-12', 'mb-3'],
          },
          password: {
            label: 'Password',
            label_class: '',
            field_group_class: ['form-group'],
            column_class: ['col-12', 'mb-3'],
            placeholder: 'Enter Password',
            policies: [
              "Minimum 8 characters and a maximum 50 characters",
              "Mix of uppercase alphabet, lowercase alphabet and digits",
              "Atleast one special character (only @, $, !, %, *, ? and & are allowed)",
              "No spaces"
            ]
          }
        },
        buttons : {
          button_details : [
            {
              name : 'Save & Continue',
              type : 'submit',
              action : 'submit'
            }
          ],
          btn_group_class: ["col-12", "text-right", "pt-3", "p-2"]
        },
        api_data: {
          // admin_email :this.admin_emails,
          // // this data will be send in the api while making post request
          // registration_code: this.userData && this.userData.registration_code  ? this.userData.registration_code :  "",
          // cpa_firm_name: this.userData && this.userData.cpa_firm_name  ? this.userData.cpa_firm_name :  "",
          // backend_user_id: this.userData && this.userData.id ? this.userData.id : '',
          // slug: "backend",
          // from_name:this.environment.from_name,
          // from:this.environment.from,
          // frontend_url: this.environment.affiliate_journey_url,
          // header_logo_path: this.environment.cdnURL+"biz2credit-logo.png",
          // logo2_path: this.environment.cdnURL+"cpa-sig-logo-hed120.png",
          // logo1_path: this.environment.cdnURL+"cpa-sig-logo-hed120.png",
          // logo3_path: this.environment.cdnURL+"b2c-logo.png",
          // is_active: false,
        },
        response_keys: {
          role : 'get_backend_roles',
        },
        api_message: {
          success: 'User created successfully',
          // error: 'Could not create user, Please try again.'
        }
      },
      edit_user: {
        style: {
          classes: [],
          css: ``
        },
        query : {
          slug: "acl-banker-edit",
        },
        field_config: {
          name: {
            label: 'Name',
            label_class: '',
            field_group_class: ['form-group'],
            column_class: ['col-12', 'mb-3'],
            placeholder: 'Enter Name'
          },
          email_address: {
            label: 'E-mail Address',
            label_class: '',
            field_group_class: ['form-group'],
            column_class: ['col-12', 'mb-3'],
            placeholder: 'Enter Email Address'
          },
          phone: {
            label: 'Mobile',
            label_class: '',
            field_group_class: ['form-group'],
            column_class: ['col-12', 'mb-3'],
            placeholder: 'Enter Mobile Number'
          },
          password: {
            label: 'Password',
            label_class: '',
            field_group_class: ['form-group'],
            column_class: ['col-12', 'mb-3'],
            placeholder: 'Enter Password'
          }
        },
        buttons : {
          button_details : [
            {
              name : 'Save & Continue',
              type : 'submit',
              action : 'submit'
            }
          ],
          btn_group_class: ["col-12", "text-right", "pt-3", "p-2"]
        },
        api_data: {
          // this data will be send in the api while making post request
          registration_code:  "",
          cpa_firm_name: "No Firm",
          slug: "backend",
          frontend_url: "google.com",
          header_logo_path: "ppplogo.png",
          logo2_path: "cpa-sig-logo-hed120.png",
          logo1_path: "cpa-sig-logo-hed120.png",
          logo3_path: "b2c-logo.png",
        },
        api_message: {
          success: 'User created successfully',
          error: 'Could not create user, Please try again.'
        }
      },
      create_role: {
          query : {
            slug: 'acl-create-role',
            // cpa_firm_name: this.userData && this.userData.cpa_firm_name  ? this.userData.cpa_firm_name :  "",

          },
          field_config: {
            role: {
              label: 'Role',
              label_class: [],
              field_group_class: ['form-group'],
              column_class: ['col-12'],
              width: '50%',
            },
            reporting_to: {
              label: 'Reporting to',
              label_class: [],
              field_group_class: ['form-group'],
              column_class: ['col-12'],
              width: '50%',
            },
          },
          buttons : {
            button_details : [
              {
                name : 'Save & Continue',
                type : 'submit',
                action : 'submit'
              }
            ],
            btn_group_class: ["col-12", "text-right", "pt-3", "p-2"]
          },
          dynamic_keys: [
            {request_key: 'banker_id', request_value: 'id'}
          ],
          response_keys: {
            role : 'get_backend_roles',
            reporting_to: 'get_backend_user_by_role'
          },
          api_message: {
            success: 'Role assigned successfully',
            error: 'Could not assign role, Please try again.'
          }
      },
      thankyou: {
        query : {
          slug: "acl-thankyou",
        },
        image: 'like.svg',
        title: 'Congratulations',
        sub_title: 'New User Successfully Added. Verification Email sent to the user to activate the profile. The link will be valid only for 24hours. Please ask user to check Junk/Spam Email folder as well.',
        link_title: 'Back to User Management',
        action: {
          id: 1,
          parent_id: null,
          title: 'User List',
          registry: 'user-list',
          group: 0,
          next_group: 1
        }
      },
      action_buttons: [
        {
          title: 'User Management',
          action : {
            description: 'User Listing Component',
            registry: 'user-list'
          }
        },
        {
          title: 'Role Management',
          action : {
            description: 'Role Listing Component',
            registry: 'role-list'
          }
        },
        {
          title: 'Permission Management',
          action : {
            description: 'Permission Listing Component',
            registry: 'permission-list'
          }
        }
      ]
    },
    app_steps: {
      orch_url: '',
      steps: [
        {
          step: 'user-create',
          is_active: false,
          title: 'Create new user',
          next_step: 'role-create',
          order: 1
        },
        {
          step: 'role-create',
          is_active: false,
          title: 'Assign Role',
          next_step: 'thankyou',
          order: 2
        },
        {
          step: 'thankyou',
          is_active: false,
          title: 'Confirmation',
          next_step: null,
          order: 3,
          is_hidden: false
        }
      ]
    },
    role_permission: {
      query : {
        slug: 'acl-role-permission',
        // cpa_firm_name: this.userData && this.userData.cpa_firm_name  ? this.userData.cpa_firm_name :  "",
      },
      response_key: 'get_permissions',
      role_title: {
        name: 'role_title',
        placeholder: 'Create Role Title'
      },
      api_message: {
        success: 'Role created successfully',
        // error: 'Could not create role, Please try again.'
      },
      permission_list: {
        get_permissions: 'get_permissions',
        master_permissions: 'master_permissions',
      },
      tabs: [
        {
          title: 'Permission List',
          type: 'generic_permissions',
          accordions: [
            {
              'title': 'Select All',
              'response_key': 'master_permissions',
              filter: {
                data_from : 'master_permissions',
                key: 'permission_type',
                value: 'generic_master'
              }
            }
          ]
        }
      ],
    },
    create_permission: {
      page_title: 'Add New Permission',
      query : {
        slug: 'acl-permission-create',
        // features_key: 'global.acl.role_count',
        // user_plan_id: this.userActivePlan.user_plan_id,
      },
      action :{
        id: 3,
        parent_id: 0,
        title: 'Role Management',
        page_title: 'Role Management',
        registry: 'role-list',
        group: 0,
        next_group: 2
      },
      field_config: {
        permissions: {
          title: '',
          width: '100%',
          style: {
            'min-height': '300px'
          },
          cross_btn: {
            'height': '25px',
            'padding': '0px',
            'background-color': '#c82333',
            'float': 'right',
            'margin-right': '-32px',
            'margin-top': '36px',
            'min-width': '30px',
          }
        },
        permission_name: {
          label: 'Permission Title',
          label_class: [],
          field_group_class: ['form-group'],
          column_class: ['col-6', 'p-0', 'pr-3', 'float-left'],
          width: '100%',
        },
        permission_slug: {
          label: 'Slug',
          label_class: [],
          field_group_class: ['form-group'],
          column_class: ['col-12', 'p-0', 'pr-3', 'float-left'],
          width: '50%',
        },
        parent_permission_id: {
          label: 'Parent Permission',
          label_class: [],
          field_group_class: ['form-group'],
          column_class: ['col-12', 'p-0', 'pr-3', 'float-left'],
          width: '50%',
        },
        created_at: {
          label: 'Parent Permission',
          label_class: [],
          field_group_class: ['form-group'],
          column_class: ['col-12', 'p-0', 'pr-3', 'float-left'],
          width: '50%',
        },
      },
      api_message: {
        success: 'Permision updated successfully',
        // error: 'Could not update permission, Please try again.'
      }
    },
    user_list: {
      query : {
        slug: 'acl-user-list',
        // cpa_firm_name: this.userData && this.userData.cpa_firm_name  ? this.userData.cpa_firm_name :  "",
      },
      response_key: 'get_backend_user_by_role',
      user_list_columns: [
        {
          key: "count",
          title: "ID",
          type: "count",
        },
        {
          key: "name",
          title:"Name",
          type: "response"
        },
        {
          key: "email_address",
          title:"Email",
          type: "response"
        },
        {
          key: "roles.role_name",
          title:"Role",
          type: "response"
        },
        {
          key: "created_at",
          title:"Date",
          type: "date",
          format: 'medium'
        },
        {
          key: "registration_type",
          title:"Registration Type",
          type: "response",
          hidden: true
        },
        {
          key: "is_active",
          title:"Status",
          type: "checkbox",
          label :{
            1: 'Active',
            0: 'Inactive'
          },
          action: 'update_user_status',
          condition: {key: 'registration_type', value: 'normal'}
        },
        {
          key: "id",
          title:"Action",
          type: "link",
          // condition: {key: 'registration_type', value: this.userData.registration_type === 'normal' ? false:'normal' }
        }
      ],
      pagination: {
        itemsPerPage: 10,
        page: 1
      },
      edit_action: {
        id: 1,
        parent_id: null,
        title: 'Add New User',
        page_title: 'Add New User',
        registry: 'user-role',
        group: 0,
        next_group: 1
      }
    },
    permission_list: {
      query : {
        slug: 'acl-permission-create',
      },
      response_key: 'get_permissions',
      columns: [
        {
          key: "count",
          title: "ID",
          type: "count",
        },
        {
          key: "name",
          title:"Permission",
          type: "response"
        },
        {
          key: "slug",
          title:"slug",
          type: "hidden"
        },
        {
          key: "parent_permission_id",
          title:"Parent Permission",
          type: "parent"
        },
        {
          key: "id",
          title:"Action",
          type: "link",
        }
      ],
      pagination: {
        itemsPerPage: 10,
        page: 1
      }
    },
    edit_banker: {
      query : {
        slug: 'acl-banker-edit',
      },
      response_key: 'delete_permission',
      api_message: {
        success: 'User updated successfully',
        error: 'Could not update user, Please try again.'
      }
    },
    new_role_permission: {
      query : {
        slug: 'acl-new-role',
        // features_key: 'global.acl.role_count',
        // user_plan_id: this.userActivePlan.user_plan_id,
      },
      api_data: {
        // backend_user_id: this.userData && this.userData.id ? this.userData.id : '',
        // cpa_firm_name: this.userData && this.userData.cpa_firm_name  ? this.userData.cpa_firm_name : ''
      },
      api_message: {
        success: 'Role created successfully',
        // error: 'Could not create role, Please try again.'
      }
    },
    role_list: {
      query : {
        slug: 'acl-role-list',
        // cpa_firm_name: this.userData && this.userData.cpa_firm_name  ? this.userData.cpa_firm_name : ''
      },
      action :{
        id: 5,
        parent_id: 3,
        title: 'Add New Role',
        registry: 'new-role',
        group: 2,
        next_group: 2
      },
      response_key: 'get_backend_roles',
      columns: [
        {
          key: "count",
          title: "ID",
          type: "count",
        },
        {
          key: "role_name",
          title:"Title",
          type: "response"
        },
        {
          key: "role_slug",
          title:"Role slug",
          type: "response"
        },
        {
          key: "created_at",
          title:"Date",
          type: "date",
          format: 'medium'
        },
        {
          key: "id",
          title:"Action",
          type: "link",
        }
      ],
      pagination: {
        itemsPerPage: 10,
        page: 1
      }
    },
    update_user_status: {
      query : {
        slug: 'update-user-status',
      },
      response_key: 'update_banker_status',
      api_message: {
        success: 'Status updated successfully',
        error: 'Could not update status, Please try again.'
      }
    },
    get_role_permission_mapping: {
      query : {
        slug: 'get-role-permission-mapping',
      },
      response_key: 'get_role_permissions'
    },
    update_role_permission: {
      query : {
        slug: 'acl-update-new-role',
      },
      api_message: {
        success: 'Role updated successfully',
        // error: ''
      }
      // response_key: '_role_permissions'
    }
  },
  urls: {
      orch_url:  "",
      get_taskinfo: "v2/tasks",
      save_taskinfo: "v2/tasks"
  }
};
