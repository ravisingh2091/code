import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { FormGroup, FormArray } from '@angular/forms';
import { FormFieldInterface } from '../../interfaces/form-fields.interface';

declare let require: any;

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss']
})
export class DynamicFormComponent implements OnInit, OnChanges {
@Input() formIndex:Number;
  @Input() fields: FormFieldInterface[] = [];
  @Input() group: FormGroup;
  @Input() slug: string;
  @Input() parent:string;
  @Input() remove: string;
  @Input() addHide: Boolean;
  @Input() accordion: Boolean;
  @Input() uploadedFiles: any;
  cssList = require('../../../../assets/json/css.json');
  pageCssJson: any;

  constructor() { }

  ngOnChanges(): void {
    this.pageCssJson = this.cssList[this.slug];
    this.fields = this.fields.map((el) => {
      const field = Object.assign({}, el);
      if (this.pageCssJson) {
        const fieldCss = this.pageCssJson[field.type];
        if (fieldCss) {
          if (fieldCss[field.name]) {
            field.css = fieldCss[field.name];
          } else if (fieldCss.common) {
            field.css = fieldCss.common;
          } else {
            field.css = fieldCss.parent;
          }
        }
      } else {
        field.css = null;
      }
      return field;
    });
  }

  ngOnInit(): void {
  }

  checkArray(val): boolean {
    return Array.isArray(val);
  }

  checkValue(group: FormGroup, field: FormFieldInterface): boolean {
    if (this.checkArray(field.visible.value) && (field.visible.value.indexOf(group.get(field.visible.key).value) > -1)) {
      return true;
    } else if (field.visible && field.visible.value === group.get(field.visible.key).value) {
      return true;
    } else {
      if (group.get(field.name)) {
        group.get(field.name).reset(field.value);
      }
      if (field.multiple) {
        const formArr = group.get(field.name) as FormArray;
        for (let i = formArr.controls.length; i > 0; i--) {
          formArr.removeAt(i);
        }
      }
      return false;
    }
    // }
  }

}
