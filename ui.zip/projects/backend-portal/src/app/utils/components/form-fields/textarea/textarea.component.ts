import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '../../../interfaces/form-fields.interface';

@Component({
  selector: 'app-textarea',
  templateUrl: './textarea.component.html',
  styleUrls: ['./textarea.component.scss']
})
export class TextareaComponent implements OnInit {

  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  indexVal: number;

  constructor() { }

  ngOnInit(): void {
    this.indexVal = new Date().getTime();
  }

}
