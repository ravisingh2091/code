import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { CommonService } from '@shared/services/common.service';
import { Options, LabelType } from 'ng5-slider';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss']
})
export class SliderComponent implements OnInit {

  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  sliderManualRefresh: EventEmitter<void> = new EventEmitter<void>();
  newOptions: Options;
  value: number;

  constructor(private common: CommonService) { }

  ngOnInit(): void {
    this.common.masterData
      .subscribe((data: any) => {
        if (data && data[this.field.name]) {
          this.field.slider = data[this.field.name];
          this.newOptions = this.createOptions();
          if (!this.group.get(this.field.name).value) {
            this.value = this.field['slider'].min;
            this.group.get(this.field.name).patchValue(this.field['slider'].min);
          }
          else {
            this.value = this.group.get(this.field.name).value;
          }
        } else if (this.field.config && this.field.config && this.field.config.rules) {
          this.field.slider = {};
          this.field.config.rules.forEach((conf) => {
            switch (conf.name) {
              case 'min':
                this.field.slider.min = conf.value;
                if (!this.group.get(this.field.name).value) {
                  this.value = this.field.slider.min;
                  this.group.get(this.field.name).patchValue(this.field['slider'].min);
                }
                break;
              case 'max':
                this.field.slider.max = conf.value;
                break;
              case 'step':
                this.field.slider.step = conf.value;
                break;
            }
          });

          this.newOptions = this.createOptions();
        } else {
          this.field.slider = {}
          this.field.slider.min = 1;
          this.field.slider.max = 100;
          this.field.slider.step = 1;
          this.newOptions = this.createOptions();
          if (!this.group.get(this.field.name).value) {
            this.value = this.field['slider'].min;
            this.group.get(this.field.name).patchValue(this.field['slider'].min);
          }
          else {
            this.value = this.group.get(this.field.name).value;
          }
        }
      });
  }


  /**
   * function to create slider options
   */
  createOptions(): any {

    let defaultTicksArray: any = [
      this.field['slider'].min,
      this.field['slider'].max
    ];

    if (this.field.config && this.field.config.step_label) {
      defaultTicksArray = [];
      let stepCounter = this.field['slider'].min;
      while (stepCounter <= this.field['slider'].max) {
        if (this.field.config.step_legend && this.field.config.step_legend[stepCounter]) {
          defaultTicksArray.push({ value: stepCounter, legend: this.field.config.step_legend[stepCounter] });
        }
        stepCounter += 1;
      }

      return {
        floor: this.field['slider'].min,
        ceil: this.field['slider'].max,
        step: this.field['slider'].step,
        showTicks: true,
        stepsArray: defaultTicksArray,
        translate: (value, lebel: LabelType) => {
          return this.field.config.step_legend[value] ? this.field.config.step_legend[value] : value;
        }
      };
    }

    return {
      floor: this.field['slider'].min,
      ceil: this.field['slider'].max,
      step: this.field['slider'].step,
      showTicksValues: true,
      ticksArray: defaultTicksArray,
      getLegend: (value: number): string => {
        if (this.field.type === 'range_amount') {
          return '$' + value / 1000 + 'K';
        }
        else if (this.field.type === 'range_percentage') {
          return value + ' %';
        } else if (this.field.config) {
          return value + '';
        } else {
          if (value > 1) {
            return value + ' Months';
          }
          else {
            return value + ' Month';
          }
        }
      }
    };
  }

  manualChangeAmount(event: any): Event {
    event = (event + '').replace(/,/g, '');
    event = parseInt(event, 10);

    if (isNaN(event)) {
      event = this.field.slider.min;
    }
    if (event > this.field.slider.max) {
      this.group.controls[this.field.name].setErrors({ incorrect: true });
      return this.field.slider.max;
    }
    if (event < this.field.slider.min) {
      this.group.controls[this.field.name].setErrors({ incorrect: true });
      return this.field.slider.min;
    }
    return event;
  }

  storeAmount(value): void {
    this.group.get(this.field.name).patchValue(value);
  }

}
