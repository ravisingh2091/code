import { Component, OnInit, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
// import { FormFieldInterface } from '../../../interfaces/form-fields.interface';
import { CommonService } from '@shared/services/common.service';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';


@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss']
})
export class CheckboxComponent implements OnInit, AfterViewInit {


  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  indexVal: number;
  marked = false;
  @ViewChild('placeHolder') placeHolder: ElementRef;
  constructor(private common: CommonService, private formGenerate: FormGenerateService) { }

  ngOnInit(): void {

    this.indexVal = new Date().getTime();
    this.common.masterData
      .subscribe((data: any) => {
        if (data) {
          if (data[this.field.name]) {
            this.field.options = data[this.field.name].data.data;
          }
        }
      });

  }

  ngAfterViewInit() {
    if (this.placeHolder && this.placeHolder.nativeElement.innerHTML.match('.placeholder.')) {
      this.placeHolder.nativeElement.innerHTML = 'Please Select';
    }
  }

}
