import { Component, OnInit } from '@angular/core';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { CommonService } from '@shared/services/common.service';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
})
export class ButtonComponent implements OnInit {
  // @ViewChild(BusinessInfoComponent, {static: true}) businessInfo: BusinessInfoComponent;
  // @ViewChild('pRef', {static: true}) pRef: ElementRef;
  field: FormFieldInterface;
  slug: string;
  constructor(private common: CommonService) {
  }
  onClick($event): void {
    this.common.businessInfoFormSubmit = $event;
  }

  ngOnInit(): void {
  }
}
