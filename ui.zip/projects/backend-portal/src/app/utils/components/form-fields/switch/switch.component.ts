import { Component, OnInit } from '@angular/core';
import { FormFieldInterface } from '../../../interfaces/form-fields.interface';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-switch',
  templateUrl: './switch.component.html',
  styleUrls: ['./switch.component.scss']
})
export class SwitchComponent implements OnInit {

  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  indexVal: number;

  constructor() { }

  ngOnInit(): void {
    this.indexVal = new Date().getTime();
  }

}
