
// import { Component, OnInit, Injectable, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
// import { NgbDateStruct, NgbCalendar, NgbDateAdapter, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';

// import { CommonService } from '@shared/services/common.service';
// import { FormGenerateService } from '@shared/services/form-generate.service';

// import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
// import { FormGroup } from '@angular/forms';
// /**
//  * Service handles how to save the data  in the form
//  */
// @Injectable()
// export class CustomAdapter extends NgbDateAdapter<string> {
//   readonly DELIMITER = '-';

//   pad2(number) {
//     return (number < 10 ? '0' : '') + number
//   }

//   fromModel(value: string): NgbDateStruct {
//     let result: NgbDateStruct = null;
//     if (value && value.length) {
//       const date = new Date(value)
//       result = {
//         day: date.getDate(),
//         month: date.getMonth() + 1,
//         year: date.getFullYear()
//       };
//     }
//     return result;
//   }

//   toModel(date: NgbDateStruct): string {
//     let iso_date: string = null;
//     if (date) {
//       const new_date = new Date(date.year, date.month - 1, date.day);
//       iso_date = new_date.toISOString();
//     }
//     // Some error coming when returning iso_date
//     return iso_date;
//   }
// }

// /**
//  * This Service handles how the date is shown in the field
//  */
// @Injectable()
// export class CustomDateParserFormatter extends NgbDateParserFormatter {

//   readonly DELIMITER = '/';

//   pad2(number) {
//     return (number < 10 ? '0' : '') + number
//   }

//   parse(value: string): NgbDateStruct {
//     let result: NgbDateStruct = null;
//     if (value && value.length) {
//       const date = value.split(this.DELIMITER);
//       result = {
//         day: parseInt(date[0], 10),
//         month: parseInt(date[1], 10),
//         year: parseInt(date[2], 10)
//       };
//     }
//     return result;
//   }

//   format(date: NgbDateStruct): string {
//     let result: string = null;
//     if (date) {
//       result = this.pad2(date.month) + this.DELIMITER + this.pad2(date.day) + this.DELIMITER + date.year;
//     }
//     return result;
//   }
// }

// @Component({
//   selector: 'app-date',
//   templateUrl: './date.component.html',
//   styleUrls: ['./date.component.scss']
// })
// export class DateComponent implements OnInit {
//   @ViewChild('infoTip') infoTip: ElementRef;
//   field: FormFieldInterface;
//   group: FormGroup;
//   slug: String;
//   model: NgbDateStruct;
//   date: { year: number, month: number };
//   index_val: Number;
//   today = new Date();
//   currentMonth = this.today.getMonth();
//   currentDate = this.today.getDate();
//   currentYear = this.today.getFullYear();
//   maxDate: any;
//   minDate: any =  {month: 1, year: 1900,day : 1};
//   constructor(private calendar: NgbCalendar, config: NgbDateAdapter<string>) {
//   }

//   selectToday() {
//     this.model = this.calendar.getToday();
//   }

//   ngOnInit() {
//     const currentDate = new Date();
//     this.index_val = currentDate.getTime();
//     this.field.validations.forEach((validation) => {
//       const date = { year: currentDate.getFullYear(), month: currentDate.getMonth() + 1, day: currentDate.getDate() };
//       switch (validation.validations) {
//         case 'tommorow':
//           date.day += 1;
//           break;
//         case 'yesterday':
//           date.day -= 1;
//           break;
//       }
//       switch (validation.name) {
//         case 'max':
//           this.maxDate = date;
//           break;
//         case 'min':
//           this.minDate = date;
//           break;
//       }
//     });
//   }

//   ngAfterViewInit() {
//     if (!this.infoTip.nativeElement.title) {
//       this.infoTip.nativeElement.hidden = true;
//     }
//   }
// }





import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '../../../interfaces/form-fields.interface';

@Component({
  selector: 'app-date',
  templateUrl: './date.component.html',
  styleUrls: ['./date.component.scss']
})
export class DateComponent implements OnInit {

  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  indexVal: number;

  constructor() { }

  ngOnInit(): void {
    this.indexVal = new Date().getTime();
  }

}
