import { Component, OnInit, ElementRef, ViewChild, Input } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { FormFieldInterface } from '../../../interfaces/form-fields.interface';
import { CommonService } from '@shared/services/common.service';

@Component({
  selector: 'app-file',
  templateUrl: './file.component.html',
  styleUrls: ['./file.component.scss'],
})
export class FileComponent implements OnInit {
  selectedFiles: any[] = [];
  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  uploadedFiles: any;
  @ViewChild('fileInput') fileInput: ElementRef;

  constructor(private common: CommonService) { }

  ngOnInit(): void {
    this.group.addControl('file_data', new FormControl(null));
  }

  deselect(file,index) {
    this.selectedFiles = [...this.group.get('file_data').value];
    this.selectedFiles.splice(index,1);
    this.common.businessInfoFileUpload = this.selectedFiles;
    this.group.get('file_data').setValue(this.selectedFiles);
    this.group.get('business_pan_file').setValue(this.selectedFiles);
    if(this.selectedFiles.length == 0){
      this.group.get('show_upload_pan_file').setValue(false);
      this.group.get('business_pan_file').setValue(null);
    }
  }

  onSelectFile(event, type) {
    if (event) {
      if(type === 'select'){
        this.selectedFiles = event.target.files;
        this.group.get('file_data').setValue(this.selectedFiles);
      }
      if(type === 'drag') {
        this.selectedFiles = event;
      }
      this.group.get('file_data').setValue(this.selectedFiles);
      this.common.businessInfoFileUpload = this.selectedFiles;
    }
  }

  calculateSize(size: number) {
    let filesize = null;
    if (size < 1000) {
        filesize = `${size} bytes`;
    } else if (size < 1000 * 1000) {
        filesize = `${size / 1000} kb`;
    } else if (size < 1000 * 1000 * 1000) {
        filesize = `${size / 1000 / 1000} mb`;
    } else {
        filesize = `${size / 1000 / 1000 / 1000} gb`;
    }
    return filesize;
  }

  // onDelete(index) {
  //   let uploadedFiles = this.group.get('file_data').value;
  //   uploadedFiles.splice(index, 1);
  //   this.group.get('file_data').setValue(uploadedFiles);
  //   this.fileInput.nativeElement.value = '';
  // }
  onDelete(file,index){
    let files = [...this.selectedFiles];
    this.common.fileDelete = {file, index};
    files.splice(index,1)
    this.selectedFiles = files;
  }

}
