import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CommonService } from '@shared/services/common.service';
import { FormFieldInterface } from '../../../interfaces/form-fields.interface';

@Component({
  selector: 'app-radio',
  templateUrl: './radio.component.html',
  styleUrls: ['./radio.component.scss']
})
export class RadioComponent implements OnInit {

  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  indexVal: number;

  constructor(private common: CommonService) { }

  ngOnInit(): void {
    this.indexVal = new Date().getTime();
    this.common.masterData
      .subscribe((data: any) => {
        if (data[this.field.name]) {
          this.field.options = data[this.field.name].data.data;
        }
      });

  }

}
