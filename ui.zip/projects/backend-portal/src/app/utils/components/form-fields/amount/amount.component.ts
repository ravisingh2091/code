import { Component, OnInit } from '@angular/core';
import { FormFieldInterface } from '../../../interfaces/form-fields.interface';
import { FormGroup } from '@angular/forms';

import { environment } from '@env/environment';

@Component({
  selector: 'app-amount',
  templateUrl: './amount.component.html',
  styleUrls: ['./amount.component.scss']
})
export class AmountComponent implements OnInit {

  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  currency: string;
  indexVal: number;

  constructor() { }

  ngOnInit(): void {
    this.indexVal = new Date().getTime();
    if (environment.region === "in") {
      this.currency = "Rs";
    } else if (environment.region === "usa") {
      this.currency = "$";
    } else {
      this.currency = " ";
    }
  }

}
