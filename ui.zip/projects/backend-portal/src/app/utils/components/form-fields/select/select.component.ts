import { Component, OnInit } from '@angular/core';
import { CommonService } from '@shared/services/common.service';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '../../../interfaces/form-fields.interface';
import { Store, select } from '@ngrx/store';
import { take } from 'rxjs/operators';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss']
})
export class SelectComponent implements OnInit {
  formIndex: number;
  parent: string;
  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  options: Array<any>;
  indexVal: number;
  Data: any;
  rootStateSubscription: Subscription;
  masterData: any;
  classOfActivity: any;
  constructor(private common: CommonService,private store: Store<any>) { }

  ngOnInit(): void {


    this.indexVal = new Date().getTime();

    this.common.masterData.subscribe((data: any) => {
      this.Data = data;
      let filedName = this.field.name + '_' + this.formIndex;
      if (!(filedName in data)) {
        filedName = this.field.name;
      }

      if (data && data[filedName]) {
        this.field = { ...this.field, options: data[filedName].data.data };
        this.group.get(this.field.name).patchValue(this.group.get(this.field.name).value);
      }
    });
    
    // rootstate subscription
    this.rootStateSubscription = this.store
    .pipe(select('app'), take(1))
    .subscribe((rootState) => {
      if (rootState) {
        if(rootState.masterData){
          this.masterData = rootState.masterData
        }
        if(rootState.classOfActivityData){
              this.classOfActivity=rootState.classOfActivityData
        }


      }
    });
  }

/*executes when we switch or select option of entity type on owners page*/
  onChange(index?: any): void {
    if (this.field.name === 'state') {
      const stateValue = this.group.get(this.field.name).value;
      const cities = this.field?.options?.filter(value => value.id === stateValue)[0].cities;


      this.common.sendMasterData({
        ...this.Data,
        [`city_${this.formIndex}`]: { data: { data: cities } }
      });
    }

    if (this.field.name === 'entity_type') {
      const entityValue = this.group.get(this.field.name).value;
      if (entityValue === this.masterData?.entity_type?.data?.data[1].id) {
        this.group.get('type_of_address').setValue('6c20bf7e27105c78a37f9a70');
        this.group.get('type_of_address').disable();
      } else {
        this.group.get('type_of_address').setValue(null);
        this.group.get('type_of_address').enable();
      }
      const isCoApplicant = this.group.get('is_coApplicant').value;
      if(isCoApplicant!=null && isCoApplicant!=undefined){
        if (isCoApplicant === true) {
          this.group.get('coapplicant_type').setValue('5dd4ec0eebc4a682b8f6921a');
          this.group.get('credit_bureau').setValue(true);
          this.group.get('coapplicant_type').disable();
        }else{
          this.group.get('coapplicant_type').setValue('5dd4ec0febc4a682b8f6921b');
          this.group.get('coapplicant_type').disable();
          this.group.get('credit_bureau').setValue(true);
        }
      }
      
      const relations = this.field?.options?.filter(value => value.id === entityValue)[0].relationships;
      const addressType = this.field?.options?.filter(value => value.id === entityValue)[0].addressType;
      const typeOfEntity = this.field?.options?.filter(value => value.id === entityValue)[0].typeOfEntity;
      const classOfActivity=this.classOfActivity
      this.common.sendMasterData({
        ...this.Data,
        [`relationship_${this.formIndex}`]: { data: { data: relations } },
        [`type_of_address_${this.formIndex}`]: { data: { data: addressType } },
        [`business_constitution_${this.formIndex}`]: { data: { data: typeOfEntity } },
        [`class_of_activity_${this.formIndex}`]: { data: { data: classOfActivity } }
      });

      this.handleOwnerDetailsChange(index);
    }
  }

 /* to set owner-details value in form fields on toggling of entity type*/
  handleOwnerDetailsChange(index) {
    const entityValue = this.group.get(this.field.name).value;
    const formData = this.common.getDataFromStorage('owners-data');
    
  if (formData && (index < formData.length) && entityValue === formData[index]?.entity_type )  {
      switch(entityValue) {
        case this.masterData?.entity_type?.data?.data[1]?.id:
          this.group.patchValue({busines_name: formData[index]?.busines_name});
          this.group.patchValue({relationship: formData[index]?.relationship});
          this.group.patchValue({class_of_activity: formData[index]?.class_of_activity});
          this.group.patchValue({business_constitution: formData[index]?.business_constitution});
          break;
        case this.masterData?.entity_type?.data?.data[0]?.id:
          this.group.patchValue({individual_name: formData[index]?.individual_name});
          this.group.patchValue({date_of_birth: formData[index]?.date_of_birth});
          this.group.patchValue({gender: formData[index]?.gender});
          break;
      }
    }
  }
}


