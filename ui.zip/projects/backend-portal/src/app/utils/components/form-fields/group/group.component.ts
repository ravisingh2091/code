import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { FormFieldInterface } from '../../../interfaces/form-fields.interface';

@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.scss']
})
export class GroupComponent implements OnInit {

  isFirstOpen = true
  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  remove: string;
  // accordionName: string = 'Owner';
  addHide: Boolean;
  accordion: Boolean;
  fields: any = [];

  constructor(
    private formGenerate: FormGenerateService,
    private translate: TranslateService
  ) { }

  ngOnInit(): void {
  }

  /**
   * function to get controls of a form array
   */
  get control(): any {
    return (this.group.get(this.field.name) as FormGroup).controls;
  }
  /**
   * function to get accordion Name
   */
  accordionName(is_coApplicant, count): any {
    let formArray = this.fieldArray.controls;
    let ownerCount = 0;
    let coApplicantCount = 0;
    for (let i = 0; i < count; i++) {
      if (formArray[i].get('is_coApplicant').value) {
        coApplicantCount++
      } else {
        ownerCount++;
      }
    }
    let key = this.translate.instant(this.slug + '.label.' + this.field.name);
    return is_coApplicant ? `${key['co_applicant']} ${coApplicantCount}` : `${key['owner']} ${ownerCount}`
  }

  /**
   * function to add controls to a formarray
   */
  addMore(value): void {
    const formArray = this.group.get(this.field.name) as FormArray;
    let formObject = this.formGenerate.createControl(this.field.group_fields)
    formArray.push(formObject);
    let i=formArray.controls.length - 1
    formArray.controls[i].get('credit_bureau').setValue(true);
    if (value === 'co_applicant') {
      formArray.controls[formArray.controls.length - 1].get('is_coApplicant').setValue(true);
    } else {
      formArray.controls[formArray.controls.length - 1].get('is_coApplicant').setValue(false);
    }
  }

  /**
   * function to get formarray
   */
  get fieldArray(): FormArray {
    return this.group.controls[this.field.name] as FormArray;
  }

  removeForm(i, len): void {
    if (len === 1) {
      this.group.reset();
    } else {
      this.fieldArray.removeAt(i);
    }

  }

  /**
   * function to get total of a field
   */
  get total(): string {
    let total = 0;
    for (const group of this.control) {
      total += +group.get(this.field.total).value;
    }
    return total.toLocaleString();
  }
}
