import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '../../../interfaces/form-fields.interface';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.scss']
})
export class PasswordComponent implements OnInit {

  @ViewChild('passpolicy') passpolicy: ElementRef;

  field: FormFieldInterface;
  group: FormGroup;
  slug: string;
  indexVal: number;

  constructor() { }

  ngOnInit(): void {
    this.indexVal = new Date().getTime();
  }
  changeType(field,button){
    button.target.classList.toggle('eyeclose');
    button.target.classList.toggle('eye');
    if(field.type==='password'){
      field.type='text';
    }
    else{
      field.type='password';
    }
  }

}
