import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '../../../interfaces/form-fields.interface';

@Component({
  selector: 'app-tel',
  templateUrl: './tel.component.html',
  styleUrls: ['./tel.component.scss']
})
export class TelComponent implements OnInit {

  field: FormFieldInterface;
  group: FormGroup;
  slug: string;

  constructor() { }

  ngOnInit(): void {
  }

}
