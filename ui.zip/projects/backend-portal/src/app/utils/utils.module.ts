import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslateModule } from '@ngx-translate/core';
import { HttpClientModule } from '@angular/common/http';

// Components
import { DynamicFormComponent } from './components/dynamic-form/dynamic-form.component';
import {
  TextComponent, NumberComponent, PasswordComponent, RadioComponent,
  SliderComponent, CheckboxComponent, SwitchComponent, TelComponent, DateComponent,
  SelectComponent, GroupComponent, TextareaComponent, AmountComponent, ButtonComponent, FileComponent
} from './components/form-fields';

// Directives
import { FieldDirective } from './directives/field.directive';
import { NumberDirective } from './directives/number.directive';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxMaskModule } from 'ngx-mask';
import { DndDirective } from './directives/dnd.directive';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { Ng5SliderModule } from 'ng5-slider';


@NgModule({
  declarations: [
    DynamicFormComponent,
    TextComponent,
    PasswordComponent,
    FieldDirective,
    RadioComponent,
    CheckboxComponent,
    AmountComponent,
    TelComponent,
    GroupComponent,
    SwitchComponent,
    DateComponent,
    TextareaComponent,
    NumberComponent,
    SelectComponent,
    SliderComponent,
    NumberDirective,
    FileComponent,
    DndDirective,
    ButtonComponent,
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    Ng5SliderModule,
    ReactiveFormsModule,
    AccordionModule,
    TranslateModule.forChild(),
    NgxMaskModule.forChild()
  ],
  exports: [
    ReactiveFormsModule,
    DynamicFormComponent,
    TextComponent,
    PasswordComponent,
    FieldDirective,
    RadioComponent,
    CheckboxComponent,
    AmountComponent,
    TelComponent,
    GroupComponent,
    SwitchComponent,
    DateComponent,
    TextareaComponent,
    NumberComponent,
    SelectComponent,
    SliderComponent,
    NumberDirective,
    DndDirective,
    FileComponent,
    ButtonComponent,
    Ng5SliderModule
  ]
})
export class UtilsModule { }
