import { FieldDirective } from './field.directive';

describe('FormDirective', () => {
  it('should create an instance', () => {
    const directive = FieldDirective;
    expect(directive).toBeTruthy();
  });
});
