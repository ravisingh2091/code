import {
  ComponentFactoryResolver,
  Directive,
  Input,
  ViewContainerRef,
  OnInit,
  OnChanges
} from '@angular/core';
import { FormGroup } from '@angular/forms';



// Interfaces
import { FormFieldInterface } from '../interfaces/form-fields.interface';

// Components
import {
  TextComponent, NumberComponent, PasswordComponent, RadioComponent,
  SliderComponent, CheckboxComponent, SwitchComponent, TelComponent, DateComponent,
  SelectComponent, GroupComponent, TextareaComponent, AmountComponent, FileComponent, ButtonComponent
} from '../components/form-fields';

const componentMapper = {
  text: TextComponent,
  number: NumberComponent,
  tel_number: NumberComponent,
  email: TextComponent,
  password: PasswordComponent,
  radio: RadioComponent,
  range: SliderComponent,
  range_amount: SliderComponent,
  range_percentage: SliderComponent,
  checkbox: CheckboxComponent,
  switch: SwitchComponent,
  tel: TelComponent,
  date: DateComponent,
  select: SelectComponent,
  group: GroupComponent,
  textarea: TextareaComponent,
  amount: AmountComponent,
  file: FileComponent,
  button: ButtonComponent,
  hidden: null
};

@Directive({
  selector: '[appField]'
})
export class FieldDirective implements OnInit {
  @Input() field: FormFieldInterface;
  @Input() group: FormGroup;
  @Input() slug: string;
  @Input() remove: string;
  @Input() addHide: Boolean;
  @Input() accordion: Boolean;
  @Input() formIndex:Number;
  @Input() parent:string;
  @Input() uploadedFiles: any;
  componentRef: any;

  constructor(
    private resolver: ComponentFactoryResolver,
    private container: ViewContainerRef
  ) { }

  ngOnInit(): void {
    if (componentMapper[this.field.type]) {
      const factory = this.resolver.resolveComponentFactory(
        componentMapper[this.field.type]
      );
      this.componentRef = this.container.createComponent(factory);
      this.componentRef.instance.field = this.field;
      this.componentRef.instance.group = this.group;
      this.componentRef.instance.parent = this.parent;
      this.componentRef.instance.slug = this.slug;
      this.componentRef.instance.remove = this.remove;
      this.componentRef.instance.addHide = this.addHide;
      this.componentRef.instance.accordion = this.accordion;
      this.componentRef.instance.formIndex = this.formIndex;
      this.componentRef.instance.uploadedFiles = this.uploadedFiles;
    }
  }
}
