import { Directive, Output, EventEmitter, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appDnd]'
})
export class DndDirective {
  @Output() onFileDropped = new EventEmitter<any>();
  @HostBinding('style.background-color') public background = '#11884308';
  @HostBinding('style.opacity') public opacity = '1';
  constructor() { }

  //Dragover Listner
  @HostListener('dragover', ['$event']) onDragover(evt){
    evt.stopPropagation();
    evt.preventDefault();
    this.background = '#9ecbec';
    this.opacity = '0.8';
  }

  //DragLeave Listener
  @HostListener('dragleave',  ['$event']) public onDragLeave(evt){
    // evt.stopPropogation();
    // if (!evt) var evt = window.event
    evt.cancelBubble = true;
    if (evt.stopPropagation) evt.stopPropagation();
    evt.preventDefault();
    this.background = '#11884308'
    this.opacity = '1'
  }

  //Drop Listener
  @HostListener('drop',  ['$event']) public ondrop(evt){
    evt.preventDefault();
    evt.stopPropagation();
    this.background = '#f5fcff'
    this.opacity = '1'
    let files = evt.dataTransfer.files;
    if (files.length > 0) {
      this.onFileDropped.emit(files)
    }
  }

  // @HostListener('dragover', ['$event']) blockDrop(e: MouseEvent) {
  //   e.preventDefault();
  // }


}
