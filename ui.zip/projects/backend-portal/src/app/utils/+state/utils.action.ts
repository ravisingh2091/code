import { createAction, props } from '@ngrx/store';

export const addNextTask = createAction('[UtilState] Add Next Task', props<{ nextTask: string }>());
export const addBackendUserDetails = createAction('[UtilState] Add Backend User Details', props<{ userData: any }>());
export const addUserDetails = createAction('[UtilState] Add User Details', props<{ userData: any }>());
export const addAppID = createAction('[UtilState] Add App ID', props<{ appID: string }>());
export const addBusinessID = createAction('[UtilState] Add Business ID', props<{ businessID: string }>());
export const onLogout = createAction('[UtilState] App on Logout', props<{} | any>()); //@TODO
export const storeMasterData = createAction('[UtilState] Add master data to store', props<{ masterData: any } >());
export const storeclassOfActivityData = createAction('[UtilState] Add classOfActivityData data to store', props<{ classOfActivityData: any } >());
