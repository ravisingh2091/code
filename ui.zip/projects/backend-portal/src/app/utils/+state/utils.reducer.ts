import { createReducer, Action } from '@ngrx/store';

const utilReducer = createReducer({});

export function reducer(state: any, action: Action) {
    return utilReducer(state, action);
}
