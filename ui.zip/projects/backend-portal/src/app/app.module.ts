import { AppStateFacade } from './+state/app.facade';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { StoreModule, MetaReducer, META_REDUCERS } from '@ngrx/store';
import * as fromRoot from './+state/app.reducers';

import { updateRootState, storageMetaReducer } from './+state/app-meta.reducer';
import { EffectsModule } from '@ngrx/effects';
import { HttpClientModule } from '@angular/common/http';
import { CommonService } from '@shared/services/common.service';

export function getMetaReducers(storageService: CommonService): MetaReducer<any> {
  return storageMetaReducer(storageService);
}

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    CoreModule,
    AppRoutingModule,
    HttpClientModule,
    StoreModule.forRoot(
      { [fromRoot.APP_KEY]: fromRoot.appReducer },
      { metaReducers: [updateRootState] }
    ),
    EffectsModule.forRoot([])
  ],
  bootstrap: [AppComponent],
  providers: [
    AppStateFacade,
    {
      provide: META_REDUCERS, multi: true, deps: [CommonService], useFactory: getMetaReducers,

    }
  ]
})
export class AppModule { }
