import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent, ForgetPasswordComponent } from './core/components';
import { ChangePasswordComponent } from './core/components/change-password/change-password.component';
import { AuthLazyGuard } from './guard/auth-lazy.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'forgot-password',
    // loadChildren: () => import('./core/core.module')
    //   .then(m => m.CoreModule),
    // canLoad: [AuthLazyGuard],
    component:ForgetPasswordComponent
  },
  {
    path: 'change-password',
    component: ChangePasswordComponent,
    // loadChildren: () => import('./core/core.module')
    //   .then(m => m.CoreModule),
    //  canLoad: [AuthLazyGuard],
    canActivate: [AuthLazyGuard],

  },
  {
    path: 'reset-password/:id',
    loadChildren: () => import('./core/components/reset-password/reset-password.component')
      .then(m => m.ResetPasswordComponent),
    canLoad: [AuthLazyGuard]
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./feature/dashboard/dashboard.module')
      .then(m => m.DashboardModule),
      canLoad: [AuthLazyGuard]
  },
  {
    path: 'customer',
    loadChildren: () => import('./feature/customer/customer.module')
      .then(m => m.CustomerModule),
    canLoad: [AuthLazyGuard],
  },
  {
    path: 'application',
    loadChildren: () => import('./feature/application/application.module')
      .then(m => m.ApplicationModule),
      canLoad: [AuthLazyGuard],
  },
  {
    path: 'user-management',
    loadChildren: () => import('./feature/manage-users/manage-users.module')
      .then(m => m.ManageUsersModule),
      canLoad: [AuthLazyGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
