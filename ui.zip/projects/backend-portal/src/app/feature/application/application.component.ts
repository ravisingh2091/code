import { Component, OnInit } from '@angular/core';
import { CommonService } from '@shared/services/common.service';

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.scss']
})
export class ApplicationComponent implements OnInit {

  constructor(private common: CommonService) { }

  ngOnInit(): void {
    this.common.loginEmit = true;
  }

}
