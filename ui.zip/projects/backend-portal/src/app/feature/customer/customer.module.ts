import { AddCoApplicantComponent } from './components/add-co-applicant/add-co-applicant.component';
import { ApplicationOverviewComponent } from './components/application-overview/application-overview.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import { StoreModule } from '@ngrx/store';

import { SharedLazyModule } from '@shared/shared-lazy.module';
import { EffectsModule } from '@ngrx/effects';

import { BusinessInfoFacade } from './components/business-info/+states/business-info.facade';
import { CreateUserFacade } from './components/listing/+states/createUser.facade';
import * as fromCreateUser from './components/listing/+states/createUser.reducer';
import * as fromBusinessInfo from './components/business-info/+states/business-info.reducers';
import * as fromGSTProfile from './components/gst-profile/+states/gst-profile.reducers';
import { CreateUserEffects } from './components/listing/+states/createUser.effects';
import { BusinessInfoEffects } from './components/business-info/+states/business-info.effects';

import { CustomerRoutingModule } from './customer-routing.module';
import { BusinessInfoComponent } from './components/business-info/business-info.component';
import { CustomerComponent } from './customer.component';
import { FooterComponent } from './components/customer-footer/customer-footer.component';
import * as fromlisting from './components/listing/listing.reducer';

import * as fromownerDetails from './components/owner-detail/+state/ownerDetail.reducer';
import * as fromCollectInfo from './components/collect-info/+states/collect-info.reducers';

import { ApplicationListingFacade } from './components/listing/listing.facade';
import { SidebarComponent } from '../../shared/components/sidebar/sidebar.component';
import { ListingComponent } from './components/listing/listing.component';
import { OwnerDetailComponent } from './components/owner-detail/owner-detail.component';

import { CollectInfoFacade } from './components/collect-info/+states/collect-info.facade';
import { CollectInfoEffects } from './components/collect-info/+states/collect-info.effects';
import { ApplicationListingEffects } from './components/listing/listing.effects';
import { OwnerDetailSheetEffects } from './components/owner-detail/+state/ownerDetail.effects';
import { GSTProfileEffects } from './components/gst-profile/+states/gst-profile.effects';
import { ownerDetailSheetFacade } from './components/owner-detail/+state/ownerDetail.facade';
import { GSTProfileFacade } from './components/gst-profile/+states/gst-profile.facade';
import { GstProfileComponent } from './components/gst-profile/gst-profile.component';
import { CollectInfoComponent } from './components/collect-info/collect-info.component';
import { IncomeExpenseComponent } from './components/income-expense/income-expense.component';
import { CustomerOfferComponent } from './components/customer-offer/customer-offer.component';
import { BusinessDetailsComponent } from './components/business-details/business-details.component';
import { LoanDetailsComponent } from './components/loan-details/loan-details.component';
import { CustomerNavbarComponent } from './components/customer-navbar/customer-navbar.component';

import { PanValidationComponent } from './components/underwriter/pan-validation/pan-validation.component'
import { GstSummaryComponent } from './components/underwriter/gst-summary/gst-summary.component';
import { CompanyBureauComponent } from './components/underwriter/company-bureau/company-bureau.component';
import { BankStatementComponent } from './components/underwriter/bank-statement/bank-statement.component';
import { GstProfileViewComponent } from './components/underwriter/gst-profile-view/gst-profile-view.component';
import { UnderwriterComponent } from './components/underwriter/underwriter.component';
import { OfferDetailsComponent } from './components/offer-details/offer-details.component';

@NgModule({
  declarations: [
    BusinessInfoComponent,
    CustomerComponent,
    FooterComponent,
    ListingComponent,
    SidebarComponent,
    CollectInfoComponent,
    OwnerDetailComponent,
    GstProfileComponent,
    IncomeExpenseComponent,
    CustomerOfferComponent,
    ApplicationOverviewComponent,
    AddCoApplicantComponent,
    BusinessDetailsComponent,
    LoanDetailsComponent,
    CustomerNavbarComponent,
    UnderwriterComponent,
    PanValidationComponent,
    GstSummaryComponent,
    CompanyBureauComponent,
    BankStatementComponent,
    GstProfileViewComponent,
    OfferDetailsComponent
  ],
  imports: [
    CommonModule,
    SharedLazyModule,
    StoreModule.forFeature(fromlisting.APPLICATIONLISTING_FEATURE_KEY, fromlisting.reducer),
    StoreModule.forFeature(fromownerDetails.OWNERDETAILS_FEATURE_KEY, fromownerDetails.reducer),
    StoreModule.forFeature(fromCreateUser.CREATEUSER_FEATURE_KEY, fromCreateUser.reducer),
    StoreModule.forFeature(fromBusinessInfo.BUSINESSDETAILS_FEATURE_KEY, fromBusinessInfo.reducer),
    StoreModule.forFeature(fromGSTProfile.GSTPROFILE_FEATURE_KEY, fromGSTProfile.reducer),
    StoreModule.forFeature(fromCollectInfo.COLLECTINFO_FEATURE_KEY, fromCollectInfo.reducer),
    EffectsModule.forFeature([ApplicationListingEffects, CreateUserEffects, OwnerDetailSheetEffects, BusinessInfoEffects, GSTProfileEffects, CollectInfoEffects]),
    CustomerRoutingModule
  ],
  providers: [BusinessInfoFacade, CreateUserFacade, ApplicationListingFacade, ownerDetailSheetFacade, GSTProfileFacade, Store, CollectInfoFacade],
  exports: [
    BusinessInfoComponent
  ],
})
export class CustomerModule { }
