/**
 * Interface for the 'GSTProfile' data
 */
export interface GSTProfileState {
  loaded: boolean; // has the api been loaded
  error?: any; // last none error (if any)
  loading?: boolean;
  taskInfo?: any;
  response?: any;
}
