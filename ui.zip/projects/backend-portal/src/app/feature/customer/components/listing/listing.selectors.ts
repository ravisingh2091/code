import { createFeatureSelector, createSelector } from '@ngrx/store';
import {
  APPLICATIONLISTING_FEATURE_KEY,
  State,
  ApplicationListingPartialState,
  applicationListingAdapter
} from './listing.reducer';
import { ApplicationListingEntity } from './listing.models';

// Lookup the 'ApplicationListing' feature state managed by NgRx


export const getApplicationListingState = createFeatureSelector<
  ApplicationListingPartialState,
  State
>(APPLICATIONLISTING_FEATURE_KEY);


export const getApplicationListingLoaded = createSelector(
  getApplicationListingState,
  (state: State) => {
    return state.loaded;
  }
);

export const getApplicationListingError = createSelector(
  getApplicationListingState,
  (state: State) => state.error
);

export const getAllApplicationListing = createSelector(
  getApplicationListingState,
  getApplicationListingLoaded,
  (state: State, getApplicationListingLoaded) => (state.response && getApplicationListingLoaded) ? state.response : null
);

export const getApplicationFilters = createSelector(
  getApplicationListingState,
  getApplicationListingLoaded,
  (state: State, getApplicationListingLoaded) => (!state.response && getApplicationListingLoaded) ? state.taskInfo : null
);

