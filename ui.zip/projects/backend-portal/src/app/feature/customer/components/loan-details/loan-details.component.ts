import { Component, Input, OnInit } from '@angular/core';
import { BRM_JOURNEY_STATES } from '../../../../shared/constants/brm-journey-states';
import { find, isEqual } from 'lodash-es';

@Component({
  selector: 'app-loan-details',
  templateUrl: './loan-details.component.html',
  styleUrls: ['./loan-details.component.scss']
})
export class LoanDetailsComponent implements OnInit {
  @Input() businessDetails;
  @Input() offerDetails;
  brmJourneyStates = BRM_JOURNEY_STATES;
  showLoanDetails = false;
  showOfferDetails = false;
  constructor() { }

  ngOnInit(): void {
    const currentState = this.businessDetails.current_state;
    const stateOrderData = find(this.brmJourneyStates, {name: currentState});
    if (stateOrderData && stateOrderData.order >= 3) {
      this.showLoanDetails = true;
    }
  }

  ngOnChanges(changes) {
    if (!isEqual(changes.offerDetails.currentValue, changes.offerDetails.previousValue)) {
      this.offerDetails = changes.offerDetails.currentValue;
      if (this.offerDetails.length > 0) {
        this.showOfferDetails = true;
      }
    }
  }

}
