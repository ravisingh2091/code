import { Injectable } from '@angular/core';

import { select, Store, Action } from '@ngrx/store';

import * as fromownerDetailSheet from './ownerDetail.reducer';
import * as ownerDetailSheetSelectors from './ownerDetail.selector';

@Injectable()
export class ownerDetailSheetFacade {
  loaded$ = this.store.pipe(
    select(ownerDetailSheetSelectors.getownerDetailSheetLoaded)
  );
 

  
  submitLoginState$ = this.store.pipe(select(ownerDetailSheetSelectors.getOwnerSheetResponseState));
  loadownerDetailSheet$ = this.store.pipe(select(ownerDetailSheetSelectors.getownerDetailSheetStateData));
  generateownerDetailSheetFlag$ = this.store.pipe(select(ownerDetailSheetSelectors.getGenerateownerDetailSheetFlag));
  constructor(
    private store: Store<fromownerDetailSheet.ownerDetailSheetPartialState>
  ) {}

  dispatch(action: Action) {
    this.store.dispatch(action);
  }
}
