import {createAction, props} from '@ngrx/store';

export const loadCollectInfo = createAction(
  '[collectInfo] Load collectInfo',
  props<{slug: string}>()
);

export const loadCollectInfoSuccess = createAction(
  '[collectInfo] Load collectInfo Success',
  props<{collectInfo: any}>()
)
export const loadCollectInfoFailure = createAction(
  '[collectInfo] Load collectInfo Failure',
  props<{error: any}>()
)
