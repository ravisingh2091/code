import { DUMMY_BRM2_RESPONSE } from './../../../../shared/constants/dummyBrmDecision'; //@TODO to be removed
import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { Subscription } from 'rxjs';
import { CommonService } from '@shared/services/common.service';
import { SLUG } from "../../../../shared/constants/slug";
import { ApplicationService } from '@shared/services/application.service';
import { Store, select } from '@ngrx/store';
import { take } from 'rxjs/operators';
import { APP_STATUS } from '@shared/constants/app-status';
import { get } from 'lodash-es';


@Component({
  selector: 'app-income-expense',
  templateUrl: './income-expense.component.html',
  styleUrls: ['./income-expense.component.scss']
})

export class IncomeExpenseComponent implements OnInit {

  incomeExpenseForm: FormGroup;
  incomeExpenseConfig: FormFieldInterface[] = [];
  rootStateSubscription: Subscription;
  incomeExpenseSubscription: Subscription;
  slug: string;
  userID: string;
  appID: string;
  businessID: string;
  formSubscription: Subscription;
  providersData: any;
  offerReferenceData: any;

  constructor(
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private common: CommonService,
    private api: ApplicationService
  ) {
    this.common.goBackGet.subscribe((res) => {
      this.goBack();
    });
  }

  ngOnInit(): void {
    try {
      this.common.customerFooterEmit = true;
      /* get store's 'app' data */
      this.rootStateSubscription = this.store
        .pipe(select('app'), take(1))
        .subscribe((rootState) => {
          if (rootState) {
            this.userID = rootState?.userData?.id;
            if (rootState.appID) {
              this.appID = rootState.appID;
            }
            if (rootState.businessID) {
              this.businessID = rootState.businessID;
            }
          }
        });

      this.slug = SLUG.IncomeExpense;

      /*create form and set form fields */
      this.api.getTaskInfo({
        slug: this.slug,
        user_id: this.userID,
        app_id: this.appID,
        type: 'customer-offer'
       }).subscribe(res => {
        this.providersData = res.response_data.service_providers.data.data;
        this.offerReferenceData = get(res, 'response_data.get_business_reference.data.data');
        this.incomeExpenseConfig = res.form_fields;
        this.incomeExpenseForm = this.formGenerate.createControl(this.incomeExpenseConfig);
      }, (err) => {
        this.common.popToast("error", "Income-expense Details", "error while getting Income Expense Details")
      });

      /*subscribe to form submit button on the footer */
      this.formSubscription = this.common.formSubmitGet.subscribe((result) => {
        this.onSubmit(result);
      });
    } catch (e) {
      this.common.popToast("error", "Income-expense Details", "Something went wrong")
    }
  }

  goBack = (): void => {
    this.common.navigate(SLUG.collectInfo);
  }

  onSubmit(val): void {
    const annualRevenue = this.incomeExpenseForm.controls.annual_revenue.value;
    const repaymentAmount = this.incomeExpenseForm.controls.repayment_amount.value;

    const payload: any = {
      business_id: this.businessID,
      action_type: val.action,
      user_id: this.userID,
      app_id: this.appID,
      annual_revenue: annualRevenue,
      repayment_amount: repaymentAmount
    };

    /**update business details with income-expense data */
    this.api.saveTaskInfo(payload, { slug: this.slug })
      .subscribe((res) => {
        if (this.offerReferenceData) {
          this.updateAppStatus(APP_STATUS.submitted);
        } else {
          const brm2Response = this.getBrm2Decision();
          this.saveOfferDetais(brm2Response);
        }
      });

  }

  //@TODO to be replaced with real data
  getBrm2Decision() {
    return DUMMY_BRM2_RESPONSE
  }

  saveOfferDetais(brm2ResponseData: any) {
    /**extract offer detais from BRM2 response data */
    let formValues = {
      term: get(brm2ResponseData, `Fields.Applicants.Applicant[0].Services.Service[0].Operations.Operation[0].Data.Response.Variables.BankStatement.Tenor`),
      interest_rate: get(brm2ResponseData, `Fields.Applicants.Applicant[0].Services.Service[0].Operations.Operation[0].Data.Response.Variables.BankStatement.Rate_Of_Interest`),
      loan_amount: get(brm2ResponseData, `Fields.Applicants.Applicant[0].Services.Service[0].Operations.Operation[0].Data.Response.Variables.BankStatement.Eligible_Amounts.Eligibility_Amount_BankStatement`)
    }
    this.api.saveTaskInfo({
      app_id: this.appID,
      user_id: this.userID,
      payload: formValues,
      provider: this.getProviderId(SLUG.customerOffer)
    }, { slug: SLUG.customerOffer,
       app_id: this.appID,
        user_id: this.userID
       }, null)
      .subscribe(() => {
        /*update status of the application as incomplete  */
        this.updateAppStatus(APP_STATUS.submitted);
      });
  }

  getProviderId(type): object {
    /*find provider data for customer-offer slug */
    const object = this.providersData.find((val) => val.type === type);
    return object.id;
  }

  updateAppStatus(status: string) {
    const successStatusData = this.common.getAppStatus(status);
    this.api.saveTaskInfo({
      status_id: successStatusData.id,
      note: "submitted",
      app_id: this.appID
    }, { slug: SLUG.updateApplication })
      .subscribe((result) => {
        /*update app status and navigate to listings page  */
        this.common.popToast('success', 'Income-Expense', 'Application Submitted Successfully');
        this.common.navigate(SLUG.userListing);
      }, err => this.common.popToast('error', 'Offer','error while submitting offer'));
  }

  /*unsubscribe to the form submit button after moving on */
  ngOnDestroy(): void {
    this.formSubscription.unsubscribe();
    this.common.nextsubscriptionEmit=false;    
    this.common.NextButtonEmit='Next';
    
  }
}
