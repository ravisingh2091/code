import { Injectable } from '@angular/core';

import { select, Store, Action } from '@ngrx/store';
import * as fromCreateUser from './createUser.reducer';
import * as createUserSelectors from './createUser.selector';

@Injectable()
export class CreateUserFacade {
  loaded$ = this.store.pipe(
    select(createUserSelectors.getCreateUserLoaded)
  );
  allCreateUser$ = this.store.pipe(
    select(createUserSelectors.getAllCreateUser)
  );
  createUserResponse$ = this.store.pipe(select(createUserSelectors.getCreateUserResponse));
  constructor(
    private store: Store<fromCreateUser.CreateUserPartialState>
  ) { }

  dispatch(action: Action): void {
    this.store.dispatch(action);
  }
}
