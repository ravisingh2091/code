import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GstProfileComponent } from './gst-profile.component';

describe('GstProfileComponent', () => {
  let component: GstProfileComponent;
  let fixture: ComponentFixture<GstProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GstProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GstProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
