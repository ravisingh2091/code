import { Action, createAction, props } from '@ngrx/store';
export enum GSTActionTypes {
  LoadGSTProfile = '[GSTProfile] Load GSTProfile',
}

export class LoadGSTProfile implements Action {
  readonly type = GSTActionTypes.LoadGSTProfile;
  constructor(public payload: any) {}
}

export const resetGSTData = createAction('[GSTProfile] Reset GSTProfile');

export const loadGSTProfileSuccess = createAction(
  '[GSTProfile] Load GSTProfile Success',

  props<{ gstProfile: any }>()
);

export const gstProfileFailure = createAction(
  '[GSTProfile] Load GSTProfile Failure',
  props<{ error: any }>()
);

export const gstProfileSubmit = createAction(
  '[GSTProfile] GSTProfile Submit',
  props<{ slug: String; formData: any }>()
);

export const gstProfileComplete = createAction(
  '[GSTProfile] GSTProfile Complete',
  props<{ gstProfile: any }>()
);
export type GSTAction = | LoadGSTProfile;

export const fromGSTActions = {
  LoadGSTProfile,
};
