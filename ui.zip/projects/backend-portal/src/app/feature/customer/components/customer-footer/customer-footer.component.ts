import { Component, OnInit } from '@angular/core';

import { CommonService } from '../../../../shared/services/common.service';
@Component({
  selector: 'app-customer-footer',
  templateUrl: './customer-footer.component.html',
  styleUrls: ['./customer-footer.component.scss']
})
export class FooterComponent implements OnInit {
  NextButtonText: any='Next';
  submitFlag: boolean;
  disableFlag:boolean=false;
  constructor(
    private commonService: CommonService
  ) {
    this.commonService.NextButtonObservable.subscribe((data) => {
      
      if (data == 'Submit') {
        this.submitFlag = true;
        this.NextButtonText='Submit'
        
      } else {
        this.submitFlag = false;        
        this.NextButtonText='Next'
      }
    })


    this.commonService.nextsubscriptionObservable.subscribe((data) => {
      if (data == true) {
        this.disableFlag = true;
      } else {
        this.disableFlag = false;
      }
    })
  }

  ngOnInit(): void {

  }

  saveAndExit(action): void {
    this.commonService.formSubmit = { action };
  }
  goBack(): void {
    this.commonService.goBack = true;
  }
}