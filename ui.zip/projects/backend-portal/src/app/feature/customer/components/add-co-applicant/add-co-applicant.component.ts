import { CommonService } from './../../../../shared/services/common.service';
import { FormFieldInterface } from './../../../../utils/interfaces/form-fields.interface';
import { ApplicationService } from './../../../../shared/services/application.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { FormGenerateService } from './../../../../shared/services/form-generate.service';
import { FormGroup } from '@angular/forms';
import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'lodash-es';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-add-co-applicant',
  templateUrl: './add-co-applicant.component.html',
  styleUrls: ['./add-co-applicant.component.scss']
})
export class AddCoApplicantComponent implements OnInit {
  addCoApplicantForm: FormGroup;
  addCoApplicantConfig: FormFieldInterface[] = [];
  slug = 'add-co-applicant';
  @Input() appID;
  @Input() userID;
  @Input() ownerData;
  @Input() isCreateForm;
  individualName;
  onClose: Subject<boolean>;

  constructor(
    private formGenerate: FormGenerateService,
    private bsModalRef: BsModalRef,
    private api: ApplicationService,
    private common: CommonService,
  ) { }

  ngOnInit(): void {
    this.onClose = new Subject();
    this.api.getTaskInfo({
      slug: this.slug
    }).subscribe((coApplicantInfo) => {
      this.addCoApplicantConfig = coApplicantInfo.form_fields;
      this.common.sendMasterDataToFields(this.addCoApplicantConfig, coApplicantInfo.response_data);
      this.addCoApplicantForm = this.formGenerate.createControl(this.addCoApplicantConfig);

      if (this.isCreateForm === false) {
        this.formGenerate.setFormValues(this.addCoApplicantForm, {owners: this.ownerData});
        const entityData = _.find(coApplicantInfo.response_data.entity_type.data.data, { id: this.ownerData.entity_type });
        this.setDropdownMasterData(entityData, 'relationship');
        this.setDropdownMasterData(entityData, 'type_of_address');
        this.setDropdownMasterData(entityData, 'business_constitution');
      }
    }, err => { this.common.popToast('error', 'Error!', 'Error fetching response'); });
  }

  closeModal(reloadPage: boolean = false): void {
    this.onClose.next(reloadPage);
    this.bsModalRef.hide();
  }

  onSubmit(): void {
    if (this.formGenerate.validateCustomFormFields(this.addCoApplicantForm, 'continue', this.addCoApplicantConfig)) {
      const rawFormData = this.addCoApplicantForm.getRawValue();
      const requestData: any = {
        app_id: this.appID,
        user_id: this.userID
      };
      switch (this.isCreateForm) {
        // creating owner
        case true:
          this.modifyCreateFormData();
          rawFormData.owners.owner_id = this.generateMongoId();
          rawFormData.owners.individual_name = this.individualName;
          this.individualName = null;
          this.ownerData.existingOwners.push(rawFormData.owners);
          requestData.owners = this.ownerData.existingOwners;

          // console.log(requestData);
          // return;
          this.api.saveTaskInfo(requestData, { slug: 'add-co-applicant' })
            .subscribe(() => {
              this.closeModal(true);
              this.common.popToast('success', 'Add Co-Applicant', 'Co-Applicant added successfully');
            }, err => this.common.popToast('error', 'Add Co-Applicant', 'Unable to submit request'));
          break;

          // updating owner
        case false:
          const modifiedOwners = this.modifyUpdateFormData();
          rawFormData.owners.individual_name = this.individualName;
          this.individualName = null;
          rawFormData.owners.owner_id = this.ownerData._id;
          modifiedOwners.push(rawFormData.owners);
          requestData.owners = modifiedOwners;

          // console.log(requestData);
          // return;
          this.api.saveTaskInfo(requestData, { slug: 'add-co-applicant' })
            .subscribe(() => {
              this.closeModal(true);
              this.common.popToast('success', 'Add Co-Applicant', 'Co-Applicant updated successfully');
            }, err => this.common.popToast('error', 'Add Co-Applicant', 'Unable to submit request'));
          break;
      }
    }
  }

  modifyUpdateFormData(): any[] {
    const modifiedOwnerData = [];
    _.forEach(this.ownerData.existingOwners, (owner) => {
      if (owner._id !== this.ownerData._id) {
        owner = _.pick(owner, ['address_line_1', 'busines_name', 'coapplicant_type', 'business_constitution',
        'credit_bureau', 'date_of_birth', 'entity_type', 'gender', 'individual_name', 'is_coApplicant', 'pan_number', 'relationship', 'type_of_address', '_id']);
        owner.owner_id = owner._id;
        modifiedOwnerData.push(owner);
      }
      if (!this.individualName && owner.individual_name) {
        this.individualName = owner.individual_name;
      }
    });
    return modifiedOwnerData;
  }

  modifyCreateFormData(): void {
    this.ownerData.existingOwners = _.map(this.ownerData.existingOwners, (owner) => {
      owner = _.pick(owner, ['address_line_1', 'busines_name', 'coapplicant_type', 'business_constitution',
       'credit_bureau', 'date_of_birth', 'entity_type', 'gender', 'individual_name', 'is_coApplicant', 'pan_number', 'relationship', 'type_of_address', '_id']);
      if (!this.individualName && owner.individual_name) {
        
        this.individualName = owner.individual_name;
      }
      owner.owner_id = owner._id;
      return owner;
    });
  }

  generateMongoId(): string {
    return this.hex(Date.now() / 1000) +
      ' '.repeat(16).replace(/./g, () => this.hex(Math.random() * 16))
  }

  hex(value): string {
    return Math.floor(value).toString(16);
  }

  setDropdownMasterData(entityData, type): void {
    switch (type) {
      case 'relationship':
        this.common.sendMasterDataToFields(this.addCoApplicantConfig, {
          data: {
            data: entityData.relationships
          }
        }, 'relationship');
        break;
      case 'type_of_address':
        this.common.sendMasterDataToFields(this.addCoApplicantConfig, {
          data: {
            data: entityData.addressType
          }
        }, 'type_of_address');
        break;
      case 'business_constitution':
        this.common.sendMasterDataToFields(this.addCoApplicantConfig, {
          data: {
            data: entityData.typeOfEntity
          }
        }, 'business_constitution');
        break;
    }
  }
}
