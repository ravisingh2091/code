import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { fetch } from '@nrwl/angular';
import { ApplicationService } from '@shared/services/application.service';
import * as collectInfoActions from './collect-info.actions';
import { map, tap } from 'rxjs/operators';

@Injectable()
export class CollectInfoEffects {
  loadCollectInfo$ = createEffect(() =>
    this.actions$.pipe(
      ofType(collectInfoActions.loadCollectInfo),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        run: action => {
          return this.applicationService.getTaskInfo({
            slug: action.slug
          }).pipe(
            map((data: any) => {
              return collectInfoActions.loadCollectInfoSuccess({collectInfo: data});
            })
          );
        },
        onError: (action, error) => {
          return collectInfoActions.loadCollectInfoFailure({error});
        }
      })
    )
  );

  constructor(
    private actions$: Actions,
    private applicationService: ApplicationService
  ) {}
}
