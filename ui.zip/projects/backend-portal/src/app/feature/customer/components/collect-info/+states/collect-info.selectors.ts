import {createFeatureSelector, createSelector} from '@ngrx/store';
import {
  COLLECTINFO_FEATURE_KEY,
  State
} from  './collect-info.reducers';

export const getCollectInfoState = createFeatureSelector<State>(COLLECTINFO_FEATURE_KEY);

export const getCollectInfoLoaded = createSelector(
  getCollectInfoState,
  (state: State) => state.loaded
);
export const getCollectInfoStateData = createSelector(
  getCollectInfoState,
  getCollectInfoLoaded,
  (state: State, isLoaded) => {
      return isLoaded&&state ? state : null
  }
);
export const getcollectInfoResponseState = createSelector(
  getCollectInfoState,
  getCollectInfoLoaded,
  (state: State) => state.response_data
);

export const getcollectInfoError = createSelector(
  getCollectInfoState,
  (state: State) => state.error
);
