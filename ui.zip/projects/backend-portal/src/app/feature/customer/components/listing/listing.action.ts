import { createAction, props } from '@ngrx/store';
import { ApplicationListingEntity } from './listing.models';
// import { TaskInfoInterface } from '@rubicon/interface/task-info';
// import { request } from 'http';

export const loadApplicationListing = createAction(
  '[ApplicationListing] Load ApplicationListing',
  props<{ slug:string,request:any}>()
);


export const loadApplicationListingSuccess = createAction(
  '[ApplicationListing] Load ApplicationListing Success',
  props<{ applicationListing: any }>()
);
export const loadApplicationFilter = createAction(
  '[ApplicationListing] Load Application Filter',
  props<{ slug: string }>()
);


export const applicationFilterLoaded = createAction(
  '[ApplicationListing] Application Filter Loaded',
  props<{ applicationListing: any }>()
);
export const addApplicationData = createAction(
  '[ApplicationListing] add Application Data',
  props<{ applicationData: any }>()
);
export const addMasterData = createAction(
  '[ApplicationListing] add Master Data',
  props<{ masterData: any }>()
);

export const loadApplicationListingFailure = createAction(
  '[ApplicationListing] Load ApplicationListing Failure',
  props<{ error: any }>()
);

export const ResetApplicationListingResponse = createAction(
  '[ApplicationListing] Reset ApplicationListing Response',
  props<{  } | any>() //@TODO
);
