import { createReducer, on, Action } from '@ngrx/store';
import * as BusinessInfoActions from './business-info.actions';
import { BusinessInfoState } from './business-info.model';
// import { Action, Action } from 'rxjs/internal/scheduler/Action';

export const BUSINESSDETAILS_FEATURE_KEY = 'businessInfo';

export interface BusinessInfoPartialState {
  readonly [BUSINESSDETAILS_FEATURE_KEY]: BusinessInfoState;
}

export const initialState: BusinessInfoState = {
  loaded: false,
  loading: false,
  taskInfo: null,
  verifiedData: null,
};

const businessInfoReducer = createReducer(
  initialState,
  // on(BusinessInfoActions.LoadBusinessInfo, (state) => ({
  //   ...state,
  //   loaded: false,
  //   verifiedData: null,
  //   error: null,
  // })),
  on(
    BusinessInfoActions.LoadBusinessInfoSuccess,
    (state, { businessInfo }) => ({
      ...state,
      loaded: true,
      response: null,
      verifiedData: null,
      taskInfo: businessInfo,
    })
  ),
  on(BusinessInfoActions.BusinessInfoLoadError, (state, { error }) => ({
    ...state,
    error,
  })),
  on(BusinessInfoActions.OtpLoaded, (state, { response }) => ({
    ...state,
    response,
  })),
  on(
    BusinessInfoActions.BusinessInfoFormSubmitted,
    (state, { businessDetails }) => ({
      ...state,
      businessDetails,
    })
  ),
  on(BusinessInfoActions.BusinessInfoResponse, (state, { verifiedData }) => ({
    ...state,
    loaded: false,
    verifiedData,
  })),
  on(BusinessInfoActions.BusinessInfoFormSubmitted, (state, { businessDetails }) => ({
    ...state,
    loaded: false,
    businessDetails,
  }))
);

export function reducer(state: BusinessInfoState | undefined, action: Action) {
  return businessInfoReducer(state, action);
}
