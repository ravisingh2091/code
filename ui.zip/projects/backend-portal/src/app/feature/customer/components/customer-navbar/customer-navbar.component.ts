import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { APP_REVIEW_TABS } from '../../../../shared/constants/app-overview-tabs';
import { CommonService } from '@shared/services/common.service';

@Component({
  selector: 'app-customer-navbar',
  templateUrl: './customer-navbar.component.html',
  styleUrls: ['./customer-navbar.component.scss']
})
export class CustomerNavbarComponent implements OnInit {
  @Output() changeTab: EventEmitter<string> = new EventEmitter<any>();
  @Input() activeTabData: any;
  isCollapsed = false;
  tabNames = APP_REVIEW_TABS;
  activeTab = this.tabNames.appOverview;
  constructor(private common: CommonService) { }

  ngOnInit(): void {
    if (this.activeTabData) { this.activeTab = this.activeTabData; }
  }

  switchTab(tabName): void {
    this.activeTab = tabName;
    this.changeTab.emit(tabName);
    if (tabName) {
      this.common.navigate(tabName);
    }
  }

}
