import { createReducer, on, Action } from '@ngrx/store';
import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
import * as collectInfoActions from './collect-info.actions';
import { collectInfoEntity } from './collect-info.model';

export const COLLECTINFO_FEATURE_KEY = 'collectInfo';

export interface State extends EntityState<collectInfoEntity> {
  selectedId?: string | number;
  loaded: boolean;
  error?: string | null;
  form_fields?: any;
  task_slug: string;
  response_data?: any;
}

export interface collectInfoPartialState {
  readonly [COLLECTINFO_FEATURE_KEY]: State;
}

export const collectInfoAdapter: EntityAdapter<collectInfoEntity> = createEntityAdapter<
  collectInfoEntity
>();

export const initialState: State = collectInfoAdapter.getInitialState({
  loaded: false,
  error: null,
  form_fields: [],
  task_slug: null,
  response_data: {},
});

const collectInfoReducer = createReducer(
  initialState,
  on(collectInfoActions.loadCollectInfo, (state) => ({
    ...state,
    loaded: false,
    error: null,
  })),
  on(collectInfoActions.loadCollectInfoSuccess, (state, { collectInfo }) => ({
    ...state,
    ...collectInfo,
    loaded: true,
    error: null,
  })),
  on(collectInfoActions.loadCollectInfoFailure, (state, {error}) => ({
    ...state,
    loaded: false,
    error
  }))
);
export function reducer(state: State | undefined, action: Action ) {
return collectInfoReducer(state, action);

}
