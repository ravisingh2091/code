import { Component, OnInit, TemplateRef, inject, Inject, ViewChild } from '@angular/core';
import { BsModalService, BsModalRef, ModalDirective } from 'ngx-bootstrap/modal';
import { Store, select } from '@ngrx/store';
import { switchMap, take } from 'rxjs/operators';
import * as collectInfoActions from './+states/collect-info.actions';
import { CollectInfoFacade } from './+states/collect-info.facade';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { FormGroup } from '@angular/forms';
import { ApplicationService } from '@shared/services/application.service';
import { Subject, Subscription } from 'rxjs';
import { timer } from 'rxjs/internal/observable/timer';
import { CommonService } from '@shared/services/common.service';
import * as Selectors from './+states/collect-info.selectors';
import {SLUG} from '../../../../shared/constants/slug';
import { LoaderService } from '@shared/services/loader.service';
import { get } from 'lodash-es';
import { ServiceProvidorService } from '../../../../shared/services/service-providor.service';

@Component({
  selector: 'app-collect-info',
  templateUrl: './collect-info.component.html',
  styleUrls: ['./collect-info.component.scss'],
})
export class CollectInfoComponent implements OnInit {
  public gstInData: any;
  public linkButtonText = 'Link';
  public modalRef: BsModalRef;
  public slug: string;
  public gstInfoConfig: FormFieldInterface[] = [];
  public gstInfoForm: FormGroup;
  private user_id: string;
  private transactionId: string;
  private destroy$ = new Subject();
  private app_id: string;
  private activeGstIns = []; //'07AAACI8199P1ZP'
  providerObJ: any;
  providerID4: any;
  providerID1: any;
  providerID3: any;
  businessID: any;
  formdatasubscription: Subscription;
  flag: boolean;
  gstData: any;
  refId: any;
  responseArray: any;
  responseObj: any;
  responseDataArray:any=[];
  arrlength: number;
  docSubscription: Subscription;
  documentFetch=false;
  gstSubscription: Subscription;
  lgModal: any;
  constructor(
    private modalService: BsModalService,
    private collectInfoFacade: CollectInfoFacade,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private api: ApplicationService,
    private serviceProvider: ServiceProvidorService,
    private common: CommonService,
    private loader: LoaderService
  ) {
    this.collectInfoFacade.dispatch(
      collectInfoActions.loadCollectInfo({
        slug: SLUG.gstTransactionOtp
      })
    );
    this.common.goBackGet.subscribe((res) => {
      this.goBack();
    });

    this.formdatasubscription = this.common.formSubmitGet.subscribe(result => {
      this.onsubmit(result);
    });
  }



  ngOnInit() {

    
    this.common.customerFooterEmit = true;

    this.activeGstIns = [];
    this.store.pipe(select('app'), take(1)).subscribe((rootState) => {
      if (rootState && rootState.userData) {
        this.user_id = rootState.userData.id;
      }
      if (rootState && rootState.appID) {
        this.app_id = rootState.appID;
      }

      if (rootState && rootState.businessID) {
        this.businessID = rootState.businessID;
      }
    });
    this.collectInfoFacade.loadCollectInfo$.subscribe(async (state) => {
      if (state && state.task_slug) {
        this.slug = state.task_slug;
        this.gstInfoConfig = state.form_fields;
        this.gstInfoForm = await this.formGenerate.createControl(
          this.gstInfoConfig
        );
        this.getDocumentType();
      }
    },(err)=>{
      this.common.popToast("error", "INVALID REQUEST", "invalid request")
    }

    );

    this.flag = false;
    this.showModal()
  }
  @ViewChild('autoShownModal', { static: false }) autoShownModal: ModalDirective;
  isModalShown = false;
 
  showModal(): void {
    this.isModalShown = true;
  }
 
  hideModal(): void {
    this.autoShownModal.hide();
  }
 
  onHidden(): void {
    this.isModalShown = false;
  }
  public goBack(): void {
    this.common.navigate(SLUG.ownersDetails);
  }
  
  private getDocumentType(): void {


    if(this.documentFetch===false){
      this.documentFetch=true
      this.docSubscription= this.api
      .getTaskInfo({ slug: SLUG.documentType })
      .pipe(
        switchMap(
          async (documentTypes) => await this.getGstDetails(documentTypes)
        )
      )
      .subscribe();
    }
  }
  private getGstDetails(documentTypes){
    let providerObj = documentTypes.response_data.service_providers.data.data.find(
      (provider) => provider.type === 'gst_search'
    );
   this.gstSubscription= this.api
      .getTaskInfo({
        slug: SLUG.savedGstDetails,
        user_id: this.user_id, // '5f897d38290e93001b159b1',
        expands: 'business,business_references',
        provider: providerObj.id, // '5ca4d2573eb7c2707c64651b',
        type: providerObj.type, //
        app_id: this.app_id,
        // app_id: this.app_id, // this.app_id, //'5f897dd69f7296004b396b266'
      })
      .subscribe(async (res) => {
        if (res) {
          let gstinArr = [];
          gstinArr = await res.response_data.get_gst_search_data.data.data.result;
          this.refId = res.response_data.user_apps.data.data[0].business_references.find(val => val.type == 'gst_transaction_otp') ?.ref_id;

        await res.response_data.user_apps.data.data[0].business_references.forEach(element => {
            if (element.type == "gst_transaction_otp") {
              this.responseDataArray.push(element)
            }
          });

          this.arrlength=this.responseDataArray.length
          if (this.arrlength>0) {
            this.activeGstIns = this.responseDataArray[this.arrlength-1] ?.response ?.array;
            }

          this.formGenerate.setFormValues(this.gstInfoForm, {
            gst_otp: gstinArr,
          });
        }
      },
       (err) => {
        this.common.nextsubscriptionEmit=true;
        this.common.popToast("error", "GST Details", "error while getting GST Details")
      }
      );
  }


  public sendOTP(gstInfo): void {
    // '27AAFCK8380D1ZE'
    //gstInfo.controls.gstinId.value = 27AAFCK8380D1ZE
    const username = gstInfo.controls.username.value;
    // const gstin = gstInfo.controls.gstinId.value;
    const gstin = '27AAFCK8380D1ZE'
    let payload = { username, gstin };
    this.api
      .saveTaskInfo(payload, {
        stub: 'stub',
        slug: SLUG.gstTransactionOtp
      })
      .subscribe((res) => {
        if (res) {
          const dataSet = res.transaction_get_otp.data.data;
          this.flag = true;
          this.transactionId = dataSet.id;


          const statusId = get(dataSet, 'result.status_cd');
          if (statusId !== '1') {
            this.common.popToast('error', 'GST Transaction OTP', 'Unable to generate OTP for this GSTIN');
          }
        }
      },(err)=>{
        this.common.popToast("error", "GST Details", "error while getting OTP")
      });
  }
  public submitOtp(gstInfo): void {
    this.api
      .saveTaskInfo(
        {
          // id: '5f30e0470e863cfa71796ff7',//this.transactionId,
          id: this.transactionId,
          otp: String(gstInfo.controls.otp.value)
        },
        { slug: SLUG.transactionSubmitOtp, stub: 'stub' }
      )
      .subscribe((res) => {
        this.loader.show()
        // if (res) {
        this.getGstTransactionOtp(gstInfo);
        // }
      },(err)=>{

        this.common.popToast("error", " OTP Details", "error while Submit OTP")
      });
  }
  public getGstTransactionOtp(gstInfo): void {
    let count = 0;
    let apiRun = this.api.getTaskInfo({
      slug: SLUG.getGstTransactionOtp,
      // id: '5f30e0470e863cfa71796ff7', //  this.transactionId,
      id: this.transactionId

    });
    let subscription = timer(0, 10000)
      .pipe(switchMap(() => apiRun))
      .subscribe((result) => {
        if (result) {
          count++;
          if (result && result.response_data.get_gst_transaction_otp.data.data.result) {
            // this.saveGstTransactionOtpReference();
            this.loader.hide()
            subscription.unsubscribe();
            this.saveGstRef(gstInfo);
            return;
          } else if (count === 3) {
            subscription.unsubscribe();
            this.common.popToast('error', 'Failed', 'Can not link to gstin');
            this.loader.hide()
            // show failed message
          }
        }
      }, (err) => { this.loader.hide()

        this.common.popToast("error", "Transaction Details", "error while getting Transaction Details")
      });
  }
  private saveGstRef(gstInfo): void {
    this.providerObJ = this.serviceProvider.getProviderData('gst_transaction_otp');
    if (this.providerObJ && this.providerObJ.id) {
      this.providerID1 = this.providerObJ.id

      this.activeGstIns.push(gstInfo.controls.gstinId.value)
    }
    this.api
      .saveTaskInfo({

        ref_id: this.transactionId,
        // ref_id: this.transactionId,
        response_to_be_saved: { array: this.activeGstIns },
        user_id: this.user_id,
        app_id: this.app_id,
        service_provider: this.providerID1
      }, { slug: SLUG.saveGstOtpReference, })
      .subscribe((results) => {
        if (results) {
          this.common.popToast('success', 'Linked', 'Gstin is linked successfully');
          this.linkButtonText = 'Linked'

          // show successful message
        }
      },(err)=>{

        this.common.popToast("error", "Reference Details", "error while submitting Reference Details")
      });
  }
  public changeLinkButtonText(): void {
    this.linkButtonText = 'Linked';

    this.common.popToast('error', 'under progress', 'Error Under Development');

  }
  public openModal(template: any){
    this.modalRef = this.modalService.show(template);
  }

  // saveGstTransactionOtpReference() {
  //   this.providerObJ = this.serviceProvider.getProviderData('gst_transaction_otp');
  //   if (this.providerObJ && this.providerObJ.id) {
  //     this.providerID3 = this.providerObJ.id

  //   }
  //   this.api
  //     .saveTaskInfo({
  //       ref_id: this.transactionId,
  //       service_provider: this.providerID3
  //     },
  //       {
  //         slug: 'get-gst-transaction-otp-reference'
  //       })
  //     .subscribe((results) => {
  //       if (results) {

  //       }
  //     });
  // }



  /**
   *
   * @param val save/continue
   */
  onsubmit(val) {
    if (val.action === 'continue') {
      // if (
      //   this.formGenerate.validateCustomFormFields(
      //     this.gstInfoForm,
      //     'continue',
      //     this.gstInfoConfig)
      // ) {
      const appType = this.common.getAppType('unsecured_business_loan');
      const appStatus = this.common.getAppStatus('Incomplete');
      const payload: any = {
        business_id: this.businessID,
        action_type: val.action,
        user_id: this.user_id,
        app_id: this.app_id,
        status_id: appStatus.id,
        product_type: appType.id
      };
      payload.current_state = 'income-expense';
      return this.api.saveTaskInfo(payload, { slug: SLUG.updateBusiness }).subscribe((result) => {
        if (result) {
          this.common.navigate(SLUG.IncomeExpense);
        } else {
          this.common.popToast('error', 'GST not verified', 'Error while veryfying GST');
        }
      });
    }
    // }
    else {
      this.common.navigate(SLUG.userListing);
    }
  }

  // getDataFromReference(id) {

  //   const payload = {
  //     ref_id: id
  //   };
  //   this.api.saveTaskInfo(payload, { slug: SLUG.dataFromBusinessReference }
  //   ).subscribe((res) => {
  //     if (res) {
  //       this.gstData = res;
  //       if (this.gstData) {
  //       }
  //     }
  //   },(err)=>{
  //     this.common.popToast('error', 'GST not verified', 'Error while getting Data');
  //   });
  // }

  ngOnDestroy() {
    this.common.nextsubscriptionEmit=false;
    this.formdatasubscription.unsubscribe();
    this.docSubscription.unsubscribe();
    this.gstSubscription.unsubscribe();
  }
}
