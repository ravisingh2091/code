import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { fetch } from '@nrwl/angular';
import { map } from 'rxjs/operators';
import * as CreateUserActions from './createUser.action';

import { CommonService } from '@shared/services/common.service';
import { ApplicationService } from '../../../../../shared/services/application.service';

@Injectable()
export class CreateUserEffects {
  loadCreateUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CreateUserActions.loadCreateUser),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        run: action => {
          return this.applicationService.getTaskInfo({
            slug: action.slug
          }).pipe(
            map((data: any) => {
              // Your custom service 'load' logic goes here. For now just return a success action...
              return CreateUserActions.createUserSuccess({ createUser: data });
            }))
        },

        onError: (action, error) => {
         
        this.common.popToast('error', 'Create User', 'error while getting Creating User Details') 
          return CreateUserActions.createUserFailure({ error });
        }
      })
    )
  );

  submitCreateUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CreateUserActions.createUserSubmit),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        run: action => {
          return this.applicationService.saveTaskInfo(action.formData, {
            slug: action.slug
          }, null).pipe(
            map((data: any) => {
              return CreateUserActions.createUserComplete({ createUser: data });
            })
          );
          // Your custom service 'load' logic goes here. For now just return a success action...
        },
        onError: (action, error) => {
          
        this.common.popToast('error', 'Create User', 'error while Creating User');
          return CreateUserActions.createUserFailure({ error });
        }
      })
    )
  )

  constructor(
    private actions$: Actions,
    private applicationService: ApplicationService,
    private common:CommonService
  ) { }
}
