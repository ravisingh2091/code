import { Action, createAction, props } from '@ngrx/store';

export enum BusinessInfoActionTypes {
  LoadBusinessInfo = '[BusinessInfo] Load BusinessInfo',
  BusinessInfoLoaded = '[BusinessInfo] BusinessInfo Loaded',
  BusinessInfoLoadError = '[BusinessInfo] BusinessInfo Load Error',
  BusinessInfoFormSubmit = '[BusinessInfo] BusinessInfo Form Submit',
  BusinessInfoFormSubmitted = '[BusinessInfo] BusinessInfo Form Submitted',
  LoadBusinessInfoSuccess = '[BusinessInfo] Load BusinessInfo Success',
  LoadOtp = '[BusinessInfo] Load Otp',
  OtpLoaded = '[BusinessInfo] Otp Loaded',
  OtpLoadError = '[BusinessInfo] Otp Load Error',
  OtpResendRequested = '[BusinessInfo] Resend OTP requested to server',
  OtpResendRequestCompleted = '[BusinessInfo] Otp resend from server',
  OtpStateReset = '[BusinessInfo] Otp State Reset',
  VerifyOTP = '[BusinessInfo] Verify OTP',
  BusinessInfoResponse = '[BusinessInfo] Get BusinessInfo Response',
}

export const LoadBusinessInfo = createAction(
  BusinessInfoActionTypes.LoadBusinessInfo,
  props<{ slug: string, payload: any }>()
);

export const BusinessInfoLoadError = createAction(
  BusinessInfoActionTypes.BusinessInfoLoadError,
  props<{ error: any }>()
);

// export const BusinessInfoLoaded = createAction(BusinessInfoActionTypes.BusinessInfoLoaded,
//   props<{ slug: any }>()
//   );

export class BusinessInfoFormSubmit implements Action {
  readonly type = BusinessInfoActionTypes.BusinessInfoFormSubmit;
  constructor(public payload: any) { }
}

export class LoadOtp implements Action {
  readonly type = BusinessInfoActionTypes.LoadOtp;
  constructor(public payload: any) { }
}

export const BusinessInfoFormSubmitted = createAction(
  BusinessInfoActionTypes.BusinessInfoFormSubmitted,
  props<{ businessDetails: any }>()
);

export const BusinessInfoResponse = createAction(
  BusinessInfoActionTypes.BusinessInfoResponse,
  props<{ verifiedData: any }>()
);

export const OtpLoaded = createAction(
  BusinessInfoActionTypes.OtpLoaded,
  props<{ response: any }>()
);



export class VerifyOtp implements Action {
  readonly type = BusinessInfoActionTypes.VerifyOTP;

  constructor(public payload: any) { }
}

export class OtpLoadError implements Action {
  readonly type = BusinessInfoActionTypes.OtpLoadError;
  constructor(public payload: any) { }
}

export class OtpResendRequested implements Action {
  readonly type = BusinessInfoActionTypes.OtpResendRequested;

  constructor(public payload: any) { }
}

export class OtpResendRequestCompleted implements Action {
  readonly type = BusinessInfoActionTypes.OtpResendRequestCompleted;

  constructor(public payload: any) { }
}

export class OtpStateReset implements Action {
  readonly type = BusinessInfoActionTypes.OtpStateReset;

  constructor() { }
}
export const LoadBusinessInfoSuccess = createAction(
  BusinessInfoActionTypes.LoadBusinessInfoSuccess,
  props<{ businessInfo: any }>()
);

export type OtpAction =
  | LoadOtp
  | OtpLoadError
  | BusinessInfoFormSubmit
  | OtpResendRequested
  | OtpResendRequestCompleted
  | OtpStateReset;

export const fromOtpActions = {
  LoadOtp,
  OtpLoadError,
  BusinessInfoFormSubmit,
  OtpResendRequested,
  OtpResendRequestCompleted,
  OtpStateReset
};
