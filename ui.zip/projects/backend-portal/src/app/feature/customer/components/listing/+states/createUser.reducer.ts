import { createReducer, on, Action, State } from '@ngrx/store';

import * as  CreateUserActions from './createUser.action';
import { CreateUserState } from './createUser.model';

export const CREATEUSER_FEATURE_KEY = 'createUser';

export interface CreateUserPartialState {
  readonly [CREATEUSER_FEATURE_KEY]: CreateUserState;
}

export const initialState: CreateUserState = {
  // set initial required properties
  loaded: false,
  taskInfo: undefined,
  loading: false,
};

const createUserReducer = createReducer(
  initialState,
  on(CreateUserActions.loadCreateUser, state => ({
    ...state,
    loaded: false,
    error: null
  })),
  on(CreateUserActions.createUserSuccess, (state, { createUser }) => ({
    ...state,
    loaded: true,
    response: null,
    taskInfo: createUser
  })),
  on(CreateUserActions.createUserComplete, (state, { createUser }) => ({
    ...state,
    loaded: true,
    response: createUser,
    taskInfo: null
  })),
  on(CreateUserActions.createUserFailure, (state, { error }) => ({
    ...state,
    error
  }))
);

export function reducer(state: CreateUserState | undefined, action: Action) {
  return createUserReducer(state, action);
}
