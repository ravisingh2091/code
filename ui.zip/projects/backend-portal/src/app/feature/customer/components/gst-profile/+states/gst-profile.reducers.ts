import { createReducer, on, Action } from '@ngrx/store';

import * as GSTProfileActions from './gst-profile.actions';
import { GSTProfileState } from './gst-profile.models';

export const GSTPROFILE_FEATURE_KEY = 'gstProfile';

export interface GSTProfilePartialState {
  readonly [GSTPROFILE_FEATURE_KEY]: GSTProfileState;
}


export const initialState: GSTProfileState = {
  // set initial required properties
  loaded: false,
  taskInfo: null,
  loading: false,
};

const gstProfileReducer = createReducer(
  initialState,
  // on(GSTProfileActions.LoadGSTProfile, state => ({
  //   ...state,
  //   loaded: false,
  //   error: null
  // })),
  on(
    GSTProfileActions.resetGSTData, (state) => ({
      ...state,
      taskInfo: null
    })
  ),
  on(
    GSTProfileActions.loadGSTProfileSuccess, (state, { gstProfile }) => ({
      ...state,
      loaded: true,
      response: null,
      taskInfo: gstProfile
    })
  ),
  on(
    GSTProfileActions.gstProfileSubmit, (state, { formData }) => ({
      ...state,
      loaded: false,
      loading: true
    })
  ),
  on(
    GSTProfileActions.gstProfileComplete, (state, { gstProfile }) => ({
      ...state,
      loaded: true,
      response: gstProfile
    })
  ),
  on(GSTProfileActions.gstProfileFailure, (state, { error }) => ({
    ...state,
    error
  }))
);

export function reducer(state: GSTProfileState | undefined, action: Action) {
  return gstProfileReducer(state, action);
}
