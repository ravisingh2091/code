import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GstProfileViewComponent } from './gst-profile-view.component';

describe('GstProfileViewComponent', () => {
  let component: GstProfileViewComponent;
  let fixture: ComponentFixture<GstProfileViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GstProfileViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GstProfileViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
