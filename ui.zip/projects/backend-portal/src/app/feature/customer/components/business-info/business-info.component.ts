import { Component, OnInit, OnDestroy, ElementRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { Subscription, Observable, Subject } from 'rxjs';
import { BusinessInfoFacade } from './+states/business-info.facade';
import { CommonService } from '@shared/services/common.service';
import { ApplicationService } from '@shared/services/application.service';
import { FileUploadService } from '@shared/services/file-upload.service';
import { DownloadService } from '@shared/services/download.service';
import { FileValidator } from '@utils/validaters/file.validaters';
import { GSTProfileFacade } from '../gst-profile/+states/gst-profile.facade';
import { LoadGSTProfile } from '../gst-profile/+states/gst-profile.actions';
import { forkJoin } from 'rxjs';
import { addAppID, addBusinessID } from '@utils/+state/utils.action';
import {
  LoadOtp
} from './+states/business-info.actions';
import { SLUG } from '@shared/constants/slug';
import { Store, select } from '@ngrx/store';
import { take, switchMap } from 'rxjs/operators';
import { ServiceProvidorService } from '../../../../shared/services/service-providor.service';

@Component({
  selector: 'app-business-info',
  templateUrl: './business-info.component.html',
  styleUrls: ['./business-info.component.scss'],
})
export class BusinessInfoComponent implements OnInit, OnDestroy {
  phone: string;
  otp: string;
  showGSTProfile = false;
  loadOtpSubscrition: Subscription;
  rootStateSubscription: Subscription;
  otpResponseSubscription: Subscription;
  otpValue: any;
  verifiedData: any;
  businessInfoResponseSubscription: Subscription;
  businessDetailsResponse: Subscription;
  businessInfoForm: FormGroup;
  gstProfileForm: FormGroup;
  businessInfoConfig: FormFieldInterface[] = [];
  slug: string;
  userID: string;
  appID: string;
  businessID: string;
  businessPan: any;
  businessInfoSubscription: Subscription;
  otpLoaded: Subscription;
  businessName: string;
  fileData: any;
  pan_doc_type_id: string;
  ownership_doc_type_id: string;
  isFileValid;
  panProviderData = [];
  ownershipProviderData = [];
  tempFileList: any;
  allowedfilestypes_pan = '';
  allowedfilestypes_ownership = '';
  registered_address: any;
  uploadedFiles: any[] = [];
  registeredAddress: any;
  phoneNumber: any;
  file_upload: any;
  gstProfile: any;
  files: any = [];
  error: any;
  allowedFiles_pan: any;
  allowedFiles_ownership: any;
  progress = undefined;
  manualUploadForm: FormGroup;
  selectedFileIndex: number = null;
  isPanUploaded: Boolean;
  otp_state: any = 'unverified';
  otpSubscription: Subscription;
  formSubmitSubscription: Subscription;
  formdatasubscription: any;
  fileDeleteGet: Subscription;
  panprovidorID: string;
  docProviderID: string;
  gstProviderID: string;
  gstProfileproviderID: string;
  isAddressSplit: boolean;
  ownership_doc_type_key: any;
  pan_doc_type_key: any;
  constructor(
    private businessInfoFacade: BusinessInfoFacade,
    private gstProfileFacade: GSTProfileFacade,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private common: CommonService,
    private fileupload: FileUploadService,
    private api: ApplicationService,
    private downloadService: DownloadService,
    private el: ElementRef,
    private serviceProvider: ServiceProvidorService
  ) { }

  ngOnInit(): void {
    try {
      this.common.gstApiSubject.next('initial');
      this.common.customerFooterEmit = true;
      this.otpSubscription = this.common.businessInfoFormGet.subscribe((result) => {
        this.onClick(result);
      });
      this.formSubmitSubscription = this.common.formSubmitGet.subscribe((result) => {
        this.onSubmit(result);
      });
      this.common.goBackGet.subscribe((res) => {
        this.goBack();
      });
      this.fileDeleteGet = this.common.fileDeleteGet.subscribe((res) => {

        this.onDelete(res.file,res.index);
      })
      this.rootStateSubscription = this.store
        .pipe(select('app'), take(1))
        .subscribe((rootState) => {
          if (rootState) {
            this.userID = rootState.userData.id;
            this.phoneNumber = rootState.userData.phone_number;
            if (rootState.appID) {
              this.appID = rootState.appID;
            }
            if (rootState.businessID) {
              this.businessID = rootState.businessID;
            }
            if (rootState.businessPan) {
              this.businessPan = rootState.businessPan;
            }
          }
        });

        let panProviderObJ5 = this.serviceProvider.getProviderData('pan-verification');
        if (panProviderObJ5&& panProviderObJ5.id) {
          this.panprovidorID=panProviderObJ5.id;
        }

      //Load business-info page
      this.api.getTaskInfo({
        slug: SLUG.businessInfo,
        app_id: this.appID,
        user_id: this.userID,
        expands: 'business,business_references',
        service_provider:this.panprovidorID
      }).subscribe((businessInfo: any) => {
        if (businessInfo) {
          this.slug = businessInfo.task_slug;
          this.businessInfoConfig = businessInfo.form_fields;
          this.businessInfoForm = this.formGenerate.createControl(this.businessInfoConfig);
          this.businessInfoForm.get('user_consent').get('phone_number').setValue(this.phoneNumber);
        }
        if (this.appID) {
          if (businessInfo ?.response_data ?.user_apps ?.data ?.data ?.length > 0
            && businessInfo ?.response_data ?.user_apps ?.data ?.data[0] ?.business ?.length > 0) {
            this.otp_state = businessInfo ?.response_data ?.user_apps ?.data ?.data[0] ?.business[0] ?.otp_state;
            this.businessInfoForm
              .get('business_pan')
              .setValue(businessInfo ?.response_data ?.user_apps ?.data ?.data[0] ?.business[0] ?.business_pan);
            this.businessInfoForm.get('terms_and_condition')
              .setValue(businessInfo ?.response_data ?.user_apps ?.data ?.data[0] ?.business[0] ?.terms_and_condition);

            //check business_references and extract info
            if (businessInfo ?.response_data ?.user_apps ?.data ?.data[0] ?.business_references.length > 0) {
              let gstProfile_ref_id;
              const business_references = businessInfo?.response_data?.user_apps?.data?.data[0]?.business_references;
              business_references.forEach((val,index) => {
                if (val.type === 'document-management') {
                  if (typeof val.response === 'string') { val.response = JSON.parse(val.response) }
                  if (val.response.type === 'pan') {
                    val.response["ref_id"] = val.ref_id;
                    val.response["data_id"] = val._id;
                    this.uploadedFiles.push(val.response);
                    this.isPanUploaded = true;
                  }
                  if (val.response.type === 'ownership') {
                    val.response.size = this.fileupload.calculateSize(val.response.size);
                    val.response["ref_id"] = val.ref_id;
                    val.response["data_id"] = val._id;
                    this.files.push(val.response);
                  }
                }
                if (val.type === 'gst_profile') {
                  gstProfile_ref_id = val.ref_id;
                }
              });
              if (this.isPanUploaded) {
                this.businessInfoForm.get('business_pan_file').disable();
              }
              if (businessInfo ?.response_data ?.user_apps ?.data ?.data[0] ?.business[0] ?.otp_state === 'verified' && gstProfile_ref_id) {
                this.businessInfoForm.get('show_consent_box').setValue(false);
                this.registeredAddress = businessInfo ?.response_data ?.user_apps ?.data ?.data[0] ?.business[0] ?.primary_business_address ?.registered_address;
                this.common.gstApiSubject.next('loading');
                this.api.getTaskInfo({ slug: SLUG.getGstProfile, app_id: this.appID, ref_id: gstProfile_ref_id }).subscribe(res => {
                  this.gstProfile = res;
                  this.common.gstApiSubject.next('loaded');
                },(err)=> {
                  this.common.popToast('error','Error','Error while fetching GST data');
                })
              }
            }
            if (!this.businessID) {
              this.businessID = businessInfo ?.response_data ?.user_apps ?.data ?.data[0] ?.business[0].business_id;
              this.businessInfoFacade.dispatch(addBusinessID({ businessID: this.businessID }));
            }
            this.common.businessInfoFileUpload = this.uploadedFiles;
          }
        }
        this.file_upload = this.common.businessInfoFileUploadGet.subscribe(async result => {
          this.tempFileList = result;
          this.isFileValid = this.fileupload.isFileAllowed(this.tempFileList, this.allowedfilestypes_pan.split(','), 10);
          if (this.isFileValid.type) {
            this.common.popToast('error', 'Invalid File Type', this.isFileValid.type);
            // make the files array empty
            this.tempFileList = [];
            this.businessInfoForm.get('file_data').setValue(null);
            this.businessInfoForm.get('business_pan_file').setValue(null);
          }
          if (this.tempFileList.length > 2) {
            this.common.popToast('error', 'Limit exceeded', 'More than 2 files selected');
            this.tempFileList = [];
            this.businessInfoForm.get('file_data').setValue(null);
            this.businessInfoForm.get('business_pan_file').setValue(null);
          }
          for (const val of this.tempFileList) {
            val.file = await filetobase64(val);
          }
          function filetobase64(file) {
            return new Promise((resolve, reject) => {
              const reader = new FileReader();
              reader.readAsDataURL(file);
              reader.onload = () => resolve(reader.result);
              reader.onerror = error => reject(error);
            });
          }
          if(this.appID){
            if(this.tempFileList.length > 0){
            this.businessInfoForm.get('show_upload_pan_file').setValue(true);
            }
          }
        });

        try {
          this.api.getTaskInfo({
            slug: SLUG.documentType
          }).subscribe(async res => {
            res.response_data.document_types.data.data.forEach((val) => {
              if (val.key === 'pan') {
                this.allowedfilestypes_pan = val.allowed_file_type;
                this.pan_doc_type_id = val.id;
                this.pan_doc_type_key=val.key;
                this.allowedFiles_pan = FileValidator.getContentType(this.allowedfilestypes_pan.split(','));
              }
              if (val.key === 'ownership') {
                this.allowedfilestypes_ownership = val.allowed_file_type;
                this.ownership_doc_type_id = val.id;
                this.ownership_doc_type_key=val.key;
                this.allowedFiles_ownership = FileValidator.getContentType(this.allowedfilestypes_ownership.split(','));
              }
            });
            res.response_data.service_providers.data.data.forEach((val) => {
              if (val.type === 'pan') {
                this.panProviderData = val;
              }
              if (val.type === 'document-management') {
                this.ownershipProviderData = val;
              }
            });

          }, (err) => {
            this.common.popToast('error','Error','Error while fetching data from backend, please contact Admin');
          });
        } catch (e) { }
      }, (err) => {
        this.common.popToast('error','Error', 'Error while loading Business Info');
      });

    } catch (e) { }

  }
  onDelete(data,index) {
    let deleteConfirm = confirm("Are you sure you want to remove this pan document?");
    let _id: any;
    if (deleteConfirm) {
      if (data?._id) { _id = data?._id }
      if (data?.data_id) { _id = data?.data_id }
      this.api.getTaskInfo({
        slug: SLUG.documentDelete,
        "_id": _id
      }).subscribe((res) => {
        if (res && res.response_data.nextTask && res.response_data.nextTask.value !== 'error') {
          this.uploadedFiles.splice(index,1)
          if (this.uploadedFiles.length == 0){
            this.isPanUploaded = false;
            this.businessInfoForm.get('business_pan_file').enable();
            this.businessInfoForm.get('file_data').setValue(null);
            this.businessInfoForm.get('business_pan_file').setValue(null);
          }
        }
      }, (err) => {
        this.common.popToast('error','Error','Error while removing file');
      })
    }
  }
  removeFile(file, index) {
    let deleteConfirm = confirm("Are you sure you want to remove this ownership proof?");
    let _id: any;
    if (deleteConfirm) {
      this.selectedFileIndex = index;
      if (file ?._id ?._value) { _id = file ?._id ?._value }
      if (file ?.data_id) { _id = file ?.data_id }
      this.api.getTaskInfo({
        slug: SLUG.documentDelete,
        "_id": _id
      }).subscribe((res) => {
        if (res && res?.response_data?.nextTask && res?.response_data?.nextTask?.value !== 'error') {
          for (let i = 0; i < this.files.length; i++) {
            if (_id === this.files[i]._id ?._value) {
              this.files.splice(i, 1);
              break;
            }
            if (_id === this.files[i].data_id) {
              this.files.splice(i, 1);
              break;
            }
          }
          this.common.popToast('success', 'Success', 'File deleted successfully');
        }
      }, (err) => {
        this.common.popToast('error','Error','Error while removing file');
       })
    } else {
      this.selectedFileIndex = null;
    }
  }
  downloadFile(file) {
    let ref_id: any;
    if (file ?.doc_id ?._value) { ref_id = file ?.doc_id ?._value }
    if (file ?.ref_id) { ref_id = file ?.ref_id }
    this.api.getTaskInfo({
      slug: SLUG.documentDownload,
      "doc_id": ref_id
    }).subscribe((res) => {
      if (res && res?.response_data?.nextTask && res?.response_data?.nextTask?.value !== 'error') {
        this.downloadService.showPdf(res?.response_data?.document_download?.data?.data?.body, file.name);
      }
    }, (err) => {
      this.common.popToast('error','Error','Error while downloading file');
    })
  }

  legalNameBusiness(data: any): void {
    this.businessName = data.legalNameBusiness;
    this.gstProfileForm = data.gstProfileForm;
  }

  /*****
   * converts byte size to MB
  */
  formatBytes(bytes, decimals = 2) {
    if (bytes === 0) { return '0 Bytes'; }

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  /* Ownership PDF upload */
  onSelectFile($event) {
    let files: File[];
    if ($event) {
      $event.preventDefault();
      files = $event.target.files;
      if (!files || !files.length) {
        return;
      }
    }
    this.error = undefined;
    const invalid = FileValidator.isFileAllowed(files, this.allowedfilestypes_pan.split(','), 10485760);
    if (invalid) {
      this.error = invalid;
      // make the files array empty
      files = [];
      return;
    }


    // push files to array: temporary array
    const tempFiles = [];
    Array.from(files).forEach((file: File) => {
      tempFiles.push(file);
    });

    this.uploadDocument.call(this, tempFiles).subscribe({
      next: (end) => {
        // ... the dialog can be closed again...
        this.common.popToast('success', 'Success', "Document is uploaded successfully.");
        // this.manualUploadForm.get('file').setValue('');


        // ... the upload was successful...
        /* this.uploadSuccessful = true;

         // ... and the component is no longer uploading
         this.uploading = false;*/
      },
      error: () => {
        // this.manualUploadForm.get('file').setValue('');
        // make the files array empty
        this.files = [];
        this.common.popToast('error','Error','Error while uploading file');
      }
    });
  }

  private uploadDocument(files) {
    let docProviderObJ = this.serviceProvider.getProviderData('document-management');
    if (docProviderObJ && docProviderObJ.id ) {

      this.docProviderID=docProviderObJ.id;
    }

    this.progress = this.fileupload.uploadFile(files, { slug: SLUG.documentUpload }, {
      app_id: this.appID,
      user_id: this.userID,
      provider: this.ownershipProviderData['id'],
      doc_type_id: this.ownership_doc_type_id,
      doc_type_key:this.ownership_doc_type_key,
      service_provider:this.docProviderID


    });
    let allProgressObservables = [];
    for (let key in this.progress) {
      allProgressObservables.push(this.progress[key].progress);
      this.files.push({
        doc_id: this.progress[key].doc_id,
        name: key,
        size: this.progress[key].size,
        progress: this.progress[key].progress,
        _id: this.progress[key]._id
      });
    }
    return forkJoin(allProgressObservables);
  }

  /* Scroll and highlight the first invalid formfield */
  private scrollToFirstInvalidControl() {
    const firstInvalidControl: HTMLElement = this.el.nativeElement.querySelector(
      "form .ng-invalid"
    );

    firstInvalidControl.focus(); //without smooth behavior
  }

  goBack = (): void => {
    this.common.navigate('user-listing');
  }

  /**
   *
   * @param val save/continue
   */
  onSubmit = (val): void => {
    try {
      if (
        this.formGenerate.validateCustomFormFields(
          this.businessInfoForm,
          'continue',
          this.businessInfoConfig)
      ) {
        if(this.businessInfoForm.get('show_upload_pan_file').value === true){
          alert('Please press button to upload PAN file');
        } else {

        if (!this.businessInfoForm.get('show_consent_box').value) {
        const appType = this.common.getAppType('unsecured_business_loan');
        const appStatus = this.common.getAppStatus('Incomplete');
        let payload: any = {
          business_pan: this.businessInfoForm.get('business_pan').value,
          terms_and_condition: this.businessInfoForm.get('terms_and_condition').value,
          business_id: this.businessID,
          action_type: val.action,
          user_id: this.userID,
          app_id: this.appID,
          otp_state: this.otp_state,
          status_id: appStatus.id,
          product_type: appType.id
        };


        let addressObservable = new Observable((observer) => {
          observer.next(null);
          observer.complete();
        });
        if(val.action === 'continue'){
          addressObservable = this.api.saveTaskInfo(
            {
              address: this.gstProfileForm.getRawValue().primary_business_address.registered_address,
              stub: 'stub',
              consent: 'y',
              version: '2.1',
              action: 'address_split',
              provider: 'K10'
            },
            { slug: SLUG.addressSplit });
        }

        addressObservable
          .pipe(
            switchMap((res: any) => {
              if (res) {
                if (res ?.address_split ?.status === 200) {
                  if(Object.keys(res ?.address_split ?.data ?.data ?.result).length === 0 && val.action === 'continue'){
                    this.isAddressSplit = false;
                    this.common.popToast('error','Error','Error while submitting business info');
                  } else {
                    this.isAddressSplit = true;
                    let address_line_1;
                    let address_line_2;
                    let address_line_3;
                    const registeredAddress = res.address_split.data.data.result;
                    if(registeredAddress.House || registeredAddress.Floor || registeredAddress.Complex || registeredAddress.Building){
                      let house = registeredAddress.House?registeredAddress.House + ", " : ""
                      let floor = registeredAddress.Floor?registeredAddress.Floor + ", " : ""
                      let complex = registeredAddress.Complex? registeredAddress.Complex +", " : ""
                      let building  = registeredAddress.Building?registeredAddress.Building:""
                      address_line_1 = house + floor + complex + building;
                    }
                    if(registeredAddress.Street || registeredAddress.Landmark || registeredAddress.locality){
                      let street = registeredAddress.Street? registeredAddress.Street+ ", " : ""
                      let landmark = registeredAddress.Landmark? registeredAddress.Landmark + ", ": ""
                      let locality = registeredAddress.locality? registeredAddress.locality+ ", ":""
                      let untagged = registeredAddress.Untagged? registeredAddress.Untagged:""
                      address_line_2 = street + landmark + locality + untagged;
                    }
                    if(registeredAddress.City || registeredAddress.State){
                      let city = registeredAddress.City? registeredAddress.City+ ", " : ""
                      let state = registeredAddress.State? registeredAddress.State: ""
                      address_line_3 = city + state;
                    }
                    payload.business_address = {
                      address_line_1: address_line_1 || " ",
                      address_line_2: address_line_2 || " ",
                      address_line_3: address_line_3 || " ",
                      pincode: registeredAddress.Pin,
                      state: registeredAddress.State,
                      type_of_address: 'REGISTERED OFFICE',
                      city: registeredAddress.City || registeredAddress.State
                    };
                  }
                  payload = { ...this.gstProfileForm.getRawValue(), ...payload };
                }
              }
              if (val.action === 'continue') {
                if(this.isAddressSplit) {
                  payload.current_state = 'owners-details';
                }
                payload.legal_name_business = this.businessName;
              }
              if (val.action === 'save') {
                return this.api.saveTaskInfo(payload, { slug: SLUG.updateBusiness });
              } else if (val.action === 'continue') {
                if (this.otp_state === 'verified') {
                  return this.api.saveTaskInfo(payload, { slug: SLUG.updateBusiness });
                }
                else {
                  this.common.popToast('error', 'Cannot Proceed Further', 'Please verify otp');
                }
              }
            })
          ).subscribe((res) => {
            if (val.action === 'save') {
              if (!this.appID) {
                this.businessInfoFacade.dispatch(addAppID({ appID: res ?.create_application ?.data ?.data ?._id }));
                this.appID = res ?.create_application ?.data ?.data ?._id;
              }
              if (!this.businessID) {
                this.businessInfoFacade.dispatch(addBusinessID({ businessID: res ?.create_business ?.data ?.data ?._id }));
                this.businessID = res ?.create_business ?.data ?.data ?._id;
              }
              this.common.navigate('user-listing');
            }
            if (val.action === 'continue' && this.isAddressSplit) {
              this.common.navigate('owners-details');
            }
          }, (err) => {
            this.common.popToast('error','BusinessInfo','Error while submitting business info');
          });
        } else {
          this.common.popToast('error', 'Cannot Proceed Further', 'Please verify otp');
        }
        }
      } else {
        this.scrollToFirstInvalidControl();
      }
    } catch (e) { }
  }
  /* For generate-otp, upload-pan, verify-otp and send otp */
  onClick(event): void {
    if (event === 'handle_change') {
      this.businessInfoForm
        .get('user_consent')
        .get('show_otp')
        .setValue(false);
    } else {
      try {
        this.businessInfoForm.controls['terms_and_condition'].markAsTouched();
        if (
          this.formGenerate.validateCustomFormFields(
            this.businessInfoForm,
            'continue',
            this.businessInfoConfig
          ) && this.businessInfoForm.get('terms_and_condition').value === true
        ) {
          if (!this.businessInfoForm.get('user_consent').get('show_otp').value) {
            this.common.storeDataInStorage('business_phone', this.businessInfoForm.get('user_consent').get('phone_number').value);
            if (this.businessInfoForm.get('user_consent').get('phone_number').value) {
              this.api.getTaskInfo({
                slug: SLUG.checkPhonenumber,
                phone_number: this.businessInfoForm.get('user_consent').get('phone_number').value
              }).subscribe((res) => {
                let loadOTP: boolean;
                if (res && res.response_data.nextTask && res.response_data.nextTask.value !== "error") {
                  if (res.response_data.check_phonenumber.data.data.length > 0) {
                    if (res.response_data.check_phonenumber.data.data[0].id === this.userID) { loadOTP = true }
                  }
                  else { loadOTP = true }
                }
                if (loadOTP === true) {
                  this.api.saveTaskInfo({
                    phone_number: `+91${this.businessInfoForm.get('user_consent').get('phone_number').value}`
                   }, { slug: SLUG.generateOtp, type: 'verification' }).subscribe(
                    (otpState) => {
                      if (otpState) {
                        if (this.businessInfoForm) {
                          this.fileData = this.businessInfoForm ?.value.file_data;
                          this.otpValue = otpState.otp_generate ?.data ?.data ?.otp;
                          this.businessInfoForm
                            .get('user_consent')
                            .get('show_otp')
                            .setValue(true);
                          this.otp_state = 'verifying';
                        }
                      }
                    }, (err) => {
                      err?.send_otp?.errors?.errors?.forEach(elem => {
                        if(elem.type === "FIELD_REQUIRED" && elem.parameter === "mobile"){
                          this.common.popToast('error','Error','Mobile number is required');
                        }
                        if(elem.type === "FIELD_INVALID" && elem.parameter === "otp"){
                          this.common.popToast('error','Error','Error while generating OTP please try again');
                        }
                      })
                    })
                } else {
                  this.common.popToast('error', 'Already Exists', 'This phone number has already been registered');
                }
              }, (err) => {
                this.common.popToast('error','Error','There was some problem while checking phone number');
              })
            }
          } else {
            if (this.businessInfoForm.get('user_consent').get('show_otp').value) {
              if (this.businessInfoForm.get('user_consent').get('otp').value !== null && this.businessInfoForm.get('user_consent').get('otp').value !== "") {
                let phoneNumber = this.common.getDataFromStorage('business_phone');
                this.api.saveTaskInfo({
                  phone_number: `91${phoneNumber}`,
                  otp: this.businessInfoForm.get('user_consent').get('otp').value
                }, { slug: SLUG.verifyOtp }).subscribe((res) => {
                  if (res && res.nextTask && res.nextTask.value !== "error") {
                    this.otp_state = 'verified';
                    const appType = this.common.getAppType('unsecured_business_loan');
                    const appStatus = this.common.getAppStatus('Incomplete');
                    const payload: any = {
                      business_pan: this.businessInfoForm.get('business_pan').value,
                      terms_and_condition: this.businessInfoForm.get('terms_and_condition').value,
                      user_id: this.userID,
                      action_type: 'save',
                      stub: 'stub',
                      otp_state: this.otp_state,
                      service_provider:this.serviceProvider.getProviderData('pan-verification')['id'],
                      status_id: appStatus.id,
                      product_type: appType.id
                    };
                    if (this.appID) { payload.app_id = this.appID; }
                    if (this.businessID) { payload.business_id = this.businessID; }
                    this.businessInfoForm.get('show_consent_box').setValue(false);
                    this.api.saveTaskInfo(payload, { slug: this.slug }).subscribe((data) => {
                      if (!this.businessID) {
                        this.businessID = data ?.create_business ?.data ?.data ?._id;
                        this.businessInfoFacade.dispatch(addBusinessID({ businessID: this.businessID }));
                      }
                      if (!this.appID) {
                        this.appID = data ?.create_application ?.data ?.data ?._id;
                        this.businessInfoFacade.dispatch(addAppID({ appID: this.appID }));
                      }

                      let gstProviderObJ = this.serviceProvider.getProviderData('gst_search');
                      if (gstProviderObJ && gstProviderObJ.id) {
                        this.gstProviderID=gstProviderObJ.id

                      }
                      let gstProfileproviderObJ = this.serviceProvider.getProviderData('gst_profile');
                      if (gstProfileproviderObJ && gstProfileproviderObJ.id) {
                        this.gstProfileproviderID=gstProfileproviderObJ.id
                      }
                      this.gstProfileFacade.dispatch(
                        new LoadGSTProfile({
                          slug: SLUG.gstData,
                          stub: 'stub',
                          business_pan: this.businessInfoForm.get('business_pan').value,
                          app_id: this.appID,
                          user_id: this.userID,
                          service_provider:this.gstProviderID,
                          service_provider2:this.gstProfileproviderID
                        })
                      );
                      this.common.gstApiSubject.next('loading');
                      if (this.tempFileList) {
                        const allProgressObservables = [];
                        let docProviderObJ = this.serviceProvider.getProviderData('document-management');
                        if (docProviderObJ && docProviderObJ.id) {
                          this.docProviderID= docProviderObJ.id
                        }
                        for (const val of this.tempFileList) {
                          const progress = this.api
                            .saveTaskInfo(
                              {
                                type: val.type,
                                filename: val.name,
                                response_to_be_saved: { filesize: val.size, filename: val.name, type: "pan" },
                                data: val.file,
                                app_id: data.create_application.data.data._id,
                                user_id: this.userID,
                                doc_type_id: this.pan_doc_type_id,
                                filekey: 'data',
                                // provider: this.panProviderData['id'],
                                doc_type_key : this.pan_doc_type_key,
                                service_provider:this.docProviderID
                              }, {
                                slug: SLUG.documentUpload,
                              });
                          allProgressObservables.push(progress);
                        }
                        forkJoin(allProgressObservables).subscribe((response: any) => {
                          if (response) {
                            response.forEach((val) => {
                              val.upload_document_reference.data.data.response["_id"] = val.upload_document_reference.data.data._id;
                              val.upload_document_reference.data.data.response["doc_id"] = val.upload_document_reference.data.data.ref_id;
                              this.uploadedFiles.push(val ?.upload_document_reference ?.data ?.data ?.response);
                              this.isPanUploaded = true;
                            });
                          }
                        }, (err) => {
                          this.common.popToast('error','Error','Error while uploading PAN file');
                        });
                      }
                    }, (err) => {
                      this.businessInfoForm.get('show_consent_box').setValue(true);
                      if (err) {
                        if (!this.businessID) {
                          this.businessID = err ?.create_business ?.data ?.data ?._id;
                          this.businessInfoFacade.dispatch(addBusinessID({ businessID: this.businessID }));
                        }
                        if (!this.appID) {
                          this.appID = err ?.create_application ?.data ?.data ?._id;
                          this.businessInfoFacade.dispatch(addAppID({ appID: this.appID }));
                        }
                        this.businessInfoForm
                          .get('user_consent')
                          .get('show_otp')
                          .setValue(false);
                        // this.common.popToast('error','Error','Error while submitting business-info');
                      }
                    });
                  }
                });
              }
              else if (this.businessInfoForm.get('user_consent').get('otp').value === null || this.businessInfoForm.get('user_consent').get('otp').value === "") {
                if (this.businessInfoForm.get('user_consent').get('show_otp').value === true) {
                  this.common.popToast('error','OTP','Please enter OTP');
                }
              }
            }

          }
        } else {
          this.formGenerate.validateCustomFormFields(
            this.businessInfoForm,
            'continue',
            this.businessInfoConfig
          );
        }
        if(this.businessInfoForm.get('show_upload_pan_file').value === true) {
          if (this.tempFileList) {
            const allProgressObservables = [];
            let docProviderObJ = this.serviceProvider.getProviderData('document-management');
                if (docProviderObJ && docProviderObJ.id) {

                  this.docProviderID= docProviderObJ.id

                }
            for (const elem of this.tempFileList) {
              let docProviderObJ = this.serviceProvider.getProviderData('document-management');
                if (docProviderObJ && docProviderObJ.id) {

                  this.docProviderID= docProviderObJ.id

                }
              const progress = this.api
                .saveTaskInfo(
                  {
                    type: elem.type,
                    filename: elem.name,
                    response_to_be_saved: { filesize: elem.size, filename: elem.name, type: "pan" },
                    data: elem.file,
                    app_id: this.appID,
                    user_id: this.userID,
                    doc_type_id: this.pan_doc_type_id,
                    doc_type_key : this.pan_doc_type_key,
                    filekey: 'data',
                    // provider: this.panProviderData['id'],
                    service_provider:this.docProviderID
                  }, {
                  slug: SLUG.documentUpload,
                });
              allProgressObservables.push(progress);
            }
            forkJoin(allProgressObservables).subscribe((response: any) => {
              if (response) {
                response.forEach(elem => {
                  if(elem?.upload_document_reference?.data?.data?.response){
                    elem.upload_document_reference.data.data.response["_id"] = elem.upload_document_reference.data.data._id;
                    elem.upload_document_reference.data.data.response["doc_id"] = elem.upload_document_reference.data.data.ref_id;
                    this.uploadedFiles.push(elem?.upload_document_reference?.data?.data?.response);
                    this.isPanUploaded = true;
                    this.businessInfoForm.get('business_pan_file').disable();
                    this.businessInfoForm.get('show_upload_pan_file').setValue(false);
                  }
                });
              }
            }, (err) => {
                this.common.popToast('error','Error','Error while uploading PAN file');
            });
          }
        }
      } catch (e) { }
    }
  }

  ngOnDestroy(): void {
    this.rootStateSubscription.unsubscribe();
    this.file_upload.unsubscribe();
    this.otpSubscription.unsubscribe();
    this.formSubmitSubscription.unsubscribe();
    this.fileDeleteGet.unsubscribe();
  }
}
