/**
 * Interface for the 'CreateUser' data used in
 */

export interface CreateUserState {
  loaded: boolean; // has the LendingNeeds list been loaded
  error?: any; // last none error (if any)
  loading: boolean;
  taskInfo: any;
  response?: any;
  errors?: any;
  formData?: any;
}
