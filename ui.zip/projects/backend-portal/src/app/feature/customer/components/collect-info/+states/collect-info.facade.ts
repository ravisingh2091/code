import { Injectable } from '@angular/core';
import { select, Store, Action } from '@ngrx/store';
import * as fromCollectInfo from './collect-info.reducers';
import * as CollectInfoFacadeSelectors from './collect-info.selectors';
@Injectable()
export class CollectInfoFacade {
  loaded$ = this.store.pipe(
    select(CollectInfoFacadeSelectors.getCollectInfoLoaded)
  );
  loadCollectInfo$ = this.store.pipe(
    select(CollectInfoFacadeSelectors.getCollectInfoStateData)
  );
  constructor(private store: Store<fromCollectInfo.collectInfoPartialState>) {}

  public dispatch(action: Action) {
    this.store.dispatch(action);
  }
}
