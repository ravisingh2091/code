import { ApplicationService } from '@shared/services/application.service';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-gst-profile-view',
  templateUrl: './gst-profile-view.component.html',
  styleUrls: ['./gst-profile-view.component.scss']
})
export class GstProfileViewComponent implements OnInit {
  isFirstOpen = true;
  @Input() appID;
  @Input() gstProfileRefId;
  @Input() gstProfileData;
  constructor(private api: ApplicationService) { }

  ngOnInit(): void {
    this.gstProfileData.signatories = this.gstProfileData.authorized_members.join(',');
    this.gstProfileData.natureOfBusiness = this.gstProfileData.nature_of_business_gst.join(',');
  }
}
