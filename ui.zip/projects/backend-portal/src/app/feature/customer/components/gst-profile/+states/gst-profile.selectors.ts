import { createFeatureSelector, createSelector, State } from '@ngrx/store';
import {
  GSTPROFILE_FEATURE_KEY,
  GSTProfilePartialState,
} from './gst-profile.reducers';
import { GSTProfileState } from './gst-profile.models';

// Lookup the 'GSTProfile' feature state managed by NgRx
export const getGSTProfileState = createFeatureSelector<GSTProfileState>(GSTPROFILE_FEATURE_KEY);


export const getGSTProfileLoaded = createSelector(
  getGSTProfileState,
  (state: GSTProfileState) => state.loaded
);

export const getGSTProfileError = createSelector(
  getGSTProfileState,
  (state: GSTProfileState) => state.error
);

export const getAllGSTProfile = createSelector(
  getGSTProfileState,
  getGSTProfileLoaded,
  (state: GSTProfileState,getGSTProfileLoaded) => (getGSTProfileLoaded && !state.response) ? state.taskInfo : null
  );

export const getGSTProfileResponse = createSelector(
  getGSTProfileState,
  (state: GSTProfileState) => state.response ? state.response : null
);
