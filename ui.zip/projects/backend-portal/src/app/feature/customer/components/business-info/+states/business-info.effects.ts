import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType, Effect } from '@ngrx/effects';
import { fetch, DataPersistence } from '@nrwl/angular';
import { map, switchMap } from 'rxjs/operators';
import { forkJoin } from 'rxjs';
import * as BusinessInfoActions from './business-info.actions';

import { BusinessInfoPartialState } from './business-info.reducers';
import {
  LoadOtp,
  OtpLoadError,
  BusinessInfoActionTypes,
  BusinessInfoFormSubmit,
} from './business-info.actions';
import { ApplicationService } from '@shared/services/application.service';

@Injectable()
export class BusinessInfoEffects {
  loadBusinessInfo$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(BusinessInfoActions.LoadBusinessInfo),
      fetch({
        id: () => {
          return new Date().getTime().toString();
        },
        run: (action) => {
          return this.applicationService
            .getTaskInfo({
              slug: action.slug,
              app_id: action.payload.app_id,
              user_id: action.payload.user_id,
              expands: action.payload.expands
            })
            .pipe(
              map((data: any) => {
                return BusinessInfoActions.LoadBusinessInfoSuccess({
                  businessInfo: data,
                });
              })
            );
          // Your custom service 'load' logic goes here. For now just return a success action...
        },
        onError: (action, error) => {
          console.error('Error', error);
          return BusinessInfoActions.BusinessInfoLoadError({ error });
        },
      })
    );
  });

  @Effect() loadOtp$ = this.dataPersistence.fetch(
    BusinessInfoActionTypes.LoadOtp,
    {
      id: (action: LoadOtp, state: BusinessInfoPartialState) => {
        return new Date().getTime().toString();
      },
      run: (action: LoadOtp, state: BusinessInfoPartialState) => {
        // Your custom REST 'load' logic goes here. For now just return an empty list...
        return this.applicationService
          .saveTaskInfo(
            {
              ...action.payload,
            },
            { slug: action.payload.slug }
          )
          .pipe(
            map((data: any) => {
              return BusinessInfoActions.OtpLoaded({ response: data });
            })
          );
      },

      onError: (action: LoadOtp, error) => {
        return new OtpLoadError(error);
      },
    }
  );

  @Effect() businessInfoFormSubmit$ = this.dataPersistence.fetch(
    BusinessInfoActionTypes.BusinessInfoFormSubmit,
    {
      id: (action: BusinessInfoFormSubmit, state: BusinessInfoPartialState) => {
        return new Date().getTime().toString();
      },
      run: (
        action: BusinessInfoFormSubmit,
        state: BusinessInfoPartialState
      ) => {
        // Your custom REST 'load' logic goes here. For now just return an empty list...
        return this.applicationService
          .saveTaskInfo(action.payload,
            { slug: action.payload.slug }
          )
          .pipe(
            switchMap((data: any) => {
              const allProgressObservables = [];
              // for (const key in action.payload.file) {
              for (const val of action.payload.file) {
                const progress = this.applicationService
                  .saveTaskInfo(
                    {
                      type: val.type,
                      filename: val.name,
                      data: val.file,
                      app_id: data.create_application.data.data._id,
                      user_id: action.payload.user_id,
                      doc_type_id: action.payload.doc_type_id,
                      filekey: 'data',
                      provider: action.payload.provider
                    }, {
                      slug: 'document-upload',
                    });

                allProgressObservables.push(progress);
              }
              return forkJoin(allProgressObservables)
                .pipe(
                  map((res: any) => {
                    if (res) {
                      return BusinessInfoActions.BusinessInfoResponse({
                        verifiedData: {
                          fileResponse: res,
                          businessResponse: data,
                        },
                      });
                    }
                  })
                );
              // }
              // else {
              //   debugger
              //   return BusinessInfoActions.BusinessInfoResponse({
              //     verifiedData : data
              //   });
              // }
            })
          );
      },

      onError: (action: BusinessInfoFormSubmit, error) => {
        return BusinessInfoActions.BusinessInfoLoadError({ error });
      },
    }
  );
  constructor(
    private actions$: Actions,
    private dataPersistence: DataPersistence<BusinessInfoPartialState>,
    private applicationService: ApplicationService
  ) { }
}
