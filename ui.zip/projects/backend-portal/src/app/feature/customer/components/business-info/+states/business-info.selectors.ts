import { createFeatureSelector, createSelector } from '@ngrx/store';
import { BUSINESSDETAILS_FEATURE_KEY } from './business-info.reducers';
import { BusinessInfoState, OtpState } from './business-info.model';
const getOtpState = createFeatureSelector<OtpState>(BUSINESSDETAILS_FEATURE_KEY);

// Lookup the 'BusinessInfo' feature state managed by NgRx
export const getBusinessInfoState = createFeatureSelector<BusinessInfoState>(
  BUSINESSDETAILS_FEATURE_KEY
);

export const getLoaded = createSelector(
  getBusinessInfoState,
  (state: BusinessInfoState) => state.loaded
);
export const getError = createSelector(
  getBusinessInfoState,
  (state: BusinessInfoState) => state.error
);

export const getAllBusinessInfo = createSelector(
  getBusinessInfoState,
  getLoaded,
  (state: BusinessInfoState, getForgotPasswordLoaded) =>
    getForgotPasswordLoaded && !state.response ? state.taskInfo : null
);
export const getBusinessInfoResponse = createSelector(
  getBusinessInfoState,
  getLoaded,
  (state: BusinessInfoState) => state.verifiedData ? state.verifiedData : null
);
export const getBusinessDetailsResponse = createSelector(
  getBusinessInfoState,
  getLoaded,
  (state: BusinessInfoState) => state.verifiedData ? state.verifiedData : null
);
export const getBusinessInfoResponseState = createSelector(
  getBusinessInfoState,
  getLoaded,
  (state: BusinessInfoState) => state.response ? state.response : null
);

export const getAllOtp = createSelector(
  getOtpState,
  getLoaded,
  (state: OtpState, isLoaded) => {
    return isLoaded ? state : null;
  }
);
export const getOtpResponse = createSelector(
  getOtpState,
  getLoaded,
  (state: OtpState) => (state.response ? state.response : null)
);
export const getResendOtpResponse = createSelector(
  getOtpState,
  getLoaded,
  (state: OtpState) => {
    return state.resendResponse;
  }
);
