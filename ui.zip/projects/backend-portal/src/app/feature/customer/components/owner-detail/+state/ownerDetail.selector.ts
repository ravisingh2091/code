import { createFeatureSelector, createSelector } from '@ngrx/store';
import {
  OWNERDETAILS_FEATURE_KEY,
  State,
  ownerDetailSheetPartialState,
  ownerDetailSheetAdapter
} from './ownerDetail.reducer';

// Lookup the 'ownerDetailSheet' feature state managed by NgRx
export const getownerDetailSheetState = createFeatureSelector<State>
(OWNERDETAILS_FEATURE_KEY);


export const getownerDetailSheetLoaded = createSelector(
  getownerDetailSheetState,
  (state: State) => state.loaded
);
export const getownerDetailSheetStateData = createSelector(
  getownerDetailSheetState,
  getownerDetailSheetLoaded,
  (state: State, isLoaded) => {
      return isLoaded&&state ? state : null
  }    
);
export const getownerDetailSheetFlag = createSelector(
  getownerDetailSheetState,
  (state: State) => state.generateownerDetailSheet  
);
export const getGenerateownerDetailSheetFlag = createSelector(
  getownerDetailSheetFlag,
  getownerDetailSheetLoaded,
  (flag: boolean, isLoaded) => {
      return isLoaded&&flag ? flag : null
  }    
);
export const getOwnerSheetResponseState = createSelector(
  getownerDetailSheetState,
  getownerDetailSheetLoaded,
  (state: State) => state.response_data
);

export const getownerDetailSheetError = createSelector(
  getownerDetailSheetState,
  (state: State) => state.error
);


