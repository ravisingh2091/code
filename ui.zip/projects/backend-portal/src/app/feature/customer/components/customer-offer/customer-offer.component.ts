import { Component, OnInit } from '@angular/core';
import { ApplicationService } from '../../../../shared/services/application.service';
import { FormGenerateService } from '../../../../shared/services/form-generate.service';
import { CommonService } from '@shared/services/common.service';
import { Subscription } from 'rxjs';
import {SLUG} from "../../../../shared/constants/slug";
import { Store, select } from '@ngrx/store';
import { take } from 'rxjs/operators';
import { APP_STATUS } from '../../../../shared/constants/app-status';

@Component({
  selector: 'app-customer-offer',
  templateUrl: './customer-offer.component.html',
  styleUrls: ['./customer-offer.component.scss']
})
export class CustomerOfferComponent implements OnInit {
  slug: any;
  appId;
  userId;
  customerOfferConfig: any;
  CustomerOfferForm: any;
  loanProcessFee = 0;
  rootStateSubscription: Subscription;
  providersData;
  formsubsctiption: Subscription;

  constructor(
    private api: ApplicationService,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private common: CommonService
  ) {
    this.common.goBackGet.subscribe((res) => {
      this.goBack();
    });

  }

  ngOnInit(): void {

    this.common.customerFooterEmit = true;
    /*fetch offer form values and create form */
    this.api.getTaskInfo({
      slug: SLUG.customerOffer,
    }).subscribe(res => {
      if (res) {
        this.slug = res.task_slug;
        this.customerOfferConfig = res.form_fields;
        this.providersData = res.response_data.service_providers.data.data;
        this.CustomerOfferForm = this.formGenerate.createControl(this.customerOfferConfig);
        this.setFormValues();
      }
    },
    err=>{
      this.common.popToast('error', 'Offer', 'error while getting offer details');
      this.common.nextsubscriptionEmit=true;
    });

    this.rootStateSubscription = this.store
      .pipe(
        select('app'),
        take(1)
      ).subscribe(rootState => {
        if (rootState) {
          this.appId = rootState.appID;
          this.userId = rootState?.userData?.id;
        }
      });
      /*subscribe to form submit button on the footer */
    this.formsubsctiption=this.common.formSubmitGet.subscribe((result) => {
      this.onSubmit(result);
    });
    
    this.common.NextButtonEmit='Submit';
  }

  goBack = (): void => {
    this.common.navigate(SLUG.IncomeExpense);
  }

  setFormValues(): void {
    this.CustomerOfferForm.controls.loan_amount.patchValue(100000);
    this.CustomerOfferForm.controls.term.patchValue(4);
    this.CustomerOfferForm.controls.interest_rate.patchValue(5);
    this.setLoanProcessFee();
  }

  setLoanProcessFee(): void {
    this.loanProcessFee = (1 / 100) * this.CustomerOfferForm.controls.loan_amount.value;
  }

  onSubmit(val): void {
    
    const formValues = this.CustomerOfferForm.getRawValue();
    /*create customer offer */
    this.api.saveTaskInfo({
      ...formValues,
      app_id: this.appId,
      user_id: this.userId,
      action: val.data,
      payload: formValues,
      provider: this.getProviderId(this.slug)
    }, { slug: SLUG.customerOffer,
       app_id: this.appId,
        user_id: this.userId
       }, null)
      .subscribe(() => {
        /*update status of the application as incomplete  */
        this.updateAppStatus(APP_STATUS.incomplete);
      }, (err) => this.common.popToast('error', 'Offer', 'error while submitting offer'));
  }

  updateAppStatus(status: string) {
    const successStatusData = this.common.getAppStatus(status);
    this.api.saveTaskInfo({
      status_id: successStatusData.id,
      note: "submitted",
      app_id: this.appId
    }, { slug: SLUG.updateApplication })
      .subscribe((result) => {
        /*update app status and navigate to listings page  */
        this.common.popToast('success', 'Offer', 'Offer created successfully');
        this.common.navigate(SLUG.userListing);
      }, err => this.common.popToast('error', 'Offer','error while submitting offer'));
  }

  getProviderId(type): object {
    /*find provider data for customer-offer slug */
    const object = this.providersData.find((val) => val.type === type);
    return object.id;
  }

  detectFormChanges() {
    this.setLoanProcessFee();
  }
  ngOnDestroy(): void {
    /*unsubscribe to form submit button on the footer */
    this.formsubsctiption.unsubscribe();
    this.common.nextsubscriptionEmit=false;    
    this.common.NextButtonEmit='Next';
  }
}
