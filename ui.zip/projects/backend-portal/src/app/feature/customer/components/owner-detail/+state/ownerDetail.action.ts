import { createAction, props } from '@ngrx/store';
import { ownerDetailSheetEntity } from './ownerDetail.model';

export const loadownerDetailSheet = createAction(
  '[ownerDetailSheet] Load ownerDetailSheet',
  props<{ user_id: string, slug: string, expands: string }>()
);

export const loadownerDetailSheetSuccess = createAction(
  '[ownerDetailSheet] Load ownerDetailSheet Success',
  props<{ ownerDetailSheet: any }>()
);

export const loadownerDetailSheetFailure = createAction(
  '[ownerDetailSheet] Load ownerDetailSheet Failure',
  props<{ error: any }>()
);
export const addSheetData = createAction(
  '[ownerDetailSheet] add Sheet Data',
  props<{ sheetData: any }>()
);
export const generateownerDetailSheet = createAction(
  '[ownerDetailSheet] Generate ownerDetailSheet',
  props<{ action: boolean }>()
);
export const setIntialownerDetailSheet = createAction(
  '[ownerDetailSheet] setIntial ownerDetailSheet'
);

export const formSubmit = createAction(
  '[ownerDetailSheet] form submitted',
  props<{ payload: any, slug: string }>()
);

export const formSubmitCompleted = createAction(
  '[ownerDetailSheet] form submit completed',
  props<{ ownerDetailSheet: any }>()
);
