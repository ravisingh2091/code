import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType, Effect } from '@ngrx/effects';
import { fetch, DataPersistence } from '@nrwl/angular';
import { map } from 'rxjs/operators';
import * as GSTProfileActions from './gst-profile.actions';
import { ApplicationService } from '../../../../../shared/services/application.service';
import { GSTActionTypes, LoadGSTProfile } from './gst-profile.actions';
import { GSTProfilePartialState } from './gst-profile.reducers';
import { CommonService } from '@shared/services/common.service';
@Injectable()
export class GSTProfileEffects {
  @Effect() loadGSTProfile$ = this.dataPersistence.fetch(
    GSTActionTypes.LoadGSTProfile,
    {
      id: (action: LoadGSTProfile, state: GSTProfilePartialState) => {
        return new Date().getTime().toString();
      },
      run: (action: LoadGSTProfile, state: GSTProfilePartialState) => {
        // Your custom REST 'load' logic goes here. For now just return an empty list...
        return this.applicationService
          .getTaskInfo(
            { ...action.payload }
          )
          .pipe(
            map((data: any) => {
              return GSTProfileActions.loadGSTProfileSuccess({
                gstProfile: data,
              });
            })
          );
      },

      onError: (action, error) => {
        this.common.popToast('error','Error','Error while fetching GST details');
        this.common.gstApiSubject.next('initial');
        return GSTProfileActions.gstProfileFailure({ error });
      },
    }
  );
  // loadGSTProfile$ = createEffect(() =>
  //   this.actions$.pipe(
  //     ofType(GSTProfileActions.loadGSTProfile),
  //     fetch({
  //       id: () => {
  //         return new Date().getTime().toString();
  //       },
  //       run: (action) => {
  //         return this.applicationService
  //           .getTaskInfo({
  //             slug: action.slug,
  //             stub: action.stub,
  //           })
  //           .pipe(
  //             map((data: any) => {
  //               // Your custom service 'load' logic goes here. For now just return a success action...
  //               return GSTProfileActions.loadGSTProfileSuccess({
  //                 gstProfile: data,
  //               });
  //             })
  //           );
  //       },

  //       onError: (action, error) => {
  //         console.error('Error', error);
  //         return GSTProfileActions.gstProfileFailure({ error });
  //       },
  //     })
  //   )
  // );

  submitgstProfile$ = createEffect(() =>
    this.actions$.pipe(
      ofType(GSTProfileActions.gstProfileSubmit),
      fetch({
        id: () => {
          return new Date().getTime().toString();
        },
        run: (action) => {
          return this.applicationService
            .saveTaskInfo(
              { ...action.formData },
              {
                slug: action.slug,
              }
            )
            .pipe(
              map((data: any) => {
                return GSTProfileActions.gstProfileComplete({
                  gstProfile: data,
                });
              })
            );
        },
        onError: (action, error) => {
          console.error('Error', error);
          return GSTProfileActions.gstProfileFailure({ error });
        },
      })
    )
  );
  constructor(
    private actions$: Actions,
    private dataPersistence: DataPersistence<GSTProfilePartialState>,
    private applicationService: ApplicationService,
    private common: CommonService
  ) { }
}
