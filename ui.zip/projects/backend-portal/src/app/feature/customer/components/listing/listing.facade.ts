import { Injectable } from '@angular/core';

import { select, Store, Action } from '@ngrx/store';

import * as fromApplicationListing from './listing.reducer';
import * as ApplicationListingSelectors from './listing.selectors';

@Injectable()

export class ApplicationListingFacade {
  loaded$ = this.store.pipe(
    select(ApplicationListingSelectors.getApplicationListingLoaded)
  );
  allApplicationListing$ = this.store.pipe(
    select(ApplicationListingSelectors.getAllApplicationListing)
  );
  applicationListingFilters$ = this.store.pipe(
    select(ApplicationListingSelectors.getApplicationFilters)
  );
  constructor(
    private store: Store<fromApplicationListing.ApplicationListingPartialState>
  ) { }

  // applicationListingFilters$: any;
  dispatch(action: Action) {
    this.store.dispatch(action);
  }
}
