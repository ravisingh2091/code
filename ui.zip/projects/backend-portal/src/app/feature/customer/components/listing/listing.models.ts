export interface ApplicationListingEntity {
    app_listing_total_count: any;
    response_data: any;
    app_listing_by_filter: any; 
     loaded?: boolean; // has the api been loaded
    error?: any; // last none error (if any)
    loading?: boolean;
    taskInfo?: any;
    response?: any;
  }
  