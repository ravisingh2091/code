import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-pan-validation',
  templateUrl: './pan-validation.component.html',
  styleUrls: ['./pan-validation.component.scss']
})
export class PanValidationComponent implements OnInit {
  isFirstOpen = true;
  @Input() businessData;
  constructor() { }

  ngOnInit(): void {
  }

}
