import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { fetch, DataPersistence } from '@nrwl/angular';

import { ApplicationService } from '@shared/services/application.service';

import { map } from 'rxjs/operators';
// import { ApplicationService } from '@sha';
// import { TaskInfoInterface } from '@rubicon/interface/task-info';

import * as ApplicationListingActions from './listing.action';
import { ApplicationListingPartialState } from './listing.reducer';
import { State } from '@ngrx/store';
// import { ApplicationService } from '../../../../shared/services/application.service';
// import { request } from 'http';

@Injectable()
export class ApplicationListingEffects {

  loadApplicationListing$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ApplicationListingActions.loadApplicationListing),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        run: action => {
          return this.applicationService
            .getTaskInfo({ slug: action.slug, ...action.request })
            .pipe(
              map((data: any) => {
                // Your custom service 'load' logic goes here. For now just return a success action...
                return ApplicationListingActions.loadApplicationListingSuccess({ applicationListing: data });
                // Your custom service 'load' logic goes here. For now just return a success action...
              }),
            );
        },
        onError: (action, error) => {
          console.error('Error', error);
          return ApplicationListingActions.loadApplicationListingFailure({
            error
          });
        }
      })
    )
  );

  constructor(
    private actions$: Actions,
    private applicationService: ApplicationService
  ) { }
}
