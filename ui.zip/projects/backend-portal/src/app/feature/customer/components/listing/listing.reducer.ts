import { createReducer, on, Action } from '@ngrx/store';
import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';

import * as ApplicationListingActions from './listing.action';
import { ApplicationListingEntity } from './listing.models';

export const APPLICATIONLISTING_FEATURE_KEY = 'applicationListing';

export interface State extends EntityState<ApplicationListingEntity> {
  selectedId?: string | number; // which ApplicationListing record has been selected
  loaded: boolean; // has the LendingNeeds list been loaded
  error?: any; // last none error (if any)
  loading: boolean;
  taskInfo: any;
  response?: any;
  errors?: any;
  formData?: any;
}

export interface ApplicationListingPartialState {
  readonly [APPLICATIONLISTING_FEATURE_KEY]: State;
}

export const applicationListingAdapter: EntityAdapter<ApplicationListingEntity> = createEntityAdapter<
  ApplicationListingEntity
>();

export const initialState: State = applicationListingAdapter.getInitialState({
  // set initial required properties
  loaded: false,
  loading: false,
  taskInfo: null,
  response: null
});

const applicationListingReducer = createReducer(
  initialState,
  on(ApplicationListingActions.loadApplicationListingSuccess,
    (state, { applicationListing }) =>
      ({
        ...state,
        taskInfo: null,
        response: applicationListing,
        loaded: true
      })
  ),
  on(ApplicationListingActions.applicationFilterLoaded,
    (state, { applicationListing }) =>
      ({
        ...state,
        taskInfo: applicationListing,
        response: null,
        loaded: true
      })
  ),
  on(ApplicationListingActions.loadApplicationListingFailure,
    (state, { error }) => ({ ...state, error })
  ),
  on(ApplicationListingActions.ResetApplicationListingResponse, (state) => ({
    ...state,
    loaded: false,
    response: undefined
  })
  ),
);

export function reducer(state: State | undefined, action: Action) {
  return applicationListingReducer(state, action);
}
