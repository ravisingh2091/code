export interface collectInfoEntity {
  id: string | number; // Primary ID,
  loaded: boolean;
  error?: string | null;
  form_fields: any;
  task_slug: string;
  generateownerDetailSheet: boolean;
  response_data?: any
}
