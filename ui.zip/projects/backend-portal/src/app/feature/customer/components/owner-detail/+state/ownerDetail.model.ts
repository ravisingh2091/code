/**
 * Interface for the 'ownerDetailSheet' data
 */
export interface ownerDetailSheetEntity {
    id: string | number; // Primary ID,
    loaded: boolean;
    error?: string | null;
    form_fields: any;
    task_slug: string;
    generateownerDetailSheet: boolean;
    response_data?: any
  }
  