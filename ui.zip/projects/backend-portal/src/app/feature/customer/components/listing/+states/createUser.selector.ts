import { createFeatureSelector, createSelector, State } from '@ngrx/store';
import {
  CREATEUSER_FEATURE_KEY,
} from './createUser.reducer';
import { CreateUserState } from './createUser.model';

// Lookup the 'CreateUser' feature state managed by NgRx
export const getCreateUserState = createFeatureSelector<CreateUserState>(CREATEUSER_FEATURE_KEY);

export const getCreateUserLoaded = createSelector(
  getCreateUserState,
  (state: CreateUserState) => state.loaded
);

export const getCreateUserError = createSelector(
  getCreateUserState,
  (state: CreateUserState) => state.error
);

export const getAllCreateUser = createSelector(
  getCreateUserState,
  getCreateUserLoaded,
  (state: CreateUserState, loaded) => (loaded && !state.response) ? state.taskInfo : null
);

export const getCreateUserResponse = createSelector(
  getCreateUserState,
  (state: CreateUserState) => state.response ? state.response : null
);
