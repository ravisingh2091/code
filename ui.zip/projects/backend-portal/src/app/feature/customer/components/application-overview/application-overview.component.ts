import { AddCoApplicantComponent } from './../add-co-applicant/add-co-applicant.component';
import { Component, OnInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { CommonService } from '@shared/services/common.service';
import { ApplicationService } from '@shared/services/application.service';

@Component({
  selector: 'app-application-overview',
  templateUrl: './application-overview.component.html',
  styleUrls: ['./application-overview.component.scss']
})
export class ApplicationOverviewComponent implements OnInit {
  isFirstOpen = true;
  modalRef: BsModalRef;
  appID = this.common.getDataFromStorage('ao_app_id');
  userID = this.common.getDataFromStorage('ao_user_id');
  refID = this.common.getDataFromStorage('ao_ref_id');
  recordId = this.common.getDataFromStorage('ao_record_id');
  addCoApplicantParams = {};
  gstProfile: any;
  ownersList: any = [];
  entity_type: any = [];
  businessDetails: any = [];
  offerDetails = [];
  entityType: any = [];
  businessPan: string;

  constructor(
    private modalService: BsModalService,
    private common: CommonService,
    private api: ApplicationService) { }

  ngOnInit(): void {
    /**get gst data for business details accordion */
    this.getGSTProfileData(this.refID);
    /**get the data of all owners under an application and user */
    this.getOwners();
  }

  getOwners = () => {
    try {
      this.api.getTaskInfo({
        slug: 'get_owners',
        app_id: this.appID,
        user_id: this.userID
      })
        .subscribe(res => {
          this.ownersList = res.response_data.get_owners.data.data;
          this.entityType = res.response_data.entity_type.data.data;
          this.businessDetails = res.response_data.get_business.data.data;
          this.offerDetails = res.response_data.get_business_reference.data.data;
          this.businessPan = this.businessDetails[0].business_pan;

          if (this.ownersList.length > 0) {
            const singleOwner = this.ownersList[0];
            /**set params for add co-applicant modal */
            this.addCoApplicantParams = {
              appID: this.appID,
              userID: this.userID,
              ownerData: {
                gender: singleOwner.gender,
                individualName: singleOwner.individual_name,
                dob: singleOwner.date_of_birth,
                existingOwners: this.ownersList
              },
              isCreateForm: true
            };
          }
        },
          err => {
            this.common.popToast('error', 'Owners', 'Error while fetching owners. Please try after some time');
          })
    } catch (error) {
      this.common.popToast('error', 'Owners', 'Something went wrong');
    }
  }

  getGSTProfileData = (gstRefId) => {
    try {
      this.api.getTaskInfo({
        slug: 'get-gst-profile',
        ref_id: gstRefId
      }).subscribe(res => {
        this.gstProfile = res.response_data.get_gst_profile.data.data.result;
      },
        err => {
          this.common.popToast('error', 'GST profile', 'Error while fetching GST profile data')
        });
    } catch (error) {

    }
  }

  openAddModal(): void {
    this.modalRef = this.modalService.show(AddCoApplicantComponent, { initialState: this.addCoApplicantParams });
    /**reload page on modal close */
    this.modalRef.content.onClose.subscribe(reloadPage => {
      if (reloadPage === true) {
        this.getOwners();
      }
    });
  }

  closeModal(): void {
    this.modalRef.hide();
  }

  /**get name of data related to an entity based on it's value, eg: type_of_address */
  getEntityDetail = (entity_type, key, value) => {
    const entity = this.entityType.find(e => e.id === entity_type)[`${key}`].find(e => e._id === value);
    return entity?.value;
  }

  /**open co-applicant form modal with prefilled values to edit them */
  openEditModal = (ownerData) => {
    const singleOwner = this.ownersList[0];
    ownerData.individual_name = singleOwner.individual_name;
    ownerData.dob = singleOwner.date_of_birth;
    ownerData.existingOwners = this.ownersList;
    const updateApplicant = { ownerData, isCreateForm: false, appID: this.appID, userID: this.userID };
    this.modalRef = this.modalService.show(AddCoApplicantComponent, { initialState: updateApplicant });
    this.modalRef.content.onClose.subscribe(reloadPage => {
      if (reloadPage === true) {
        this.getOwners();
      }
    });
  }
}
