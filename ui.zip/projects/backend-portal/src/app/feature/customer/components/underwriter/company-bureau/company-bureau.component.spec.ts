import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyBureauComponent } from './company-bureau.component';

describe('CompanyBureauComponent', () => {
  let component: CompanyBureauComponent;
  let fixture: ComponentFixture<CompanyBureauComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanyBureauComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyBureauComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
