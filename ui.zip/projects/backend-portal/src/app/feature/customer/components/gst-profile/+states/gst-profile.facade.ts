import { Injectable } from '@angular/core';

import { select, Store, Action } from '@ngrx/store';

import * as fromGSTProfile from './gst-profile.reducers';
import * as GSTProfileSelectors from './gst-profile.selectors';

@Injectable()
export class GSTProfileFacade {
  loaded$ = this.store.pipe(
    select(GSTProfileSelectors.getGSTProfileLoaded)
  );
  allGSTProfile$ = this.store.pipe(
    select(GSTProfileSelectors.getAllGSTProfile)
  );

  gstProfileResposne$ = this.store.pipe(select(GSTProfileSelectors.getGSTProfileResponse));
  constructor(
    private store: Store<fromGSTProfile.GSTProfilePartialState>
  ) { }

  dispatch = (action: Action): void => {
    this.store.dispatch(action);
  }
}
