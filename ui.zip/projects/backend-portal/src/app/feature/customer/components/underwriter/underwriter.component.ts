import { Component, OnInit } from '@angular/core';
import { CommonService } from '@shared/services/common.service';
import { ApplicationService } from '@shared/services/application.service';
import { APP_REVIEW_TABS } from '../../../../shared/constants/app-overview-tabs';
import { SLUG } from '@shared/constants/slug';

@Component({
  selector: 'app-underwriter',
  templateUrl: './underwriter.component.html',
  styleUrls: ['./underwriter.component.scss']
})
export class UnderwriterComponent implements OnInit {
  isFirstOpen = true;
  appID = this.common.getDataFromStorage('ao_app_id');
  userID = this.common.getDataFromStorage('ao_user_id');
  refID = this.common.getDataFromStorage('ao_ref_id');
  recordId = this.common.getDataFromStorage('ao_record_id');
  addCoApplicantParams = {};
  gstProfile: any;
  entity_type: any = [];
  businessDetails: any = [];
  entityType: any = [];
  tabNames = APP_REVIEW_TABS;
  activeTab = this.tabNames.underwriter;
  businessPan: string;
  businessData: any;
  transactionData: any;
  constructor(
    private common: CommonService,
    private api: ApplicationService) { }

  ngOnInit(){
    this.getGSTProfileData(this.refID);
    /**get business details related to owners */
    this.getOwners();
  }

  getOwners = () => {
    try {
      this.api.getTaskInfo({
        slug: SLUG.getOwners,
        app_id: this.appID,
        user_id: this.userID
      })
        .subscribe(res => {
          this.entityType = res.response_data.entity_type.data.data;
          this.businessDetails = res.response_data.get_business.data.data;
          this.businessData = res.response_data.get_business_reference.data.data[0];

          this.businessPan = this.businessDetails[0].business_pan;
        },
          err => {
            this.common.popToast('error', 'Get Owners', 'Unable to fetch owners details')
          })
    } catch (error) {
      this.common.popToast('error', 'Get Owners', 'Something went wrong.')
    }
  }

  getGSTProfileData = (gstRefId) => {
    try {
      this.api.getTaskInfo({
        slug: SLUG.getGstProfile,
        ref_id: gstRefId
      }).subscribe(res => {
        this.gstProfile = res.response_data.get_gst_profile.data.data.result;
      },
        err => {
          this.common.popToast('error', 'GST Profile', 'Error while fetching GST profile data')
        });
    } catch (error) {
      this.common.popToast('error', 'GST Profile', 'Something went wrong.')
    }
  }

  onTabChange(tabName): void {
    this.activeTab = tabName;
    if(tabName){
      this.common.navigate(tabName);
    }
  }
}
