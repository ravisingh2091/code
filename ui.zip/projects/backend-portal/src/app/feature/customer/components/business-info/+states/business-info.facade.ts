import { Injectable } from '@angular/core';

import { select, Store, Action } from '@ngrx/store';
import * as fromBusinessInfo from './business-info.reducers';
import * as businessInfoSelector from './business-info.selectors';

@Injectable()
export class BusinessInfoFacade {
  loaded$ = this.store.pipe(select(businessInfoSelector.getLoaded));
  allBusinessInfo$ = this.store.pipe(
    select(businessInfoSelector.getAllBusinessInfo)
  );
  submitBusinessInfo$ = this.store.pipe(select(businessInfoSelector.getBusinessInfoResponseState));
  allOtp$ = this.store.pipe(select(businessInfoSelector.getAllOtp));
  otpResponse$ = this.store.pipe(select(businessInfoSelector.getOtpResponse));
  businessInfoResponse$ = this.store.pipe(select(businessInfoSelector.getBusinessInfoResponse));
  businessDetailsResponse$ = this.store.pipe(select(businessInfoSelector.getBusinessDetailsResponse));
  otpResendResponse$ = this.store.pipe(select(businessInfoSelector.getResendOtpResponse));

  constructor(private store: Store<fromBusinessInfo.BusinessInfoPartialState>) {}

  dispatch(action: Action) {
    this.store.dispatch(action);
  }

}
