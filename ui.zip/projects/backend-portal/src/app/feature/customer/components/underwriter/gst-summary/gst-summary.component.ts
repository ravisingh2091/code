import { CommonService } from '@shared/services/common.service';
import { Component, OnInit, Input } from '@angular/core';
import { ApplicationService } from '../../../../../shared/services/application.service';
import { switchMap, take } from 'rxjs/operators';
import { timer, Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { SLUG } from '@shared/constants/slug';
import { ServiceProvidorService } from '@shared/services/service-providor.service';

@Component({
  selector: 'app-gst-summary',
  templateUrl: './gst-summary.component.html',
  styleUrls: ['./gst-summary.component.scss']
})
export class GstSummaryComponent implements OnInit {
  isFirstOpen = true;
  @Input() applicationID;
  @Input() gstProfileRefId;
  @Input() gsttransactionData;
  transactionData: any;
  ownersData: any;
  user_id: any;
  gstinArr: any=[];
  rootStateSubscription: Subscription;
  @Input() userID: any;
  @Input() appID: any;
  tuBrm1ProvidorID: string;
  Average_Total_Purchases: any;
  Average_Debit_Notes: any;
  Percent_Debit_Notes_Purchases: any;
  Total_Purchases: any;
  Available_Loan_Eligibility_GST: any;
  NetRevenue: any;
  GST_Sales: any;
  MPBF_Factor: any;
  MPBF: any;
  Outstanding_Balance: any;
  Gross_Profit_Basis_GST: any;
  FOIR_Percent: any;
  FOIR: any;
  Tenure: any;
  RateOfInterest: any;
  LoanLimit_Available_GST: any;
  Eligibility_With_MPBF: any;
  Eligibility_With_Foir: any;
  FinalEligibility_GST: any;
  Maximum_Allowed_GST: any;
  Maximum_Bank_Limit_GST: any;

  constructor(private api: ApplicationService,
    private common: CommonService,
    private serviceProvider: ServiceProvidorService
    ) { }

  ngOnInit() {
    let panProviderObJ = this.serviceProvider.getProviderData('tu_brm_1');
    if (panProviderObJ&& panProviderObJ.id) {
      this.tuBrm1ProvidorID=panProviderObJ.id;
      // console.log(this.tuBrm1ProvidorID);
    }
    this.getGstTransactionOtp("5efc765f4661a55aa95a2955"); // @TODO shpuld not be hard-coded
    this.getDocumentType();
  }



  public getGstTransactionOtp(id): void {
    try {
      let count = 0;
      let apiRun = this.api.getTaskInfo({
        slug: SLUG.getGstTransactionOtp,
        id: id

      });
      let subscription = timer(0, 10000)
        .pipe(switchMap(() => apiRun))
        .subscribe((result) => {
          if (result) {

            //brm2data populate
            let brm2data = result.response_data.tuBrm2Data.data.data.brm2applicationData.Variables;
            this.Average_Total_Purchases = brm2data.GST.GST_purchases.Average_Total_Purchases
            this.Average_Debit_Notes = brm2data.GST.GST_purchases.Average_Debit_Notes;
            this.Percent_Debit_Notes_Purchases = brm2data.GST.GST_purchases.Percent_Debit_Notes_Purchases;
            this.Total_Purchases = brm2data.GST.GST_purchases.Total_Purchases;
            this.NetRevenue = brm2data.GST.NetRevenue;
            this.GST_Sales = brm2data.GST.MBPF_Approach.GST_Sales;
            this.MPBF_Factor = brm2data.GST.MBPF_Approach.MPBF_Factor;
            this.MPBF = brm2data.GST.MPBF_Factor.MPBF;
            this.Outstanding_Balance = brm2data.GST.MPBF_Factor.Outstanding_Balance;
            this.Available_Loan_Eligibility_GST = brm2data.GST.MPBF_Approach.Available_Loan_Eligibility_GST;
            this.Gross_Profit_Basis_GST = brm2data.GST.FOIR_Approach.Gross_Profit_Basis_GST;
            this.FOIR_Percent = brm2data.GST.FOIR_Approach.FOIR_Percent;
            this.FOIR = brm2data.GST.FOIR_Approach.FOIR;
            this.Tenure = brm2data.GST.FOIR_Approach.Tenure;
            this.RateOfInterest = brm2data.GST.FOIR_Approach.RateOfInterest;
            this.LoanLimit_Available_GST = brm2data.GST.FOIR_Approach.LoanLimit_Available_GST;
            this.Eligibility_With_MPBF = brm2data.GST.Eligible_Amounts.Eligibility_With_MPBF;
            this.Eligibility_With_Foir = brm2data.GST.Eligible_Amounts.Eligibility_With_Foir;
            this.FinalEligibility_GST = brm2data.GST.Eligible_Amounts.FinalEligibility_GST;
            this.Maximum_Allowed_GST = brm2data.GST.Eligible_Amounts.Maximum_Allowed_GST;
            this.Maximum_Bank_Limit_GST = brm2data.GST.Eligible_Amounts.Maximum_Bank_Limit_GST;

            count++;
            if (result && result.response_data.get_gst_transaction_otp.data.data.result) {

              subscription.unsubscribe();
              return;
            } else if (count === 3) {
              subscription.unsubscribe();
            }
          }
        });
    } catch(err) {
      this.common.popToast('error', 'GST Transaction OTP', '');
    }
  }
  getDocumentType(): void {
    this.api
      .getTaskInfo({ slug: SLUG.documentType })
      .subscribe((documentTypes) => {
        this.getGstDetails(documentTypes)
      }, err => this.common.popToast('error', 'Document Type', 'Error fetching document type data'));
  }

  getGstDetails(documentTypes): void {
    let providerObj = documentTypes.response_data.service_providers.data.data.find(
      (provider) => provider.type === 'gst_search'
    );
    this.api
      .getTaskInfo({
        slug: SLUG.savedGstDetails,
        user_id: this.userID,
        expands: 'business,business_references',
        provider: providerObj.id,
        type: providerObj.type,
      })
      .subscribe(async (res) => {
        if (res) {
          this.gstinArr = await res.response_data.get_gst_search_data.data.data.result;
        }
      }, err => {
        this.common.popToast('error', 'GST Details', 'Unable to fetch saved GST Details')
      });
  }
}
