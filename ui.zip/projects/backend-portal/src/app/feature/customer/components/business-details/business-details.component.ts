import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-details',
  templateUrl: './business-details.component.html',
  styleUrls: ['./business-details.component.scss']
})
export class BusinessDetailsComponent implements OnInit {
  @Input() businessDetails: any;
  constructor(
  ) {}

  ngOnInit(): void {
  }

  datediff = (first) => {
    if (!first) {
      return '';
    }
    const from: any = this.parseDate(first);
    const dt = new Date();
    const now = dt.getDate() + '/' + (dt.getMonth() + 1) + '/' + dt.getFullYear();
    const to: any = this.parseDate(now);
    return Math.round((to - from) / (1000 * 60 * 60 * 24));
  }

  parseDate = (str: string = '1/1/1970') => {
    const dmy = str.split('/');
    const dt = new Date(parseInt(dmy[2], 10), parseInt(dmy[1], 10), parseInt(dmy[0], 10));
    return dt;
  }

}
