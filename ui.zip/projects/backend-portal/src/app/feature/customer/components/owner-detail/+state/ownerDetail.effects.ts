import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { fetch } from '@nrwl/angular';

import { CommonService } from '@shared/services/common.service';
import { ApplicationService } from '@shared/services/application.service';

import * as ownerDetailSheetActions from './ownerDetail.action';
import { map } from 'rxjs/operators';


@Injectable()
export class OwnerDetailSheetEffects {
  loadownerDetailSheet$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ownerDetailSheetActions.loadownerDetailSheet),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        run: action => {
          return this.applicationService.getTaskInfo({
            user_id:action.user_id,
            expands:action.expands,
              slug: action.slug
            }).pipe(
            map((data: any) => {
              return ownerDetailSheetActions.loadownerDetailSheetSuccess({ ownerDetailSheet: data });
            })
          );
        },

        onError: (action, error) => {
          this.common.popToast('error', ' Owner Details', 'Unable to Load Owner Details Form');
          return ownerDetailSheetActions.loadownerDetailSheetFailure({ error });
        }
      })
    )
  );


  formSubmit$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ownerDetailSheetActions.formSubmit),
      fetch({
        id: () => {
          return (new Date()).getTime().toString();
        },
        // action.formData,{
        //   slug: action.slug
        // },null
        run: action => {
          return this.applicationService.saveTaskInfo(action.payload,{
            slug: action.slug
          }, null).pipe(
            map((data: any) => {
              return ownerDetailSheetActions.formSubmitCompleted({ ownerDetailSheet: data });
            })
          );

          // Your custom service 'load' logic goes here. For now just return a success action...
        },
        onError: (action, error) => {
          console.error('Error', error);
          return ownerDetailSheetActions.loadownerDetailSheetFailure({ error });
        }
      })
    )
  );


  constructor(private actions$: Actions, private applicationService: ApplicationService,  private common: CommonService,) { }
}
