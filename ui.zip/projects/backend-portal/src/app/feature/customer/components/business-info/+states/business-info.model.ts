/**
 * Interface for the 'BusinessInfo' data used in
 *  - BusinessInfoState, and the reducer function
 */

export interface BusinessInfoState {
  loaded: boolean; // has the LendingNeeds list been loaded
  error?: any; // last none error (if any)
  loading: boolean;
  taskInfo: any;
  response?: any;
  errors?: any;
  formData?: any;
  otp?: any;
  verifiedData?: any;
}
export interface OtpState {
  loaded: boolean; // has the Otp list been loaded
  loading: boolean;
  error?: any; // last none error (if any)
  taskInfo: any;
  response: any;
  resendResponse: any;
}
