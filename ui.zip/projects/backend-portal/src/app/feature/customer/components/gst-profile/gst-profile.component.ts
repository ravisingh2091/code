import { Component, EventEmitter, OnInit, Output, Input, OnChanges, OnDestroy } from '@angular/core';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { CommonService } from '@shared/services/common.service';
import { Store, select } from '@ngrx/store';
import { take } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { FormGroup } from '@angular/forms';

import {
  gstProfileSubmit,
  LoadGSTProfile,
  resetGSTData
} from './+states/gst-profile.actions';
import { GSTProfileFacade } from './+states/gst-profile.facade';

@Component({
  selector: 'app-gst-profile',
  templateUrl: './gst-profile.component.html',
  styleUrls: ['./gst-profile.component.scss'],
})
export class GstProfileComponent implements OnInit, OnChanges {
  gstProfileForm: FormGroup;
  gstProfileConfig: FormFieldInterface[] = [];
  gstProfileSubscription: Subscription;
  slug: string;
  userID: string;
  appID: string;
  gstin: any;
  @Output() legalNameBusiness: EventEmitter<any> = new EventEmitter<any>();
  @Input() registeredAddress: string;
  @Input() gstProfile: any;
  isGSTFetched: boolean = false;
  gstDataStatus: any;

  constructor(
    private gstProfileFacade: GSTProfileFacade,
    private formGenerate: FormGenerateService,
    private common: CommonService
  ) { }

  ngOnChanges(): void {
    if (this.gstProfile) {
      const formData = this.gstProfile.response_data.get_gst_profile.data.data.result;
      this.slug = this.gstProfile.task_slug;
      this.gstProfileConfig = this.gstProfile.form_fields;
      this.gstProfileForm = this.formGenerate.createControl(this.gstProfileConfig);
      this.formGenerate.setFormValues(this.gstProfileForm, formData);
      if (this.registeredAddress) {
        this.gstProfileForm
          .get('primary_business_address')
          .get('registered_address')
          .setValue(this.registeredAddress);
      } else {
        this.gstProfileForm
          .get('primary_business_address')
          .get('registered_address')
          .setValue((this.gstProfile ?.response_data ?.get_gst_profile ?.data ?.data ?.result ?.primary_business_contact ?.branch_address)
            .toUpperCase());
      }
      this.gstin = this.gstProfile ?.response_data ?.get_gst_profile ?.data ?.data ?.result ?.gstin;

      this.gstProfileForm.get('state_jurisdiction_code')
        .setValue(this.gstProfile ?.response_data ?.get_gst_profile ?.data ?.data ?.result ?.stjCd);

      this.gstProfileForm.get('central_jurisdiction_code')
        .setValue(this.gstProfile ?.response_data ?.get_gst_profile ?.data ?.data ?.result ?.ctjCd);

      this.gstProfileForm
        .get('nature_of_business')
        .setValue(this.gstProfile ?.response_data ?.get_gst_profile ?.data ?.data ?.result ?.primary_business_contact ?.nature_of_business);

      this.gstProfileForm
        .get('primary_business_address')
        .get('nature_of_business')
        .setValue(this.gstProfile ?.response_data ?.get_gst_profile ?.data ?.data ?.result ?.primary_business_contact ?.nature_of_business);

      this.legalNameBusiness.emit({
        legalNameBusiness: formData.legal_name_business,
        gstProfileForm: this.gstProfileForm
      });
      this.isGSTFetched = true;
    }
  }

  ngOnInit(): void {
    this.common.gstApiSubject.subscribe((res) => {
        this.gstDataStatus = res;
    })
    this.gstProfileSubscription = this.gstProfileFacade.allGSTProfile$.subscribe(
      (gstState: any) => {
        if (gstState) {
          this.common.gstApiSubject.next('loaded');
          const formData = gstState.response_data.gst_profiling.data.data.result;
          this.slug = gstState.task_slug;
          this.gstProfileConfig = gstState.form_fields;
          this.gstProfileForm = this.formGenerate.createControl(
            this.gstProfileConfig
          );
          this.formGenerate.setFormValues(this.gstProfileForm, formData);
          if (this.registeredAddress) {
            this.gstProfileForm
              .get('primary_business_address')
              .get('registered_address')
              .setValue(this.registeredAddress);
          } else {
            this.gstProfileForm
              .get('primary_business_address')
              .get('registered_address')
              .setValue((gstState ?.response_data ?.gst_profiling ?.data ?.data ?.result ?.primary_business_contact ?.branch_address)
                .toUpperCase());
          }

          this.gstin = gstState ?.response_data ?.gst_profiling ?.data ?.data ?.result ?.gstin;
          this.gstProfileForm.get('state_jurisdiction_code')
            .setValue(gstState ?.response_data ?.gst_profiling ?.data ?.data ?.result ?.stjCd);

          this.gstProfileForm.get('central_jurisdiction_code')
            .setValue(gstState ?.response_data ?.gst_profiling ?.data ?.data ?.result ?.ctjCd);

          this.gstProfileForm
            .get('nature_of_business')
            .setValue(gstState ?.response_data ?.gst_profiling ?.data ?.data ?.result ?.primary_business_contact ?.nature_of_business);


          this.gstProfileForm
          .get('primary_business_address')
          .get('nature_of_business')
          .setValue(gstState ?.response_data ?.gst_profiling ?.data ?.data ?.result ?.primary_business_contact ?.nature_of_business);

          this.legalNameBusiness.emit({
            legalNameBusiness: formData.legal_name_business,
            gstProfileForm: this.gstProfileForm
          });
          this.isGSTFetched = true;
        }
      }
    );
  }
  ngOnDestroy(): void {
    this.gstProfileFacade.dispatch(resetGSTData());
  }
}
