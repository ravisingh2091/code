import { ApplicationService } from '@shared/services/application.service';
import { CommonService } from '@shared/services/common.service';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { APP_REVIEW_TABS } from '@shared/constants/app-overview-tabs';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { FormGroup } from '@angular/forms';
import { product } from '@shared/constants/lineofCredit';
import { SLUG } from '@shared/constants/slug';
import { ServiceProvidorService } from '@shared/services/service-providor.service';

@Component({
  selector: 'app-offer-details',
  templateUrl: './offer-details.component.html',
  styleUrls: ['./offer-details.component.scss']
})
export class OfferDetailsComponent implements OnInit {
  @Input() offerDetails: [];
  appID = this.common.getDataFromStorage('ao_app_id');
  userID = this.common.getDataFromStorage('ao_user_id');
  refID = this.common.getDataFromStorage('ao_ref_id');
  recordId = this.common.getDataFromStorage('ao_record_id');
  showOfferDetails = false;
  isFirstOpen = true;
  tabNames = APP_REVIEW_TABS;
  activeTab = this.tabNames.offer;
  slug: string;
  offerDetailsConfig:  FormFieldInterface[] = [];
  offerDetailsForm: FormGroup;
  Eligibility_Amount_BankStatement: any;
  FinalEligibility_BankStatement : any;
  Eligibility_With_MPBF: any;
  Maximum_Allowed_GST: any;
  Maximum_Bank_Limit_GST: any;
  FinalEligibility_GST: any;
  Maximum_Eligible_Amount_Of_GST_BankStatement: any;
  Maximum_Eligible_Amount_Of_GST_BankStatement_DeclaredIncome: any;
  tuBrm1ProvidorID: string;
  constructor(
    private common: CommonService,
    private api: ApplicationService,
    private formGenerate: FormGenerateService,
    private serviceProvider: ServiceProvidorService
  ) {
  }

  ngOnInit(): void {
    this.common.customerFooterEmit = true;
    let panProviderObJ = this.serviceProvider.getProviderData('tu_brm_1');
        if (panProviderObJ&& panProviderObJ.id) {
          this.tuBrm1ProvidorID=panProviderObJ.id;
          // console.log(this.tuBrm1ProvidorID);
        }


    this.api.getTaskInfo({
      slug: SLUG.offerDetails,
      app_id: this.appID,
      user_id: this.userID,
      provider: this.tuBrm1ProvidorID
    }).subscribe((res) => {
      // console.log(res);
      this.slug = res.task_slug;
      this.offerDetailsConfig = res.form_fields;
      this.offerDetailsForm = this.formGenerate.createControl(this.offerDetailsConfig);
      this.common.sendMasterDataToFields(this.offerDetailsConfig, {
        data: {
          data: product
          }
        }
      ,"product");
      let brm2data = res.response_data.tuBrm2Data.data.data.brm2applicationData.Variables;
      this.Eligibility_Amount_BankStatement = brm2data.BankStatement.Eligible_Amounts.Eligibility_Amount_BankStatement;
      this.FinalEligibility_BankStatement = brm2data.BankStatement.Eligible_Amounts.FinalEligibility_BankStatement;
      this.Eligibility_With_MPBF = brm2data.GST.Eligible_Amounts.Eligibility_With_MPBF;
      this.Maximum_Allowed_GST = brm2data.GST.Eligible_Amounts.Maximum_Allowed_GST;
      this.Maximum_Bank_Limit_GST = brm2data.GST.Eligible_Amounts.Maximum_Bank_Limit_GST;
      this.FinalEligibility_GST = brm2data.GST.Eligible_Amounts.FinalEligibility_GST;
      this.Maximum_Eligible_Amount_Of_GST_BankStatement = brm2data.Maximum_Eligible_Amount_Of_GST_BankStatement;
      this.Maximum_Eligible_Amount_Of_GST_BankStatement_DeclaredIncome = brm2data.Maximum_Eligible_Amount_Of_GST_BankStatement_DeclaredIncome;
    })
  }

  onTabChange(tabName): void {
    this.activeTab = tabName;
    if (tabName) {
      this.common.navigate(tabName);
    }
  }

  onSubmit(): void {
    // console.log('submit');
  }

}

