import { createReducer, on, Action } from '@ngrx/store';
import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';

import * as ownerDetailSheetActions from './ownerDetail.action';
import { ownerDetailSheetEntity } from './ownerDetail.model';

export const OWNERDETAILS_FEATURE_KEY = 'ownerDetailSheet';

export interface State extends EntityState<ownerDetailSheetEntity> {
  selectedId?: string | number; // which ownerDetailSheet record has been selected
  loaded: boolean; // has the ownerDetailSheet list been loaded
  error?: string | null; // last none error (if any)
  form_fields?: any;
  task_slug: string;
  generateownerDetailSheet?: boolean;
  response_data?: any;
}

export interface ownerDetailSheetPartialState {
  readonly [OWNERDETAILS_FEATURE_KEY]: State;
}

export const ownerDetailSheetAdapter: EntityAdapter<ownerDetailSheetEntity> = createEntityAdapter<
  ownerDetailSheetEntity
>();

export const initialState: State = ownerDetailSheetAdapter.getInitialState({
  // set initial required properties
  loaded: false,
  error: null,
  form_fields:[],
  task_slug: null,
  generateownerDetailSheet: false,
  response_data: {}
});

const ownerDetailSheetReducer = createReducer(
  initialState,
  on(ownerDetailSheetActions.loadownerDetailSheet, state => ({
    ...state,
    loaded: false,
    error: null
  })),
  on(ownerDetailSheetActions.loadownerDetailSheetSuccess, (state, { ownerDetailSheet }) =>
   ( { ...state, 
    ...ownerDetailSheet,
      loaded: true,
      error: null,
  })
  ),
  on(ownerDetailSheetActions.loadownerDetailSheetFailure, (state, { error }) => ({
    ...state,
    loaded: false,
    error
  })
  ),
  on(ownerDetailSheetActions.generateownerDetailSheet, (state, { action }) => ({
    ...state,
    generateownerDetailSheet: action
  })
  ),
  on(ownerDetailSheetActions.setIntialownerDetailSheet, state => ({
    ...state,
    loaded: false,
    error: null,
    form_fields:[],
    task_slug: null,
    generateownerDetailSheet: false,
    response_data: {}
  })
  ),
  on(ownerDetailSheetActions.formSubmit, (state) => ({
    ...state,
    loaded: false,
    loading: true
  })),
  on(ownerDetailSheetActions.formSubmitCompleted, (state, { ownerDetailSheet }) => ({
    ...state,
    loaded: true,
    loading: false,
    response: ownerDetailSheet
  })),
);

export function reducer(state: State | undefined, action: Action) {
  return ownerDetailSheetReducer(state, action);
}
