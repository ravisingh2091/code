import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Component, OnInit, ElementRef } from '@angular/core';
import { ownerDetailSheetFacade } from './+state/ownerDetail.facade';
import { FormGenerateService } from '../../../../shared/services/form-generate.service';
import { CommonService } from '@shared/services/common.service';
import { FormGroup } from '@angular/forms';
import * as ownerDetailActions from './+state/ownerDetail.action';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { Subscription, of } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { take, switchMap, mergeMap } from 'rxjs/operators';
import { get } from 'lodash-es';
import { SLUG } from '../../../../shared/constants/slug';

import { ApplicationService } from '@shared/services/application.service';
import { ServiceProvidorService } from '../../../../shared/services/service-providor.service';
import { storeMasterData, storeclassOfActivityData } from '../../../../utils/+state/utils.action';
import { AppStateFacade } from '../../../../+state/app.facade';
@Component({
  selector: 'app-owner-detail',
  templateUrl: './owner-detail.component.html',
  styleUrls: ['./owner-detail.component.scss']
})
export class OwnerDetailComponent implements OnInit {
  
  ownerDetailSubscription: any;
  slug: string;
  ownerDetailConfig: FormFieldInterface[] = [];
  ownerDetailForm: FormGroup;
  submitownerDetailSubscription: any;
  data: {};
  value_data: unknown[];
  group: any;
  field: any;
  isRemove: number;
  addHide: boolean = false;
  accordion: boolean = true;
  submitownerDetailsSubscription: Subscription;
  rootStateSubscription: any;
  backendUserID: any;
  user_id: string;
  app_id: any;
  pan: string;
  company_name: any;
  tuRefFlag:boolean=false;
  cin: any;
  showForm: boolean = false;
  owners: any;
  business_pan: any;
  legal_name_of_business: any;
  business_name: string;
  flag1: boolean;
  env: any;
  stub: boolean;
  company_searchParamas: any;
  cinApiParams: any;
  businessID: any;
  formInitialValue: any;
  ownersDataList: any = [];
  business_reference: any;
  ownersData: any;
  business_refId: any;
  formdatasubscription: any;
  TuproviderID: string;
  compSearchProviderID: string;
  cinProviderID: string;
  mcaproviderID: string;
  modalRef: BsModalRef;
  masterData: any;
  displayData: string;
  resultFlag: boolean;
  stateArray: any;
  ownerState: any;
  ownerCity: any;
  stateObject: any;
  tuReference: any;
  gst_refId: any;
  constitution_of_business: any;

  constructor(
    private ownerDetailFacade: ownerDetailSheetFacade,
    private appFacade: AppStateFacade,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private common: CommonService,
    private api: ApplicationService,
    private el: ElementRef,
    private serviceProvider: ServiceProvidorService,
    private modalService: BsModalService,
  ) {
    this.common.customerFooterEmit = true;
    this.common.goBackGet.subscribe((res) => {
      this.goBack();
    });

    /*subscribe to form submit button on the footer */
    this.formdatasubscription = this.common.formSubmitGet.subscribe(result => {
      this.onsubmit(result);
    });
  }

  ngOnInit(): void {
    this.resultFlag=true;
 this.displayData="We have pulled data from MCA, if you find any discrepancy please update data in MCA Portal"

 // root state subscription
    this.rootStateSubscription = this.store
      .pipe(
        select('app'),
        take(1)
      ).subscribe(rootState => {
        if (rootState) {
          if (rootState && rootState.userData) {
            this.user_id = rootState.userData.id;
          }
          if (rootState && rootState.appID) {
            this.app_id = rootState.appID;
          }

          if (rootState && rootState.businessID) {
            this.businessID = rootState.businessID;
          }
          if(rootState.masterData){
            this.masterData = rootState.masterData
          }

          /* api hit to fetch the owner details page data for form*/
          this.api.getTaskInfo({
            slug: SLUG.ownersDetails,
            user_id: this.user_id,
            expands: 'business,business_references,owner_details'
          }).subscribe(state => {
            if (state) {
              if (state && state.task_slug) {
                this.slug = state.task_slug;
                this.ownerDetailConfig = state.form_fields;
                
          /*sending data to option (select type) fields*/
                this.common.sendMasterDataToFields(this.ownerDetailConfig, state.response_data);
               
          /* generating form*/
                this.ownerDetailForm = this.formGenerate.createControl(this.ownerDetailConfig);
                if (state && state.response_data) {
                  state.response_data.user_apps?.data?.data.every(element => {
                    if(element._id==this.app_id){
                      const appData = element
                      if(appData){
                        const businessArray = appData ?.business;
                        if(businessArray) {
                          this.business_reference = element?.business_references;
                          this.business_refId = element?.business_references.find(val => val.type == SLUG.cinProfile) ?.ref_id;
                          this.gst_refId = element?.business_references.find(val => val.type == "gst_profile") ?.ref_id;
    
                          this.formInitialValue = state.response_data;

                        const  businessData = businessArray.find(val => val.app_id == this.app_id);
                          if(businessData){

                            this.business_pan = businessData.business_pan;
                            this.company_name = businessData.legal_name_business;
                          }
                          let classOFActivity = this.formInitialValue?.class_of_activity?.data?.data;
                          if(classOFActivity){
                            
          /* dispatching action to send the data to store*/
                            this.appFacade.dispatch(storeclassOfActivityData({ classOfActivityData: classOFActivity }))
                          }
                          if (element?.owner_details?.length > 0) {
                        
                            const pan4 = this.business_pan[3].toUpperCase();
                            if (pan4 === 'P') {
                              // this.addHide = true;
                            } else if (pan4 === 'C') {
                              // this.addHide = true;
                            } else {
                              let legal_name_of_business = this.business_name;
                              const llp = /\bllp|\bLLP|\blimited lia|\bLimited Lia/gm;
                              if (llp.test(legal_name_of_business)) {
    
                                // this.addHide = true;
                              } else {
                                // this.addHide = false;
                              }
                            }
                            for (const [index, data] of element ?.owner_details.entries()) {
                              this.ownersDataList.push({
                                ...data,
                                date_of_birth: data ?.date_of_birth ?.slice(0, 10).split('/').reverse().join('-')
                            });

                               /* preparing data for select fields*/
                              if (this.formInitialValue) {

                                let masterData: any = {};
                                const relations = this.formInitialValue ?.entity_type ?.data ?.data
                                  .filter(value => value.id === data.entity_type)[0].relationships;

                                const addressType = this.formInitialValue ?.entity_type ?.data ?.data
                                  .filter(value => value.id === data.entity_type)[0].addressType;

                                const typeOfEntity = this.formInitialValue ?.entity_type ?.data ?.data
                                  .filter(value => value.id === data.entity_type)[0].typeOfEntity;

                                let class_of_activity = this.formInitialValue ?.class_of_activity ?.data ?.data;
                                masterData = {
                                  [`relationship_${index}`]: { data: { data: relations } },
                                  [`type_of_address_${index}`]: { data: { data: addressType } },
                                  [`business_constitution_${index}`]: { data: { data: typeOfEntity } },
                                  [`class_of_activity_${index}`]: { data: { data: class_of_activity } }
                                };

                                if (data ?.state) {
                                  const cities = this.formInitialValue ?.state ?.data ?.data ?.filter(value => value.id === data.state)[0].cities;
                                  masterData[`city_${index}`] = {
                                    data: { data: cities }
                                  };

                                }

                                if (data ?.entity_type == this.masterData ?.entity_type ?.data ?.data[1] ?.id) {

                                  this.ownerDetailForm ?.controls ?.owners['controls'][index] ?.get('type_of_address').disable();
                                }
                                
                                this.common.sendMasterData(masterData);
                              }
                            }
                              
                               /* set owners data in owners-details form fields*/
                            this.formDataSet(this.ownersDataList);
                            
                                    /* set owners data in session storage*/
                            this.common.storeDataInStorage('owners-data', this.ownersDataList);
                          } else {
                            if (this.business_refId) {        
                          /* get cin/mca  data from stored reference */
                              this.getDataFromReference(this.business_refId);

                            } else {
                              
                          /* api hit to get constitution_of_business (type of business) */
                              this.api.getTaskInfo({ slug: SLUG.getGstProfile, app_id: this.app_id, ref_id:  this.gst_refId }).subscribe(res => {
                                if(res && res.response_data){
                                    let constitution_of_business=res?.response_data?.get_gst_profile?.data?.data?.result?.constitution_of_business;
                                    this.constitution_of_business=constitution_of_business.toLowerCase();
                                    const constitutionRegex = /\bprivate limited|\blimited|\bpvt ltd|\bltd/gm
                                    
                                           /* to check whether type of constitution of business is pvt. ltd or ltd. */
                                  if(this.constitution_of_business && constitutionRegex && constitutionRegex.test(this.constitution_of_business)){
                                    this.getOwnersData();
                                  }else{
                                   let  optionsData = [{ entity_type: this.masterData?.entity_type?.data?.data[0]?.id }];
                                   this.setOptions(optionsData);
                                  }
                                }
                              })
                            }
    
                          }
                          return false;
                        }
                      }
                    }
                    return true;
                  });
                }
              }
            }
          },
          (err)=>{
             this.formdatasubscription.unsubscribe(); 
             this.common.nextsubscriptionEmit=true;
             this.resultFlag=false;
             this.displayData="We are unable to fetch Data from MCA"
            this.common.popToast('error', 'Owners Details', 'error while Loading Owners Details Form')
          }
          );
        
        }
      }
      );
  }
  /* to scroll to the field that need to be field */
  private scrollToFirstInvalidControl() {
    const firstInvalidControl: HTMLElement = this.el.nativeElement.querySelector(
      "form .ng-invalid"
    );
    firstInvalidControl.focus(); //without smooth behavior
  }
 /* function for back button */
  goBack = (): void => {
    this.common.navigate(SLUG.businessInfo);
  }

  /**
   *
   * @param val save/continue
   */

    /* function executes on next button */
  onsubmit = (val): void => {
    if (val.action === 'continue') {
      if (
        this.formGenerate.validateCustomFormFields(
          this.ownerDetailForm,
          'continue',
          this.ownerDetailConfig)
      ) {
        const ownerSave = [];
        this.ownerDetailForm.getRawValue().owners.map((value, index) => {
          const ownerId = this.ownersDataList[index]?._id;

          ownerSave.push({
            ...value,
            date_of_birth: value?.date_of_birth?.slice(0, 10).split('-').reverse().join('/'),
          });


        });
        if (ownerSave?.length > 0) {


          const Payload = {
            owners: ownerSave, user_id: this.user_id, app_id: this.app_id
          };
          let BRMDecision = '';
           /* api  hit to save owners-details */
          this.api.saveTaskInfo(Payload, { slug: SLUG.ownersDetails })
            .pipe(
              switchMap(res => {

                let TuproviderObJ = this.serviceProvider.getProviderData('tu_brm_1');
                if (TuproviderObJ && TuproviderObJ.id) {
                  this.TuproviderID = TuproviderObJ.id
                }
                /* api hit to get tu decision */
                if(this.tuRefFlag==false){
                  return this.api.getTaskInfo({
                    slug: SLUG.tuBrm1Call,
                    app_id: this.app_id,
                    user_id: this.user_id,
                    service_provider: this.TuproviderID
                  });
                }else{
                  return this.api.getTaskInfo({
                    slug: SLUG.tuBrm1CallWithoutReference,
                    app_id: this.app_id,
                    user_id: this.user_id,
                    service_provider: this.TuproviderID
                  });
                }
                
              }),
              switchMap(res => {
                BRMDecision = get(res, 'response_data.tu_brm1_call.data.data.BRMDecision');
                const appType = this.common.getAppType('unsecured_business_loan');
                const appStatus = this.common.getAppStatus('Incomplete');

                const payload: any = {
                  business_id: this.businessID,
                  action_type: val.action,
                  user_id: this.user_id,
                  app_id: this.app_id,
                  status_id: appStatus.id,
                  product_type: appType.id
                };
                payload.current_state = 'collect-info';
                /* api hit to update business */
                return this.api.saveTaskInfo(payload, { slug: SLUG.updateBusiness });
              })
            ).subscribe((result) => {
              if (BRMDecision && (BRMDecision.toLowerCase() === 'go')) {
                // this.modalRef = this.modalService.show(AlertDialog, {});
                this.common.navigate(SLUG.collectInfo);
              } else {
                this.common.popToast('error', 'BRM Decision', 'Error while validating BRM Decision');
              }
            },err => {
              if (err.owner_save) {
                this.common.popToast('error', 'Owner Details', 'Unable to save owner details for this application');
              } else if (err.create_application) {
                this.common.popToast('error', 'Owner Details', 'Unable to update business details');
              } else if (err.tu_brm1_call) {
                this.common.popToast('error', 'Owner Details', 'Error while fetching TU decision');
              } else if (err.tu_brm1_call_reference) {
                this.common.popToast('error', 'Owner Details', 'Error while fetching TU decision');
              } else {
                this.common.popToast('error', 'Owner Details', 'Something went wrong. Please try after some time');
              }
            });
        }
      } else {
        this.scrollToFirstInvalidControl();
      }
    } else {
      /*executes when clicked on save and exit button*/
      const ownerSave = [];
      this.ownerDetailForm.getRawValue().owners.map((value, index) => {
        ownerSave.push({
          ...value,
          date_of_birth: value?.date_of_birth?.slice(0, 10).split('-').reverse().join('/'),
        });
      });
      if (ownerSave.length > 0) {
        const Payload = {
          owners: ownerSave, user_id: this.user_id, app_id: this.app_id
        };
        /* api hit to save owners-details */
        this.api.saveTaskInfo(Payload, { slug: SLUG.ownersDetails })
          .pipe(
            switchMap(res => {
              const payload: any = {
                business_id: this.businessID,
                action_type: val.action,
                user_id: this.user_id
              };
              if (val.action === 'save') {
                return of(null);
              }
            })
          ).subscribe((result) => {
            if (result || result == null) {
              this.common.navigate(SLUG.userListing);
            }
          },(err)=>{
            this.resultFlag=false;
            this.displayData="We are unable to fetch Data from MCA"
            this.common.popToast('error', ' Owner Details', 'Unable to Load Owner Details Form');
            });
      }
      // }
      //  else {
      //   this.scrollToFirstInvalidControl();
      // }
    }


  }
  /* to get cin/mca  data from stored reference */
  getDataFromReference(id) {

    const payload = {
      ref_id: id
    };
    
    this.api.saveTaskInfo(payload, { slug: SLUG.dataFromBusinessReference }
    ).subscribe(res => {
      if (res) {
        this.ownersData = res;
        if (this.ownersData) {

        /*to get CIN/MCA data from reference*/
          this.callOwners('data_from_business_reference');
        }
      }
    },(err)=>{
      this.formdatasubscription.unsubscribe(); 
      this.common.nextsubscriptionEmit=true;
      this.resultFlag=false;
      this.displayData="We are unable to fetch Data from MCA"
      this.common.popToast('error', ' Owner Details', 'Unable to get Owners Details');
      });
  }

  /*to get cin/mca  data from by api hit*/
  getOwnersData() {
    let compSearchProviderObJ = this.serviceProvider.getProviderData(SLUG.companySearch);
    if (compSearchProviderObJ && compSearchProviderObJ.id) {
      this.compSearchProviderID = compSearchProviderObJ.id


    }
    let cinProviderObJ = this.serviceProvider.getProviderData(SLUG.cinProfile);
    if (cinProviderObJ && cinProviderObJ.id) {
      this.cinProviderID = cinProviderObJ.id;

    }

    let mcaproviderObJ = this.serviceProvider.getProviderData('mca-signatories');
    if (mcaproviderObJ && mcaproviderObJ.id) {

      this.mcaproviderID = mcaproviderObJ.id;

    }


    this.company_searchParamas = {
      company_name: this.company_name,
      user_id: this.user_id,
      stub: 'stub',
      app_id: this.app_id,
      service_provider: this.compSearchProviderID
    };

    this.cinApiParams = {
      cin: this.cin,
      user_id: this.user_id,
      stub: 'stub',
      app_id: this.app_id,
      service_provider: this.cinProviderID,
      service_provider2: this.mcaproviderID
    };

    
  /* api to get data from company search */
    this.api.saveTaskInfo(
      this.company_searchParamas, { slug: SLUG.companySearch }
    ).subscribe(res => {
      if (res) {

        this.cinApiParams.cin = res.company_search.data.data.result.sort((a, b) => {
          return b.score - a.score;
        })[0].cin;

        if (this.cinApiParams.cin) {
          // BRMDecision = get(res, 'response_data.tu_brm1_call.data.data.BRMDecision');
          const appType = this.common.getAppType('unsecured_business_loan');
          const appStatus = this.common.getAppStatus('Incomplete');
          const payload: any = {
            business_id: this.businessID,
            // action_type: val.action,
            cin: this.cinApiParams.cin,
            user_id: this.user_id,
            app_id: this.app_id,
            status_id: appStatus.id,
            product_type: appType.id
          };
          payload.current_state = 'owners-details';
           this.api.saveTaskInfo(payload, { slug: SLUG.updateBusiness }).subscribe((res)=>{
             if (res) {
               this.api.saveTaskInfo(this.cinApiParams, {slug: SLUG.cinProfile}).subscribe(res => {
                 if (res) {
                   this.ownersData = res;
                   if (this.ownersData) {
                    
                     this.callOwners('cin_profile');
                   }

                 }
               }, (err) => {
                 this.formdatasubscription.unsubscribe();
                 this.common.nextsubscriptionEmit = true;
                 this.resultFlag = false;
                 this.displayData = "We are unable to fetch CIN/MCA Details" 
                 if (err.cin_profile) {
                  this.common.popToast('error', ' Cin Profile ', 'Unable to load Cin Profile Data ');
                } else if (err.mca_signatories) {
                  this.common.popToast('error', 'MCA Signatories', 'Unable to load MCA Signatories Data ');
                } else if (err.cin_profile_reference) {
                  this.common.popToast('error', ' Cin Profile ', 'Unable to load Cin Profile Data ');
                }else if (err.mca_signatories_reference) {
                  this.common.popToast('error', 'MCA Signatories', 'Unable to load MCA Signatories Data ');
                }else{
                  this.common.popToast('error', 'Owners Details', 'Unable to load Owners Details ');
                }
               });

             }
           },(err)=>{
            this.resultFlag=false;
            this.displayData="We are unable to fetch CIN/MCA Details"
            this.common.popToast('error', 'Update Business', 'Unable to Update Business');
            });
        }

      }
    }, (err) => {
      this.formdatasubscription.unsubscribe();
      this.common.nextsubscriptionEmit = true;
      this.resultFlag = false;
      this.displayData = "We are unable to fetch Data from MCA"
      this.common.popToast('error', 'Company Search', 'Unable to Search Company');
      });
  }



  /* to prepare owners data for setting up in form fields of owners-details form */
  callOwners(key) {
    let owners = [];
    let directors = this.ownersData[key]?.data?.data?.result?.directors;
    directors?.map(data => {
      if (data && data.address) {
        this.api.saveTaskInfo(
          {
            address: data.address,
            stub: 'stub',
            consent: 'y',
            version: '2.1',
            action: 'address_split',
            provider: 'K10'
          },
          { slug: SLUG.addressSplit }).subscribe(result => {
            const addressData = result?.address_split?.data?.data?.result;
           
            let address_line_1;
            let address_line_2;
            let address_line_3;
            const registeredAddress = addressData;
            this.stateArray=this.formInitialValue?.state?.data?.data;
            this.stateObject = this.stateArray?.find(val => val.value === addressData?.State);
            if(this.stateObject){
              this.ownerState=this.stateObject?.id;
              this.ownerCity=this.stateObject?.cities.find(val => val.value === addressData["City"])?._id;
            }
            if(registeredAddress.House || registeredAddress.Floor || registeredAddress.Complex || registeredAddress.Building){
              let house = registeredAddress.House?registeredAddress.House + ", " : ""
              let floor = registeredAddress.Floor?registeredAddress.Floor + ", " : ""
              let complex = registeredAddress.Complex? registeredAddress.Complex +", " : ""
              let building  = registeredAddress.Building?registeredAddress.Building:""
              address_line_1 = house + floor + complex + building;
            }
            if(registeredAddress.Street || registeredAddress.Landmark || registeredAddress.locality){
              let street = registeredAddress.Street? registeredAddress.Street+ ", " : ""
              let landmark = registeredAddress.Landmark? registeredAddress.Landmark + ", ": ""
              let locality = registeredAddress.locality? registeredAddress.locality+ ", ":""
              let untagged = registeredAddress.Untagged? registeredAddress.Untagged:""
              address_line_2 = street + landmark + locality + untagged;
            }
            if(registeredAddress.City || registeredAddress.State){
              let city = registeredAddress.City? registeredAddress.City+ ", " : ""
              let state = registeredAddress.State? registeredAddress.State: ""
              address_line_3 = city + state;
            }

            if(this.ownerCity && this.ownerState){

              owners.push({
                entity_type: this.masterData?.entity_type?.data?.data[0]?.id,
                identifier_number: data?.din,
                pan_number: data?.pan,
                date_of_birth: data?.dob?.slice(0, 10).split('-').reverse().join('-'),
                individual_name: data?.name,
                address_line_1: address_line_1 || " ",
                address_line_2: address_line_2 || " ",
                address_line_3: address_line_3 || " ",
                pincode: addressData?.Pin,
                state:this.ownerState,
                city:this.ownerCity
              });
            }
            else if(this.ownerState){
              owners.push({
                entity_type: this.masterData?.entity_type?.data?.data[0]?.id,
                identifier_number: data?.din,
                pan_number: data?.pan,
                date_of_birth: data?.dob?.slice(0, 10).split('-').reverse().join('-'),
                individual_name: data?.name,
                address_line_1: address_line_1 || " ",
                address_line_2: address_line_2 || " ",
                address_line_3: address_line_3 || " ",
                pincode: addressData?.Pin,
                state:this.ownerState
              });
            }
            else if(this.ownerCity){
              owners.push({
                entity_type: this.masterData?.entity_type?.data?.data[0]?.id,
                identifier_number: data?.din,
                pan_number: data?.pan,
                date_of_birth: data?.dob?.slice(0, 10).split('-').reverse().join('-'),
                individual_name: data?.name,
                address_line_1: address_line_1 || " ",
                address_line_2: address_line_2 || " ",
                address_line_3: address_line_3 || " ",
                pincode: addressData?.Pin,
                city:this.ownerCity
              });
            }
            if (owners?.length == directors?.length) {
              this.setOptions(owners)
            }
          },(err)=>{
            this.resultFlag=false;
            this.displayData="We are unable to fetch Data from MCA"
            this.common.popToast('error', ' Address Split', 'error while getting proper Address,try after sometime.');
            })

      } else {
        owners.push({
          entity_type: this.masterData?.entity_type?.data?.data[0]?.id,
          identifier_number: data?.din,
          pan_number: data?.pan,
          date_of_birth: data?.dob?.slice(0, 10).split('-').reverse().join('-'),
          individual_name: data?.name,
        })
        if (owners?.length == directors?.length) {
          this.setOptions(owners)
        }
      }

    });

  }

  /* to setup data for select fields of owners form */
  setOptions(owners) {

    let setData;
    const pan4 = this.business_pan[3].toUpperCase();
    if (pan4 === 'P') {
      setData = [{ entity_type: this.masterData?.entity_type?.data?.data[0]?.id }];
      // this.addHide = true;
    } else if (pan4 === 'C') {
      setData = owners;
      // this.addHide = true;
    } else {
      const legal_name_of_business = this.business_name;
      const llp = /\bllp|\bLLP|\blimited lia|\bLimited Lia/gm;
      if (llp.test(legal_name_of_business)) {
        setData = owners;
        // this.addHide = true;
      } else {
        setData = [{ entity_type: this.masterData?.entity_type?.data?.data[0]?.id }];
        // this.addHide = false;
      }
    }
    if (this.formInitialValue && this.masterData) {
      const relations = this.formInitialValue ?.entity_type ?.data ?.data
        .filter(value => value.id === this.masterData ?.entity_type ?.data ?.data[0] ?.id)[0].relationships;
      const addressType = this.formInitialValue ?.entity_type ?.data ?.data
        .filter(value => value.id === this.masterData ?.entity_type ?.data ?.data[0] ?.id)[0].addressType;
      const typeOfEntity = this.formInitialValue ?.entity_type ?.data ?.data
        .filter(value => value.id === this.masterData ?.entity_type ?.data ?.data[1] ?.id)[0].typeOfEntity;
      const class_of_activity = this.formInitialValue ?.class_of_activity ?.data ?.data;

      if (this.ownerState && this.stateArray) {
        const cities = this.stateArray ?.filter(value => value.id === this.ownerState)[0].cities;
        this.common.sendMasterData({
          city: { data: { data: cities } }
        });
      }
      // let typedata = this.formInitialValue.entity_type.data.data.filter(value => value.id === this.masterData.entity_type.data.data[1].id)[0].typeOfEntity;
      this.common.sendMasterData({
        relationship: { data: { data: relations } },
        type_of_address: { data: { data: addressType } },
        business_constitution: { data: { data: typeOfEntity } },
        class_of_activity: { data: { data: class_of_activity } }
      });

 /* set data in owner-details form fields*/
      this.formDataSet(setData);
      
  /* to store owners data in session storage */
      this.common.storeDataInStorage('owners-data', setData);
    }
  }

 /* set data in owner-details form fields*/
  formDataSet(setData) {

    this.isRemove = setData?.length;
    this.formGenerate.setFormValues(this.ownerDetailForm, { owners: setData });

    for (let i = 0; i < setData?.length; i++) {
    this.ownerDetailForm?.controls?.owners["controls"][i].get('credit_bureau').setValue(true);

      if (setData[i]?.entity_type == this.masterData?.entity_type?.data?.data[1]?.id) {
        this.ownerDetailForm?.controls?.owners['controls'][i] ?.get('type_of_address').disable();
      }

    }
    this.showForm = true;
  }


  ngOnDestroy(): void {
    this.formdatasubscription.unsubscribe();
    this.common.nextsubscriptionEmit=false;
    this.common.deleteDataFromStorage('owners-data');
  }

}

