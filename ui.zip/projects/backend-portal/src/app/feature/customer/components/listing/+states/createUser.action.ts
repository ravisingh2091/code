import { createAction, props } from '@ngrx/store';

export const loadCreateUser = createAction(
  '[CreateUser] Load Create User',
  props<{ slug: string }>()
);

export const createUserSuccess = createAction(
  '[CreateUser] Load Create User Success',
  props<{ createUser: any }>()
);

export const createUserFailure = createAction(
  '[CreateUser] Load Create User Failure',
  props<{ error: any }>()
);

export const createUserSubmit = createAction(
  '[CreateUser] Create User Submit',
  props<{ slug: string, formData: any }>()
);

export const createUserComplete = createAction(
  '[CreateUser] Create User Complete',
  props<{ createUser: any }>()
);
