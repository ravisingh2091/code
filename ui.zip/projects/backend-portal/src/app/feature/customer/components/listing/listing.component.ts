import { Component, OnInit, TemplateRef, OnDestroy } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { ApplicationListingFacade } from './listing.facade';
import { FormGenerateService } from '@shared/services/form-generate.service';
import { CommonService } from '@shared/services/common.service';
import { ApplicationService } from '@shared/services/application.service';
import { FormGroup } from '@angular/forms';
import {SLUG} from '../../../../shared/constants/slug';
import { FormFieldInterface } from '@utils/interfaces/form-fields.interface';
import { CreateUserFacade } from './+states/createUser.facade';
import { createUserSubmit, loadCreateUser } from './+states/createUser.action';
import { addAppID, addUserDetails, addBusinessID } from '@utils/+state/utils.action';
import { get } from 'lodash-es';

import { forkJoin, Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { take, switchMap, catchError } from 'rxjs/operators';

@Component({
  selector: 'app-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.scss']
})
export class ListingComponent implements OnInit, OnDestroy {
  private isAscendic: boolean = true;
  public dpConfig: Partial<BsDatepickerConfig> = new BsDatepickerConfig();
  createUserForm: FormGroup;
  createUserConfig: FormFieldInterface[] = [];
  createUserSubscription: Subscription;
  modalRef: BsModalRef;
  mainSlug: string;
  slug: string;
  filterConfig: any;
  filterForm: any;
  filterData: any;
  loadApplicationListingSubscription: Subscription;
  flag: boolean;
  rootStateSubscription: Subscription;
  startindex: number;
  page: any;
  pageLimit: any;
  clicks = 0;
  allUsers: any = [];
  user_apps: any = [];
  listingData: any;
  backendUserID: string;
  IdArray: any = [];
  appData: any = [];
  userArray: any = [];
  appStatus: any = [];
  backendUser: any = [];
  showAccordion: number;
  currentPage = 1;
  perPage = 10;
  filterParams = {
    skip: 0,
    limit: 10,
    backend_user_id: ''
  };
  globalObj: any = {
    totalApps: 0,
    previous: false,
    next: true
  };
  pager: any = {
    endIndex: 10,
    currentPage: 1
  };
  totalUsers: any;
  productType: any;
  editUserConfig: any;
  editUserForm: any;
  customerDetails: any;
  editModalRef: BsModalRef;
  filterBarConfig: any;
  filterBarForm: any;
  GoFlag: boolean;
  email: any;
  phone: any;
  filterStack: any={};
  // filterStack: any;

  constructor(
    private modalService: BsModalService,
    private applicationListingFacade: ApplicationListingFacade,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private createUserFacade: CreateUserFacade,
    private common: CommonService,
    private api: ApplicationService
  ) {
    this.dpConfig.containerClass = 'theme-dark-blue';
  }

  ngOnInit(): void {
    this.currentPage = 1;
    this.common.customerFooterEmit = false;
    this.clicks = 1;
    this.flag = false;
    this.onLoad({
      slug: SLUG.userListing,
      per_page: 10
    });
// root state subscription
    this.rootStateSubscription = this.store
      .pipe(
        select('app'),
        take(1)
      ).subscribe(rootState => {
        if (rootState) {
          if (rootState.backendUserData) {
            this.backendUserID = rootState.backendUserData.user.id;
          }
        }
      });

// FilterBar Form
    this.api.getTaskInfo({
      slug: SLUG.filterBar,
    }).subscribe(res => {
      if (res) {
        this.slug = res.task_slug;
        this.filterBarConfig = res.form_fields;
        this.filterBarForm = this.formGenerate.createControl(this.filterBarConfig);
        this.formGenerate.setFormValues(this.editUserForm, this.customerDetails);
      }
    },(err)=>{
      this.common.popToast('error', 'Filter Bar', 'error while getting Filter Bar');
    });

  }
// create application and add user data,appID,businessID to store
  goToCreate = (user): void => {
    try {
      this.applicationListingFacade.dispatch(addUserDetails({
        userData: {
          email_address: user.email_address,
          first_name: user.first_name,
          last_name: user.last_name,
          id: user.id,
          phone_number: user.phone_number
        }
      }));
      this.applicationListingFacade.dispatch(addAppID({ appID: null }));
      this.applicationListingFacade.dispatch(addBusinessID({ businessID: null }));
      this.common.navigate(SLUG.businessInfo);
    } catch (e) { }
  }
  // sorting user list
  sort() {
    this.isAscendic ? this.ascendic() : this.descendic()
  }
  // sorting list in ascending order
  ascendic() {
    this.isAscendic = false;
    this.allUsers = this.allUsers.sort((a, b) => {
      if (a.record_id < b.record_id) {
        return 1;
      }
      if (a.record_id > b.record_id) {
        return -1;
      }
      return 0;
    });
  }
  // sorting list in descending order
  descendic() {
    this.isAscendic = true;
    this.allUsers = this.allUsers.sort((a, b) => {
      if (a.record_id > b.record_id) {
        return 1;
      }
      if (a.record_id < b.record_id) {
        return -1;
      }
      return 0;
    })
  }
// routing to current state and underwriter journey
  goTo = (userApp, user): void => {
    try {
      const filteredRefs = userApp.business_ref.filter(elem => elem.app_id === userApp.app_id);
      const tuRef = filteredRefs.find(elem => elem.type === 'tu_brm_1');
      this.applicationListingFacade.dispatch(addAppID({ appID: userApp.app_id }));
      if (userApp?.business.length > 0) {
        this.applicationListingFacade.dispatch(addBusinessID({ businessID: userApp.business[0]._id }));
      } else {
        this.applicationListingFacade.dispatch(addBusinessID({ businessID: null }));
      }
      this.applicationListingFacade.dispatch(addUserDetails({
        userData: {
          email_address: user.email_address,
          first_name: user.first_name,
          last_name: user.last_name,
          id: user.id,
          phone_number: user.phone_number
        }
      }));
      if(userApp.appStatus.value==="Submitted"){

        this.overview(userApp.app_id,userApp.user_id,userApp.business_ref,userApp.record_id);
        return
      }
      if (tuRef) {
          // this.overview(userApp.app_id,userApp.user_id,userApp.business_ref,userApp.record_id);
        if (tuRef && tuRef.response && tuRef.response.BRMDecision && tuRef.response.BRMDecision.toLowerCase() === 'go') {

         this.GoFlag=true;
          this.common.navigate(userApp?.business[0].current_state);
        } else {
          this.common.popToast('error', 'Application Status', 'This application got rejected in TU decision.');
        }
      } else {
        if (userApp?.business.length > 0 && userApp?.business[0].current_state) {
          this.common.navigate(userApp?.business[0].current_state);
        } else {
          this.common.navigate(SLUG.businessInfo);
        }
      }
          // this.common.navigate(userApp?.business[0].current_state);

    } catch (e) { }
  }


// mapping data of applications and user
  mappingData(): void {
    this.allUsers = [];
    this.userArray.map((element) => {
      const applications = [];
      this.appData.map(value => {
        if (value.user_id === element.id) {
          applications.push({
            ...value,
            appStatus: this.appStatus.find(app => app.id === value.status_id),
            productType: this.productType.find(app => app.id === value.product_type)
          });
        }
      });
      const backendUser = this.backendUser.find(user => user.id === element.backend_user_id);
      this.allUsers.push({ ...element, applications, backendUser });
    });
  }
// create user form
  openModal = (template: TemplateRef<any>) => {
    this.api.getTaskInfo({
      slug: SLUG.createUser}
      ).subscribe((createUserState: any) => {
        if (createUserState) {
          this.slug = createUserState.task_slug;
          this.createUserConfig = createUserState.form_fields;
          this.createUserForm = this.formGenerate.createControl(this.createUserConfig);
          this.common.sendMasterDataToFields(this.createUserConfig, createUserState.response_data);
        }
      },(err)=>{
        this.common.popToast('error', 'Create User', 'error while loading Create User Form')
      });

    this.modalRef = this.modalService.show(template);

  }
// for loading applications
  onLoad(apiData): void {
    this.IdArray=[];
    this.api.getTaskInfo(apiData)
      .pipe(
        switchMap((applicationListingState: any) => {
          if (applicationListingState) {

            this.mainSlug = applicationListingState.task_slug;
            this.userArray = applicationListingState?.response_data?.get_all_users?.data?.data?.result;
            this.totalUsers = applicationListingState?.response_data?.get_all_users?.data?.data?.total;
            this.setPage(this.currentPage);
            this.common.storeAppStatus(applicationListingState.response_data.app_status.data.data);
            this.common.storeDataInStorage('app_type', applicationListingState.response_data.app_type.data.data)
            this.appStatus = applicationListingState?.response_data?.app_status?.data?.data;
            this.productType = applicationListingState?.response_data?.app_type?.data?.data;
            const backendUser = [];
            for (const val of this.userArray) {
              this.IdArray.push(val.id);
              if (val.backend_user_id) {
                backendUser.push(val.backend_user_id);
              }
            }
            const forkJoinData = [];
            forkJoinData.push(this.api.saveTaskInfo(
              {
                user_ids: this.IdArray,
                expands: [
                  {
                    key: 'business_info',
                    foreign_field: 'app_id',
                    local_field: 'app_id',
                    as: 'business'

                  },
                  {
                    key: 'service_business',
                    foreign_field: 'app_id',
                    local_field: 'app_id',
                    as: 'business_ref'
                  }
                ]
              }, { slug: SLUG.userListData }
            ));

            if (backendUser.length) {
              forkJoinData.push(this.api.saveTaskInfo(
                {
                  user_ids: backendUser.filter((value, index, self) => self.indexOf(value) === index)
                }, {
                slug: SLUG.backendUsers
              }
              ));
            }
            return forkJoin(forkJoinData);
          }else{

        this.common.popToast('error', 'Load User', 'error while Getting User')
          }
        })
      ).subscribe((res: any) => {

        this.appData = res[0]['user-listing-applications'].data.data;
        if (res.length > 1) {
          this.backendUser = res[1].backend_users.data.data;  
        }
        this.mappingData();
      },
      (err)=>{
        this.common.popToast('error', 'Load Applications', 'error while Getting User Applications')
      });
  }

  // function for creating user
  onSubmit = (): void => {
    if (this.createUserForm.valid) {
      const payload = {
        ...this.createUserForm.value,
        backend_user_id: this.backendUserID,
        full_name: this.createUserForm.get('first_name').value + ' ' + this.createUserForm.get('last_name').value
      };
      this.api.saveTaskInfo(payload, { slug: SLUG.createUser }
      ).subscribe(userState => {
        if (userState) {
          if ((this.filterBarForm.value.full_name != null && this.filterBarForm.value.full_name !="") || (this.filterBarForm.value.email_address != null && this.filterBarForm.value.email_address !="")) {
            this.clearFilterStack();
            this.currentPage = 1;
            this.onLoad({
              slug: SLUG.userListing,
              per_page: 10
            });
          }else{
            this.currentPage = 1;
            this.onLoad({
              slug: SLUG.userListing,
              per_page: 10
            });
          }
          this.modalRef.hide();
          this.common.popToast('success', 'Success!', 'Customer created successfully');
        }
      });
    } else {

      this.formGenerate.validateAllFormFields(this.createUserForm);
    }
  }

// edit user form
  editCustomerModal = (edit_template: TemplateRef<any>, user) => {
    this.customerDetails = user;
    this.email = user.email_address;
    this.phone = user.phone_number;
    this.api.getTaskInfo({
      slug: SLUG.updateUser,
    }).subscribe(res => {
      if (res) {
        this.slug = res.task_slug;
        this.editUserConfig = res.form_fields;
        this.editUserForm = this.formGenerate.createControl(this.editUserConfig);

        this.formGenerate.setFormValues(this.editUserForm, this.customerDetails);
      }
    },
    (err)=>{

      this.common.popToast('error', 'Update User', 'error while getting Update User Form')
    }
    );
    this.editModalRef = this.modalService.show(edit_template);


  }

// update user
  onUpdate() {
    const user_id = this.customerDetails.id;
    if (this.editUserForm.valid) {
      const payload: any = {
        user_id,
        ...this.editUserForm.value,
        full_name: this.editUserForm.get('first_name').value + ' ' + this.editUserForm.get('last_name').value
      };

      if(this.editUserForm.get('phone_number').value !== this.phone){
        payload.checkPhone = true;
      }

      if(this.editUserForm.get('email_address').value !== this.email){
        payload.checkEmail = true;
      }

      this.api.saveTaskInfo(payload, { user_id, slug: SLUG.updateUser }
      ).subscribe(res => {
        if (res) {
          this.onLoad({
            slug: SLUG.userListing,
            per_page: 10
          });
          this.editModalRef.hide();
          this.common.popToast('success', 'Edit Customer', 'Update Successful');
        }
      }
      );

    } else {
      this.formGenerate.validateAllFormFields(this.editUserForm);
    }
  }
// for resetting filterstack
  clearFilterStack(){
this.filterStack.full_name="";
this.filterStack.email_address="";

this.filterBarForm.get('full_name').patchValue("");

this.filterBarForm.get('email_address').patchValue("");
  }



// filter data by search Bar
  filteredData() {
    if ((this.filterBarForm.value.full_name != null && this.filterBarForm.value.full_name !="") || (this.filterBarForm.value.email_address != null && this.filterBarForm.value.email_address !="") ) {

      if (this.filterBarForm.value.full_name !=null) {
        this.filterStack.full_name = this.filterBarForm.value.full_name;
      }

      if (this.filterBarForm.value.email_address !=null) {
        this.filterStack.email_address = this.filterBarForm.value.email_address;
      }
      if(this.filterStack.full_name){
        this.filterBarForm.get('full_name').patchValue(this.filterStack.full_name);
      }
      if(this.filterStack.email_address){
        this.filterBarForm.get('email_address').patchValue(this.filterStack.email_address);
      }
      this.currentPage=1;
      this.onLoad({
        slug: SLUG.userListing,
        per_page: this.pager.pageSize,
        ...this.filterStack
      });
    } else {
         this.currentPage=1;
         this.onLoad({
           slug: SLUG.userListing,
           start:0,
           per_page: 10
         });
    }
  }
// routing to page no. or next or previous
  clickPage(page: number, flag?): void {


    if (!page) {
      if (flag === 'next') {
        page = this.currentPage + 1;
        this.currentPage = this.currentPage + 1;
        this.setPage(page);
        // this.currentPage = this.currentPage + 1;
        // const totalPage = Math.ceil(+this.globalObj.totalApps / +this.perPage);
        if (this.currentPage === this.pager.totalPage) {
          this.globalObj.next = false;
        }
      }
      if (this.currentPage > 0) {
        this.globalObj.previous = true;
      }

      if (flag === 'previous' && this.currentPage >= 0) {
        this.globalObj.next = true;
        page = this.currentPage - 1;
        this.currentPage = this.currentPage - 1;
        this.setPage(page);
        if (this.currentPage === 1) {
          this.globalObj.previous = false;

        }
      }
    } else {
      this.currentPage = page;
      if (page >= 2) {
        this.globalObj.previous = true;
      }
      if (page === 1) {
        this.globalObj.previous = false;
      }
      const totalPage = Math.ceil(+this.globalObj.totalApps / +this.perPage);
      if (page === totalPage) {
        this.globalObj.next = false;
      } else {
        this.globalObj.next = true;
      }

    }

    this.setPage(page);
    if ((this.filterStack.full_name != null && this.filterStack.full_name !="") || (this.filterStack.email_address != null && this.filterStack.email_address !="")) {
   

      this.onLoad({
        slug: SLUG.userListing,
        per_page: this.pager.pageSize,
         start: this.pager.startIndex,
        ...this.filterStack,
      });
      if(this.filterStack.full_name){
        this.filterBarForm.get('full_name').patchValue(this.filterStack.full_name);
      }
      if(this.filterStack.email_address){
        this.filterBarForm.get('email_address').patchValue(this.filterStack.email_address);
      }

    } else {
      this.onLoad({
        slug: SLUG.userListing,
        per_page: this.pager.pageSize,
        start: this.pager.startIndex
      });
    }

  }

// function to set page
  setPage(page: number): void {
    this.pager = this.getPager(
      this.totalUsers,
      page,
      this.perPage
    );
  }
// function to get pager data
  getPager(totalItems: number, currentPage: number = 1, pageSize: number): object {
    // calculate total pages
    const totalPages = Math.ceil(totalItems / pageSize);

    let startPage: number, endPage: number;
    if (totalPages <= 5) {
      startPage = 1;
      endPage = totalPages;
    } else {
      if (currentPage <= 3) {
        startPage = 1;
        endPage = 5;
      } else if (currentPage + 1 >= totalPages) {
        startPage = totalPages - 4;
        endPage = totalPages;
      } else {
        startPage = currentPage - 2;
        endPage = currentPage + 2;
      }
    }

    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);
    const pages = Array.from(Array(endPage + 1 - startPage).keys()).map(
      i => startPage + i
    );
    if (this.currentPage === 1) {
      this.globalObj.next = true;
      this.globalObj.previous=false;
    }

    if (this.currentPage === totalPages) {
      this.globalObj.next = false;
    }else{
      this.globalObj.next = true;
    }
    if(totalPages==0){
      this.globalObj.next = false;
      
      this.globalObj.previous = false;
      this.pager.totalPages=0;
    }


    return {
      totalItems,
      currentPage,
      pageSize,
      totalPages,
      startPage,
      endPage,
      startIndex,
      endIndex,
      pages
    };
  }
// function to handle accordian
  handleAccordion(i): void {
    this.showAccordion = this.showAccordion === i ? null : i;
  }
// function to check prequalified validations
  checkPreQulified(userApp: any, type: string): object {
    if(type==='tu_brm_1'){

    if(userApp?.appStatus?.value==='Submitted'){
      const businessRef = userApp?.business_ref?.filter(elem => elem.app_id === userApp.app_id);
      if (businessRef.some(value => value.type === type)) {
        return { 'badge-success': true };
      } else {
        return { 'badge-danger': true };
      }
    }
      const businessRef = userApp?.business_ref?.filter(elem => elem.app_id === userApp.app_id);
      if (businessRef.some(value => value.type === type)) {
        return { 'badge-warning': true };
      } else {
        return { 'badge-danger': true };
      }

    }else{
      const businessRef = userApp?.business_ref?.filter(elem => elem.app_id === userApp.app_id);
      if (businessRef.some(value => value.type === type)) {
        return { 'badge-success': true };
      } else {
        return { 'badge-danger': true };
      }
    }

  }


  ngOnDestroy(): void {
    this.rootStateSubscription.unsubscribe();
    // this.loadApplicationListingSubscription.unsubscribe();
  }


// function for routing app overview
  overview = (appId, userId, refs, recordId) => {
    const gstRef = refs.find(e => e.type === 'gst_profile');
    if (gstRef) {
      const refId = gstRef.ref_id;
      this.common.storeDataInStorage('ao_app_id', appId);
      this.common.storeDataInStorage('ao_user_id', userId);
      this.common.storeDataInStorage('ao_ref_id', refId);
      this.common.storeDataInStorage('ao_record_id', recordId);
      this.common.navigate(SLUG.addCoApplicant);
    }
    else {
      this.common.popToast('error', 'Not Found', 'Unable to find GST Profile for this application');
    }
  }


}



