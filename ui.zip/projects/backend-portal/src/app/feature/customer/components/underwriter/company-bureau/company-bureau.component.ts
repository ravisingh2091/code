import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-bureau',
  templateUrl: './company-bureau.component.html',
  styleUrls: ['./company-bureau.component.scss']
})
export class CompanyBureauComponent implements OnInit {
  isFirstOpen = true;
  constructor() { }

  ngOnInit() {
  }

}
