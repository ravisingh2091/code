import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonService } from '@shared/services/common.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {

  showFooter = true;

  constructor(private common: CommonService, private changeDetection: ChangeDetectorRef) {

   }

  ngOnInit(): void {
    this.common.customerFooterObservable
      .subscribe((val) => {
        this.showFooter = val;
        this.changeDetection.detectChanges();
      });

    this.common.loginEmit = true;
  }

}
