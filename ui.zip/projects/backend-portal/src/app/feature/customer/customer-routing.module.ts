import { ApplicationOverviewComponent } from './components/application-overview/application-overview.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerOfferComponent } from './components/customer-offer/customer-offer.component';
import { BusinessInfoComponent, ListingComponent } from './components';
import { OwnerDetailComponent } from './components/owner-detail/owner-detail.component';
import {CollectInfoComponent} from './components/collect-info/collect-info.component'
import { IncomeExpenseComponent } from './components/income-expense/income-expense.component';
import { CustomerComponent } from './customer.component';
import { UnderwriterComponent } from './components/underwriter/underwriter.component';
import { OfferDetailsComponent } from './components/offer-details/offer-details.component'

const routes: Routes = [
  {
    path: '',
    component: CustomerComponent,
    children: [
      {
        path: 'business-info',
        component: BusinessInfoComponent
      },
      {
        path: 'listing',
        component: ListingComponent
      },
      {
        path: 'owners-details',
        component: OwnerDetailComponent
      },
      {
        path: 'collect-info',
        component: CollectInfoComponent
      },
      {
        path: 'income-expense',
        component: IncomeExpenseComponent
      },
      {
        path: 'app-overview',
        component: ApplicationOverviewComponent
      },
      {
        path: 'underwriter',
        component: UnderwriterComponent
      },
      {
        path: 'offer-details',
        component: OfferDetailsComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerRoutingModule { }
