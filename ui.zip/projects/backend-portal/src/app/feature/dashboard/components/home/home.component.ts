import { Component, OnInit } from '@angular/core';
import { ApplicationService } from '@shared/services/application.service';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  slug: string;
  userID: string;
  username: any;
  totalApps: any;
  userDetails: any;
  allUsers: any;
  constructor(private api: ApplicationService) {}

  ngOnInit(): void {
    this.username = JSON.parse(
      sessionStorage.getItem('state')
    ).app.backendUserData.user.name;
    try {
      this.api.getTaskInfo({ slug: 'user-listing' }).subscribe((res) => {
        this.allUsers = res.response_data.get_all_users.data.data.result;
        this.api
          .getTaskInfo({
            slug: 'get-all-applications',
          })
          .subscribe((res) => {
            this.userDetails = []
            this.totalApps = res.response_data.get_all_applications.data.total;
            res.response_data.get_all_applications.data.data.forEach((elem) => {
              this.userDetails.push({
                record_id : elem.record_id,
                  status_id : elem.status_id,
                  createdAt : elem.created_at,
                  username : this.allUsers.find(
                    (val) => elem.user_id === val.id
                  )?.full_name
              });
            });
            this.userDetails.sort((a,b) => {
              return <any>new Date(b.createdAt) - <any>new Date(a.createdAt)
            })
          });
      });
    } catch (e) {}
  }
}
