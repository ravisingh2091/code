import { createReducer, on, Action } from '@ngrx/store';
import * as DashboardActions from './dashboard.actions';

export const DASHBOARD_FEATURE_KEY = 'dashboard';

export interface State {
  loaded: boolean; // has the Dashboard being loaded
  taskInfo: any,
  error?: string | null; // last none error (if any)
}

export interface DashboardPartialState {
  readonly [DASHBOARD_FEATURE_KEY]: State;
}

export const initialState: State = {
  // set initial required properties
  loaded: false,
  taskInfo: null
};

const dashboardReducer = createReducer(
  initialState,
  on(DashboardActions.loadDashboard, state => ({
    ...state,
    loaded: false,
    error: null
  })),
  on(DashboardActions.loadDashboardSuccess, (state, { dashboard }) => ({
    ...state,
    taskInfo: dashboard,
    loaded: true,
    error: null
  })),
  on(DashboardActions.loadDashboardFailure, (state, { error }) => ({
    ...state,
    error
  }))
);

export function reducer(state: State | undefined, action: Action) {
  return dashboardReducer(state, action);
}
