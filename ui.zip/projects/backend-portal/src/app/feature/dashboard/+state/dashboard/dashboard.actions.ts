import { createAction, props } from '@ngrx/store';

export const loadDashboard = createAction('[Dashboard] Load Dashboard',
  props<{ slug: string }>());

export const loadDashboardSuccess = createAction(
  '[Dashboard] Load Dashboard Success',
  props<{ dashboard: any }>()
);

export const loadDashboardFailure = createAction(
  '[Dashboard] Load Dashboard Failure',
  props<{ error: any }>()
);
