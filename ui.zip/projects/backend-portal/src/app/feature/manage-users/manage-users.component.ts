import { Component, OnInit } from '@angular/core';
import { config } from '../../shared/common.config';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.scss']
})
export class ManageUsersComponent implements OnInit {
  commonConfig = config;
  constructor() { }

  ngOnInit(): void {
    this.commonConfig.urls.orch_url = environment.orchUrl;
  }

}
