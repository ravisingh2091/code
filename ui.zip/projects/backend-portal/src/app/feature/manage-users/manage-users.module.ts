import { SharedModule } from '@shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { UserManagementModule } from 'user-management';
import { ManageUsersComponent } from './manage-users.component';
import { SharedLazyModule } from '@shared/shared-lazy.module';
// import { ToastrModule, ToastrService } from 'ngx-toastr';
import { ManageUsersRoutingModule } from './manage-users-routing.module';


@NgModule({
  declarations: [
    ManageUsersComponent
  ],
  imports: [
    CommonModule,
    // UserManagementModule,
    SharedLazyModule,
    // ToastrModule.forRoot({}),
    ManageUsersRoutingModule,
    SharedModule
  ],
  providers: [
    // ToastrService,
  ]
})
export class ManageUsersModule { }
