import { createReducer, on, Action } from '@ngrx/store';

export const APP_KEY = 'app';
export interface AppState {
    token?: string;
    nextTask?: string;
    previousTask?: string;
    userData?: any;
    backendUserData?: any;
    appID?: string;
    businessID?: string;
    review?: string;
    maxStep?: number;
    masterData?: any;
}

export const initialState: AppState = {
    token: null,
    nextTask: null,
    userData: null,
    backendUserData: null,
    appID: null,
    businessID: null,
    masterData: null,
};

const rootReducer = createReducer(
    initialState
);


export function appReducer(state: AppState | undefined, action: Action) {
    return rootReducer(state, action);
}
