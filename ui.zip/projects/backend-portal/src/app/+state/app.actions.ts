import { createAction } from '@ngrx/store';

export const onReview = createAction('[AppState] on Review');
