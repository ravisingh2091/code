import { ActionReducer, Action } from '@ngrx/store';
import * as _ from 'lodash-es';
import { CommonService } from '@shared/services/common.service';
// import { APP_STEP } from '@rubicon/interface/task-info';

let onInit = true; // after load/refresh…

// the key for the local storage.
const localStorageKey = 'state';

export function storageMetaReducer<S, A extends Action = Action>(storageService: CommonService) {
  return (reducer: ActionReducer<S, A>) => {
    return (state: S, action: A): S => {
      // reduce the nextState.
      const nextState = reducer(state, action);
      // init the application state.
      if (onInit) {
        onInit = false;
        const savedState = storageService.getDataFromStorage(localStorageKey);
        return _.merge(nextState, savedState);
      }
      // save the next state to the application storage.
      const stateToSave = nextState;

      if (action.type === '[UtilState] App on Logout') {
        state = undefined;
        storageService.deleteDataFromStorage(localStorageKey);
        return reducer(state, action);
      }
      storageService.storeDataInStorage(localStorageKey, stateToSave);
      return nextState;
    };
  }
}

export function updateRootState(reducer) {
  return (state, action) => {
    switch (action.type) {
      case '[UtilState] Add Next Task':
        // state = {
        //     ...state,
        //     app: {
        //         ...state.app,
        //         maxStep:APP_STEP[action.nextTask]>state.app.maxStep?APP_STEP[action.nextTask]:state.app.maxStep,
        //         previousTask:state.app.nextTask,
        //         nextTask: action.nextTask
        //     }
        // };
        break;
      case '[UtilState] Add Backend User Details':
        state = {
          ...state,
          app: {
            ...state.app,
            backendUserData: action.userData,
            review: null,
          },
          signup: {
          }
        };
        break;
      case '[UtilState] Add User Details':
        state = {
          ...state,
          app: {
            ...state.app,
            userData: action.userData,
            review: null,
          },
          signup: {
          }
        };
        break;
      case '[UtilState] Add App ID':
        state = {
          ...state,
          app: {
            ...state.app,
            appID: action.appID,
            review: null,
            maxStep: 0
          }
        };
        break;
      case '[UtilState] Add Business ID':
        state = {
          ...state,
          app: {
            ...state.app,
            businessID: action.businessID
          }
        };
        break;
      case '[UtilState] App on Logout':
        state = {
          app: {}
        };
        break;
      case '[UtilState] Add master data to store':
          state = {
            ...state,
            app: {
              ...state.app,
              masterData: action.masterData,
              review: null,
            }
          };
          break;
          case '[UtilState] Add classOfActivityData data to store':
          state = {
            ...state,
            app: {
              ...state.app,
              classOfActivityData: action.classOfActivityData,
              review: null,
            }
          };
          break;
      default:
        break;
    }
    return reducer(state, action);
  };
}
