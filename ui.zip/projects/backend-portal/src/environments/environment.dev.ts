export const environment = {
    production: true,
    stub: false,
    orchUrl: '//orchestrator-aria-dev.b2cdev.com/',
    region: 'in',
    tenantID: 'e6812091-b3b5-4ed5-96bc-0cad58355569',
    appLang: 'en'
};
