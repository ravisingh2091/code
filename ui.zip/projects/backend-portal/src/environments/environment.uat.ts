export const environment = {
    production: true,
    stub: true,
    orchUrl: 'https://orch-biz2x-tu-uat.b2cdev.com/',
    region: 'in',
    tenantID: 'e6812091-b3b5-4ed5-96bc-0cad58355569',
    appLang: 'en'
};
