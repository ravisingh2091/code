import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { FormGenerateService, TaskInfoService, CommonService } from '@rubicon/utils';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { GetStartedFacade } from '../+state/get-started.facade';
import { fromGetStartedActions } from '../+state/get-started.actions';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
@Component({
  selector: 'select-industry',
  templateUrl: './select-industry.component.html',
  styleUrls: ['./select-industry.component.scss']
})
export class SelectIndustryComponent implements OnInit, OnDestroy {
  
  industryConfig:FormFieldInterface[] = [];
  industryForm: FormGroup;
  slug: string = '';
  naics: string = '';
  masterData:any;
  formSubscription: Subscription;
  commonSubscription: Subscription;

  constructor(private formGenerateService: FormGenerateService,
    private taskinfoService: TaskInfoService,
    private commonService: CommonService,
    private getStartedFacade: GetStartedFacade,
    private common: CommonService) { }
   
  ngOnInit(): void {
      this.taskinfoService.getTaskInfo({slug: CONSTANTS.SLUG["select-industry"]}).subscribe(response =>{
        this.slug = response.task_slug;  
        this.industryConfig = response.form_fields;
        this.industryForm = this.formGenerateService.createControl(this.industryConfig);     
        this.onChanges();  
        this.commonService.sendMasterDataToFields(this.industryConfig, response.response_data);
        this.getStartedFacade.getStartedData$.subscribe(data => {
          if (data) {
            this.formGenerateService.setFormValues(this.industryForm, {
              business_industry: data.industry, 
              sub_industry: data.subIndustry
            });
          }
        })
      })
    this.commonSubscription = this.common.masterData
    .subscribe((data: any) => { 
      this.masterData = data;
    })
  }

  onChanges():void{
    this.formSubscription = this.industryForm.get('sub_industry').valueChanges.subscribe((val) => {
      if(val&&this.masterData["sub_industry"]){
        this.naics = this.masterData["sub_industry"].data.filter(sub_ins=> sub_ins._id===val).pop()?.naics;
      }
    });
  }

  onSubmit(action) {
    if(this.formGenerateService.validateCustomFormFields(this.industryForm, action, this.industryConfig)) {
      this.getStartedFacade.dispatch( new fromGetStartedActions.IndustrySubmitted({
        industry:this.industryForm.value.business_industry, 
        subindustry: this.industryForm.value.sub_industry,
        naics: this.naics
      }))
      this.commonService.navigate(CONSTANTS.SLUG['get-started']);
    } 
  }

  ngOnDestroy() { 
    this.commonSubscription.unsubscribe();
    this.formSubscription.unsubscribe();
  }
}
