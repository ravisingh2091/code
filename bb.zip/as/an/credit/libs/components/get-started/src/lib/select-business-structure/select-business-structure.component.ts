import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormGenerateService, TaskInfoService, CommonService } from '@rubicon/utils';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { GetStartedFacade } from '../+state/get-started.facade';
import { fromGetStartedActions } from '../+state/get-started.actions';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';

@Component({
  selector: 'select-business-structure',
  templateUrl: './select-business-structure.component.html',
  styleUrls: ['./select-business-structure.component.scss']
})
export class SelectBusinessStructureComponent implements OnInit, OnDestroy {
  selectedOption = 'default';
 
  slug: string='';
  form: FormGroup;
  formConfig: FormFieldInterface[] = [];
  

  constructor(private formGenerateService: FormGenerateService,
    private taskinfoService: TaskInfoService,
    private commonService: CommonService,
    private getStartedFacade: GetStartedFacade) { }

  ngOnInit(): void {
 
    this.taskinfoService.getTaskInfo({slug: CONSTANTS.SLUG['select-business-structure'] }).subscribe(response => {
      this.slug = response.task_slug;
      this.formConfig = response.form_fields;
      this.form = this.formGenerateService.createControl(this.formConfig);
      this.commonService.sendMasterDataToFields(this.formConfig, response.response_data);
      this.getStartedFacade.businessStructure$.subscribe(data => {
        if (data) {
          this.formGenerateService.setFormValues(this.form, {business_structure: data});
        }
      } )
      this.commonService.updateStepState(CONSTANTS.APP_STEP[this.slug]);
    })

  }

  
  checked(event: any) {
    this.selectedOption = event.target.id;
  }
  onSubmit(action) {
    if(this.formGenerateService.validateCustomFormFields(this.form,action,this.formConfig)) {
      this.getStartedFacade.dispatch(new fromGetStartedActions.BusinessStructureSubmitted({business_structure: this.form.value.business_structure}));
      this.commonService.navigate('create-profile');
    }
    
  }

  ngOnDestroy() {
    this.commonService.updateStepState(0);
  }

}
