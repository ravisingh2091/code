import {
  getStartedActions,
  getStartedActionTypes,
} from './get-started.actions';
export const GET_STARTED_FEATURE_KEY = 'getStarted';

export interface GetStartedState {
  zip_code: number;
  state: string;
  city: string;
  industry: string;
  subIndustry: string;
  naics: string,
  business_structure: string;
  profileData: any;
}

export interface GetStartedPartialState {
  readonly [GET_STARTED_FEATURE_KEY]: GetStartedState;
}

export const initialState: GetStartedState = {
  zip_code: null,
  industry: null,
  subIndustry: null,
  naics: null,
  business_structure: null,
  profileData: null,
  state: null,
  city: null
};

export function reducer(
  state: GetStartedState = initialState,
  action: getStartedActions
) {
  switch (action.type) {
    case getStartedActionTypes.zipCodeSubmitted:
      return {
        ...state,
        zip_code: action.payload.zip_code,
        state: action.payload.state,
        city: action.payload.city
      };
    case getStartedActionTypes.industrySubmitted:
      return {
        ...state,
        industry: action.payload.industry,
        subIndustry: action.payload.subindustry,
        naics: action.payload.naics
      };
    case getStartedActionTypes.businessStructureSubmitted:
      return {
        ...state,
        business_structure: action.payload.business_structure,
      };
    case getStartedActionTypes.clearGetStarted:
      return {
        ...state,
        zip_code: null,
        business_structure: null,
        subIndustry: null,
        industry: null,
        state: null,
        city: null
      };
    case getStartedActionTypes.saveProfileResponse:
      return {
        ...state,
        profileData: action.payload.profileData,
      };
    default:
      return state;
  }
}
