import { Component, OnInit } from '@angular/core';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { FormGroup } from '@angular/forms';
import {
  FormGenerateService,
  TaskInfoService,
  CommonService,
} from '@rubicon/utils';
import { GetStartedFacade } from '../+state/get-started.facade';
import { fromGetStartedActions } from '../+state/get-started.actions';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';

@Component({
  selector: 'get-started',
  templateUrl: './get-started.component.html',
  styleUrls: ['./get-started.component.scss'],
})
export class GetStartedComponent implements OnInit {
  slug: string = '';
  form: FormGroup;
  formConfig: FormFieldInterface[] = [];

  constructor(
    private formGenerateService: FormGenerateService,
    private taskinfoService: TaskInfoService,
    private commonService: CommonService,
    private getStartedFacade: GetStartedFacade
  ) {}

  ngOnInit(): void {
    this.taskinfoService
      .getTaskInfo({ slug: CONSTANTS.SLUG['get-started'] })
      .subscribe(
        (response) => {
          this.slug = response.task_slug;
          this.formConfig = response.form_fields;
          this.form = this.formGenerateService.createControl(this.formConfig);
          this.getStartedFacade.zip_code$.subscribe(data => {
            if (data) {
              this.formGenerateService.setFormValues(this.form, {zip_code: data});
            }
          })
        },
        (error) => {
          console.log('something went wrong!');
        }
      );
  }

  onSubmit(action) {
    if (
      this.formGenerateService.validateCustomFormFields(
        this.form,
        action,
        this.formConfig
      )
    ) {
      let payload = {...this.form.value}
      this.taskinfoService.saveTaskInfo({slug: this.slug}, payload).subscribe(res=> {
        if(res?.check_zip_code?.data?.data?.length > 0) {
          this.getStartedFacade.dispatch(
            new fromGetStartedActions.ZipCodeSubmitted({
              zip_code: this.form.value.zip_code,
              state: res?.check_zip_code?.data?.data[0].state,
              city: res?.check_zip_code?.data?.data[0].city
            })
          );
          this.commonService.navigate(res.nextTask.value);
        } else {
          this.commonService.popToast('error', 'Error', 'Please enter valid Business Zip Code.');
        }
        
        
      })

    
    }
  }
}
