import { Injectable } from '@angular/core';
import { Store, select, Action } from '@ngrx/store';
import { GetStartedPartialState } from './get-started.reducer';
import { getStartedQuery } from './get-started.selectors';

@Injectable()
export class GetStartedFacade {
  zip_code$ = this.store.pipe(select(getStartedQuery.getGetStartedZipCode));
  industry$ = this.store.pipe(select(getStartedQuery.getSelectedIndustry));
  businessStructure$ = this.store.pipe(
    select(getStartedQuery.getSelectedBusinessStructure)
  );
  getStartedData$ = this.store.pipe(select(getStartedQuery.getGetStartedState));
  getProfileData$ = this.store.pipe(
    select(getStartedQuery.getSelectedProfileData)
  );

  constructor(private store: Store<GetStartedPartialState>) {}

  dispatch(action: Action) {
    this.store.dispatch(action);
  }
}
