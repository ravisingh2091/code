import { createFeatureSelector, createSelector } from '@ngrx/store';
import {
  GET_STARTED_FEATURE_KEY,
  GetStartedState,
  GetStartedPartialState,
} from './get-started.reducer';

// Lookup the 'GetStarted' feature state managed by NgRx
export const getGetStartedState = createFeatureSelector<
  GetStartedPartialState,
  GetStartedState
>(GET_STARTED_FEATURE_KEY);

export const getGetStartedZipCode = createSelector(
  getGetStartedState,
  (state: GetStartedState) => state.zip_code
);

export const getSelectedBusinessStructure = createSelector(
  getGetStartedState,
  (state: GetStartedState) => state.business_structure
);

export const getSelectedProfileData = createSelector(
  getGetStartedState,
  (state: GetStartedState) => state.profileData
);

export const getSelectedIndustry = createSelector(
  getGetStartedState,
  (state: GetStartedState) => {
    state.industry, state.subIndustry;
  }
);

export const getStartedQuery = {
  getGetStartedState,
  getGetStartedZipCode,
  getSelectedBusinessStructure,
  getSelectedIndustry,
  getSelectedProfileData,
};
