import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Route } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { GetStartedComponent } from './get-started/get-started.component';
import { SelectIndustryComponent } from './select-industry/select-industry.component';
import { SelectBusinessStructureComponent } from './select-business-structure/select-business-structure.component';
import { CreateProfileComponent } from './create-profile/create-profile.component';
import { StoreModule } from '@ngrx/store';
import * as fromGetStarted from './+state/get-started.reducer';
import { GetStartedFacade } from './+state/get-started.facade';
import { OtpModalModule } from '@credit-bench/components/otp-modal';
import { TermsAndConditionsModule } from '@credit-bench/components/terms-and-conditions';

export const GetStartedRoutes: Route[] = [
  {
    path: '',
    component: GetStartedComponent,
  },
  {
    path: 'select-industry',
    component: SelectIndustryComponent,
  },
  {
    path: 'select-business-structure',
    component: SelectBusinessStructureComponent,
  },
  {
    path: 'create-profile',
    component: CreateProfileComponent,
  },
];

@NgModule({
  imports: [
    CommonModule,
    SharedLazyModule,
    OtpModalModule,
    TermsAndConditionsModule,
    RouterModule.forChild(GetStartedRoutes),
    StoreModule.forFeature(
      fromGetStarted.GET_STARTED_FEATURE_KEY,
      fromGetStarted.reducer
    ),
  ],
  declarations: [
    GetStartedComponent,
    SelectIndustryComponent,
    CreateProfileComponent,
    SelectBusinessStructureComponent,
  ],
  providers:[GetStartedFacade]
})
export class GetStartedModule {}
