import { Component, OnInit, ViewChild, TemplateRef, Inject, OnDestroy } from '@angular/core';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { FormGroup } from '@angular/forms';
import { FormGenerateService, TaskInfoService, CommonService, addBusinessID, addAppID, addAppDetails } from '@rubicon/utils';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { fromGetStartedActions } from '../+state/get-started.actions';
import { GetStartedFacade } from '../+state/get-started.facade';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';

@Component({
  selector: 'create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.scss']
})
export class CreateProfileComponent implements OnInit, OnDestroy {
  slug: string
  profileDetailForm: FormGroup;
  profileDetailFormConfig: FormFieldInterface[] = [];
  modalRef: BsModalRef;
  modalRef2: BsModalRef;
  user_id: string = null;
  action_type: string;
  email_address: string;
  appID: string;
  businessID: string;
  userData: any = {};
  businessData: any = {};
  @ViewChild('template') template: TemplateRef<any>;
  @ViewChild('template2') template2: TemplateRef<any>;

  constructor(private formGenerateService: FormGenerateService,
    private common: CommonService,
    private modalService: BsModalService,
    private taskinfoService: TaskInfoService,
    private getStartedFacade: GetStartedFacade,
    private store: Store<any>,
    @Inject('environment') private environment
  ) { }

  ngOnInit(): void {
    this.taskinfoService.getTaskInfo({ slug: CONSTANTS.SLUG['create-profile'] }).subscribe(response => {
      if (response) {
        this.slug = response ?.task_slug;
        this.profileDetailFormConfig = response ?.form_fields;
        this.profileDetailForm = this.formGenerateService.createControl(this.profileDetailFormConfig);
        this.common.sendMasterDataToFields(this.profileDetailFormConfig, response ?.response_data);
        this.retrieveData();
        this.common.updateStepState(CONSTANTS.APP_STEP[this.slug]);
      }
    });
  }

  onSubmit(action: string): void {
    if (this.formGenerateService.validateCustomFormFields(this.profileDetailForm, action, this.profileDetailFormConfig)) {
      this.action_type = action;
      this.email_address = this.profileDetailForm.getRawValue() ?.email_address;
      const payload = { email_address: this.email_address };
      this.taskinfoService.saveTaskInfo({ slug: 'check_email' }, payload).subscribe(res => {
        if (res) {
          const profileData = this.profileDetailForm.value;
          this.getStartedFacade.dispatch(new fromGetStartedActions.SaveProfileResponse({
            profileData: {
              first_name: profileData.first_name,
              last_name: profileData.last_name,
              email_address: profileData.email_address,
              phone: Number(profileData.phone),
              how_did_you_hear_about_us: profileData.how_did_you_hear_about_us,
              have_a_loan: profileData.have_a_loan
            }
          }));
          this.openModal();
        }
      });
    }
  }

  openModal(): void {
    this.modalRef = this.modalService.show(this.template, { class: 'modal-lg TermsandCondition', backdrop: 'static' });
  };

  openModal2(): void {
    this.modalRef2 = this.modalService.show(this.template2, { class: 'modal-lg thankyouRegister', backdrop: 'static' });
  }

  closeFirstModal(): void {
    if (!this.modalRef) {
      return;
    }
    this.modalRef.hide();
    this.modalRef = null;
  }

  closeModal(): void {
    this.modalRef2.hide();
  }

  retrieveData() {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.appID = rootState ?.appID;
      this.businessID = rootState ?.businessID;
    });
    this.getStartedFacade.getStartedData$.subscribe((data) => {
      if (data) {
        this.userData = data ?.profileData;
        this.businessData.business_structure = data ?.business_structure;
        this.businessData.industry = data ?.industry;
        this.businessData.subIndustry = data ?.subIndustry;
        this.businessData.naics = data?.naics;
        this.businessData.zip_code = data ?.zip_code;
        this.businessData.state = data?.state;
        this.businessData.city = data?.city;
        this.formGenerateService.setFormValues(this.profileDetailForm, data ?.profileData);
      }
    })
  }

  agreeConditions(): void {
    const payload = {
      ...this.profileDetailForm.getRawValue(),
      header_logo_path_1: this.environment.logo1_path,
      header_logo_path_2: this.environment.logo2_path,
      mail_client_name: CONSTANTS.MAIL_TEMPLATE.project_name,
      senders_name: CONSTANTS.MAIL_TEMPLATE.senders_name,
      copyright_text: CONSTANTS.MAIL_TEMPLATE.copyright_text,
      action_type: this.action_type,
      banker_url: this.environment.banker_url,
      agreed_terms_and_conditions : true,
      action: 'CREATE_REQUEST',
      role: 'loan_officer_l1',
      ...this.businessData,
      user_name: `${this.profileDetailForm.value.first_name} ${this.profileDetailForm.value.last_name} (Customer)`,
      privacy: this.environment.privacy,
      terms: this.environment.terms,
      business_name_template: "<p></p>"
    }
    if (this.userData ?.user_id)
      payload.user_id = this.userData.user_id;
    if (this.appID)
      payload.app_id = this.appID;
    if (this.businessID)
      payload.business_id = this.businessID;
    this.taskinfoService.saveTaskInfo({ slug: CONSTANTS.SLUG['create-profile'] }, payload).subscribe(res => {
      if (res) {
        let user_id = (res ?.create_user) ? (res ?.create_user ?.data ?.data ?.id) : (res ?.update_user ?.data ?.data ?.id);
        const profileData = this.profileDetailForm.value;
        this.getStartedFacade.dispatch(new fromGetStartedActions.SaveProfileResponse({
          profileData: {
            first_name: profileData.first_name,
            last_name: profileData.last_name,
            email_address: profileData.email_address,
            phone: profileData.phone,
            user_id: user_id,
            how_did_you_hear_about_us: profileData.how_did_you_hear_about_us,
            have_a_loan: profileData.have_a_loan
          }
        }));
        this.store.dispatch(
          addAppID({ appID: res ?.create_application ?.data ?.data ?._id })
        );
        this.store.dispatch(
          addBusinessID({
            businessID: res ?.create_business ?.data ?.data ?._id,
          })
        );
        this.store.dispatch(addAppDetails({ appData: { loan_id: res ?.create_application ?.data ?.data ?.auto_id } }));
        this.closeFirstModal();
        this.openModal2();
      }
    });
  }

  ngOnDestroy() {
    this.common.updateStepState(0);
  }
}
