import {  initialState } from './get-started.reducer';
import * as GetStartedSelectors from './get-started.selectors';

// describe('GetStarted Selectors', () => {
//   const ERROR_MSG = 'No Error Available';
//   const getGetStartedId = (it) => it['id'];
//   const createGetStartedEntity = (id: string, name = '') =>
//     ({
//       id,
//       name: name || `name-${id}`,
//     } as GetStartedEntity);

//   let state;

//   beforeEach(() => {
//     state = {
//       getStarted: getStartedAdapter.setAll(
//         [
//           createGetStartedEntity('PRODUCT-AAA'),
//           createGetStartedEntity('PRODUCT-BBB'),
//           createGetStartedEntity('PRODUCT-CCC'),
//         ],
//         {
//           ...initialState,
//           selectedId: 'PRODUCT-BBB',
//           error: ERROR_MSG,
//           loaded: true,
//         }
//       ),
//     };
//   });

//   describe('GetStarted Selectors', () => {
//     it('getAllGetStarted() should return the list of GetStarted', () => {
//       const results = GetStartedSelectors.getAllGetStarted(state);
//       const selId = getGetStartedId(results[1]);

//       expect(results.length).toBe(3);
//       expect(selId).toBe('PRODUCT-BBB');
//     });

//     it('getSelected() should return the selected Entity', () => {
//       const result = GetStartedSelectors.getSelected(state);
//       const selId = getGetStartedId(result);

//       expect(selId).toBe('PRODUCT-BBB');
//     });

//     it("getGetStartedLoaded() should return the current 'loaded' status", () => {
//       const result = GetStartedSelectors.getGetStartedLoaded(state);

//       expect(result).toBe(true);
//     });

//     it("getGetStartedError() should return the current 'error' state", () => {
//       const result = GetStartedSelectors.getGetStartedError(state);

//       expect(result).toBe(ERROR_MSG);
//     });
//   });
// });
