import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { fetch } from '@nrwl/angular';

import * as GetStartedFeature from './get-started.reducer';
import * as GetStartedActions from './get-started.actions';

@Injectable()
export class GetStartedEffects {
  // init$ = createEffect(() =>
  //   this.actions$.pipe(
  //     ofType(GetStartedActions.init),
  //     fetch({
  //       run: (action) => {
  //         // Your custom service 'load' logic goes here. For now just return a success action...
  //         return GetStartedActions.loadGetStartedSuccess({ getStarted: [] });
  //       },

  //       onError: (action, error) => {
  //         console.error('Error', error);
  //         return GetStartedActions.loadGetStartedFailure({ error });
  //       },
  //     })
  //   )
  // );

  constructor(private actions$: Actions) {}
}
