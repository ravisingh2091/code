import { Action } from '@ngrx/store';

export enum getStartedActionTypes {
  zipCodeSubmitted = '[GetStarted] ZipCode Submitted',
  industrySubmitted = '[GetStarted] Industry Submitted',
  businessStructureSubmitted = '[GetStarted] Business Structure Submitted',
  clearGetStarted = '[GetStarted] Clear get-started State',
  saveProfileResponse = '[GetStarted] Save Profile Response',
}

export class ZipCodeSubmitted implements Action {
  readonly type = getStartedActionTypes.zipCodeSubmitted;
  constructor(public payload: { zip_code: number, state: string , city: string }) {}
}

export class IndustrySubmitted implements Action {
  readonly type = getStartedActionTypes.industrySubmitted;
  constructor(public payload: { industry: string; subindustry: string, naics: string }) {}
}

export class BusinessStructureSubmitted implements Action {
  readonly type = getStartedActionTypes.businessStructureSubmitted;
  constructor(public payload: { business_structure: string }) {}
}

export class ClearGetStarted implements Action {
  readonly type = getStartedActionTypes.clearGetStarted;
  constructor() {}
}

export class SaveProfileResponse implements Action {
  readonly type = getStartedActionTypes.saveProfileResponse;
  constructor(public payload: { profileData: any }) {}
}

export type getStartedActions =
  | ZipCodeSubmitted
  | IndustrySubmitted
  | BusinessStructureSubmitted
  | ClearGetStarted
  | SaveProfileResponse;

export const fromGetStartedActions = {
  ZipCodeSubmitted,
  IndustrySubmitted,
  BusinessStructureSubmitted,
  ClearGetStarted,
  SaveProfileResponse,
};
