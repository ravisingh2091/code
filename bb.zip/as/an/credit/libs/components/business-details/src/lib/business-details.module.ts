import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Route } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { AnnualGrossSalesComponent } from './annual-gross-sales/annual-gross-sales.component';
import { AboutBusinessComponent } from './about-business/about-business.component';

export const businessDetailsRoutes: Route[] = [
  {
    path: '',
    component: AnnualGrossSalesComponent,
  },
  {
    path: 'about-business',
    component: AboutBusinessComponent,
  },
];
@NgModule({
  imports: [
    CommonModule,
    SharedLazyModule,
    RouterModule.forChild(businessDetailsRoutes),
  ],
  declarations: [AnnualGrossSalesComponent, AboutBusinessComponent],
})
export class BusinessDetailsModule {}
