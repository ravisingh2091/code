import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { TaskInfoService, FormGenerateService, CommonService} from '@rubicon/utils';
import { Subscription } from 'rxjs';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';


@Component({
  selector: 'annual-gross-sales',
  templateUrl: './annual-gross-sales.component.html',
  styleUrls: ['./annual-gross-sales.component.scss'],
})
export class AnnualGrossSalesComponent implements OnInit, OnDestroy {
  grossSalesConfig: FormFieldInterface[] = [];
  grossSalesForm: FormGroup;
  slug:string = '';
  nextTask:string = '';
  previousTask: string= '';
  application_status_id: string = '';
  appId: string = '';
  banker_data:any;
  rootStateSubscription: Subscription;
  businessId: string;
  constructor(
    private taskinfoservice: TaskInfoService,
    private formGenerateService: FormGenerateService,
    private common: CommonService,
    private store: Store<any>,
    @Inject('CONSTANTS') public CONSTANTS,
    @Inject('environment' ) public environment) { }
  
  selectedOption = 'default';

  ngOnInit(): void { 
    this.store.select('app').pipe(take(1)).subscribe(data => {     
      this.businessId = data.businessID;
      if(this.environment.journeyType === 'banker-journey'){
        this.application_status_id=data?.appData?.status_id;
        this.banker_data=data?.userData;
        this.appId = data?.appID;
      }
    });
    this.taskinfoservice.getTaskInfo({
      slug: this.CONSTANTS.SLUG['gross-sales'],
      business_id: this.businessId
    }).subscribe(response => {
      this.slug = response.task_slug;
      this.common.updateStepState(this.CONSTANTS.APP_STEP[this.slug]);
      this.previousTask = response.previous_task; 
      this.grossSalesConfig = response.form_fields;    
      this.grossSalesForm = this.formGenerateService.createControl(this.grossSalesConfig);
      this.common.sendMasterDataToFields(this.grossSalesConfig, response.response_data);
      this.formGenerateService.setFormValues(this.grossSalesForm, {
        annual_revenue: response?.response_data?.get_business_data?.data.data[0].annual_revenue,
        operating_years: response?.response_data?.get_business_data?.data?.data[0].operating_years
      });
    },
    error => {
      console.log("something went wrong!");
    })
  }

  checked(event: any) {
    this.selectedOption = event.target.id;
  }

  onPrevious() {
    this.common.navigate(this.previousTask);
  }

  onSubmit(action) {
    if(this.formGenerateService.validateCustomFormFields(this.grossSalesForm,action,this.grossSalesConfig )) {
        const payload = {
          ...this.grossSalesForm.getRawValue(),
          business_id: this.businessId,
          action_type: action
        }
        this.taskinfoservice.saveTaskInfo({ slug: this.CONSTANTS.SLUG['gross-sales'] }, payload).subscribe(res => {          
          if (res && res.nextTask) {
            if(this.environment.journeyType === 'banker-journey'){
              this.nextTask = action === 'continue' ? res.nextTask.value : 'manage-loans';
              if(action === 'save' && this.application_status_id!==this.CONSTANTS?.APPLICATION_STATUS?.application_in_progress) {
                this.addActivityLog();
              }
            }else{
              this.nextTask = action === 'continue' ? res.nextTask.value : 'dashboard';
            }
            // this.nextTask = action === 'continue' ? res.nextTask.value: 'dashboard';
            this.common.navigate(this.nextTask, this.businessId);
          }
         });
      
    }  
  }
  addActivityLog(){
    const log_data = {
      role_slug:  this.banker_data?.role_slug,
      app_id: this.appId,
      backend_user_id: this.banker_data?.user_id,
      user_name: this.banker_data?.full_name,
      activity: 'application_edited'
    };
    this.common.addActivityLog(log_data);
  }

  ngOnDestroy() {
    this.common.updateStepState(0);
  }
}
