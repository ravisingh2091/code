import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnualGrossSalesComponent } from './annual-gross-sales.component';

describe('AnnualGrossSalesComponent', () => {
  let component: AnnualGrossSalesComponent;
  let fixture: ComponentFixture<AnnualGrossSalesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnnualGrossSalesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnualGrossSalesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
