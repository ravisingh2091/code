import { Component, OnInit, TemplateRef, OnDestroy, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { Store } from '@ngrx/store';
import {
  CommonService,
  FormGenerateService,
  TaskInfoService,
} from '@rubicon/utils';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Subscription } from 'rxjs';
import { filter, take, toArray, distinctUntilChanged } from 'rxjs/operators';
@Component({
  selector: 'about-business',
  templateUrl: './about-business.component.html',
  styleUrls: ['./about-business.component.scss'],
})
export class AboutBusinessComponent implements OnInit, OnDestroy {
  mmodalRef: BsModalRef | null;
  modalRef: BsModalRef;
  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();
  aboutbusinessConfig: FormFieldInterface[] = [];
  aboutbusinessForm: FormGroup;
  slug: '';
  modalTable = [];
  selectedBusinessOption: any;
  businessId: string;
  businessData: any;
  nextTask: string = '';
  previousTask: string = '';
  formData: any = null;
  userId;
  disableContinue = true;
  masterData: any;
  naics: any;
  businessIndustry:any;
  application_status_id: string = '';
  appId: string = '';
  banker_data:any;
  commonSubscription: Subscription;
  formSubscription: Subscription;
  loan_id: string;
  constructor(
    private modalService: BsModalService,
    private taskinfoservice: TaskInfoService,
    private formGenerateService: FormGenerateService,
    private common: CommonService,
    private store: Store<any>,
    @Inject('CONSTANTS') private CONSTANTS,
    @Inject('environment' ) public environment
  ) {
    this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.bsRangeValue = [this.bsValue, this.maxDate];
  }
  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(data => {      
      this.businessId = data.businessID;
      if(this.environment.journeyType === 'banker-journey'){
        this.userId = data?.appData.userData.user_id;
        this.application_status_id=data?.appData?.status_id;
        this.banker_data=data?.userData;
        this.appId = data?.appID;
        this.loan_id = data?.appData?.loan_id;
      }else{
        this.userId= data?.userData.user_id;
      }
    });
    this.taskinfoservice.getTaskInfo({
      slug: this.CONSTANTS.SLUG['about-business'],
      business_id: this.businessId
    }).subscribe(
      (response) => {
        this.slug = response.task_slug;
        this.common.updateStepState(this.CONSTANTS.APP_STEP[this.slug]);
        this.nextTask = response.response_data.nextTask.value;
        this.previousTask = response.previous_task;        
        this.aboutbusinessConfig = response.form_fields;
        this.aboutbusinessForm = this.formGenerateService.createControl(
          this.aboutbusinessConfig
          );
          this.common.sendMasterDataToFields(
            this.aboutbusinessConfig,
            response.response_data
            );
            this.businessData = response?.response_data?.get_business_data?.data?.data[0];
            this.businessData.lexis_nexis = (this.businessData&&this.businessData.lexis_nexis) || false;   
            this.formGenerateService.setFormValues(this.aboutbusinessForm, this.businessData);
            this.commonSubscription = this.common.masterData
            .subscribe((data: any) => {
              if(data.sub_industry){
                this.masterData = data.sub_industry
              }
            })
            this.formSubscription = this.aboutbusinessForm.get('sub_industry').valueChanges.subscribe((val) => {
              if(val&&this.masterData){
                this.naics = this.masterData.data.filter(sub_ins=> sub_ins._id===val).pop()?.naics;
                if(this.naics){
                  this.aboutbusinessForm.patchValue({naics: this.naics})
                }
              }
            });
        if(this.businessData.industry){
          this.aboutbusinessForm.patchValue({business_industry: this.businessData.industry})
        }

        this.aboutbusinessForm.get("business_structure").valueChanges.pipe(
          distinctUntilChanged())
          .subscribe(val=> {
          this.common.sendMasterDataToFields(this.aboutbusinessConfig, response.response_data);
          })

        //for checking business structure start-up than remove validation 
        if (this.businessData.business_structure === "5c1ca192eb72d4c894b91611") {
          this.aboutbusinessForm.get('app_biz_tax_id').clearValidators();
        } else {
          setTimeout(() => {
            let asterikElement = document.getElementsByClassName('hideShowAsterik')[0] as HTMLElement;
            asterikElement.classList.remove("hideShowAsterik");
          }, 10)
        }
      },
      (error) => {
        console.log('something went wrong!');
      }
    );
  }

  onContinue(action: string, template?: TemplateRef<any>) {
    if(this.formGenerateService.validateCustomFormFields(this.aboutbusinessForm,action,this.aboutbusinessConfig )) {
      if (action === 'continue' && !this.aboutbusinessForm.get('lexis_nexis').value) {
        this.formData = this.aboutbusinessForm.getRawValue();
        this.openModal(template);
        this.disableContinue = true;
      } else if (action === 'continue' && this.aboutbusinessForm.get('lexis_nexis').value) {
        let payload = {
          ...this.aboutbusinessForm.getRawValue(),
          business_id: this.businessId,
        }
        // phone number always null , we will not be saving it in the db
        if(payload.hasOwnProperty('phone_number')) {
          delete payload.phone_number;
        }
        if(payload?.business_industry){
          payload.industry = this.aboutbusinessForm?.value?.business_industry;
          delete payload?.business_industry
        }
        if(payload?.franchise_check === null){
          delete payload?.franchise_check
        }
        if(payload?.business_franchise_code === null){
          delete payload?.business_franchise_code
        }
        if(payload?.franchise_business_structure === null){
          delete payload?.franchise_business_structure
        }
        if(payload?.state_of_incorporation === null){
          delete payload?.state_of_incorporation
        }
        if(payload?.trade_name === null){
          delete payload?.trade_name
        }
        if(this.environment.journeyType === 'banker-journey'){
          payload['frontend_url'] = this.environment.customerJourneyUrl;
          payload['header_logo_path_1'] = this.environment.logo1_path;
          payload['header_logo_path_2'] = this.environment.logo2_path;
          payload['mail_client_name'] =  this.CONSTANTS.MAIL_TEMPLATE.project_name;
          payload['senders_name'] = this.CONSTANTS.MAIL_TEMPLATE.senders_name;
          payload['copyright_text'] = this.CONSTANTS.MAIL_TEMPLATE.copyright_text;
          payload['no_reply_mail'] = this.CONSTANTS.MAIL_TEMPLATE.no_reply_mail;
          payload['privacy'] = this.environment.privacy;
          payload['terms'] = this.environment.terms;
          payload['banker_name'] = this.banker_data?.full_name;
          payload['case_id'] = this.loan_id;
          payload['banker_phone_number'] = this.maskPhoneNumber(this.banker_data?.phone);

      }
        this.taskinfoservice.saveTaskInfo({ slug: this.CONSTANTS.SLUG['about-business'] }, payload).subscribe(res => {
          if (res?.send_temporary_password?.data.code === 200 && res.nextTask) {
            this.nextTask = res.nextTask.value;
            this.common.popToast('success', '', 'Profile Details has been successfully sent to the customer.')
            this.common.navigate(this.nextTask, this.businessId);
          } else if (res && res.nextTask) {
            this.nextTask = res.nextTask.value;
            this.common.navigate(this.nextTask, this.businessId);
          }
         });
      } else if (action === 'save') {
        const payload = {
          ...this.aboutbusinessForm.getRawValue(),
          business_id: this.businessId,
          action_type: action
        }
        if(!payload.lexis_nexis){
          delete payload.state,
          delete payload.city,
          delete payload.business_structure,
          delete payload.company_status,
          delete payload.industry,
          delete payload.business_industry,
          delete payload.naics,
          delete payload.street_name,
          delete payload.street_no,
          delete payload.sub_industry
        }
        if(payload.lexis_nexis){
          payload.industry = this.aboutbusinessForm?.value?.business_industry;
          delete payload?.business_industry
        }
        if(payload?.franchise_check === null){
          delete payload?.franchise_check
        }
        if(payload?.franchise_business_structure === null){
          delete payload?.franchise_business_structure
        }
        if(payload?.business_franchise_code === null){
          delete payload?.business_franchise_code
        }
        if(payload?.state_of_incorporation === null){
          delete payload?.state_of_incorporation
        }
        if(payload?.trade_name === null){
          delete payload?.trade_name
        }
        if(this.environment.journeyType === 'banker-journey'){
          payload['frontend_url'] = this.environment.customerJourneyUrl;
          payload['header_logo_path_1'] = this.environment.logo1_path;
          payload['header_logo_path_2'] = this.environment.logo2_path;
          payload['mail_client_name'] =  this.CONSTANTS.MAIL_TEMPLATE.project_name;
          payload['senders_name'] = this.CONSTANTS.MAIL_TEMPLATE.senders_name;
          payload['copyright_text'] = this.CONSTANTS.MAIL_TEMPLATE.copyright_text;
          payload['no_reply_mail'] = this.CONSTANTS.MAIL_TEMPLATE.no_reply_mail;
          payload['privacy'] = this.environment.privacy;
          payload['terms'] = this.environment.terms;
          payload['banker_name'] = this.banker_data?.full_name;
          payload['case_id'] = this.loan_id;
          payload['banker_phone_number'] = this.maskPhoneNumber(this.banker_data?.phone);
      }
        this.taskinfoservice.saveTaskInfo({ slug: this.CONSTANTS.SLUG['about-business'] }, payload).subscribe(res => {
          if (res?.send_temporary_password?.data.code === 200 && res.nextTask) {
            this.nextTask = res.nextTask.value;
            this.common.popToast('success', '', 'Profile Details has been successfully sent to the customer.')
            this.common.navigate(this.nextTask, this.businessId);
          }
          else if (res && res.nextTask) {
            if(this.environment.journeyType === 'banker-journey'){
              if(action === 'save' && this.application_status_id!==this.CONSTANTS?.APPLICATION_STATUS?.application_in_progress) {
                this.addActivityLog();
              }
              this.common.navigate('manage-loans');
            }else{
              this.common.navigate('dashboard');
            }
          }
         });
      }
     }  
  } 
  addActivityLog(){
    const log_data = {
      role_slug:  this.banker_data?.role_slug,
      app_id: this.appId,
      backend_user_id: this.banker_data?.user_id,
      user_name: this.banker_data?.full_name,
      activity: 'application_edited'
    };
    this.common.addActivityLog(log_data);
  }
  openModal(template: TemplateRef<any>) {
    this.taskinfoservice
      .saveTaskInfo(
        { slug: this.CONSTANTS.SLUG['about-business'] },
        {
          ...this.aboutbusinessForm.value,
        }
      )
      .subscribe((data) => {
        if (data?.widget_business_search?.errors) {
          this.modalTable = [];
        } 
        // else if(data?.widget_business_search?.errors?.code === 500){
        //   this.common.popToast('error', 'Error', 'Please try after sometime');
        // }
        else {
          this.modalTable = [...data.widget_business_search.data.data.result];
        }
        this.modalRef = this.modalService.show(template, {
          id: 1,
          class: 'modal-lg confirmBusiness',
          backdrop: 'static',
        });
      });
  }

  selectedBusiness(event) {
    this.selectedBusinessOption = event;
    this.disableContinue = false;
  } 

   closeModal(modalId?: number) {
    var businessDetailsObject: {[key: string]: any} = {};
    businessDetailsObject['trade_name'] = this.formData.trade_name;
     setTimeout(() => {
      this.formGenerateService.setFormValues(this.aboutbusinessForm, this.businessData);
      if (
        this.selectedBusinessOption &&
        this.selectedBusinessOption.company_name_info &&
        this.selectedBusinessOption.company_name_info.company_name
      ) {
        businessDetailsObject.business_name = this.selectedBusinessOption.company_name_info.company_name;
      }
      if (this.selectedBusinessOption && this.selectedBusinessOption.is_active === '0') {
        businessDetailsObject.company_status = '5c20bf7e27105c78ad7f9280';
      } else {
        businessDetailsObject.company_status = '5c20bf7e27105c78ad7f9283';
      }
      if (
        this.selectedBusinessOption?.phone_info &&
        this.selectedBusinessOption?.phone_info?.phone10
      ) {
        businessDetailsObject.biz_phone_no = this.selectedBusinessOption.phone_info.phone10;
      }
      if (
        this.selectedBusinessOption?.address_info &&
        this.selectedBusinessOption?.address_info.address
      ) {
        if (this.selectedBusinessOption?.address_info.address.city) {
          businessDetailsObject.city = this.selectedBusinessOption.address_info.address.city;
        }
        if (this.selectedBusinessOption?.address_info.address.state) {
          businessDetailsObject.state = this.selectedBusinessOption.address_info.address.state;
        }
        if (this.selectedBusinessOption?.address_info?.address?.street_number) {
          businessDetailsObject.street_no = this.selectedBusinessOption.address_info.address.street_number;
        }
        if (this.selectedBusinessOption?.address_info?.address?.street_name) {
          businessDetailsObject.street_name = this.selectedBusinessOption.address_info.address.street_name;
        }
        if (this.selectedBusinessOption?.address_info?.address?.zip5) {
          businessDetailsObject.zip_code = this.selectedBusinessOption.address_info.address.zip5;
        }
      }
      if (
        this.selectedBusinessOption.tin_info &&
        this.aboutbusinessForm &&
        this.aboutbusinessForm.get('app_biz_tax_id')
      ) {
        businessDetailsObject.app_biz_tax_id = this.selectedBusinessOption.tin_info.tin;
      }

      if (this.selectedBusinessOption.address_from_date) {
        let date = this.selectedBusinessOption.address_from_date;
        if(date && date.year && date.month && date.day){
        businessDetailsObject.business_incorporation_date = new Date(
          parseInt(date.year, 10),
          parseInt(date.month, 10) - 1,
          parseInt(date.day, 10)
        );
       }
      }
      this.aboutbusinessForm.patchValue(businessDetailsObject);
      this.aboutbusinessForm.patchValue({ lexis_nexis: true, business_industry: this.businessData.industry,   });
      this.aboutbusinessForm.patchValue({ business_industry: this.businessData.industry });
      this.aboutbusinessForm.patchValue({ sub_industry: this.businessData.sub_industry });
    }, 0);

    this.modalService.hide(modalId);
  }

  dismissModal(modalId?: number){
    let businessObject  = {
      ...this.businessData,
    }
    businessObject['trade_name'] = this.formData.trade_name;
    businessObject['business_name'] = this.formData.business_name;
    businessObject['phone_number'] = this.formData.phone_number;
    businessObject['business_incorporation_date'] = this.formData.business_incorporation_date;
    businessObject['app_biz_tax_id'] = this.formData.app_biz_tax_id;
    businessObject['biz_phone_no'] = this.formData.biz_phone_no;
    this.formGenerateService.setFormValues(this.aboutbusinessForm, businessObject);
    this.aboutbusinessForm.patchValue({ lexis_nexis: true });
    this.aboutbusinessForm.patchValue({ business_industry: this.businessData.industry });
    this.aboutbusinessForm.patchValue({ sub_industry: this.businessData.sub_industry });
    this.modalService.hide(modalId);
  }

  ngOnDestroy(){
    this.commonSubscription?.unsubscribe();
    this.formSubscription?.unsubscribe();
    this.common.updateStepState(0);
  }

  onPrevious() {
    this.common.navigate(this.previousTask);
  }

  maskPhoneNumber(num) {
    if(num && Number(num) !== NaN && Number(num) !== 0 && !isNaN(Number(num))) {
      num = num.toString();
      const phoneNumber = num.match(/(\d{3})(\d{3})(\d{4})/);
      return num.length === 10 ? `(${phoneNumber[1]}) ${phoneNumber[2]}-${phoneNumber[3]}` : '';
    }
    return '';
  }
}
