import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import {
  addAppDetails,
  CommonService,
  FormGenerateService,
  TaskInfoService,
} from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';

@Component({
  selector: 'hmda-form',
  templateUrl: './hmda.component.html',
  styleUrls: ['./hmda.component.scss'],
})
export class HMDAComponent implements OnInit {

  formConfig: FormFieldInterface[] = [];
  form: FormGroup;
  slug = CONSTANTS.SLUG['hmda'];
  app_id: any;
  backend_user_id: string;
  productName: string;
  user_id: string;
  appData: any;
  business_id: string;
  hmdaReference: any;
  username: string;
  business_name: string;
  role_slug: string;
  applicationDetails:any;
  business_Structure={
    '5c1ca192eb72d4c894b91605':'Individual',
    '5c1ca192eb72d4c894b91600':'Sole Proprietorship'
  }

  constructor(
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private formGenerate: FormGenerateService,
    private store: Store<any>
  ) {}

  

  ngOnInit() {
    
    this.store.select('app').pipe(take(1)).subscribe((rootState) => {
        this.user_id = rootState.appData.user_id;
        this.app_id = rootState.appID;
        this.appData = { ...rootState.appData };
        this.business_id = rootState.businessID;
        this.backend_user_id = rootState.userData.user_id;
        this.productName = rootState.appData?.productName;
        this.hmdaReference = rootState?.appData?.hmdaReference;
        this.username = rootState?.userData?.['full_name'];
        this.role_slug = rootState?.userData?.['role_slug'];
        this.business_name=rootState?.appData?.business_name;
        
        let params = { slug: CONSTANTS.SLUG['hmda'],app_id:this.app_id};

        if (this.hmdaReference) {
          params['refId'] = this.hmdaReference.ref_id;
        }

        this.taskInfoService.getTaskInfo({ ...params }).subscribe((response) => {
            this.formConfig = response?.form_fields;
            this.form = this.formGenerate.createControl(this.formConfig);
            this.slug = response?.task_slug;
            this.applicationDetails=response?.response_data?.app_detail?.data?.data[0];

            this.common.sendMasterDataToFields(
              this.formConfig,
              response?.response_data
            );
            
            let hmdaForm =response?.response_data?.get_hmda_data?.data?.data[0]?.form_data[0];

            if (hmdaForm) {
              this.formGenerate.setFormValues(this.form, hmdaForm);
            }
            else{
              this.setFields()
            }
          });
      });
     
  }
  calculateAge(dob)
  {
    if(dob) {
      let DOB=new Date(dob)
      let today=new Date();
      let age=today.getFullYear()-DOB.getFullYear();
      let month = today.getMonth() - DOB.getMonth();
      if (month < 0 || (month === 0 && today.getDate() < DOB.getDate())) {
          age--;
      }
      return age;
    }
    return '';
    
  }
  setFields()
  {
    let businessStructure=this.applicationDetails.business[0].business_structure
    let owners=this.applicationDetails.owners;
    let formData={};
    formData['borrower']={
        'application_type':'5e8da550fde40b2e1c31f200',
        'dwelling_isSecured':'5e8723158f2f4e3ac475fab6',
        'borrower_name':this.business_name
    }
    formData['completed_by']=this.username;
            
    if(this.business_Structure[businessStructure]){
        let primaryOwnerData=owners.find(owner=>owner.is_primary==true);
          formData['applicant']={
          'applicant_name':primaryOwnerData.first_name+(primaryOwnerData.middle_name? ' '+ primaryOwnerData.middle_name+' ':' ')+ primaryOwnerData.last_name,
          'age':this.calculateAge(primaryOwnerData.dob)

        }
        let secondaryOwners=owners.filter(owner=>owner.is_secondary==true);
        
        if(secondaryOwners.length>0){
          
          let secOwnerMax=secondaryOwners.reduce(function(prev, current) {
            return (prev.ownership > current.ownership) ? prev : current
          })
          
          formData['co_applicant']={
            'co_applicant_name':(secOwnerMax.first_name? secOwnerMax.first_name: '' )+ (secOwnerMax.middle_name?' '+secOwnerMax.middle_name+' ':' ')+(secOwnerMax.last_name?secOwnerMax.last_name:''),
            'co_age':this.calculateAge(secOwnerMax.dob)
            };
          
        }
        else{
          
          formData['co_applicant']={
            'co_applicant_name':'9999 - No Co-applicant',
            'co_age':'9999 - No Co-applicant',
            'co_Ethinicity':'5f08356423690e5f7dfdb548',
            'co_Race':'5f08356423690e5f7dfdb548',
            'co_sex':'5f08356423690e5f7dfdb548'
          };
          formData['co_visual_basis']={
            'co_Ethinicity_collection':'5f08356423690e5f7dfdb548',
            'co_Race_collection':'5f08356423690e5f7dfdb548',
            'co_Sex_collection':'5f08356423690e5f7dfdb548'
          }
        }

    }else{
      formData['borrower']['dwelling_isSecured']='5e8723158f2f4e3ac475fab7'
      formData['applicant']={
        'applicant_name':this.business_name,
        'age':'8888- Not Applicable-Entity',
        'Ethinicity':'5c20bf7e27105c78ad3f9493',
        'Race':'5f0835951182f11239f6b150',
        'sex':'5f0835655e3a0b54edfe9848'
        };
        formData['co_applicant']={
          'co_applicant_name':'9999 - No Co-applicant',
          'co_age':'9999 - No Co-applicant',
          'co_Ethinicity':'5f08356423690e5f7dfdb548',
          'co_Race':'5f08356423690e5f7dfdb548',
          'co_sex':'5f08356423690e5f7dfdb548'
        };
        formData['visual_basis']={
          'Ethinicity_collection':'5f08356423690e5f7dfdb547',
          'Race_collection':'5f08356423690e5f7dfdb547',
          'Sex_collection':'5f08356423690e5f7dfdb547'
        };
        formData['co_visual_basis']={
          'co_Ethinicity_collection':'5f08356423690e5f7dfdb548',
          'co_Race_collection':'5f08356423690e5f7dfdb548',
          'co_Sex_collection':'5f08356423690e5f7dfdb548'
        }
           
    }
    
    this.formGenerate.setFormValues(this.form,formData);
}


  backToUnderwriting() {
    this.common.navigate('underWriting');
  }
  onSubmit(action: any) {
    let formData = this.form.getRawValue();
    
    if (this.formGenerate.validateCustomFormFields(this.form,action,this.formConfig)) {
     
      let payload = {
        app_id: this.app_id,
        backend_user_id: this.backend_user_id,
        action_type: 'save',
        form_data: [{ ...formData, productName: this.productName }],
        type: 'hmda-form',
      };
      let params = {
        slug: CONSTANTS.SLUG['hmda'],
        app_id: this.app_id,
        user_id: this.user_id,
      };
      if (this.hmdaReference) {
        params['refId'] = this.hmdaReference.ref_id;
        params['hmda_ref_mainid'] = this.hmdaReference._id;
      }
      this.taskInfoService
        .saveTaskInfo({ slug: CONSTANTS.SLUG['hmda'], ...params }, payload)
        .subscribe((response) => {
          this.common.popToast(
            'success',
            '',
            'HMDA information submitted successfully.'
          );
          this.addActivityLog();
          this.common.navigate('underWriting');
        });
    }
    else{
      window.scroll(0,0)
    }
  }
  addActivityLog(){
    const log_data = {
      role_slug:  this.role_slug,
      app_id: this.app_id,
      backend_user_id: this.backend_user_id,
      user_name: this.username,
      activity: 'hmda_updated'
    };
    this.common.addActivityLog(log_data);
  }
  ngOnDestroy() {
    if (this.hmdaReference) {
      delete this.appData.hmdaReference;
      this.store.dispatch(addAppDetails({ appData: { ...this.appData } }));
    }
  }
}
