import { Component, OnInit, Input, Inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';

@Component({
  selector: 'hmda-pdf',
  templateUrl: './hmda-pdf.component.html',
  styleUrls: ['./hmda-pdf.component.scss']
})
export class hmdaPdfComponent implements OnInit {

  @Input() hmdapdfData: any; 
  loanId: any;
  businessName: any;
  formData:any;
  dwelling_secured: any;
 
  application_type:any;
  ethinicity:any;
  loan_purpose:any;
  collection:any;
  race:any;
  sex:any;
  subrace:any;
  subethnicity:any;
  occupancyType:any;
  
  coethinicity: any;
  co_collection: any;
  co_sex: any;
  co_race: any;
  subRace_native: any;
  logo1_path: string;
  logo2_path: string;
 
  constructor(
    private store: Store<any>,
    @Inject('environment') public environment
  ) { }

  ngOnInit(): void {
    this.logo1_path = this.environment.logo1_path;
    this.logo2_path = this.environment.logo2_path;
    if(this.hmdapdfData) {
      this.formData = this.hmdapdfData.get_hmda_data.data.data[0].form_data[0];
      this.dwelling_secured = this.hmdapdfData?.yes_no?.data?.data;
      this.application_type=this.hmdapdfData?.hmda_application_type?.data?.data;
      this.ethinicity=this.hmdapdfData?.hmda_ethinicity?.data?.data;
      this.loan_purpose=this.hmdapdfData?.hmda_loan_purpose?.data?.data;
      this.collection=this.hmdapdfData?.hmda_collection?.data?.data;
      this.race=this.hmdapdfData?.hmda_race?.data?.data;
      this.sex=this.hmdapdfData?.hmda_sex?.data?.data;
      this.subrace=this.hmdapdfData?.hmda_subrace?.data?.data;
      this.subethnicity=this.hmdapdfData?.hmda_sub_ethinicity?.data?.data;
      this.occupancyType=this.hmdapdfData?.occupancy_type?.data?.data;
      this.co_collection=this.hmdapdfData?.hmda_co_collection?.data?.data;
      this.coethinicity=this.hmdapdfData.hmda_co_ethinicity?.data?.data;
      this.co_sex=this.hmdapdfData?.hmda_co_sex?.data?.data;
      this.co_race=this.hmdapdfData?.hmda_co_race?.data?.data;
      this.subRace_native=this.hmdapdfData?.hmda_subrace_native?.data?.data;
      
      this.store.select('app').pipe(take(1)).subscribe(rootstate => {
        this.loanId = rootstate.appData.loan_id;
       this.businessName = rootstate.appData.business_name;
     })
    }
  }

}
