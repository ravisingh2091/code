import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Route, RouterModule } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { HMDAComponent } from './HMDA-component/hmda.component';
import { hmdaPdfComponent } from './HMDA-pdf/hmda-pdf.component';

export const HMDARoutes: Route[] = [
    {path:'hmda-component', component: HMDAComponent},
    
 
];
@NgModule({
  declarations: [HMDAComponent,hmdaPdfComponent],
  imports:[
  CommonModule,
  RouterModule.forChild(HMDARoutes),
  SharedLazyModule

],
  
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  exports:[HMDAComponent,hmdaPdfComponent]
})
export class HmdaModule {}
