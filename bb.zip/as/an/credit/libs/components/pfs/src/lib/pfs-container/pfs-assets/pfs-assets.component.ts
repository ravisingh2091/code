import { Component, Inject, OnInit } from '@angular/core';
import { TaskInfoService, FormGenerateService, CommonService, CurrencyFormatPipe, addAdditionalAppData } from '@rubicon/utils';
import { FormGroup, FormArray } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { take, takeUntil, debounceTime } from 'rxjs/operators';
import { ReplaySubject, merge } from 'rxjs';
import { PfsService } from '../../pfs.service';
@Component({
  selector: 'pfs-assets',
  templateUrl: './pfs-assets.component.html',
  styleUrls: ['./pfs-assets.component.scss']
})
export class PfsAssetsComponent implements OnInit {
  formConfig: FormFieldInterface[] = [];
  form: FormGroup;
  liabilitiesFormConfig: FormFieldInterface[] = [];
  liabilitiesForm: FormGroup;
  slug: string;
  previousTask: string;
  app_id: string;
  user_id: string;
  business_id: string;
  pfsOwnerID: string;
  edit:boolean = false;
  ownerID: string;
  ownerData: any = {};
  compDestroyed$ = new ReplaySubject(1);
  pfs_submitted = false;
  liabilites = ['bank_loans', 'margin_loans', 'mortgages_on_real_estate_for_investment',
    'taxes_payable', 'other_outstanding_notes', 'loans_against_life_insurance', 'net_worth'
  ];
  assets = ['cash', 'marketable_securities', 'non_marketable_securities', 'real_estate_for_personal_or_residential',
    'other_personal_assets', 'cash_value_life_insurance', 'other_investments', 'real_estate_for_investment', 'accounts_or_notes_receivable'];
  constructor(
    private taskinfoService: TaskInfoService,
    private common: CommonService,
    private store: Store<any>,
    private pfsService: PfsService,
    private formGenerateService: FormGenerateService,
    @Inject('environment') public environment,
    private currencyPipe: CurrencyFormatPipe
  ) { }

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.pfsService.showDownloadPdfOption(false);
      this.user_id = this.environment.journeyType == "customer-journey"? (rootState?.userData?.user_id ? rootState.userData.user_id : null): (rootState?.appData?.user_id ? rootState.appData.user_id : null);
      this.app_id = rootState?.appID;
      this.business_id = rootState?.businessID;
      this.pfsOwnerID = rootState?.additionalAppData?.pfsOwnerID;
      this.edit = rootState?.additionalAppData?.edit || false;
      this.taskinfoService.getTaskInfo({
        slug: CONSTANTS.SLUG['pfs_assets_and_liabilities'],
        app_id: this.app_id,
        user_id: this.user_id,
        business_id: this.business_id
      }).subscribe(response => {
        this.slug = response?.task_slug;
        this.previousTask = response?.previous_task;
        this.formConfig = response?.form_fields;
        this.form = this.formGenerateService.createControl(this.formConfig);
        const owners = response?.response_data?.get_owner_data?.data?.data || [];
        this.ownerData = this.pfsOwnerID ? owners.filter(owner=>owner._id===this.pfsOwnerID)?.pop() : owners.filter(owner=> owner.is_primary)?.pop();
        this.ownerID = this.ownerData?._id;
        const pfs_doc_id = this.ownerData?.pfs_doc_id ? this.ownerData?.pfs_doc_id : null;
        this.pfsService.getOwnerDetails({ owner_id: this.ownerID, pfs_doc_id: pfs_doc_id });
        if (this.ownerData) this.setFormData();
      });
    })
  }

  setFormData(): void {
    const schedule_data = {
      pfs_assets: {},
      pfs_liabilities: {}
    };
    if (this.ownerData.pfs_assets && this.ownerData.pfs_liabilities && (this.ownerData.pfs_submitted==='yes')) {
      schedule_data.pfs_assets = this.ownerData.pfs_assets;
      schedule_data.pfs_liabilities = this.ownerData.pfs_liabilities;
      this.form.disable();
      this.pfs_submitted= true
      this.pfsService.showDownloadPdfOption(true);
    } else {
      schedule_data.pfs_assets = {
        cash: this.ownerData?.pfs_schedule?.cash?.reduce((accumulator, currentValue) => accumulator + (currentValue.deposit_balance ? Number(currentValue.deposit_balance) : 0), 0),
        marketable_securities: this.ownerData?.pfs_schedule?.marketable_securities?.reduce((accumulator, currentValue) => accumulator + (currentValue.market_value ? Number(currentValue.market_value) : 0), 0),
        non_marketable_securities: this.ownerData?.pfs_schedule?.non_marketable_securities?.reduce((accumulator, currentValue) => accumulator + (currentValue.estimated_market_value ? Number(currentValue.estimated_market_value) : 0), 0),
        real_estate_for_personal_or_residential: this.ownerData?.pfs_schedule?.real_estate_details?.reduce((accumulator, currentValue) => {
          return accumulator + (currentValue.property_type !== '5e8723158f2f4e3ac475fac3' ? (currentValue.market_value ? Number(currentValue.market_value) : 0) : 0)
        }, 0),
        real_estate_for_investment: this.ownerData?.pfs_schedule?.real_estate_details?.reduce((accumulator, currentValue) => {
          return accumulator + (currentValue.property_type === '5e8723158f2f4e3ac475fac3' ? (currentValue.market_value ? Number(currentValue.market_value) : 0) : 0)
        }, 0),
        accounts_or_notes_receivable: this.ownerData?.pfs_schedule?.account_taxes_receivable?.reduce((accumulator, currentValue) => accumulator + (currentValue.present_balance ? Number(currentValue.present_balance) : 0), 0),
      };
      this.form.get('pfs_assets').get('pfs_assets_total').patchValue({ 'restricted_cash':  this.ownerData?.pfs_schedule?.restricted_cash?.reduce((accumulator, currentValue) => accumulator + (currentValue.restricted_amount ? Number(currentValue.restricted_amount) : 0), 0) });          

      if(this.ownerData?.pfs_assets){
        schedule_data.pfs_assets['other_investments'] = this.ownerData?.pfs_assets.other_investments ? this.ownerData.pfs_assets.other_investments : null,
        schedule_data.pfs_assets['other_personal_assets'] = this.ownerData?.pfs_assets.other_personal_assets ? this.ownerData.pfs_assets.other_personal_assets : null,
        schedule_data.pfs_assets['cash_value_life_insurance'] = this.ownerData?.pfs_assets.cash_value_life_insurance ? this.ownerData.pfs_assets.cash_value_life_insurance : null
      }
      schedule_data.pfs_liabilities = {
        bank_loans: this.ownerData?.pfs_schedule?.cash?.reduce((accumulator, currentValue) => accumulator + (currentValue.loan_balance ? Number(currentValue.loan_balance) : 0), 0),
        margin_loans: this.ownerData?.pfs_schedule?.marketable_securities?.reduce((accumulator, currentValue) => {
          return accumulator + (currentValue.investment_pledged === 'Yes' ? (currentValue.value_pledged ? Number(currentValue.value_pledged) : 0) : 0)
        }, 0),
        mortgages_on_real_estate_for_personal_residential_use: this.ownerData?.pfs_schedule?.real_estate_details?.reduce((accumulator, currentValue) => {
          return accumulator + (currentValue.property_type !== '5e8723158f2f4e3ac475fac3' ? (currentValue.present_laon_amount ? Number(currentValue.present_laon_amount) : 0) : 0)
        }, 0),
        mortgages_on_real_estate_for_investment: this.ownerData?.pfs_schedule?.real_estate_details?.reduce((accumulator, currentValue) => {
          return accumulator + (currentValue.property_type === '5e8723158f2f4e3ac475fac3' ? (currentValue.present_laon_amount ? Number(currentValue.present_laon_amount) : 0) : 0)
        }, 0),
        taxes_payable: this.ownerData?.pfs_schedule?.account_taxes_payable?.reduce((accumulator, currentValue) => accumulator + (currentValue.present_balance ? Number(currentValue.present_balance) : 0), 0),
      };
      this.form.get('pfs_liabilities').get('pfs_liabilities_total').patchValue({ 'contingent_liabilities': this.ownerData?.pfs_schedule?.contingent_liabilities?.reduce((accumulator, currentValue) => accumulator + (currentValue.contingent_amount ? Number(currentValue.contingent_amount) : 0), 0)
      });          

      if (this.ownerData?.pfs_liabilities) {
        schedule_data.pfs_liabilities['loans_against_life_insurance'] = this.ownerData.pfs_liabilities.loans_against_life_insurance ? this.ownerData.pfs_liabilities.loans_against_life_insurance : null,
        schedule_data.pfs_liabilities['other_outstanding_notes'] = this.ownerData.pfs_liabilities.other_outstanding_notes ? this.ownerData.pfs_liabilities.other_outstanding_notes : null
      }
      const assets_form_array: FormArray = this.form.get('pfs_assets') as FormArray;
      const liabilities_form_array: FormArray = this.form.get('pfs_liabilities') as FormArray;
      merge(...this.getFields(this.assets, assets_form_array)).pipe(debounceTime(500), takeUntil(this.compDestroyed$)).subscribe(res => {
        if (res) {
          const assets = assets_form_array.getRawValue();
          const sum = Object.keys(assets).reduce((acc, value) => {            
            if (value !== 'total_assets' && value !== 'restricted_cash' && value !=='pfs_assets_total')
              return acc + (assets[value] ? Number(assets[value]) : 0);
            else
              return acc + 0;
          }, 0);
          this.form.get('pfs_assets').get('pfs_assets_total').patchValue({ 'total_assets': sum });          
        }
      });
      merge(...this.getFields(this.liabilites, liabilities_form_array),
        assets_form_array.get('pfs_assets_total').get('total_assets').valueChanges).pipe(debounceTime(500), takeUntil(this.compDestroyed$)).subscribe(res => {
          if (res) {
            const liabilities = liabilities_form_array.getRawValue();
            const sum = Object.keys(liabilities).reduce((acc, value) => {
              if (value !== 'total_liabilities' && value !== 'net_worth' && value !== 'total_liabilities_and_net_worth' && value !== 'contingent_liabilities' && value!=='pfs_liabilities_total')
                return acc + (liabilities[value] ? Number(liabilities[value]) : 0);
              else
                return acc + 0;
            }, 0);
            const net_worth = (assets_form_array.get('pfs_assets_total').get('total_assets').value ? Number(assets_form_array.get('pfs_assets_total').get('total_assets').value) : 0) - (sum ? Number(sum) : 0);
            this.form.get('pfs_liabilities').get('pfs_liabilities_total').patchValue({
              'total_liabilities': sum,
              'net_worth':'$ ' + this.currencyPipe.transform(net_worth, 0, ''),
              'total_liabilities_and_net_worth': sum + net_worth
            });
          }
        });
    }
    this.formGenerateService.setFormValues(this.form, schedule_data);
  }

  getFields(fields, form_array) {
    const obj = []
    fields.forEach(res => {
      if (form_array.get(res)){
        obj.push(form_array.get(res).valueChanges)
      }        
    })
    return obj;
  }

  onSubmit(action): void {
    if (this.formGenerateService.validateCustomFormFields(this.form, action, this.formConfig)) {
      const payload = {
        app_id: this.app_id,
        action_type: action,
        owner_id: this.ownerID,
        user_id: this.user_id,
        ...this.form.getRawValue()
      }
      let params = { slug: CONSTANTS.SLUG['pfs_assets_and_liabilities'], skip_error: true};
      if(this.pfsOwnerID){
        params['process_pfs'] = true;
      }
      if (action === 'continue') {
        payload['pfs_submitted'] = 'yes';
        params['status_id'] = '5c20bf7e27105c78ad7f9281';
      }
      this.taskinfoService.saveTaskInfo(params, payload).subscribe(response => {
        if (action === 'continue') {
          if(!this.pfsOwnerID&&response.update_app_status_by_query_data&&response.update_app_status_by_query_data.status===200){
            this.pfsService.showDownloadPdfOption(true);
            this.pfs_submitted=true;
            this.form.disable();
            this.common.popToast('success', 'Application Submitted', 'Your application has been submitted successfully.');
          } else if(this.pfsOwnerID&&response.update_owner&&response.update_owner.status===200){
            this.pfsService.showDownloadPdfOption(true);
            this.pfs_submitted=true;
            this.edit = false;
            this.store.dispatch(addAdditionalAppData({ additionalAppData: { pfsOwnerID: this.pfsOwnerID, edit: false, full_name: `${this.ownerData.first_name}${this.ownerData.middle_name ? ' '+ this.ownerData.middle_name+' ':' '}${this.ownerData.last_name}` }}))
            this.form.disable();
            this.common.popToast('success', 'PFS Submitted', 'PFS data submitted successfully.');
          } else{
            if(this.pfsOwnerID){
              this.common.popToast('error', '', 'Failed to submit PFS data.');
            } else {
              this.common.popToast('error', '', 'Failed to submit application.');
            }
          }
        } else if(action === 'save') {
          this.common.navigate('dashboard');
        }
      });
    } else {
      const formGroupInvalid = document.body.querySelectorAll('input.ng-invalid, select.ng-invalid');
      formGroupInvalid[0]?(formGroupInvalid[0] as HTMLInputElement).focus():'';
    }
  }

  onPrevious() {
    this.common.navigate(this.previousTask);
  }
}
