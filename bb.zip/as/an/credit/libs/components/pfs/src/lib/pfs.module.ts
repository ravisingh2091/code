import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GetStartedPfsComponent } from './get-started-pfs/get-started-pfs.component';
import { Route, RouterModule } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { PfsContainerComponent } from './pfs-container/pfs-container.component';
import { PfsScheduleComponent } from './pfs-container/pfs-schedule/pfs-schedule.component';
import { PfsAssetsComponent } from './pfs-container//pfs-assets/pfs-assets.component';
import { CashComponent } from './pfs-container/pfs-schedule/cash/cash.component';
import { RestrictedCashComponent } from './pfs-container/pfs-schedule/restricted-cash/restricted-cash.component';
import { MarketableSecuritiesComponent } from './pfs-container/pfs-schedule/marketable-securities/marketable-securities.component';
import { NonMarketableSecuritiesComponent } from './pfs-container/pfs-schedule/non-marketable-securities/non-marketable-securities.component';
import { RealEstatePersonalComponent } from './pfs-container/pfs-schedule/real-estate-personal/real-estate-personal.component';
import { NotesReceivableComponent } from './pfs-container/pfs-schedule/notes-receivable/notes-receivable.component';
import { NotesPayableComponent } from './pfs-container/pfs-schedule/notes-payable/notes-payable.component';
import { ContigentLiabilitiesComponent } from './pfs-container/pfs-schedule/contigent-liabilities/contigent-liabilities.component';
import { PfsService } from './pfs.service';
import { CurrencyFormatPipe } from '@rubicon/utils';
import { PfsPdfDownloadComponent } from './pfs-pdf-download/pfs-pdf-download.component';

export const pfsRoutes: Route[] = [
  {
    path: 'pfs-form',
    component: PfsContainerComponent,
    children: [
      {
        path: 'schedules',
        component: PfsScheduleComponent,
      },
      {
        path: 'assets',
        component: PfsAssetsComponent,
      },
    ],
  },
  {
    path: 'get-started',
    component: GetStartedPfsComponent,
  },
];

@NgModule({
  imports: [
    CommonModule,
    SharedLazyModule,
    BsDatepickerModule.forRoot(),
    RouterModule.forChild(pfsRoutes),
  ],
  declarations: [
    GetStartedPfsComponent,
    PfsContainerComponent,
    PfsScheduleComponent,
    PfsAssetsComponent,
    CashComponent,
    RestrictedCashComponent,
    MarketableSecuritiesComponent,
    NonMarketableSecuritiesComponent,
    RealEstatePersonalComponent,
    NotesReceivableComponent,
    NotesPayableComponent,
    ContigentLiabilitiesComponent,
    PfsPdfDownloadComponent,
  ],
  providers: [PfsService, CurrencyFormatPipe],
  exports: [
    GetStartedPfsComponent,
    PfsContainerComponent,
    PfsScheduleComponent,
    PfsAssetsComponent,
    CashComponent,
    RestrictedCashComponent,
    MarketableSecuritiesComponent,
    NonMarketableSecuritiesComponent,
    RealEstatePersonalComponent,
    NotesReceivableComponent,
    NotesPayableComponent,
    ContigentLiabilitiesComponent,
  ],
})
export class PfsModule {}
