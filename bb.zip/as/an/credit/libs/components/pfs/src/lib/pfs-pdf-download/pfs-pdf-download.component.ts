import { Component, Inject, OnInit } from '@angular/core';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { TaskInfoService } from '@rubicon/utils';
import { distinctUntilChanged, take } from 'rxjs/operators';
import { PfsService } from '../pfs.service';

@Component({
  selector: 'pfs-pdf-download',
  templateUrl: './pfs-pdf-download.component.html',
  styleUrls: ['./pfs-pdf-download.component.scss'],
})
export class PfsPdfDownloadComponent implements OnInit {
  loanID: number;
  appID: string;
  userID: string;
  ownerData: any;
  fullName: string;
  ownership = [];
  property_type = [];
  ownerDetails: any;
  pfsOwnerID: string;
  logo1_path: string;
  logo2_path: string;
  constructor(
    private store: Store<any>,
    @Inject('environment') public environment,
    private taskInfoService: TaskInfoService,
    private pfsService: PfsService,
  ) {}

  ngOnInit(): void {
    this.logo1_path = this.environment.logo1_path;
    this.logo2_path = this.environment.logo2_path;
  
    this.store
      .select('app')
      .pipe(take(1))
      .subscribe((rootState) => {
        if (rootState?.userData?.id) {
          const userData = rootState.userData;
          this.loanID = rootState?.appData?.loan_id;
          this.pfsOwnerID = rootState?.additionalAppData?.pfsOwnerID;
          // this.userData = {
          //   ...userData,
          this.fullName = rootState?.additionalAppData?.full_name ?  rootState.additionalAppData.full_name : (userData?.first_name ? userData?.first_name : '') +(userData.middle_name ?' '+ userData.middle_name+' ' : ' ') +(userData?.last_name ? userData?.last_name : '');
          // };
        }
        // else {
        //   this.userData = null;
        // }
        this.appID = rootState?.appID ? rootState.appID : null;
        this.userID = this.environment.journeyType == 'customer-journey' ? rootState?.userData?.user_id ? rootState.userData.user_id : null : rootState?.appData?.user_id ? rootState.appData.user_id : null;

        this.pfsService.ownerDetails$.subscribe((response) => {

          this.ownerDetails = response;
        });

        if (!this.ownerDetails.pfs_doc_id) {
        this.taskInfoService
          .getTaskInfo({
            slug: CONSTANTS.SLUG['pfs-schedule'],
            app_id: this.appID,
            user_id: this.userID
          })
          .subscribe((response) => {
            const owners = response?.response_data?.get_owner_data?.data?.data || [];
            this.ownerData = this.pfsOwnerID ? owners.filter(owner=>owner._id===this.pfsOwnerID)?.pop() : owners.filter(owner=> owner.is_primary)?.pop();
          });
        this.taskInfoService
          .getTaskInfo({ slug: CONSTANTS.SLUG['real_estate_details'] })
          .subscribe((response) => {
            this.ownership = [...response.response_data.ownership.data.data];
            this.property_type = [
              ...response.response_data.property_type.data.data,
            ];
          });
        }
      });
  }
  getTotal(name, item) {
    let total = 0;
    if (item) {
      item.forEach((element) => {
        if (element[name]) {
          total += Number(element[name]);
        } else {
          total += 0;
        }
      });
    }
    return total.toLocaleString();
  }
}
