import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormGroup } from '@angular/forms';
import {
  FormGenerateService,
  CommonService,
  TaskInfoService,
} from '@rubicon/utils';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { ReplaySubject, Subject, merge } from 'rxjs';
import { takeUntil, distinctUntilChanged, map } from 'rxjs/operators';

@Component({
  selector: 'real-estate-personal',
  templateUrl: './real-estate-personal.component.html',
  styleUrls: ['./real-estate-personal.component.scss'],
})
export class RealEstatePersonalComponent implements OnInit {
  slug: string = '';
  formConfig = [];
  form: FormGroup;
  masterData: any;
  compDestroyed$ = new ReplaySubject(1);
  changesUnsubscribe = new Subject();
  formArray: FormArray;
  constructor(
    private formGenerate: FormGenerateService,
    private common: CommonService,
    private taskInfoService: TaskInfoService
  ) {}
  ngOnInit(): void {}

  getData(action: string) {
    if (action === 'continue') {
      const result = this.formGenerate.validateCustomFormFields(
        this.form,
        action,
        this.formConfig
      )
        ? { ...this.form.value }
        : false;
      return result;
    } else {
      return { ...this.form.value };
    }
  }
  setData(ownerData: any) {
    this.taskInfoService
      .getTaskInfo({ slug: CONSTANTS.SLUG['real_estate_details'] })
      .subscribe((response) => {
        if (response) {
          this.slug = response.task_slug;
          this.formConfig = response.form_fields;
          this.form = this.formGenerate.createControl(this.formConfig);
          this.masterData = response.response_data;
          this.common.sendMasterDataToFields(this.formConfig, this.masterData);
          this.formArray = this.form.get('real_estate_details') as FormArray;
          this.onChange(this.formArray);
          this.formArray.valueChanges
            .pipe(takeUntil(this.compDestroyed$), distinctUntilChanged())
            .subscribe((val) => {
              this.onChange(this.formArray);
            });
          this.formGenerate.setFormValues(this.form, ownerData?.pfs_schedule);
          if (
            ownerData?.pfs_schedule?.real_estate_details &&
            ownerData?.pfs_submitted
          ) {
            this.form.disable();
          }
        }
      });
  }
  onChange(formArray) {
    this.changesUnsubscribe.next();
    merge(
      ...formArray.controls.map((control: AbstractControl, index: number) =>
        control.valueChanges.pipe(
          takeUntil(this.changesUnsubscribe),
          map((value) => ({ rowIndex: index, val: value }))
        )
      )
    ).subscribe((changes: any) => {
      if (changes?.val?.outstanding_debt?.toLowerCase() === 'yes') {
        let formArrControl = formArray.controls[changes.rowIndex];
        if (!formArrControl.controls.lender.enabled) {
          formArrControl.controls.lender.enable();
        }
        if (!formArrControl.controls.laon_amount.enabled) {
          formArrControl.controls.laon_amount.enable();
        }
        if (!formArrControl.controls.monthly_payment.enabled) {
          formArrControl.controls.monthly_payment.enable();
        }
        if (!formArrControl.controls.present_laon_amount.enabled) {
          formArrControl.controls.present_laon_amount.enable();
        }
        if (!formArrControl.controls.loan_maturity_date.enabled) {
          formArrControl.controls.loan_maturity_date.enable();
        }
      } else if (changes?.val?.outstanding_debt?.toLowerCase() === 'no') {
        let formArrControl = formArray.controls[changes.rowIndex];
        if (!formArrControl.controls.lender.disabled) {
          formArrControl.controls.lender.disable();
          formArrControl.controls.lender.reset();
        }
        if (!formArrControl.controls.laon_amount.disabled) {
          formArrControl.controls.laon_amount.disable();
          formArrControl.controls.laon_amount.reset();
        }
        if (!formArrControl.controls.monthly_payment.disabled) {
          formArrControl.controls.monthly_payment.disable();
          formArrControl.controls.monthly_payment.reset();
        }
        if (!formArrControl.controls.present_laon_amount.disabled) {
          formArrControl.controls.present_laon_amount.disable();
          formArrControl.controls.present_laon_amount.reset();
        }
        if (!formArrControl.controls.loan_maturity_date.disabled) {
          formArrControl.controls.loan_maturity_date.disable();
          formArrControl.controls.loan_maturity_date.reset();
        }
      }
    });
  }
}
