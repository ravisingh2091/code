import { Component, ViewChild , ViewChildren , QueryList , AfterViewInit, OnInit } from '@angular/core';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { CommonService } from '@rubicon/utils';
import { TabsetComponent, TabDirective } from 'ngx-bootstrap/tabs';
import { take } from 'rxjs/operators';
@Component({
  selector: 'get-started-pfs',
  templateUrl: './get-started-pfs.component.html',
  styleUrls: ['./get-started-pfs.component.scss']
})
export class GetStartedPfsComponent implements OnInit {
  // disableSwitching: boolean;
  business_id = '';
  @ViewChild('tabset') tabset: TabsetComponent;

  constructor(
    private commonService: CommonService,
    private store: Store<any>,
  ) {}
  ngAfterViewInit(){
  }
  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.business_id = rootState?.businessID;
    })
    this.commonService.updateStepState(CONSTANTS.APP_STEP['pfs-get-started']);
  }
  navigate() {
    this.commonService.navigate('pfs-schedule', this.business_id);
  }

}
