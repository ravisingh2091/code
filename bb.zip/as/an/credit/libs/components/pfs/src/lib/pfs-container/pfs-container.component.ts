import { HttpErrorResponse } from '@angular/common/http';
import {
  Component,
  ElementRef,
  Inject,
  OnInit,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { Store } from '@ngrx/store';
import { DownloadService, TaskInfoService, addAdditionalAppData } from '@rubicon/utils';
import { of, Subscription } from 'rxjs';
import { distinctUntilChanged, switchMap } from 'rxjs/operators';
import { PfsService } from '../pfs.service';
@Component({
  selector: 'pfs-container',
  templateUrl: './pfs-container.component.html',
  styleUrls: ['./pfs-container.component.scss'],
})
export class PfsContainerComponent implements OnInit {
  @ViewChildren('pdfContent') GeneratePDFComponent: QueryList<ElementRef>;
  userData: any;
  assetsEnabled: boolean = true;
  enableDownloadPdf: boolean = false;
  sub1: Subscription;
  sub2: Subscription;
  loanID: number;
  appID: string;
  userID: string;
  ownerDetails: any;
  pfs_doc_id: string;
  owner_name: string;
  constructor(
    private pfsService: PfsService,
    private store: Store<any>,
    private Download: DownloadService,
    private taskInfoService: TaskInfoService,
    @Inject('environment') public environment
  ) {}

  ngOnInit(): void {
    this.store
      .select('app')
      .pipe(distinctUntilChanged())
      .subscribe((rootState) => {
        if (rootState?.userData?.id) {
          const userData = rootState?.userData;
          this.loanID = rootState?.appData?.loan_id;
          this.owner_name = rootState?.additionalAppData?.full_name || '';
          this.appID = rootState?.appID ? rootState.appID : null;
          this.userID =
            this.environment.journeyType == 'customer-journey'
              ? rootState?.userData?.user_id
                ? rootState.userData.user_id
                : null
              : rootState?.appData?.user_id
              ? rootState.appData.user_id
              : null;
          this.userData = {
            ...userData,
            full_name:
              (userData?.first_name ? userData?.first_name : '') +
               (userData.middle_name ? ' '+userData.midddle_name+' ' : '')+
              ' ' + (userData?.last_name ? userData?.last_name : ''),
          };    
        } else {
          this.userData = null;
        }
      });
    this.sub1 = this.pfsService.data$.subscribe((response) => {
      this.assetsEnabled = response;
    });
    this.sub2 = this.pfsService.enableDownloadPdfOption$.subscribe(
      (response) => {
        this.enableDownloadPdf = response;
      }
    );
    this.pfsService.ownerDetails$.subscribe((response) => {
      this.ownerDetails = response;
    });
  }

  ngOnDestroy(): void {
    if (this.sub1) this.sub1.unsubscribe();
    if (this.sub2) this.sub2.unsubscribe();
    this.store.dispatch(addAdditionalAppData({ additionalAppData: null }));
  }

  downloadPdf() {
    let body = [];
    for (let child of this.GeneratePDFComponent.toArray()) {
      body.push({
        doc_type_id: '5ef9aad1dc5f787eccbb82ed',
        filename: this.loanID + '_PFS',
        content: child.nativeElement.innerHTML,
        owner_id: this.ownerDetails.owner_id,
        app_id: this.appID,
        user_id: this.userID,
        style: `
        body {-webkit-print-color-adjust: exact!important;}
        @media all {
          .page-break {
            display: none;
          }
        }
        
        @media print {
          .page-break {
            display: block;
            page-break-before: always;
          }
        }
        
        body {
          color: #000;
          font-family: Arial, Helvetica, sans-serif;
          font-style: normal;
          font-size: 9.4pt;
          line-height: 20px;
          margin-bottom: 0;
          margin-top: 0;
        }
        
        .clear {
          margin: 0;
          padding: 0;
          height: 0;
          clear: both;
        }
        
        div,
        p,
        li,
        ul,
        span,
        td,
        th,
        a {
          margin: 0;
          padding: 0;
        }
        
        p {
          padding-bottom: 6px;
        }
        
        .wraperPage {
          width: 100%;
          margin: 10px auto;
        }
        .pfsText {
          font-size: 24px;
          font-weight: 600;
          text-align: right;
        }
        .newPage {
          width: 100%;
          display: block;
        }
        
        .wrap {
          width: 100%;
          padding-bottom: 5px;
        }
        
        .wrap {
          width: 100%;
          display: inline-block;
          margin-bottom: 2px;
        }
        
        input[type='checkbox'] {
          margin: 0;
          padding: 2px;
        }
        
        input[type='text'] {
          margin: 0;
          padding: 1px 1%;
          width: 98%;
          border: 0;
          background: none;
        }
        
        tr,
        td,
        ul {
          padding: 0;
          margin: 0;
          line-height: 13px;
        }
        
        .lebelText {
          font-size: 12px;
          color: #333;
          text-align: left;
          font-weight: bold;
          padding-bottom: 1px;
        }
        
        .valueText {
          font-size: 12px;
          color: #333;
          text-align: left;
          font-weight: normal;
          padding-bottom: 1px;
        }
        
        .table {
          border: 1px solid #2a5135;
          width: 100%;
          margin-bottom: 0.7rem;
          color: #212529;
          border-collapse: collapse;
        }
        .GreenBgTitle {
          color: #fff;
          text-align: center;
          font-size: 20px;
          font-weight: bold;
          padding: 6px 0;
          margin-top: 20px;
          background: #2a5135;
        }
        .subTitle {
          color: #2a5135;
          text-align: left;
          font-size: 20px;
          font-weight: bold;
          padding: 10px 0;
          border-bottom: 1px solid #2a5135;
        }
        .subTitle2 {
          color: #2a5135;
          text-align: left;
          font-size: 14px;
          font-weight: bold;
          padding: 6px 0;
        }
        
        .table td,
        .table th {
          color: #2a5135;
          border-color: #2a5135;
          vertical-align: middle;
          font-size: 14px;
          padding: 10px 6px;
          font-weight: 500;
          border-bottom: 1px solid #2a5135;
          border-right: 1px solid #2a5135;
        }
        .table th {
          font-weight: bold;
        }
        .ogText td {
          border-top: 2px solid #ddd;
          padding-top: 14px;
        }
        .ogText .lebelText,
        .ogText .valueText {
          font-size: 20px;
          color: #2a5135;
        }
        .tr {
          text-align: right;
        }
        .logoText td {
          padding-bottom: 6px;
        }
        ​​​​​​​​`,
      });
    }

    if (this.ownerDetails.pfs_doc_id) {
      body[0]['pfs_doc_id'] = this.ownerDetails.pfs_doc_id;
    }
    let base64Data;
    this.pfsService
      .getPdfbase64(body[0], { slug: 'download_pfs_pdf' })
      .pipe(
        switchMap((res: any) => {
          if (this.ownerDetails.pfs_doc_id) {
            base64Data = res.download_document.data;
            return of(base64Data);
          } else {
          base64Data = res.get_base64_pdf.data.data;
          const payload = {
            ref_id: res.upload_document_pdf.data.data.doc_id,
            app_id: this.appID,
            user_id: this.userID,
            owner_id: this.ownerDetails.owner_id,
            provider: '5d53fe9fc82e7f05bca236f1',
            type: 'pfs-pdf',
            response: res.upload_document_pdf.data.data.filename,
          };
          return this.taskInfoService.saveTaskInfo(
            { slug: 'save_reference' },
            payload
          );
          }
        })
      )
      .subscribe((response) => {
        this.Download.showPdf(base64Data, this.loanID + '_PFS');
      });
  }
}
