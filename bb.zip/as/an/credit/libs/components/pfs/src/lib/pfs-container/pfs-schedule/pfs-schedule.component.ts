import {
  Component,
  OnInit,
  ViewChildren,
  QueryList,
  Inject,
} from '@angular/core';
import { TaskInfoService, CommonService } from '@rubicon/utils';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';
import { PfsService } from '../../pfs.service';

@Component({
  selector: 'pfs-schedule',
  templateUrl: './pfs-schedule.component.html',
  styleUrls: ['./pfs-schedule.component.scss'],
})
export class PfsScheduleComponent implements OnInit {
  ownerData: any;
  ownerID: string;
  appID: string;
  userID: string;
  businessID: string;
  pfsOwnerID: string;
  edit:boolean = false;
  nextTask: any;
  previousTask: string;
  constructor(
    private taskInfoService: TaskInfoService,
    private common: CommonService,
    private pfsService: PfsService,
    private store: Store<any>,
    @Inject('environment') public environment
  ) {}
  @ViewChildren(
    'accordion1,accordion2,accordion3,accordion4,accordion5,accordion6,accordion7,accordion8'
  )
  accordions: QueryList<any>;

  ngOnInit(): void {
    this.store
      .select('app')
      .pipe(take(1))
      .subscribe((rootState) => {
        if (rootState?.appID) {
          this.businessID = rootState?.businessID ? rootState.businessID : null;
          this.edit = rootState?.additionalAppData?.edit || false;
          this.pfsOwnerID = rootState?.additionalAppData?.pfsOwnerID;
          this.appID = rootState?.appID ? rootState.appID : null;
          this.userID =
            this.environment.journeyType == 'customer-journey'
              ? rootState?.userData?.user_id
                ? rootState.userData.user_id
                : null
              : rootState?.appData?.user_id
              ? rootState.appData.user_id
              : null;
          this.taskInfoService
            .getTaskInfo({
              slug: CONSTANTS.SLUG['pfs-schedule'],
              app_id: this.appID,
              user_id: this.userID
            })
            .subscribe((response) => {
              const owners = response?.response_data?.get_owner_data?.data?.data || [];
              this.ownerData = this.pfsOwnerID ? owners.filter(owner=>owner._id===this.pfsOwnerID)?.pop() : owners.filter(owner=> owner.is_primary)?.pop();
              this.ownerID = this.ownerData?._id;
              const pfs_doc_id = this.ownerData?.pfs_doc_id ? this.ownerData?.pfs_doc_id : null;
              this.pfsService.changeAssestsProperty(
                this.ownerData?.is_asset_enable
                  ? this.ownerData.is_asset_enable
                  : false
              );
              this.pfsService.showDownloadPdfOption(
                this.ownerData?.pfs_submitted
                  ? this.ownerData.pfs_submitted
                  : false
              );
              this.pfsService.getOwnerDetails({ owner_id: this.ownerID, pfs_doc_id: pfs_doc_id });
              this.previousTask = response.previous_task;
            });
        }
      });
  }

  onPrevious() {
    this.common.navigate(this.previousTask);
  }

  onSubmit(action: string) {
    const payload = {
      pfs_schedule: null,
      owner_id: this.ownerID,
      action_type: action,
      app_id: this.appID,
      user_id: this.userID,
    };
    let invalidFormStatus = false;
    this.accordions.forEach((component) => {
      if (component.getData(action) === false) {
        invalidFormStatus = true;
      }
      payload.pfs_schedule = {
        ...payload.pfs_schedule,
        ...component.getData(action),
      };
    });

    //If any of the form is invalid just return from this function
    if (invalidFormStatus) {
      return;
    }
    if (action === 'continue') {
      payload['is_asset_enable'] = true;
    }
    this.taskInfoService
      .saveTaskInfo({ slug: 'pfs-schedule' }, payload)
      .subscribe((res) => {
        if (res?.nextTask?.value) {
          if (action === 'continue')
            this.pfsService.changeAssestsProperty(true);
          this.nextTask =
            action === 'continue' ? res.nextTask.value : 'dashboard';
          this.common.navigate(this.nextTask, this.businessID);
        }
      });
  }

  setAccordionData(event, index) {
    if(event) {
       const component = this.accordions.find((item, accordionIndex)=> accordionIndex=== index );
       component.setData(this.ownerData);
    }
  }
}
