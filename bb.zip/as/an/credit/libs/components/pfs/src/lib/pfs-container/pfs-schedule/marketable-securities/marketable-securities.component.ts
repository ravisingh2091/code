import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormGroup } from '@angular/forms';
import {
  FormGenerateService,
  CommonService,
  TaskInfoService,
} from '@rubicon/utils';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { merge, ReplaySubject, Subject } from 'rxjs';
import { takeUntil, map, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'marketable-securities',
  templateUrl: './marketable-securities.component.html',
  styleUrls: ['./marketable-securities.component.scss'],
})
export class MarketableSecuritiesComponent implements OnInit {
  slug: string = '';
  formConfig = [];
  form: FormGroup;
  compDestroyed$ = new ReplaySubject(1);
  changesUnsubscribe = new Subject();
  formArray: FormArray;
  constructor(
    private formGenerate: FormGenerateService,
    private common: CommonService,
    private taskInfoService: TaskInfoService
  ) {}
  ngOnInit(): void {}

  getData(action: string) {
    if (action === 'continue') {
      const result = this.formGenerate.validateCustomFormFields(
        this.form,
        action,
        this.formConfig
      )
        ? { ...this.form.value }
        : false;
      return result;
    } else {
      return { ...this.form.value };
    }
  }

  setData(ownerData: any) {
    this.taskInfoService
      .getTaskInfo({ slug: CONSTANTS.SLUG['marketable_securities'] })
      .subscribe((response) => {
        if (response) {
          this.slug = response.task_slug;
          this.formConfig = response.form_fields;
          this.form = this.formGenerate.createControl(this.formConfig);
          this.common.sendMasterDataToFields(
            this.formConfig,
            response?.response_data
          );
          this.formArray = this.form.get('marketable_securities') as FormArray;
          this.onChange(this.formArray);
          this.formArray.valueChanges
            .pipe(takeUntil(this.compDestroyed$), distinctUntilChanged())
            .subscribe((val) => {
              this.onChange(this.formArray);
            });
          this.formGenerate.setFormValues(this.form, ownerData?.pfs_schedule);
          if (
            ownerData?.pfs_schedule?.marketable_securities &&
            ownerData?.pfs_submitted
          ) {
            this.form.disable();
          }
        }
      });
  }

  onChange(formArray) {
    this.changesUnsubscribe.next();
    merge(
      ...formArray.controls.map((control: AbstractControl, index: number) =>
        control.valueChanges.pipe(
          takeUntil(this.changesUnsubscribe),
          map((value) => ({ rowIndex: index, val: value }))
        )
      )
    ).subscribe((changes: any) => {
      if (changes?.val?.investment_pledged?.toLowerCase() === 'yes') {
        let formArrControl = formArray.controls[changes.rowIndex];
        if (!formArrControl.controls.value_pledged.enabled) {
          formArrControl.controls.value_pledged.enable();
        }
      } else if (changes?.val?.investment_pledged?.toLowerCase() === 'no') {
        let formArrControl = formArray.controls[changes.rowIndex];
        if (!formArrControl.controls.value_pledged.disabled) {
          formArrControl.controls.value_pledged.disable();
          formArrControl.controls.value_pledged.reset();
        }
      }
    });
  }
}
