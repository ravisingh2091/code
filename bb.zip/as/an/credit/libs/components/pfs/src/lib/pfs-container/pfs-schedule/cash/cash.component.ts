import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormGroup } from '@angular/forms';
import {
  FormGenerateService,
  CommonService,
  TaskInfoService,
} from '@rubicon/utils';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { merge, ReplaySubject, Subject } from 'rxjs';
import { distinctUntilChanged, map, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'cash',
  templateUrl: './cash.component.html',
  styleUrls: ['./cash.component.scss'],
})
export class CashComponent implements OnInit {
  slug: string = '';
  formConfig = [];
  form: FormGroup;
  compDestroyed$ = new ReplaySubject(1);
  changesUnsubscribe = new Subject();
  formArray: FormArray;
  constructor(
    private formGenerate: FormGenerateService,
    private common: CommonService,
    private taskInfoService: TaskInfoService
  ) {}

  ngOnInit(): void {}

  getData(action: string) {
    if (action === 'continue') {
      const result = this.formGenerate.validateCustomFormFields(
        this.form,
        action,
        this.formConfig
      )
        ? { ...this.form.value }
        : false;
      return result;
    } else {
      return { ...this.form.value };
    }
  }

  setData(ownerData: any) {
    this.taskInfoService
      .getTaskInfo({ slug: CONSTANTS.SLUG['schedule_cash'] })
      .subscribe((response) => {
        if (response) {
          this.slug = response.task_slug;
          this.formConfig = response.form_fields;
          this.form = this.formGenerate.createControl(this.formConfig);
          this.common.sendMasterDataToFields(
            this.formConfig,
            response?.response_data
          );
          this.formArray = this.form.get('cash') as FormArray;
          this.onChange(this.formArray);
          this.formArray.valueChanges
            .pipe(takeUntil(this.compDestroyed$), distinctUntilChanged())
            .subscribe((val) => {
              this.onChange(this.formArray);
            });
          this.formGenerate.setFormValues(this.form, ownerData?.pfs_schedule);
          if (ownerData?.pfs_schedule?.cash && ownerData?.pfs_submitted) {
            this.form.disable();
          }
        }
      });
  }

  onChange(formArray) {
    this.changesUnsubscribe.next();
    merge(
      ...formArray.controls.map((control: AbstractControl, index: number) =>
        control.valueChanges.pipe(
          takeUntil(this.changesUnsubscribe),
          map((value) => ({ rowIndex: index, val: value }))
        )
      )
    ).subscribe((changes: any) => {
      if (changes?.val?.collateral_cash?.toLowerCase() === 'yes') {
        let formArrControl = formArray.controls[changes.rowIndex];
        if (!formArrControl.controls.loan_balance.enabled) {
          formArrControl.controls.loan_balance.enable();
        }
      } else if (changes?.val?.collateral_cash?.toLowerCase() === 'no') {
        let formArrControl = formArray.controls[changes.rowIndex];
        if (!formArrControl.controls.loan_balance.disabled) {
          formArrControl.controls.loan_balance.disable();
          formArrControl.controls.loan_balance.reset();
        }
      }
    });
  }
}
