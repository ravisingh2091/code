import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormGenerateService, TaskInfoService } from '@rubicon/utils';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';

@Component({
  selector: 'notes-receivable',
  templateUrl: './notes-receivable.component.html',
  styleUrls: ['./notes-receivable.component.scss'],
})
export class NotesReceivableComponent implements OnInit {
  slug: string = '';
  formConfig = [];
  form: FormGroup;
  constructor(
    private formGenerate: FormGenerateService,
    private taskInfoService: TaskInfoService
  ) {}
  ngOnInit(): void {}

  getData(action: string) {
    if (action === 'continue') {
      const result = this.formGenerate.validateCustomFormFields(
        this.form,
        action,
        this.formConfig
      )
        ? { ...this.form.value }
        : false;
      return result;
    } else {
      return { ...this.form.value };
    }
  }

  setData(ownerData: any) {
    this.taskInfoService
      .getTaskInfo({ slug: CONSTANTS.SLUG['account_taxes_receivable'] })
      .subscribe((response) => {
        if (response) {
          this.slug = response.task_slug;
          this.formConfig = response.form_fields;
          this.form = this.formGenerate.createControl(this.formConfig);
          this.formGenerate.setFormValues(this.form, ownerData?.pfs_schedule);
          if (
            ownerData?.pfs_schedule?.account_taxes_receivable &&
            ownerData?.pfs_submitted
          ) {
            this.form.disable();
          }
        }
      });
  }
}
