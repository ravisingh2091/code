import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import {
  FormGenerateService,
  CommonService,
  TaskInfoService,
} from '@rubicon/utils';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';

@Component({
  selector: 'non-marketable-securities',
  templateUrl: './non-marketable-securities.component.html',
  styleUrls: ['./non-marketable-securities.component.scss'],
})
export class NonMarketableSecuritiesComponent implements OnInit {
  slug: string = '';
  formConfig = [];
  form: FormGroup;
  constructor(
    private formGenerate: FormGenerateService,
    private common: CommonService,
    private taskInfoService: TaskInfoService
  ) {}
  ngOnInit(): void {}

  getData(action: string) {
    if (action === 'continue') {
      const result = this.formGenerate.validateCustomFormFields(
        this.form,
        action,
        this.formConfig
      )
        ? { ...this.form.value }
        : false;
      return result;
    } else {
      return { ...this.form.value };
    }
  }

  setData(ownerData: any) {
    this.taskInfoService
      .getTaskInfo({ slug: CONSTANTS.SLUG['non_marketable_securities'] })
      .subscribe((response) => {
        if (response) {
          this.slug = response.task_slug;
          this.formConfig = response.form_fields;
          this.form = this.formGenerate.createControl(this.formConfig);
          this.common.sendMasterDataToFields(
            this.formConfig,
            response?.response_data
          );
          this.formGenerate.setFormValues(this.form, ownerData?.pfs_schedule);
          if (
            ownerData?.pfs_schedule?.non_marketable_securities &&
            ownerData?.pfs_submitted
          ) {
            this.form.disable();
          }
        }
      });
  }
}
