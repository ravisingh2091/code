import { Injectable } from "@angular/core";
import { TaskInfoService } from '@rubicon/utils';
import { BehaviorSubject } from "rxjs";
import { map } from 'rxjs/operators';

@Injectable()
export class PfsService {
  //for enabling tag assets & liabilities,  we are creating asstesEnable property
  private assetsEnable = new BehaviorSubject(false);
  private enableDownloadPdf = new BehaviorSubject(false);
  private ownerDetails = new BehaviorSubject({});

   
   data$ = this.assetsEnable.asObservable();
  enableDownloadPdfOption$ = this.enableDownloadPdf.asObservable();
  ownerDetails$ = this.ownerDetails.asObservable();

   constructor(
    private taskinfoService: TaskInfoService
  ) { }

   changeAssestsProperty(data: boolean) {
       this.assetsEnable.next(data);
   }

   showDownloadPdfOption(data: boolean) {
    this.enableDownloadPdf.next(data);
  }
  getOwnerDetails(data: any) {
    this.ownerDetails.next(data);
  }
  
  getPdfbase64(body: any, slug: any) {

    return this.taskinfoService.saveTaskInfo(slug, body)
      .pipe(
        map((res: any) => {
          return res;
        })
      )
  }

}