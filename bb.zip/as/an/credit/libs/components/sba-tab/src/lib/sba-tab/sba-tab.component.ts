import { Component, OnDestroy, OnInit } from '@angular/core';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { SendToSbaService } from '@credit-bench/send-to-sba';
import { Store } from '@ngrx/store';
import { TaskInfoService } from '@rubicon/utils';
import { take } from 'rxjs/operators';
import * as _ from 'lodash'; 
import { Subscription } from 'rxjs';
import { ManageLoansService } from '@credit-bench/components/manage-loans';
import { KEYS } from "@credit-bench/send-to-sba";
@Component({
  selector: 'sba-tab',
  templateUrl: './sba-tab.component.html',
  styleUrls: ['./sba-tab.component.scss']
})
export class SbaTabComponent implements OnInit, OnDestroy {
  AssignToSubscription: Subscription;
  appData: any;
  businessDetails : any;
  initiateSBA = false;
  additional_1919_flag: boolean = true;
  allOwnerEsignStatusDone: boolean = false;
  //form_1920: any;
  role_slug: string;
  app_id: string;
  user_id: string;
  state_info =  {
    current_state: '',
    workable_state: [],
    show_score_pull: false,
    show_sba_submit: false,
    show_sba_tabs: false
  }
  constructor(
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    private sendToSBAService: SendToSbaService,
    private manageLoanService: ManageLoansService
  ) {}

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.user_id = rootState?.appData?.user_id;
      this.app_id  = rootState.appID;
      this.role_slug = rootState?.userData?.role_slug;
      let slugData = {
        slug: CONSTANTS.SLUG['application_detail'],         
        app_id: this.app_id,
        user_id: this.user_id
      }
      this.taskInfoService.getTaskInfo(slugData)
      .subscribe(response => {
        this.appData = response?.response_data?.app_detail?.data?.data[0];
        this.getCurrentState();
        if(this.appData){
          this.businessDetails = this.appData?.business[0];
          let step_not_required =this.businessDetails?.step_not_required;
          if(this.appData.owners.length){
            let flag = true;
            this.appData.owners.forEach(owner=>{
              if(owner.esign_status!=='sign'){
                flag = false;
              }
            });
            this.allOwnerEsignStatusDone = flag;
          }
          //this.form_1920 = this.appData?.business_references?.find(ref=>ref.type==="form_1920");
          if(!this.businessDetails.hasOwnProperty('step_not_required')) {
            this.initiateSBA = true;
          } else {
            this.initiateSBA = step_not_required.some(step => step === 'SBA Form');
          }
        }
      })
    })

    this.AssignToSubscription = this.manageLoanService.AssignToChangeEvent().subscribe(change=>{
      if(change){
        this.state_info.show_sba_tabs = false;
        setTimeout(function(){
          this.getCurrentState();
        })
      }
    })
  }

  otherSbaForms() {
    this.initiateSBA = false;
  }

  sendToSBAAccord(data){
    this.allOwnerEsignStatusDone = data;
  }
  
  getCurrentState(){
    this.sendToSBAService.getCurrentStage(this.role_slug, this.app_id, this.user_id).subscribe(response=>{
      this.state_info.workable_state = response?.get_stages_for_role?.data?.data?.stages?.map(t=>t.type);
      this.state_info.current_state = response?.get_stage?.data?.data?.stage?.type;
      this.state_info.show_sba_submit = (this.state_info.current_state==="pre_closing")&&this.state_info.workable_state.includes(this.state_info.current_state) ? true : false;
      this.state_info.show_score_pull = ["fulfillment_services","pre_underwriting","underwriting"].includes(this.state_info.current_state)&&this.state_info.workable_state.includes(this.state_info.current_state);
      this.state_info.show_sba_tabs = this.checkTabShowEligibiltiy(this.state_info.current_state);
    })
  }

  checkTabShowEligibiltiy(stage){
    let loan_amount = this.appData?.business?.[0]?.purpose_arr?.reduce((acc,purpose)=>acc+parseFloat(purpose.amount_field),0);
    if(loan_amount){
      if(loan_amount>KEYS.ORIGINATION_SCORE_PULL_LIMIT){
        return !["loan_officer","fulfillment_services","pre_underwriting","underwriting"].includes(stage);
      } else{
        return !["loan_officer"].includes(stage);
      }
    }
    return false;
  }

  ngOnDestroy(){
    this.AssignToSubscription.unsubscribe();
  }
}
