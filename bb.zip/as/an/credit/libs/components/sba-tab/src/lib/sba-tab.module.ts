import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SbaTabComponent } from './sba-tab/sba-tab.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { Route, RouterModule } from '@angular/router';
import { Sba159Module } from '@credit-bench/sba159';
import { SbaForm601Module } from '@credit-bench/sba-form601';
import { SbaForm1050Module } from '@credit-bench/sba-form1050';
import {SbaFormLandlordModule} from '@credit-bench/sba-form-landlord';
import {Form1919TableModule} from '@credit-bench/components/form1919-table';
import {Sba1920Module} from '@credit-bench/sba1920';
import { SendToSbaModule } from '@credit-bench/send-to-sba';
export const routes: Route[] = [
  {path: '', component: SbaTabComponent},
]
@NgModule({
  declarations: [SbaTabComponent],
  imports: [
    CommonModule,
    SharedLazyModule,
    RouterModule.forChild(routes),
    Sba159Module,
    SbaForm601Module,
    SbaForm1050Module,
    SbaFormLandlordModule,
    Form1919TableModule,
    Sba1920Module,
    SendToSbaModule
  ]
})
export class SbaTabModule { }
