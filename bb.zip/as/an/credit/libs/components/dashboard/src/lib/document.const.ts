export const DOUMENT_CONFIG = {
  uniqueAccordionKey: '',
  displayDocTable: true,
  custom_loader: true,
  accordian_visible: true,
  link_bank_account: {
      key: 'bank_statements',
      btn_name: 'Link bank account',
  },
  timeZone: 'EDT',
  timeFormat: 'MM-dd-yyyy / h:mm a',
  document_count: true,
  heading_css: 'fs20 fwb m-0 ptc py-3 pt-lg-5 hideLabel',
  doc_icon_css: 'common-file d-block mr-2',
  accordion_css: {
      label_col_css: 'col-12 col-lg-8',
      label_css: 'pt-2 d-inline-block fs16 fwm',
      upload_col_css: 'col-12 col-lg-4 text-right',
  },
  provider: '5d53fe9fc82e7f05bca235f1',
  refResponseKey: 'get_manual_bank_statement_reference',
  app_id: null,
  user_id: null,
  docReferences: [],
  uploadedDocs: [],
  backendUserList: [],
  allNotes: [],
  version: 'v2',
  task: {
      url: '',
      download: {
          params: {
              slug: 'download_document',
          }
      },
      upload: {
          params: {
              slug: 'manual-upload-bank-statements',
              backend_user_id: '',
          }
      },
      rename: {
          params: { slug: 'update_file' },
          headers: {
              'x-region': 'usa',
          },
      },
      notes: {
          params: {
              slug: 'create_doc_notes',
              backend_user_id: '',
          },
          headers: {
              'x-region': 'usa',
          },
      },
      download_all: {
          params: {
              slug: 'download_all'
          }
      },
      yodlee: {
          slug: 'yodlee_mail_template',
      },
      shareAll: {
          params: {
              slug: 'share-all',
          },
          body: {
              share_all_url: '',
              email_address: '',
              subject: '',
              personal_message: '',
          },
      },
      document_type: {
          params: {
              slug: 'documents',
              bring_doc_type_only: true,
          },
          headers: {
          },
          method: 'post',
          body: {},
          response_key: 'document_type_post',
          no_records: 'No record(s) found'
      },
      delete: {
          params: {
              slug: 'delete-documents',
          },
          method: 'post',
          headers: { 'x-region': 'usa' },
          body: {
              doc_id: '',
          },
      },
      headers: { 'x-region': 'usa' },
  },

  urls: {},
  share_all: {
      subject: {
          label: 'Subject (optional)',
          id: 'subject',
      },
      personal_message: {
          label: 'Add a personal message (optional)',
          id: 'personal_message',
      },
      email: {
          label:
              'Enter the e-mail address of the person(s) whom you would like to share with. Separate each e-mail with a comma.',
          id: 'email_address',
      },
  },
  document_listing: {
      response: 'get_uploaded_docs',
  },
  document_button: {
      buttons: {
          // upload: true,
          // download: true,
          // delete: true,
          // rename: true,
          // notes: true,
          // update_status: true,
          // download_all : true,
          // share_all : true
      },
      upload: {
          visible: true,
          response: 'manual_doc_upload',
          refResponse: 'manual_bank_statement_reference',
          multiple: true,
          max_file_size: 20,
          name: 'Upload',
          submit_css: 'btn btn-primary btn-md',
          submitWrapper_css: 'text-center w-100',
          errorMessage: 'Please select a file.'
      },
      update_status: {
          visible: true,
          multiple: true,
          max_file_size: 20,
          name: 'Status',
          submit_css: 'btn btn-primary btn-md',
          submitWrapper_css: 'text-right w-100',
          errorMessage: 'Please select an option.',
          statusOptions: []
      },
      notes: {
          visible: true,
          multiple: true,
          max_file_size: 100,
          name: 'Notes',
          displayTable: true,
          submit_css: 'btn btn-primary btn-md',
          submitWrapper_css: 'col-12 text-right pt-3 mb-5',
          errorMessage: 'Field cannot be blank.'
      },
      download: {
          visible: true,
          response: 'download_document',
          column_class: 'fa downloadIcon fa-lg ml-2',
          css: {
              border: '0',
          },
      },
      delete: {
        title: '',
        confirmationPopup: true,
        text: 'Are you sure, you want to delete this file?',
        submit_css: 'btn btn-primary btn-md',
        noBtn_css: 'btn btn-default btn-md ml-3',
        submitWrapper_css: 'col-12 text-right pt-3',
          response: '',
          column_class: 'deleteIcon2 d-inline-block ml-2',
          css: { border: 'none' },
      },
      rename: {
          response: '',
          column_class: 'editIcon d-inline-block',
          css: { border: 'none' },
          submit_css: 'btn btn-primary btn-md',
          submitWrapper_css: 'text-right w-100',
          name: 'Rename file',
          errorMessage: 'Field cannot be blank.'
      },
      download_all: {
          response: ['download_document_all', 'fileData'],
          column_class: 'btn btn-secondary',
      },
      type: 'document-management',
  },
  document_filter: {
      visible: false,
      form_fields: {
          from_date: {
              css: {
              width: '68%',
              'text-align': 'center',
              'font-size': '16px',
              'box-shadow': '0 0 2px',
              'margin-left': '48%',
              },
              order: 3,
              placeholder: 'From Date',
              name: 'from_date',
              type: 'date',
          },
          to_date: {
              css: {
              width: '68%',
              'text-align': 'center',
              'font-size': '16px',
              'box-shadow': '0 0 2px',
              'margin-left': '17%',
              },
              order: 4,
              placeholder: 'To Date',
              name: 'to_date',
              type: 'date',
          },
          document_type: {
              css: {
              width: '68%',
              'text-align': 'center',
              'font-size': '16px',
              'box-shadow': '0 0 2px',
              'margin-left': '-15%',
              },
              order: 5,
              placeholder: 'Document Type',
              name: 'document_type',
              type: 'dropdown',
          },
      },
      maingrid: {
          'text-align': 'center',
          padding: '10px',
          width: '100%',
          border: '1px solid #BFBFBF',
      },
  },
};

export const CONFIG_TYPES = {
  config_0: { value: "basic", label: "" },  
  config_1: { value: "60c6559d7020ef2b54ddc61b", label: "Initial Document Collection" },
  config_2: { value: "60c6559d7020ef2b54ddc61c", label: "Credit, E Tran, Due Diligence & Pre Qualification Decision" },
  config_3: { value: "60c6559d7020ef2b54ddc61d", label: "Collection of Remaining Documents Required for Underwriting" },
  config_4: { value: "60c6559d7020ef2b54ddc61e", label: "Underwriting" },
  config_5: { value: "60c6559d7020ef2b54ddc61f", label: "Pre-Close" },
  config_6: { value: "60c6559d7020ef2b54ddc620", label: "Pre-Close Quality Assurance" },
  config_7: { value: "60c6559d7020ef2b54ddc621", label: "Closing" },
  config_8: { value: "requested", label: "Additional Documents" },
  config_9: { value: "miscellaneous", label: "Miscellaneous Documents" }
};