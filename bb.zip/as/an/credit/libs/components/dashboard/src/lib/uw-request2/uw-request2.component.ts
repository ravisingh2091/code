import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CommonService, FormGenerateService, TaskInfoService, UploadService } from '@rubicon/utils';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { forkJoin } from 'rxjs';
@Component({
  selector: 'uw-request2',
  templateUrl: './uw-request2.component.html',
  styleUrls: ['./uw-request2.component.scss']
})
export class UwRequest2Component implements OnInit {
  @Output() closeModal = new EventEmitter<string>();
  @Input() applicationData: any;
  progress = undefined;
  slug: string = '';
  uwRequestConfig = [];
  uwRequestForm: FormGroup;
  nextTask: string = '';
  app_id: string = '';
  user_id: string = '';
  modal3Open: boolean = false;
  constructor(
    private formGenerate: FormGenerateService,
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private uploadService: UploadService
  ) { } 

  ngOnInit(): void {
    this.app_id = this.applicationData.app_id;
    this.user_id = this.applicationData.user_id;
    this.taskInfoService.getTaskInfo({ slug: CONSTANTS.SLUG['reply_uw_request']}).subscribe(response => {
      this.uwRequestConfig = response.form_fields;
      this.uwRequestForm = this.formGenerate.createControl(this.uwRequestConfig);
      this.slug = response.task_slug;
      this.common.sendMasterDataToFields(this.uwRequestConfig, response.response_data);
    })
  }

  openModal3(action: string) {
    if(this.formGenerate.validateCustomFormFields(this.uwRequestForm, action, this.uwRequestConfig)) {
      this.uploadDocuments.call(this).subscribe({next:(end) => {
        this.uwRequestForm.reset();
        this.modal3Open = true;
        this.common.popToast('success', '', `Data submitted successfully.`);
      },
      error:()=>{
        console.log('error');
      }});
    }
  }

    uploadDocuments() {
      let uploadData = {
        app_id:this.app_id,user_id:this.user_id,
        comment: this.uwRequestForm.value.comment,
        no_encryption: true
      }
      this.progress = this.uploadService.uploadFile(this.uwRequestForm.value.file_data,{ slug: CONSTANTS.SLUG['reply_uw_request']},uploadData, 'upload_document', 'document_upload_reference');
      let allProgressObservables = [];
      for (let key in this.progress) {
        allProgressObservables.push(this.progress[key].progress);
        }
      return forkJoin(allProgressObservables);
    }

  hideModal() {
    if (this.modal3Open) {
      this.modal3Open = false;
    } else {
      this.closeModal.emit();
    }

  }

}
