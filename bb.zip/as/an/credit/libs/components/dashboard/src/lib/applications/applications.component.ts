import { Component, Inject, OnInit, TemplateRef, ViewChild } from '@angular/core';
import {
  CommonService,
  TaskInfoService,
  addAppID,
  addBusinessID,
  addUserDetails,
  addAppDetails,
  addAdditionalAppData,
  DownloadService,
  MasterDataPipe,
  FormGenerateService
} from '@rubicon/utils';
import * as _ from 'lodash';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';
import { ApplicationPdfComponent } from '@credit-bench/components/application-pdf';
import { getShortRole} from '../../../../../app-workflow/actions';
import { DOUMENT_CONFIG, CONFIG_TYPES } from '../document.const';
import { forkJoin } from 'rxjs';


@Component({
  selector: 'applications',
  templateUrl: './applications.component.html',
  styleUrls: ['./applications.component.scss'],
})
export class ApplicationsComponent implements OnInit {
  mmodalRef: BsModalRef | null;
  modalRef: BsModalRef;
  modalRef2: BsModalRef;
  modalRef3: BsModalRef;
  withdrawAppModalRef: BsModalRef;
  appList: any = [];
  business: any;
  user_id: string = '';
  userRecord_id: string = '';
  userData: any = {};
  data = {};
  app_master_data: [];
  configtypes: any;
  backendUsers:any[] = [];
  roles: any;
  withdrawAppForm : any;
  withdrawAppConfig : any;
  selectedappData : any;
  slug: string = ''; 
  backend_user_id = null;
  appInProg = CONSTANTS?.APPLICATION_STATUS?.application_in_progress
  appDeclined = CONSTANTS?.APPLICATION_STATUS?.application_soft_decline
  appHardDecline = CONSTANTS?.APPLICATION_STATUS?.application_hard_decline
  appHardWithdraw = CONSTANTS?.APPLICATION_STATUS?.app_hard_withdrawn
  appSoftWithdraw = CONSTANTS?.APPLICATION_STATUS?.app_soft_withdrawn
  statusMap = CONSTANTS?.STATUSMAP;
  @ViewChild('applicationPdf') applicationPdf: ApplicationPdfComponent;
  
  appAssignedToMap = {};
  bankerMap: any = {};
  subStatusMap: any = {};

  constructor(
    private modalService: BsModalService,
    private taskinfoservice: TaskInfoService,
    private commonService: CommonService,
    private store: Store<any>,
    private download: DownloadService,
    private taskInfoService: TaskInfoService,
    private masterDataPipe: MasterDataPipe,
    private formGenerate: FormGenerateService,
    @Inject("environment") private environment
  ) { }
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, {
      id: 1,
      class: 'uwRequest',
      backdrop: 'static',
    });
  }
  openModal2(template2: TemplateRef<any>) {
    this.data = {
      app_id: '6053419e3821590011f4f7f4',
      user_id: '6053419eae3349001042949f',
    };
    this.modalRef2 = this.modalService.show(template2, {
      id: 2,
      class: 'uwRequest',
      backdrop: 'static',
    });
  }
  openModal3(template3: TemplateRef<any>) {
    this.modalRef3 = this.modalService.show(template3, {
      id: 3,
      class: 'uwRequest',
      backdrop: 'static',
    });
  }

  ngOnInit(): void {
    this.store.dispatch(addAdditionalAppData({ additionalAppData: null }));
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.user_id = rootState.userData.user_id;
      this.userRecord_id = rootState.userData.record_id;
      this.userData = {
        ...rootState.userData
      }
      delete this.userData['step_not_required'];
      this.loadAppData();
      this.store.dispatch(addAppID({ appID: null }));
      this.store.dispatch(addBusinessID({ businessID: null }));
    });
  }

  loadAppData(): void {
    this.taskinfoservice.getTaskInfo({
      slug: CONSTANTS.SLUG['dashboard'],
      user_id: this.user_id
    })
      .subscribe((response) => {
        this.prepareSubStatusMap(response);
        this.appList = response.response_data.app_listing.data.data;
        this.roles = response.response_data.get_role_by_slug.data.data;
        this.prepareAssignedToMap();
        this.app_master_data = response.response_data.app_status.data.data;
        this.appList.forEach((applications) => {
          if (applications.business && applications.business[0] && applications.business[0].purpose_arr) {
            let loan_amt_details = applications.business[0].purpose_arr;
            let loan_amount: number = loan_amt_details.reduce((sum, item) => {
              return parseInt(sum) + parseInt(item.amount_field);
            }, 0);
            applications.business[0]['loan_amount'] = loan_amount;
          }
          let primary_owner = applications.owners.find(({ is_primary }) => is_primary === true)
          if ( applications.business_references && applications.business_references.length > 0)  {
            let decline_letter = applications.business_references.find(({response}) => response?.type === 'decline_letter'); 
            (decline_letter) ? applications['decline_letter'] = decline_letter : "";
          }
          if (primary_owner && applications?.owner_references.length > 0) {
            let owner_references = applications.owner_references.find((ref: any) => ref.type === "esign_sba_1919_doc" && ref.response === "sign" && ref?.owner_id === primary_owner?._id)
            if (!owner_references) {
              owner_references = applications.owner_references.find((ref: any) => ref.type === "form_1919_pdf" && ref?.owner_id === primary_owner?._id)
            }
            if (owner_references) {
              applications['sba_1919_pdf_ref'] = owner_references
            }
          }

        });

      });
  }

  prepareSubStatusMap(response) {
    const subStatuses = _.get(response, 'response_data.app_sub_status.data.data'); 
    if(subStatuses && subStatuses.length) {
      subStatuses.forEach((status) => {
          this.subStatusMap[status.id] = { value: status.value, type: status.type }
      });
    }
  }
  getLastStatus(activity) {
    if(activity?.length) {
      const index = activity.map(item=>(item.status_id !== this.appDeclined && item.status_id !== this.appSoftWithdraw)).lastIndexOf(true);
      if(index >= 0) {
        if(!this.subStatusMap[activity[index].sub_status_id]) {
          return this.statusMap[activity[index]?.status_id]? this.statusMap[activity[index]?.status_id] : this.masterDataPipe.transform(activity[index].status_id, this.app_master_data,'id','value')
        } else {
          return this.subStatusMap[activity[index]?.sub_status_id]?.value;
        }
      }
    }
  }
  viewApplication(index): void {
    let appID = this.appList[index]._id;
    let loan_id = this.appList[index].auto_id;
    let businessID = this.appList[index].business[0]._id;
    let currentState = this.appList[index].business[0].current_state;
    if (this.appList[index].business[0]?.step_not_required) {
      this.userData['step_not_required'] = this.appList[
        index
      ].business[0].step_not_required;
    }
    this.store.dispatch(addUserDetails({ userData: this.userData }));
    this.store.dispatch(addAppID({ appID }));
    this.store.dispatch(addBusinessID({ businessID }));
    this.store.dispatch(addAppDetails({ appData: { loan_id } }));
    this.commonService.navigate(currentState);
  }

  goToPFS(index, owner, edit?): void {
    const appID = this.appList[index]._id;
    const loan_id = this.appList[index].auto_id;
    const businessID = this.appList[index].business[0]._id;
    const currentState = edit ? 'pfs-schedule' : 'pfs_assets_and_liabilities';
    const pfsOwnerID = owner._id || owner.id;
    if (this.appList[index].business[0]?.step_not_required) {
      this.userData['step_not_required'] = this.appList[
        index
      ].business[0].step_not_required;
    }
    this.store.dispatch(addUserDetails({ userData: this.userData }));
    this.store.dispatch(addAppID({ appID }));
    this.store.dispatch(addBusinessID({ businessID }));
    this.store.dispatch(
      addAdditionalAppData({
        additionalAppData: {
          pfsOwnerID: pfsOwnerID,
          edit: edit ? true : false,
          full_name: `${owner.first_name}${owner.middle_name?(' '+ owner.middle_name+' '):' '}${owner.last_name}`,
        },
      })
    );
    this.store.dispatch(addAppDetails({ appData: { loan_id } }));
    this.commonService.navigate(currentState);
  }

  createApplication(): void {
    
     const incompleteApplicationExist = this.appList.find(app =>  app.status_id === CONSTANTS.APPLICATION_STATUS['application_in_progress']);
    if(!incompleteApplicationExist &&this.appList.length > 0  &&this.appList[this.appList.length-1].business) {
      const payload = {
        business_structure:this.appList[this.appList.length-1]?.business[0]?.business_structure,
        industry:this.appList[this.appList.length-1]?.business[0]?.industry,
        subIndustry: this.appList[this.appList.length-1]?.business[0]?.sub_industry,
        naics: this.appList[this.appList.length-1]?.business[0]?.naics,
        zip_code:this.appList[this.appList.length-1]?.business[0]?.zip_code,
        state: this.appList[this.appList.length-1]?.business[0]?.state,
        city: this.appList[this.appList.length-1]?.business[0]?.city,
        user_id: this.user_id,
        header_logo_path_1: this.environment.logo1_path,
        header_logo_path_2: this.environment.logo2_path,
        banker_url: this.environment.banker_url,
        action: 'CREATE_NEW_APP_REQUEST',
        role: 'loan_officer_l1',
        senders_name: CONSTANTS.MAIL_TEMPLATE.senders_name,
        copyright_text: CONSTANTS.MAIL_TEMPLATE.copyright_text,
        mail_client_name: CONSTANTS.MAIL_TEMPLATE.project_name,
        user_name: `${this.userData.first_name} ${this.userData.last_name} (Customer)`,
        privacy: this.environment.privacy,
        terms: this.environment.terms,
        business_name_template: "<p></p>"
      }
      this.taskinfoservice.saveTaskInfo({
        slug: CONSTANTS.SLUG['create_new_application']
      },payload).subscribe((response) => {
        if (response) {
          let loan_id = response?.create_application?.data?.data?.auto_id;
          let businessID = response?.create_business?.data?.data?._id;
          let appID = response?.create_application?.data?.data?._id;
          this.store.dispatch(addUserDetails({ userData: this.userData }));
          this.store.dispatch(addAppID({ appID }));
          this.store.dispatch(addBusinessID({ businessID }));
          this.store.dispatch(addAppDetails({ appData: { loan_id } }));
          this.commonService.navigate(response?.nextTask?.value, businessID);
        }       
      })
    }else {
      this.commonService.popToast("error", "", "Please complete your existing application first.");;
    }
  }

  toogleDocuments(app, index) {
    this.configtypes = {};
    if(!app.config){
      app.config = {};
    }
    if (!app?.business[0]?.product) {
      this.configtypes = CONFIG_TYPES;
      this.openStage(app, 'config_0');
    }
    app.stages_docs = [];
    app.allDocumentTyes = [];
    this.appList.forEach((app_t) => {
      app_t.showPFS = false;
      if (app._id !== app_t._id) {
        app_t.showDocuments = false;
      }
    });
    this.appList[index].showDocuments = !app.showDocuments;
    if (app.showDocuments && app?.business[0]?.product) {
      this.reqDocsStage(app);
      this.taskInfoService
        .getTaskInfo({
          slug: 'get-current-stage',
          app_id: app._id,
          user_id: app.user_id,
        })
        .subscribe((response) => {
            const stageNumber = response.response_data.get_current_stage.data.data.stage._id;
            let tempArray = ['config_8', 'config_9'];
            for (let key in CONFIG_TYPES) {
              let value = CONFIG_TYPES[key];
              tempArray.push(key);
              if (value.value === stageNumber) {
                break;
              }
            }
            if (tempArray.length > 0) {
              this.configtypes = Object.keys(CONFIG_TYPES)
                .filter(key => tempArray.includes(key)).reduce((obj, key) => {
                  obj[key] = CONFIG_TYPES[key];
                  return obj;
                }, {});
            }
        });
    }
  }

  openStage(app, item?) {
    if(!app.didDataCall){
      app.didDataCall = true;
      this.proceedToCommonWidegtData(app,item);
    } else if(app.didDataCall && !app.config[item]?.setup_done){
      this.configSetup(app, item);
    }
  }

  proceedToCommonWidegtData(app, item){
    const params = {
      slug: CONSTANTS.SLUG.document_widget_data,
      app_id: app._id,
      user_id: app.user_id,
      type: "document",
      skip_error: true,
      notes_not_required: true
    }
    this.taskInfoService.getTaskInfo(params).subscribe(res=>{
      if(res.response_data) {
        app.docReferences = res.response_data?.get_manual_bank_statement_reference?.data?.data ? res.response_data.get_manual_bank_statement_reference.data.data : [];
        app.uploadedDocs = res.response_data?.get_uploaded_docs?.data?.data ? res.response_data.get_uploaded_docs.data.data : [];
      }
      this.proceedToGetBackendUser(app, item);
    })
  }

  proceedToGetBackendUser(app, item){
    let user_ids = [];
    app.docReferences.forEach(tuple=>{
      if(tuple.backend_user_id && !user_ids.includes(tuple.backend_user_id)) 
      user_ids.push(tuple.backend_user_id)
    });
    if(user_ids.length){
      this.taskInfoService.saveTaskInfo({slug: CONSTANTS.SLUG.get_backend_users}, {user_ids}).subscribe(users=>{
        app.backendUserList = users?.get_backend_users?.data?.data ? users.get_backend_users.data.data: [];
        this.configSetup(app, item);
      })
    } else{
      this.configSetup(app, item);
    }
  }

 async configSetup(app, item, call_sync?){
      app.config[item] = _.cloneDeep(DOUMENT_CONFIG);
      app.config[item].uniqueAccordionKey = this.configtypes[item];
      app.config[item].user_id = app.user_id;
      app.config[item].app_id = app._id;
      app.config[item].lead_ref_id = app.auto_id;
      app.config[item].task.url = `${this.environment.orchUrl}v2/tasks`;
      app.config[item].docReferences = app.docReferences || [];
      app.config[item].uploadedDocs = app.uploadedDocs || [];
      app.config[item].backendUserList = app.backendUserList || [];
      app.config[item].allNotes = app.allNotes || [];
    if (item === 'config_0') {
      app.config[item].displayDocTable = false;
    }

      app.config[item].task = {
        ...app.config[item].task,
        document_type: {
          ...app.config[item].task.document_type,
          body: ['config_8', 'config_9'].includes(item) ? await this.syncDocQuerySetup(app, item) : this.docQuerySetup(app, item),
        }
      };
      app.config[item].document_button = {
        ...app.config[item].document_button,
        buttons: {
          upload: true,
          download: true,
          delete: false,
          rename: false,
          notes: false,
          update_status: false,
        }
      };
      if (!call_sync) {
        this.bringDocStructure(app, item)
   }
 }
  
  bringDocStructure(app, item){
    const doc = app.config[item].task.document_type;
    if(item==='config_8'&&!app.reqDocKeys.length){
      app.config[item].documentTypes = [];
      app.config[item].setup_done = true;
      return;
    }
    if(item==='config_9'&&!app.miscellaneousDocKeys.length){
      app.config[item].documentTypes = [];
      app.config[item].setup_done = true;
      return;
    }
    if (app.allDocumentTyes.length > 0 && item !== 'config_8' && item !== 'config_9') {
      app.config[item].documentTypes = [];
      app.allDocumentTyes.forEach((docType) => {
        if (docType.type === item) {
          app.config[item].documentTypes.push(...docType.response);
        }
      });
      app.config[item].setup_done = true;
    } else {
      if (item !== 'config_0') {
        app.config[item].documentTypes = [];
      }
      this.taskInfoService.saveTaskInfo({ ...doc.params, app_id: app._id, user_id: app.user_id }, doc.body).subscribe(res => {
        if (item === 'config_9') {
          res?.document_type_post?.data?.data?.forEach(element => {
            if (element?.parent_key) {
              delete element.parent_key;
            }
          });
        }
        if (item === 'config_0') {
            app.config[item].documentTypes = res?.document_type_post?.data?.data || [];
        } else {
          res?.document_type_post?.data?.data?.forEach(element => {
            if (element?.filter_conditions?.journey_type !== 'banker-journey' && !element?.hide_accordian) {
              app.config[item].documentTypes.push(element);
            }
          });
        }
          if (app.stages_docs.length > 0) {
            app.stages_docs = [...app.stages_docs, ...app.config[item].documentTypes];
          } else {
            app.stages_docs = [...app.config[item].documentTypes];
          }
        app.config[item].setup_done = true;
      })
    }
  }
  async syncDocQuerySetup(app, item) {
    let obj;
    switch (item) {
      case 'config_8':
        await this.reqDocsStage(app);
        obj = {
          ...app.config[item].task.document_type.body,
          key: app.reqDocKeys
        }
        break;
      case 'config_9':
        await this.miscellaneousDocsStage(app);
        obj = {
          ...app.config[item].task.document_type.body,
          key: app.miscellaneousDocKeys
        }
        break;
      default:
        obj = {};
        break;
    }
    return obj;
  }
  docQuerySetup(app, item) {
    let obj;
    switch (item) {
      case "config_0":
        obj = {
          ...app.config[item].task.document_type.body,
          and: "basic_doc",
          basic_doc: true
        }
        break;
      default:
        obj = {
          ...app.config[item].task.document_type.body,
          orIn: 'business_structure,loan_purpose',
          and: 'requested_document,journey_type',
          andIn: 'product,stage',
          nin: 'rejected_specific_business_structure',
          or: 'bypass_business_structure_and_loan_purpose,bypass_loan_purpose',
          bypass_business_structure_and_loan_purpose: 'true',
          bypass_loan_purpose: 'true',
          requested_document: 'false',
          isArray: 'loan_purpose',
          journey_type: "customer-journey",
          stage: this.configtypes[item].value,
          loan_purpose: app?.business[0].purpose_arr ? (app.business[0].purpose_arr.map(tup => tup.purpose)).join(",") : '',
          business_structure: app?.business[0]?.business_structure,
          product: this.getStageCategory(app, this.configtypes[item].value),
          rejected_specific_business_structure: app?.business[0]?.business_structure
        }
        break;
    }
    return obj;
  }
  getStageCategory(app, stage) {
    if(app?.business[0]?.stage_data) {
    let particularStage = app.business[0].stage_data.find((elem) => elem.stage === stage);
    if (particularStage) {
      return particularStage.product;
      }
    }
    return app?.business[0]?.product;
  }
  async reqDocsStage(app) {
    await this.taskInfoService
      .getTaskInfo({
        slug: CONSTANTS.SLUG.requested_documents,
        requested_document: true,
        and: 'requested_document',
        app_id: app._id,
        user_id: app.user_id,
        only_selected_docs: true
      }).toPromise()
      .then((response) => {
        app.reqDocKeys = [];
        const doc_data = response.response_data?.get_saved_requested_docs?.data?.data.doc_data
        doc_data?.forEach(doc_type => {
          app.reqDocKeys.push(doc_type.doc_type_key);
        });
        if (app.config.config_8 && app.config.config_8.setup_done) {
          app.config.config_8.task.document_type.body = { key: app.reqDocKeys };
          this.bringDocStructure(app, 'config_8');
          // if(app.config?.config_9?.setup_done){
          //   this.miscellaneousDocsStage(app);
          // }
        }
      });
  }

  async miscellaneousDocsStage(app){ 
      let obs = [];
      let configArray = [];
      for(let item of Object.keys(this.configtypes).slice(1, -2)) {
          if (!app.config[item]?.setup_done) {
            this.configSetup(app, item, true);          
            const doc = app.config[item].task.document_type;
            configArray.push(item);
            obs.push(this.taskInfoService.saveTaskInfo({ ...doc.params, app_id: app._id, user_id: app.user_id }, doc.body));
            }
    }
    // if (!app.config?.config_8?.setup_done) {
    //   this.reqDocsStage(app);
    // }
      await forkJoin(obs)
        .toPromise()
        .then((response) => { 
          app.allDocumentTyes = [];
          response?.forEach((res: any, index) => {
            app.allDocumentTyes.push({response: res?.document_type_post?.data?.data, type: configArray[index]});
          });
          
          response?.forEach((res: any) => {
            app.stages_docs.push(...res.document_type_post.data.data);
          });
          let ignored_docs = [
            ...app.stages_docs.map((doc) => doc.key),
            ...app.reqDocKeys,
          ];
          let considered_doc = [];
          app.uploadedDocs.forEach((doc) => {
            if (
              !ignored_docs.includes(doc.doc_type_key) &&
              !considered_doc.includes(doc.doc_type_key)
            ) {
              considered_doc.push(doc.doc_type_key);
            }
          });
  
          app.miscellaneousDocKeys = considered_doc;
          if (app.config.config_9 && app.config.config_9.setup_done) {
            app.config.config_9.task.document_type.body = {
              key: app.miscellaneousDocKeys,
            };
            setTimeout(() => {
              this.bringDocStructure(app, 'config_9');
            }, 0);
          }
        });
  }
  tooglePFS(app, index) {
    this.appList.forEach((app_t) => {
      app_t.showDocuments = false;
      if (app._id !== app_t._id) {
        app_t.showPFS = false;
      }
    });
    this.appList[index].showPFS = !app.showPFS;
  }

  downloadForm(data:any, downloadType: string){
    let payload: {};
    let file_name : any;
    if(data.decline_letter && downloadType === 'adverse_letter'){
       payload = {doc_id: data.decline_letter?.ref_id};
       file_name = data.decline_letter?.response?.filename;
    }
    else if(data.sba_1919_pdf_ref && downloadType === '1919_form'){
      payload = {doc_id: data.sba_1919_pdf_ref?.ref_id};
      file_name = `${data?.auto_id}__form_1919.pdf`;
    }
      this.taskinfoservice.saveTaskInfo({slug: CONSTANTS.SLUG['download_pdf']}, payload).subscribe((data) => {
        if (data?.download_document?.data)
          this.download.showPdf(data.download_document.data, file_name);
      })
  }

  downloadPdf(item){
    this.applicationPdf.downloadPdf(item);
  }

  ngOnDestroy(){
    if(this.mmodalRef){
      this.mmodalRef.hide();
    }
    if (this.modalRef) {
      this.modalRef.hide();
    }
    if (this.modalRef2) {
      this.modalRef2.hide();
    }
    if (this.modalRef3) {
      this.modalRef3.hide();
    }
  }

  prepareAssignedToMap() {
    this.appAssignedToMap = {};
    this.bankerMap = {};
    const lo_role_ids = this.roles.map((role) => {
      if(role.role_slug === 'loan_officer_l2' || role.role_slug === 'loan_officer_l1') return role.id;
      }).filter(notUndefined => notUndefined !== undefined);
    let assigned_user_ids = [];
    this.appList.forEach((item) => {
      assigned_user_ids.push(...(item.app_assignment || []).filter((assign) => assign.assigned_to !== undefined).map(assign=>assign.assigned_to));
      const allAssignment = (item.app_assignment || []).filter((assign) => {
        if(!assign.stage && assign.assigned_to !== undefined && lo_role_ids.includes(assign.role_id)) return true;
        else if(assign.assigned_to !== undefined && assign.stage === "loan_officer") return true; 
      });
      const len = allAssignment.length;
      
      // allAssignment.forEach((assignment) => {
      //   if(!this.appAssignedToMap[item._id]) {
      //     this.appAssignedToMap[item._id] = [];
      //   }
        
      //   this.appAssignedToMap[item._id].push(assignment.assigned_to);
      // });
      if(len) {
        const firstAssignTo = allAssignment[allAssignment.length - 1];
          if(!this.appAssignedToMap[item._id]) {
            this.appAssignedToMap[item._id] = firstAssignTo.assigned_to;
          }
      }
    });
    
    let values = assigned_user_ids;
    if(values?.length) {

      // const user_ids = [];
      // Object.values(this.appAssignedToMap).forEach((ids: any) => {
      //   user_ids.push(...ids);
      // });

      // const uniqueIds = new Set(user_ids);

      this.taskinfoservice.saveTaskInfo({slug: CONSTANTS.SLUG['banker-by-ids']}, {user_ids: values }).subscribe((res) => {
        const bankers = _.get(res, 'get_banker_by_ids.data.data') || [];
        bankers.forEach((bu) => {
          if(!this.bankerMap[bu.id]) {
            this.bankerMap[bu.id] = bu; 
          }
        });
      });
    }
  }

  getBankerName(appId) {
    // const bankerIds = this.appAssignedToMap[appId];

    // const bankerRoleNames = [];
    // bankerIds.forEach(id => {
    //   const banker = this.bankerMap[id];
    //   bankerRoleNames.push({
    //     role: banker.roles.role_name,
    //     name: banker.name,
    //     short_slug: getShortRole(banker.roles.role_slug) 
    //   })
    // });
    const bankerId = this.appAssignedToMap[appId];
    const banker = this.bankerMap[bankerId];
    if(!this.bankerMap[bankerId]){
      return {
        role: '',
        name: '',
        short_slug: ''
      }
    }

    return {
      role: banker.roles.role_name,
      name: banker.name,
      short_slug: getShortRole(banker.roles.role_slug) 
    };
  }

  onViewConnectBanker(index): void {
    let appID = this.appList[index]._id;
    let loan_id = this.appList[index].auto_id;
    let businessID = this.appList[index].business[0]._id;
    this.store.dispatch(addUserDetails({ userData: this.userData }));
    this.store.dispatch(addAppID({ appID }));
    this.store.dispatch(addBusinessID({ businessID }));
    let primaryOwner = this.appList[index] && this.appList[index]?.owners.find((e) => e.is_primary === true);
    let primaryOwnerData: any = {};
    if (primaryOwner) {
      primaryOwnerData.primaryOwnerPhone_no = primaryOwner.phone;
      primaryOwnerData.primarOwnerEmail_id = primaryOwner.email_address;
      primaryOwnerData.primaryOwnerName = primaryOwner.first_name +(primaryOwner.middle_name?' '+primaryOwner.middle_name+' ':' ') + primaryOwner.last_name;            
    }
    let user_assignments = this.getUserAssignments(index);
    this.store.dispatch(addAppDetails({ appData: { loan_id, app_assignment: user_assignments,...primaryOwnerData } }));
    this.commonService.navigate("connect-banker");
  }

  getUserAssignments(index){
    const allAssignment = (this.appList[index].app_assignment || []).filter((assign) => assign.assigned_to !== undefined);
    let user_assignments = [];
    if(allAssignment && allAssignment.length){
      user_assignments = allAssignment.map((assignment)=>{
        let user = this.bankerMap[assignment.assigned_to];
        if(user){
          return { 
            id: user.id,
            name: user.name,
            role: user.roles.name,
            role_slug: user.roles.role_slug,
            email_address: user.email_address,
            phone_no: user.phone_number
          }
        }
        return null;
      }).filter(user=>user); 
    }
    return user_assignments;
  }

  withdrawThisApp(template, appData?){
    if(template){
      this.selectedappData = appData;
      this.taskInfoService.getTaskInfo({slug: CONSTANTS.SLUG.withdraw_application}).subscribe(res=>{
        this.withdrawAppConfig = res.form_fields;
        this.withdrawAppForm = this.formGenerate.createControl(this.withdrawAppConfig);
        this.slug = res.task_slug;
        this.withdrawAppModalRef = this.modalService.show(template, {
          class: 'modal-lg thankyouRegister',
          backdrop: 'static'
        });
      })
    }
    else{
      if (this.formGenerate.validateCustomFormFields(this.withdrawAppForm, 'continue', this.withdrawAppConfig)) {
        let withdraw_reference: any;
        let currentStage = this.selectedappData?.app_assignment[this.selectedappData.app_assignment.length - 1]?.stage;
        const allAssignment = (this.selectedappData.app_assignment || []).filter((assign) => {
          if(assign.assigned_to !== undefined && assign.stage === "loan_officer") return true; 
        });
        const firstAssignTo = allAssignment[allAssignment.length - 1];
        let bankerData = this.bankerMap[firstAssignTo.assigned_to];
        if(this.selectedappData?.business_references?.length) {
          withdraw_reference = this.selectedappData?.business_references.find(ele=> ele?.type ==="withdraw_ref");
        }
        const payload = {
          app_id : this.selectedappData?._id,
          user_id  : this.selectedappData?.user_id,
          status_id : this.appSoftWithdraw,
          action : 'APP_SOFT_WITHDRAWN_BY_CUSTOMER',
          note : this.withdrawAppForm.get('withdraw_reason').value,
          sub_status_id : CONSTANTS.WITHDRAW_SUB_STATUS[currentStage],
          role : 'customer',
          user_name : `${this.userData.first_name} ${this.userData.last_name} (Customer)`,
          ref_id: this.appSoftWithdraw,
          type: 'withdraw_ref',
          provider : "611276affb6a3804d9b6b16a",
          response_to_be_saved: {
            rm_name : bankerData?.name,
            rm_email : bankerData?.email_address,
            customer_url : this.environment.customerJourneyUrl,
            copyright_text : this.environment.copyright_text,
            senders_name : this.environment.client_name,
            header_logo_path1 : this.environment.logo1_path,
            header_logo_path2 : this.environment.logo2_path,
            privacy : this.environment.privacy,
            terms : this.environment.terms
          } 
        }
        if(withdraw_reference?._id) {
          payload['withdraw_ref_id'] = withdraw_reference._id;
        }
        this.taskInfoService.saveTaskInfo({ slug: CONSTANTS.SLUG.withdraw_application }, payload).subscribe(res => {
          if(res?.soft_withdrawn_by_customer?.data?.status === 200){
            this.commonService.popToast('success', 'Success', "The application has been withdrawn. Please connect with the banker if you want to reinstate the loan application within 3 days.");
            this.withdrawAppModalRef.hide();
            this.loadAppData();
          }
        });
      }
    }
   
  }

  showButton(type: any,app: any){ 
    if(type === 'withdraw'){
      let stages = ['loan_officer', 'fulfillment_services']
      let inStage =  (stages.includes(app?.app_assignment[app?.app_assignment.length -1]?.stage)) 
      return (app.status_id!==this.appHardWithdraw && app.status_id!==this.appSoftWithdraw && app.status_id!==this.appInProg && inStage && app.status_id!==this.appHardDecline)
    }
    else if (type === 'decline') {
      return (app?.decline_letter && app?.status_id === this.appHardDecline)
    }
  }
}
