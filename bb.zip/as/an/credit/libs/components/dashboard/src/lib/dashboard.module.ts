import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApplicationsComponent } from './applications/applications.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { RouterModule, Route } from '@angular/router';
import { UiKitModule } from '@credit-bench/ui-kit';
import { UwRequest2Component } from './uw-request2/uw-request2.component';
import { ComponentsApplicationPdfModule } from '@credit-bench/components/application-pdf';
import { MasterDataPipe } from '@rubicon/utils';

export const businessDetailsRoutes: Route[] = [
  {
    path: '',
    component: ApplicationsComponent,
  }
]
@NgModule({
  imports: [CommonModule,
    UiKitModule,
    SharedLazyModule,
    RouterModule.forChild(businessDetailsRoutes),
    ComponentsApplicationPdfModule
  ],
  declarations: [ApplicationsComponent, UwRequest2Component],
  providers: [MasterDataPipe]
})
export class DashboardModule {}
