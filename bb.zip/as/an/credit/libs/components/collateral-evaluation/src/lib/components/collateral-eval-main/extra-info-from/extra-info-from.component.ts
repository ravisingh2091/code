import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { FormGenerateService, CommonService, TaskInfoService } from '@rubicon/utils'

@Component({
  selector: 'extra-info-from',
  templateUrl: './extra-info-from.component.html',
  styleUrls: ['./extra-info-from.component.scss']
})
export class ExtraInfoFromComponent implements OnInit, OnChanges {
  slug: string = CONSTANTS.SLUG.collateral_extra_info_form;
  form: FormGroup;
  formConfig: [];
  @Input() init_data;
  @Input() is_view_mode;

  ngOnChanges(simpleChanges: SimpleChanges){
    if(simpleChanges.init_data && simpleChanges.init_data.currentValue && this.form){
      this.formGenerate.setFormValues(this.form, this.init_data);
    }
    if(simpleChanges.is_view_mode && simpleChanges.is_view_mode.currentValue && this.form){
      this.form.disable();
    }
  }
  
  constructor(
    private formGenerate: FormGenerateService,
    private common: CommonService,
    private tasksInfoService: TaskInfoService
  ) { }

  ngOnInit(): void {
    this.tasksInfoService.getTaskInfo({slug: this.slug}).subscribe(response=>{
      this.formConfig = response.form_fields;
      this.form = this.formGenerate.createControl(this.formConfig);
      this.common.sendMasterDataToFields(this.formConfig,response?.response_data);
      if(this.init_data){
        this.formGenerate.setFormValues(this.form, this.init_data);
      }
      if(this.is_view_mode){
        this.form.disable();
      }
    })
  }

  getFormValue(){
    return {  extra_info_form: this.form.value }
  }

}
