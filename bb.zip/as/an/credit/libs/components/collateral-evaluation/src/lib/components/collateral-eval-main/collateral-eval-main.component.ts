import { Component, ElementRef, OnInit, QueryList, ViewChildren } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { CommonService, FormGenerateService, TaskInfoService } from '@rubicon/utils';
import { fromEventPattern, of, Subscription, timer } from 'rxjs';
import { delay, switchMap, take } from 'rxjs/operators';
import { CalculationService } from '../../services/calculation.service';

@Component({
  selector: 'collateral-eval-main',
  templateUrl: './collateral-eval-main.component.html',
  styleUrls: ['./collateral-eval-main.component.scss']
})
export class CollateralEvalMainComponent implements OnInit {
  @ViewChildren('real_estate_form,real_estate_valuation_form,aba_form,aba_valuation_form,extra_info') forms;
  eventListenerSubscription: Subscription;
  appId;
  userId;
  businessId;
  businessData;
  aba_form_val = {
    total_net_value: null,
    total_gross_value: null
  };
  real_estate_form_val = {
    total_net_value: null,
    total_gross_value: null,
    total_re_loans: null
  };
  aba_evaluation_form_data = null; 
  aba_form_data = null; 
  extra_info_form_data = null;
  real_estate_evaluation_form_data = null;
  real_estate_form_data = null;
  load_forms = false;
  is_view_mode = false;
  backendUserID = null;
  page_saved = false;
  ref_id;
  ref_main_id;
  collateral_data;
  master_data;
  userData:any;
  loanID='';
  businessName='';
  @ViewChildren('pdfCollateral') GenerateCollateralPDFComponent: QueryList<ElementRef>;
  uploadPdf = false;
  constructor(
    private common: CommonService,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private calculationService: CalculationService,
    private taskInfoService: TaskInfoService,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.route.fragment.subscribe(fragment => { 
      if(fragment == 'view'){
        this.is_view_mode = true;
      }
     });
    
    this.store.select('app').pipe(take(1)).
      subscribe(rootState => {
        this.appId = rootState?.appID;
        this.userId = rootState?.appData?.user_id;
        this.businessId = rootState?.businessID;
        this.businessData = rootState?.appData;
        this.loanID = rootState?.appData?.loan_id;
        this.backendUserID = rootState?.userData?.user_id;
        this.userData = rootState?.userData;
        this.businessName = rootState?.appData.business_name;
        let query = {
          slug: CONSTANTS.SLUG['collateral_evaluation_analysis'],
          app_id: this.appId,
          user_id: this.userId
        };
        if(!this.uploadPdf){
          query['skip_master_apis'] = true;
        }
        this.taskInfoService.getTaskInfo(query)
        .subscribe((res: any) => {
          if(res && res.response_data) {
            let {all_collateral_type, cities, lein_value, percentage, state, valuation_source, yes_no, collateral_appraisal_type} = res.response_data;
            this.master_data = {
              all_collateral_type: (all_collateral_type && all_collateral_type.data && all_collateral_type.data.data && all_collateral_type.data.data.length > 0) ? all_collateral_type.data.data : [],
              // aba_asset_description: (aba_asset_description && aba_asset_description.data && aba_asset_description.data.data && aba_asset_description.data.data.length> 0)?aba_asset_description.data.data:[],
              cities: (cities && cities.data && cities.data.data && cities.data.data.length > 0)?cities.data.data:[], 
              // collateral: (collateral && collateral.data && collateral.data.data && collateral.data.data.length > 0)?collateral.data.data:[], 
              lein_value: (lein_value && lein_value.data && lein_value.data.data && lein_value.data.data.length > 0)?lein_value.data.data:[],
              percentage: (percentage && percentage.data && percentage.data.data && percentage.data.data.length > 0)?percentage.data.data:[],
              state: (state && state.data && state.data.data && state.data.data.length > 0)?state.data.data:[],
              valuation_source: (valuation_source && valuation_source.data && valuation_source.data.data && valuation_source.data.data.length > 0)?valuation_source.data.data:[],
              yes_no: (yes_no && yes_no.data && yes_no.data.data && yes_no.data.data.length > 0)?yes_no.data.data:[],
              collateral_appraisal_type: (collateral_appraisal_type && collateral_appraisal_type.data && collateral_appraisal_type.data.data && collateral_appraisal_type.data.data.length > 0) ? collateral_appraisal_type.data.data : []
            }
          }

          if(res && res.response_data && res.response_data.get_collateral_evaluation && res.response_data.get_collateral_evaluation.data
             && res.response_data.get_collateral_evaluation.data.data && res.response_data.get_collateral_evaluation.data.data.id){
            let service_data = this.calculationService.serviceToFormData(res.response_data.get_collateral_evaluation.data.data);
            let {aba_evaluation_form, aba_form, extra_info_form, real_estate_evaluation_form, real_estate_form } = service_data;
            this.aba_evaluation_form_data = aba_evaluation_form;
            this.aba_form_data = aba_form;
            this.extra_info_form_data = extra_info_form;
            this.real_estate_evaluation_form_data = real_estate_evaluation_form;
            this.real_estate_form_data = real_estate_form;
            this.page_saved = true;
            this.ref_id = res.response_data.get_collateral_evaluation.data.data.id;
            this.load_forms = true;
          }

          if(res?.response_data?.get_collateral_evaluation_reference?.data?.data[0]){
            this.ref_main_id = res?.response_data?.get_collateral_evaluation_reference?.data?.data[0]._id;
          }

          if(res && res.response_data && res.response_data.get_collateral_evaluation_reference && res.response_data.get_collateral_evaluation_reference.data
            && res.response_data.get_collateral_evaluation_reference.data.data && !res.response_data.get_collateral_evaluation_reference.data.data[0]){
            this.load_forms = true;
          }
          // this.load_forms = false;

          if(!this.load_forms){
            this.common.popToast('error', 'Error', 'Failed to load forms.');
          }
          
        },()=>{
          this.common.popToast('error', 'Error', 'Failed to load forms.');
        });
      });

    this.eventListenerSubscription = this.common.eventListener.subscribe((data) => {
      if(data&&data.slug&&['aba-form','real-estate-form'].includes(data.slug) && this.forms){
        const group = data.group;
        const slug = data.slug;
        if(data.name==="gross_value"){
          const gross_value = data.value;
          const advance_rate = group.get('advance_rate').value/100;
          this.calculate(gross_value, advance_rate, group, slug);
        } else if(data.name==="advance_rate"){
          const advance_rate = data.value;;
          const gross_value = group.get('gross_value').value/100;
          this.calculate(gross_value, advance_rate, group, slug);
        } else if(['aba','real_estate'].includes(data.name)){
          this.doValuesSum(data.group.get(data.name), data.slug, true);
        }
      }
    })
  }

  calculate(gross_value, advance_rate, group, slug){
    if((gross_value||gross_value===0)&&advance_rate){
      const value = parseFloat((gross_value*advance_rate).toFixed(0));
      group.get('net_value').setValue(value,{emitEvent: false});
      this.doValuesSum(group, slug);
    } else{
      group.get('net_value').setValue(null,{emitEvent: false});
      this.doValuesSum(group, slug);
    }
  }

  valuationFormIntialization(event){
    this.doValuesSum(event.group, event.slug, true);
  }

  triggerABAEvaluation(event){
    const component = this.forms && this.forms.toArray().filter(form=> form.slug==='real-estate-form')?.pop();
    if(component && component.form){
      this.doValuesSum(component.form.get("real_estate"), component.slug, true);
    }
  }

  doValuesSum(group, slug, already_parent?){
    let gross_value = 0;
    let net_value = 0;
    let did_gross = false;
    let did_net = false;
    
    const values = already_parent ? group.value : group.parent.value;
    values.forEach(grp=>{
      if(grp.gross_value||grp.gross_value==0){
        did_gross = true;
        gross_value += +grp.gross_value; 
      }
      if(grp.net_value||grp.net_value==0){
        did_net = true;
        net_value += +grp.net_value; 
      }
    });

    if(!did_gross)
      gross_value = null;
    if(!did_net)
      net_value = null;

    if(slug==='aba-form'){
      this.aba_form_val = {
        total_net_value: (net_value||net_value===0) ? net_value : null,
        total_gross_value: (gross_value||gross_value===0) ? gross_value : null
      }
    } else{
      if(this.forms){
        this.real_estate_form_val = {
          total_net_value: (net_value||net_value===0) ? net_value : null,
          total_gross_value: (gross_value||gross_value===0) ? gross_value : null,
          total_re_loans: this.forms.toArray().filter(form=> form.slug==='real-estate-valuation-form')?.pop()?.form?.value?.total_re_loans
        }
      }
    }
  }

  onSubmit(){
    let form_valid_flag = true;
    const action = 'continue';
    let success_message = "Collateral Evaluation Analysis submitted successfully.";
    let error_message = "Failed to submit Collateral Evaluation Analysis.";
    let form_data:any = {}; 
    this.forms.toArray().forEach(component=>{
      if(component.form.invalid){
        const result = this.formGenerate.validateCustomFormFields(
          component.form,
          action,
          component.formConfig
        )
        form_valid_flag = false;
      } else{
        form_data = {...form_data, ...component.getFormValue()}
      }
    });
    if(form_valid_flag){
      let body:any = this.calculationService.formToServiceData(form_data);
      if(this.page_saved){
        if(this.ref_id){
          body["ref_id"] = this.ref_id;
        }
        if(this.ref_main_id){
          body["ref_main_id"] = this.ref_main_id;
        }
      }
      body["loan_id"] = this.loanID;
      let delay = of(1);
      if(this.uploadPdf){
        this.collateral_data = {...form_data, loanID: this.loanID, businessName: this.businessName};
        delay = timer(1000);
      }
      delay.pipe(switchMap(()=>{
        if(this.uploadPdf){
          let pdf_data = this.calculationService.getCollateralEvalHtml(this.GenerateCollateralPDFComponent, this.loanID);
          body = {...body,...pdf_data, upload_pdf: true};
        }
        return this.taskInfoService.saveTaskInfo({
          slug: CONSTANTS.SLUG['collateral_evaluation_analysis'],
          app_id: this.appId,
          user_id: this.userId,
          backend_user_id: this.backendUserID
        }, body);
      })).subscribe(response => {
        if(response && response.nextTask && response.nextTask.value != "error"){
          if(body['ref_id']){
            if(response.update_collateral_evaluation && response.update_collateral_evaluation.data
              && response.update_collateral_evaluation.data.data && response.update_collateral_evaluation.data.data.id){
                this.ref_id = response.update_collateral_evaluation.data.data.id; 
                this.page_saved = true;
                this.common.popToast('success', '', success_message);
                this.addActivityLog();
                this.common.navigate('underWriting');
            }else{
              this.common.popToast('error', 'Error', error_message);
            }
          }else{
            if(response.save_collateral_evaluation && response.save_collateral_evaluation.data
              && response.save_collateral_evaluation.data.data && response.save_collateral_evaluation.data.data.id
              && response.save_collateral_evaluation_reference && response.save_collateral_evaluation_reference.data &&
              response.save_collateral_evaluation_reference.data.data && response.save_collateral_evaluation_reference.data.data.ref_id){
                this.ref_id = response.save_collateral_evaluation.data.data.id;
                this.page_saved = true;
                this.common.popToast('success', '', success_message);
                this.addActivityLog();
                this.common.navigate('underWriting');
            }else{
              this.common.popToast('error', 'Error', error_message);
            }
          }
          if(response?.get_collateral_evaluation_reference?.data?.data[0]){
            this.ref_main_id = response.get_collateral_evaluation_reference?.data?.data[0]?._id;
          }
        }else{
          this.common.popToast('error', 'Error', error_message);
        }
      },()=>{
        this.common.popToast('error', 'Error', error_message);
      });
    } else {
      const formGroupInvalid = document.body.querySelectorAll('input.ng-invalid, ng-select.ng-invalid, textarea.ng-invalid');
      const node = formGroupInvalid[0];
      node ? (node.nodeName==="NG-SELECT") ? (node.children[0].children[0].children[1].children[0] as HTMLInputElement).focus() : (node as HTMLInputElement).focus():'';
    }
  }

  addActivityLog(){
    const log_data = {
      role_slug: this.userData.role_slug,
      app_id: this.appId,
      backend_user_id: this.backendUserID,
      user_name: this.userData.full_name,
      activity: 'cea_updated'
    };
    this.common.addActivityLog(log_data);
  }

  ngOnDestroy() {
    this.eventListenerSubscription.unsubscribe();
  }

}
