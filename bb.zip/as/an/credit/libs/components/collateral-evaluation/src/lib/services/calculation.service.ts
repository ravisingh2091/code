import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculationService {

  constructor() { }

  getEvaluationRatio({...args}){
    const { total_re_gross_value, total_re_net_value, total_re_loan, total_aba_net_value, total_loans, type } = args;
    if(type==="aba-valuation-form"){
      return {
        excess_deficit_collateral_value: this.ABAExcessDeficitCollateralValue(total_aba_net_value, total_loans),
        aba_collateral_covergage_ratio: this.ratioABACollateralCovergageRatio(total_aba_net_value, total_loans),
        combined_collateral_coverage_ratio: this.ratioCombinedCollateralCoverageRatio(total_re_net_value, total_re_loan, total_aba_net_value, total_loans)
      }
    } else if(type==="real-estate-valuation-form"){
      return {
        re_excess_deficit_collateral_value: this.realStateDeficitCollateralValue(total_re_net_value, total_re_loan),
        real_estate_loan_to_value: this.ratioRealEstateLoantovalue(total_re_gross_value, total_re_loan),
        real_estate_collateral_coverage_ratio: this.ratioRealEstateCollateralCoverageRatio(total_re_net_value, total_re_loan)
      }
    } else{
      return null;
    }
  }

  realStateDeficitCollateralValue(total_re_net_value, total_re_loan){
    /**
      *Formula 
      * RE Excess (Deficit) Collateral Value = Total Real State Net Value - Total RE Loans
    */
    if(total_re_net_value||total_re_net_value===0){
      if(total_re_loan||total_re_loan==0){
        return total_re_net_value - total_re_loan; 
      }
      return total_re_net_value;
    }
    return null;
  }

  ratioRealEstateLoantovalue(total_re_gross_value, total_re_loan){
    /**  
     * Formula
     * ABA Collateral Coverage Ratio = Total RE Loans / Total Real State Gross value
    */
    if(total_re_gross_value&&(total_re_loan||total_re_loan==0)){
      return (total_re_loan/total_re_gross_value).toFixed(2);
    }
    return null;
  }

  ratioRealEstateCollateralCoverageRatio(total_re_net_value, total_re_loan){
    /**
      * Formula
      * ABA Collateral Coverage Ratio = Total Real State Net value / Total RE Loans
    */
    if((total_re_net_value||total_re_net_value===0)&&+total_re_loan){
      return (total_re_net_value/total_re_loan).toFixed(2);
    }
    return null;
  }
  
  ABAExcessDeficitCollateralValue(total_aba_net_value, total_loans){
    /**
      *Formula 
      * ABA Excess/(Deficit) Collateral Value = Total ABA Net Value - Total Loans
    */
    if(total_aba_net_value||total_aba_net_value===0){
      if(total_loans||total_loans==0){
        return total_aba_net_value - total_loans; 
      }
      return total_aba_net_value;
    }
    return null;
  }     

  ratioABACollateralCovergageRatio(total_aba_net_value, total_loans){
    /**
      * Formula
      * ABA Collateral Coverage Ratio = Total ABA Net Value / Total Loans
    */
    if((total_aba_net_value||total_aba_net_value===0)&&+total_loans){
      return (total_aba_net_value/total_loans).toFixed(2);
    }
    return null;
  }

  ratioCombinedCollateralCoverageRatio(total_re_net_value, total_re_loan, total_aba_net_value, total_loans){
    /**
     * Formula
     * Combined Collateral Coverage Ration = (Total Real State Net value + Total ABA Net Value)/(Total RE Loans + Total Loans)
    */
      if((total_re_loan&&total_re_loan!="0") || (total_loans&&total_loans!="0")){
        total_re_loan = total_re_loan || 0;
        total_loans = total_loans || 0;
        if(total_re_net_value || total_re_net_value===0 || total_aba_net_value || total_aba_net_value===0){
          total_re_net_value = total_re_net_value || 0;
          total_aba_net_value = total_aba_net_value || 0;
          return ((total_re_net_value+total_aba_net_value)/(parseFloat(total_re_loan)+parseFloat(total_loans))).toFixed(2);
        }
      return null;
    }
    return null;
  }

  formToServiceData(form_data){
    let body = {
      "total_collaterals": []
    }

    if (form_data && form_data.real_estate_evaluation_form) {
      let real_state = {
        "collateral_key": "real_estate",
        ...form_data.real_estate_evaluation_form
      }
      if (form_data.real_estate_form && form_data.real_estate_form.real_estate) {
        real_state["collaterals"] = form_data.real_estate_form.real_estate;
      }
      body["total_collaterals"].push(real_state);
    }

    if (form_data && form_data.aba_evaluation_form) {
      let aba_evaluation = {
        "collateral_key": "aba",
        ...form_data.aba_evaluation_form
      }
      if (form_data.aba_form && form_data.aba_form.aba) {
        aba_evaluation["collaterals"] = form_data.aba_form.aba;
      }
      body["total_collaterals"].push(aba_evaluation);
    }

    if (form_data && form_data.extra_info_form) {
      body = {
        ...body,
        ...form_data.extra_info_form
      }
    }
    return body;
  }

  serviceToFormData(service_data) {
    let body = {
      "real_estate_form": {
        "real_estate": []
      },
      "real_estate_evaluation_form": {},
      "aba_form": {
        "aba": []
      },
      "aba_evaluation_form": {},
      "extra_info_form": {}
    };
    if (service_data) {
      let { total_collaterals, ...extra_info_form } = service_data;
      if (extra_info_form) {
        body["extra_info_form"] = extra_info_form;
      }
      if (total_collaterals && total_collaterals.length > 0) {
        let real_estate_data, aba_data;
        total_collaterals.forEach(collateral => {
          switch (collateral.collateral_key) {
            case "real_estate": real_estate_data = collateral;
              break;
            case "aba": aba_data = collateral;
              break;
          }
        });
        if (real_estate_data) {
          let { collaterals, ...real_estate_evaluation_form } = real_estate_data;
          if (collaterals) {
            body["real_estate_form"].real_estate = collaterals;
          }
          if (real_estate_evaluation_form) {
            body["real_estate_evaluation_form"] = real_estate_evaluation_form;
          }
        }
        if (aba_data) {
          let { collaterals, ...aba_evaluation_form } = aba_data;
          if (collaterals) {
            body["aba_form"].aba = collaterals;
          }
          if (aba_evaluation_form) {
            body["aba_evaluation_form"] = aba_evaluation_form;
          }
        }
      }
    }
    return body;
  }

  getCollateralEvalHtml(GenerateCollateralPDFComponent, loanID) {
    let body = [];
    for (let child of GenerateCollateralPDFComponent.toArray()) {
      let filename = loanID+'_collateral_evaluation.pdf';
      let doc_type_id = '60c8365690c5bc3e4851fa40';
      let doc_type_key = 'collateral_evaluation_pdf';
      body.push({
        filename,
        content: child.nativeElement.innerHTML,
        doc_type_id,
        doc_type_key,
        response_to_be_saved:{
          filename,
          doc_type_id,
          doc_type_key
        },
        style: this.getCollateralStyle(),
      });
    }
    return {
      ...body[0]
    };
  }


  getCollateralStyle(){
    return `
    body {
      -webkit-print-color-adjust: exact !important;
  }

  @media all {
      .page-break {
          display: none;
      }
  }

  @media print {
      .page-break {
          display: block;
          page-break-before: always;
      }
  }

  body {
      color: #000;
      font-family: Arial, Helvetica, sans-serif;
      font-style: normal;
      font-size: 9.4pt;
      line-height: 20px;
      margin-bottom: 0;
      margin-top: 0;
  }

  .clear {
      margin: 0;
      padding: 0;
      height: 0;
      clear: both;
  }

  div,
  p,
  li,
  ul,
  span,
  td,
  th,
  a {
      margin: 0;
      padding: 0;
  }

  p {
      padding-bottom: 6px;
  }

  .wraperPage {
      width: 100%;
      margin: 10px auto;
  }

  .pfsText {
      font-size: 25px;
      font-weight: 600;
      text-align: right;
  }

  .newPage {
      width: 100%;
      display: block;
  }

  .wrap {
      width: 100%;
      padding-bottom: 5px;
  }





  .wrap {
      width: 100%;
      display: inline-block;
      margin-bottom: 2px;
  }

  input[type="checkbox"] {
      margin: 0;
      padding: 2px;
  }

  input[type="text"] {
      margin: 0;
      padding: 1px 1%;
      width: 98%;
      border: 0;
      background: none
  }



  tr,
  td,
  ul {
      padding: 0;
      margin: 0;
      line-height: 13px;
  }


  .lebelText {
      font-size: 14px;
      color: #333;
      text-align: left;
      font-weight: bold !important;
      padding-bottom: 5px;
  }

  .valueText {
      font-size: 14px;
      color: #333;
      text-align: left;
      font-weight: normal !important;
      padding-bottom: 5px;
  }



  .table {
      border: 1px solid #2a5135;
      width: 100%;
      margin-bottom: 1rem;
      color: #212529;
      border-collapse: collapse;
  }

  .GreenBgTitle {
      color: #fff !important;
      text-align: center;
      font-size: 16px !important;
      font-weight: bold !important;
      padding: 15px 0;
      background-color: #2a5135;
  }

  .loanid {
      color: #2a5135;
      text-align: right;
      font-size: 18px;
      font-weight: bold;
      padding: 15px 0;
      border-top: 1px solid #2a5135;
      border-bottom: 1px solid #2a5135;
  }

  .subTitle2 {
      color: #2a5135;
      text-align: left;
      font-size: 16px;
      font-weight: bold;
      padding: 15px 0;
  }

  .subTitle3 {
      color: #2a5135;
      text-align: left;
      font-size: 14px;
      font-weight: bold;
      padding: 15px 0;
  }

  .table td,
  .table th {
      color: #2a5135;
      border-color: #2a5135;
      vertical-align: middle;
      font-size: 14px;
      padding: 15px 10px;
      font-weight: 500;
      border-bottom: 1px solid #2a5135;
      border-right: 1px solid #2a5135;
  }

  .table th {
      font-weight: bold;
  }

  .ogText td {
      border-top: 2px solid #ddd;
      padding-top: 30px;
  }

  .ogText .lebelText,
  .ogText .valueText {
      font-size: 20px;
      color: #2a5135
  }

  .tr {
      text-align: right;
  }

  .logoText td {
      padding-bottom: 10px;
  }

  .vertical-separator{
    background: #2a5135;
    width: 1px;
    height: 43px;
    margin-top: -16px;
    margin-right: 15px;
    margin-left: 15px;
    display: inline-block;
    margin-bottom: -16px;
  }
  .real-state-table th, .real-state-table td{
    padding: 5px 3px;
  }
  .real-state-table .valueText, .real-state-table .lebelText{
    font-size: 12px; 
  }`;
  }

}
