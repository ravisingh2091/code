import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CollateralPdfComponent } from './components/collateral-eval-main/collateral-pdf/collateral-pdf.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
@NgModule({
  imports: [
    CommonModule,
    SharedLazyModule
  ],
  exports: [CollateralPdfComponent],
  declarations: [CollateralPdfComponent],
})
export class CollateralEvaluationEagerModule {}
