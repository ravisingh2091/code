import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { FormGenerateService, CommonService, TaskInfoService } from '@rubicon/utils'
import { ReplaySubject } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { CalculationService } from '../../../services/calculation.service';

@Component({
  selector: 'real-estate-evaluation-form',
  templateUrl: './real-estate-evaluation-form.component.html',
  styleUrls: ['./real-estate-evaluation-form.component.scss']
})
export class RealEstateEvaluationFormComponent implements OnChanges, OnInit, OnDestroy {
  @Output() inform_parent = new EventEmitter<any>();
  @Input() re_form_collateral_values;
  @Input() init_data;
  @Input() is_view_mode;
  slug: string = CONSTANTS.SLUG.real_estate_valuation_form;
  form: FormGroup;
  formConfig: [];
  compDestroyed$ = new ReplaySubject(1);
  

  constructor(
    private formGenerate: FormGenerateService,
    private common: CommonService,
    private tasksInfoService: TaskInfoService,
    private calculationService: CalculationService
  ) { }

  ngOnChanges(simpleChanges: SimpleChanges) {
    if(simpleChanges.init_data && simpleChanges.init_data.currentValue && this.form){
      this.formGenerate.setFormValues(this.form, this.init_data);
    }
    if(simpleChanges.is_view_mode && simpleChanges.is_view_mode.currentValue && this.form){
      this.form.disable();
    }

    /** Detecting changes for net_value and gross from parent in real estate form*/
    if(this.form)
      this.proceedToCalculations();
  }

  ngOnInit(): void {
    this.tasksInfoService.getTaskInfo({slug: this.slug}).subscribe(response=>{
      this.formConfig = response.form_fields;
      this.form = this.formGenerate.createControl(this.formConfig);
      this.common.sendMasterDataToFields(this.formConfig,response?.response_data);
      if(this.init_data){
        this.formGenerate.setFormValues(this.form, this.init_data);
      }
      if(this.is_view_mode){
        this.form.disable();
      }
      this.onChanges();
    })
  }

  onChanges(){
    this.form.valueChanges.pipe(takeUntil(this.compDestroyed$), distinctUntilChanged())
    .subscribe((val) => {
      /**
         * Total RE Loans = Less Existing Liens + Less Proposed RE Loans
      */
      if(val.less_exiting_lien&&val.less_proposed_re_loans){
        let total_loans = (parseFloat(val.less_exiting_lien) + parseFloat(val.less_proposed_re_loans)).toFixed(0);
        this.form.get('total_re_loans').setValue(+total_loans, { emitEvent: false })
      } else if(val.less_exiting_lien) {
        /** If Less Proposed RE Loans value is not there or zero*/
        let total_loans = parseFloat(val.less_exiting_lien).toFixed(0);
        this.form.get('total_re_loans').setValue(+total_loans, { emitEvent: false });
      } else if(val.less_proposed_re_loans){
        /** If Less Existing Liens value is not there or zero*/
        let total_loans = parseFloat(val.less_proposed_re_loans).toFixed(0);
        this.form.get('total_re_loans').setValue(+total_loans, { emitEvent: false })
      } else{
        /** If Both values are not there or zero*/
        this.form.get('total_re_loans').setValue(null, { emitEvent: false })
      }
      this.inform_parent.next(true);
      // this.proceedToCalculations();
    });
  }

  proceedToCalculations(){
    const total_re_gross_value = this.re_form_collateral_values.total_gross_value;
    const total_re_net_value = this.re_form_collateral_values.total_net_value;
    const total_re_loan = this.form.get('total_re_loans').value;
    const evaluation = this.calculationService.getEvaluationRatio({total_re_gross_value, total_re_net_value, total_re_loan, type: this.slug});
    this.form.patchValue(evaluation, { emitEvent: false });
  }

  getFormValue(){
    return {  real_estate_evaluation_form: this.form.value }
  }

  ngOnDestroy() {
    this.compDestroyed$.next();
    this.compDestroyed$.complete();
  }
}
