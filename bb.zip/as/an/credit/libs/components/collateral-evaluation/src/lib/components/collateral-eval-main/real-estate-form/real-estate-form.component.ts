import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { AbstractControl, FormArray, FormGroup, Validators } from '@angular/forms';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { FormGenerateService, CommonService, TaskInfoService } from '@rubicon/utils';
import { merge, ReplaySubject, Subject } from 'rxjs';
import { distinctUntilChanged, map, takeUntil } from 'rxjs/operators';
@Component({
  selector: 'real-estate-form',
  templateUrl: './real-estate-form.component.html',
  styleUrls: ['./real-estate-form.component.scss']
})
export class RealEstateFormComponent implements OnInit, OnChanges, OnDestroy {
  @Output() inform_parent = new EventEmitter<any>();
  @Input() init_data;
  @Input() is_view_mode;
  slug: string = CONSTANTS.SLUG.real_estate_form;
  form: FormGroup;
  formArray: FormArray;
  formConfig: any[];
  changesUnsubscribe = new Subject();
  compDestroyed$ = new ReplaySubject(1);
  shouldAddValidation = {};
  formArrayLength: number = 1;

  ngOnChanges(simpleChanges: SimpleChanges) {
    if(simpleChanges.init_data && simpleChanges.init_data.currentValue && this.form){
      this.formGenerate.setFormValues(this.form, this.init_data);
    }
    if(simpleChanges.is_view_mode && simpleChanges.is_view_mode.currentValue && this.form){
      this.form.disable();
    }
  }
  
  constructor(
    private formGenerate: FormGenerateService,
    private common: CommonService,
    private tasksInfoService: TaskInfoService
  ) { }

  ngOnInit(): void {
    this.tasksInfoService.getTaskInfo({slug: this.slug}).subscribe(response=>{
      this.formConfig = response.form_fields;
      this.form = this.formGenerate.createControl(this.formConfig);
      this.common.sendMasterDataToFields(this.formConfig,response?.response_data);
      if(this.init_data){
        this.formArrayLength = this.init_data.real_estate.length;
        this.formGenerate.setFormValues(this.form, this.init_data);
        this.inform_parent.next({ group: this.form.get('real_estate'), slug: this.slug });
      }
      if(this.is_view_mode){
        this.form.disable();
      }
      // this.formGenerate.setFormValues(this.form,obj);
      this.formArray = this.form.get('real_estate') as FormArray;
      if(this.formArrayLength===1){
        this.doChangesInValidation(0, true);
      }
      if(this.init_data?.real_estate?.length>0){
        for(let i=0; i<this.formArrayLength; i++){
          this.doChangesInValidation(i);
        }  
      }
      this.onChange(this.formArray);
      this.formArray.valueChanges.pipe(takeUntil(this.compDestroyed$), distinctUntilChanged())
      .subscribe((val) => {
        if(this.formArrayLength<val.length){
          this.formArrayLength = val.length
          this.doChangesInValidation(val.length-1, true);
          this.onChange(this.formArray);
        } else if(this.formArrayLength>val.length){
          this.shouldAddValidation = {};
          this.formArrayLength = val.length
          this.onChange(this.formArray);
        }
      });
    })
  }

  onChange(formArray) {
    this.changesUnsubscribe.next();
    merge(
      ...formArray.controls.map((control: AbstractControl, index: number) =>
        control.valueChanges.pipe(
          takeUntil(this.changesUnsubscribe),
          map((value) => ({ rowIndex: index, val: value }))
        )
      )
    ).subscribe((changes: any) => {
        const values = changes.val;
        let flag = false;
        for(let control_val in values){
          if(values[control_val]||values[control_val]===0){
            flag = true;
          }
        }
        if(flag){
          this.shouldAddValidation[changes.rowIndex] = flag;
          this.doChangesInValidation(changes.rowIndex);
        }
        if(!flag&&this.shouldAddValidation[changes.rowIndex]!==flag){
          this.shouldAddValidation[changes.rowIndex] = flag;
          this.doChangesInValidation(changes.rowIndex, true);
        }
    });
  }

  doChangesInValidation(index, remove?){
    this.formConfig[0].group_fields.forEach(field=>{
      if(field.name!=='net_value'){
        let  control = this.formArray.controls[index].get(field.name);
        control.setValidators(remove ? this.createValidation(field.validations) : this.createValidation(field.validations).concat([Validators.required]));
        control.updateValueAndValidity({emitEvent: false});
      }
    })
  }

  createValidation(validations){
    let validList = [];
    validations.forEach(valid=>{
      if(valid.name === 'pattern'){
        if (!Array.isArray(valid.validations)) {
          valid.validations = valid.validations.replace(/^\/|\/$/g, '');
        }
        validList.push(Validators.pattern(valid.validations))
      }
    })
    return validList;
  }

  getFormValue(){
    return {  real_estate_form: this.form.value }
  }

  ngOnDestroy(){
    this.compDestroyed$.next();
    this.compDestroyed$.complete();
    this.changesUnsubscribe.complete();
  }
  
}
