import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CollateralEvalMainComponent } from './components/collateral-eval-main/collateral-eval-main.component';
import { RouterModule, Route } from '@angular/router';
import { RealEstateFormComponent } from './components/collateral-eval-main/real-estate-form/real-estate-form.component';
import { RealEstateEvaluationFormComponent } from './components/collateral-eval-main/real-estate-evaluation-form/real-estate-evaluation-form.component';
import { AbaFormComponent } from './components/collateral-eval-main/aba-form/aba-form.component';
import { AbaEvaluationFormComponent } from './components/collateral-eval-main/aba-evaluation-form/aba-evaluation-form.component';
import { SharedLazyModule } from "@credit-bench/shared-lazy";
import { ExtraInfoFromComponent } from './components/collateral-eval-main/extra-info-from/extra-info-from.component';
import { CollateralEvaluationEagerModule } from './collateral-evaluation-eager.module';

export const CollateralRoutes: Route[] = [
  {
    path: '', component: CollateralEvalMainComponent
  }
]
@NgModule({
  imports: [
    CommonModule,
    SharedLazyModule,
    CollateralEvaluationEagerModule,
    RouterModule.forChild(CollateralRoutes)
  ],
  declarations: [CollateralEvalMainComponent, RealEstateFormComponent, RealEstateEvaluationFormComponent, AbaFormComponent, AbaEvaluationFormComponent, ExtraInfoFromComponent],
})
export class CollateralEvaluationModule {}
