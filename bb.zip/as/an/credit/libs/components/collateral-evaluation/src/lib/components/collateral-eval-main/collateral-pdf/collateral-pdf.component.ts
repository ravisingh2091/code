import { Component, Input, OnChanges, OnInit, SimpleChanges, Inject } from '@angular/core';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';

@Component({
  selector: 'collateral-pdf',
  templateUrl: './collateral-pdf.component.html',
  styleUrls: ['./collateral-pdf.component.scss']
})
export class CollateralPdfComponent implements OnInit, OnChanges {

  @Input() init_data;
  @Input() master_data;
  logo1_path: string;
  logo2_path: string;

  aba_evaluation_form;
  aba_form;
  extra_info_form;
  real_estate_evaluation_form;
  real_estate_form;
  // aba_asset_description;
  cities; 
  all_collateral_type;
  collateral_appraisal_type;
  // collateral; 
  lein_value; 
  percentage; 
  state; 
  valuation_source;
  yes_no;
  loanID;
  businessName;
  CONST_YES_NO = CONSTANTS.YES_NO;
  client_name;

  ngOnChanges(simpleChanges: SimpleChanges){
    if(simpleChanges && simpleChanges.init_data && simpleChanges.init_data.currentValue){
      let {aba_evaluation_form, aba_form, extra_info_form, real_estate_evaluation_form, real_estate_form, loanID, businessName } = simpleChanges.init_data.currentValue;
      this.aba_evaluation_form = aba_evaluation_form;
      this.aba_form = aba_form;
      this.extra_info_form = extra_info_form;
      this.real_estate_evaluation_form = real_estate_evaluation_form;
      this.real_estate_form = real_estate_form;  
      this.loanID = loanID;
      this.businessName = businessName;
    }

    if(simpleChanges && simpleChanges.master_data && simpleChanges.master_data.currentValue){
      let {all_collateral_type, cities, lein_value, percentage, state, valuation_source, yes_no, collateral_appraisal_type} = simpleChanges.master_data.currentValue;
      this.all_collateral_type = all_collateral_type;
      this.cities = cities;
      this.collateral_appraisal_type = collateral_appraisal_type;
      // this.aba_asset_description = aba_asset_description;
      // this.collateral = collateral;
      this.lein_value = lein_value;
      this.percentage = percentage;
      this.state = state;
      this.valuation_source = valuation_source;
      this.yes_no = yes_no;
    }
}

  constructor(
    @Inject('environment') public environment,
  ) { }

  ngOnInit(): void {
    this.logo1_path = this.environment.logo1_path;
    this.logo2_path = this.environment.logo2_path;
    this.client_name = this.environment.client_name;
  }

}
