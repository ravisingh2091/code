import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { FormGenerateService, CommonService, TaskInfoService } from '@rubicon/utils'
import { ReplaySubject } from 'rxjs';
import { distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { CalculationService } from '../../../services/calculation.service';

@Component({
  selector: 'aba-evaluation-form',
  templateUrl: './aba-evaluation-form.component.html',
  styleUrls: ['./aba-evaluation-form.component.scss']
})
export class AbaEvaluationFormComponent implements OnChanges, OnInit, OnDestroy {
  @Input() form_collateral_values;
  @Input() re_form_collateral_values;
  @Input() init_data;
  @Input() is_view_mode;
  slug: string = CONSTANTS.SLUG.aba_valuation_from;
  form: FormGroup;
  formConfig: [];
  compDestroyed$ = new ReplaySubject(1);
  
  constructor(
    private formGenerate: FormGenerateService,
    private common: CommonService,
    private tasksInfoService: TaskInfoService,
    private calculationService: CalculationService
  ) { }

  ngOnChanges(simpleChanges: SimpleChanges) {
    if(simpleChanges.init_data && simpleChanges.init_data.currentValue && this.form){
      this.formGenerate.setFormValues(this.form, this.init_data);
    }
    if(simpleChanges.is_view_mode && simpleChanges.is_view_mode.currentValue && this.form){
      this.form.disable();
    }
    /** Detecting changes for net_value and gross from parent in real estate form and aba form*/
    if(this.form)
      this.proceedToCalculations();
  }

  ngOnInit(): void {
    this.tasksInfoService.getTaskInfo({slug: this.slug}).subscribe(response=>{
      this.formConfig = response.form_fields;
      this.form = this.formGenerate.createControl(this.formConfig);
      this.common.sendMasterDataToFields(this.formConfig,response?.response_data);
      if(this.init_data){
        this.formGenerate.setFormValues(this.form, this.init_data);
      }
      if(this.is_view_mode){
        this.form.disable();
      }
      this.onChanges();
    })
  }

  onChanges(){
    this.form.valueChanges.pipe(takeUntil(this.compDestroyed$), distinctUntilChanged())
    .subscribe((val) => {
      /**
         * Total Loans = Less Existing Liens + Less Proposed Loans
      */
      if(val.less_exiting_lien&&val.less_proposed_loans){
        let total_loans = (parseFloat(val.less_exiting_lien) + parseFloat(val.less_proposed_loans)).toFixed(0);
        this.form.get('total_loans').setValue(+total_loans, { emitEvent: false })
      } else if(val.less_exiting_lien) {
        /** If Less Proposed Loans value is not there or zero*/
        let total_loans = parseFloat(val.less_exiting_lien).toFixed(0);
        this.form.get('total_loans').setValue(+total_loans, { emitEvent: false });
      } else if(val.less_proposed_loans){
        /** If Less Existing Liens value is not there or zero*/
        let total_loans = parseFloat(val.less_proposed_loans).toFixed(0);
        this.form.get('total_loans').setValue(+total_loans, { emitEvent: false })
      } else{
        /** If Both values are not there or zero*/
        this.form.get('total_loans').setValue(null, { emitEvent: false })
      }
      this.proceedToCalculations();
    });
  }

  proceedToCalculations(){
    const total_re_net_value = this.re_form_collateral_values.total_net_value;
    const total_aba_net_value = this.form_collateral_values.total_net_value; 
    const total_re_loan = this.re_form_collateral_values.total_re_loans;
    const total_loans = this.form.get('total_loans').value;
    const evaluation = this.calculationService.getEvaluationRatio({total_re_net_value, total_re_loan, total_aba_net_value, total_loans, type: this.slug});
    this.form.patchValue(evaluation, { emitEvent: false });
  }

  getFormValue(){
    return {  aba_evaluation_form: this.form.value }
  }

  ngOnDestroy() {
    /** appropiate signal received and unsubscription of observable. */
    this.compDestroyed$.next();
    this.compDestroyed$.complete();
  }
}
