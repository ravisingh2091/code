import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Route } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { OwnerDetailsComponent } from './owner-details/owner-details.component';
import { YourBusinessInfoComponent } from './your_business_info/your_business_info.component';
import { MasterDataPipe } from '@rubicon/utils';

export const OwnerDetailsRoutes: Route[] = [
  {
    path:'' , component: OwnerDetailsComponent,
  },
  {
    path:'business-info' , component: YourBusinessInfoComponent,
  }
];

@NgModule({
  imports: [
    CommonModule,
    SharedLazyModule,
    RouterModule.forChild(OwnerDetailsRoutes)
  ],
  declarations: [
    OwnerDetailsComponent,
    YourBusinessInfoComponent
  ],
  providers: [MasterDataPipe]
})
export class OwnerDetailsModule {}
