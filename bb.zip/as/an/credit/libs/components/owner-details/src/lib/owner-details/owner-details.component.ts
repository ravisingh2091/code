import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { TaskInfoService, FormGenerateService, CommonService } from '@rubicon/utils';
import { FormGroup, FormArray } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { Store, select } from '@ngrx/store';
import { DOCUMENT } from '@angular/common';
import { take, distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { ReplaySubject } from 'rxjs';

@Component({
  selector: 'app-owner-details',
  templateUrl: './owner-details.component.html',
  styleUrls: ['./owner-details.component.scss']
})
export class OwnerDetailsComponent implements OnInit, OnDestroy {

  name: string;
  slug: string;
  nextTask: string;
  previousTask: string;
  app_id: string;
  user_id: string;
  application_status_id: string;
  business_id: string;
  ownerDetailFormConfig: FormFieldInterface[] = [];
  ownerDetailForm: FormGroup;
  ownerData: any = {};
  userData: any = {};
  compDestroyed$ = new ReplaySubject(1);
  bankerData : any;
  constructor(private taskinfoService: TaskInfoService,
    private common: CommonService,
    private store: Store<any>,
    @Inject(DOCUMENT) private document: Document,
    private formGenerateService: FormGenerateService,
    @Inject('CONSTANTS') private CONSTANTS,
    @Inject('environment' ) public environment) { }

  ngOnInit(): void {
    this.name = this.CONSTANTS.CLIENT_CONFIG.name;
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.app_id = rootState.appID;
      this.business_id = rootState.businessID
      if(this.environment.journeyType === 'banker-journey'){
        this.user_id = rootState.appData.userData.user_id;
        this.userData = rootState?.appData.userData;
        this.bankerData = rootState?.userData;
        this.application_status_id=rootState?.appData?.status_id;
      }else{
        this.user_id = rootState.userData.user_id;
        this.userData = rootState.userData;
      }
        this.taskinfoService.getTaskInfo({
        slug: this.CONSTANTS.SLUG['owner-details'],
        app_id: this.app_id,
        user_id: this.user_id,
        business_id: this.business_id
      }).subscribe(response => {
        this.slug = response?.task_slug;
        this.previousTask = response?.previous_task;
        this.ownerDetailFormConfig = response?.form_fields;
        this.ownerDetailForm = this.formGenerateService.createControl(this.ownerDetailFormConfig);
        this.common.sendMasterDataToFields(this.ownerDetailFormConfig, response?.response_data)
        if (response ?.response_data ?.get_owner_data ?.data ?.data ?.length) {
          this.ownerData = response.response_data.get_owner_data.data.data.find(res => res.is_primary);
          this.formGenerateService.setFormValues(this.ownerDetailForm, { owners: this.ownerData });
        }
        this.common.updateStepState(this.CONSTANTS.APP_STEP[this.slug]);
        this.setPersonalDetail();
      })
    });
  }

  setPersonalDetail(): void {
    let form_array: FormArray = this.ownerDetailForm.get('owners') as FormArray;
    form_array.get('same_as_personal_detail').valueChanges.pipe(
      distinctUntilChanged(), takeUntil(this.compDestroyed$)).subscribe(value => {
        if (value) {
          this.formGenerateService.setFormValues(this.ownerDetailForm, { owners: this.userData });
        } else {
          this.formGenerateService.setFormValues(this.ownerDetailForm, {
            owners: {
              first_name: '',
              middle_name:'',
              last_name: '',
              phone: '',
              email_address: ''
            }
          });
        }
      })
  }

  onSubmit(action: string): void {
    if (this.formGenerateService.validateCustomFormFields(this.ownerDetailForm, action, this.ownerDetailFormConfig)) {
      let payload: any = {
        app_id: this.app_id,
        user_id: this.user_id,
        action_type: action
      }
      
      if (this.ownerData ?._id) {
        payload = {
          owner_id: this.ownerData._id,
          is_primary: true,
          ...payload,
          consent: (this.ownerDetailForm.getRawValue().owners?.agreed_terms_and_condition == true) ? "received": this.ownerData.consent,
          ...this.ownerDetailForm.getRawValue().owners
        }
      } else {
        payload.owners = [{
          ...this.ownerDetailForm.getRawValue().owners,
          is_primary: true,
          consent: (this.ownerDetailForm.getRawValue().owners?.agreed_terms_and_condition == true) ? 'received': 'pending',
          owner_type: 'individual',
          // sba_process_status: 0
        }]
      }
      if (this.ownerDetailForm.getRawValue().owners ?.agreed_terms_and_condition || action === 'save' || this.environment.journeyType === 'banker-journey') {
        this.taskinfoService.saveTaskInfo({ slug: this.CONSTANTS.SLUG['owner-details'] }, payload).subscribe(response => {
          if (response ?.nextTask ?.value) {
            if(this.environment.journeyType === 'banker-journey'){
              this.nextTask = action === 'continue' ? response.nextTask.value : 'manage-loans';
              if(action === 'save' && this.application_status_id!==this.CONSTANTS?.APPLICATION_STATUS?.application_in_progress) {
                this.addActivityLog()
              }
            }else{
              this.nextTask = action === 'continue' ? response.nextTask.value : 'dashboard';
            }
            this.common.updateStepState(this.CONSTANTS.APP_STEP[this.nextTask]);
            this.common.navigate(this.nextTask, this.business_id);
          }
        });
      }
      else{
        this.common.popToast('error', 'Error', 'Please accept the terms and conditions.');
      }
    }
  }

  onPrevious(): void {
    this.common.navigate(this.previousTask);
  }

  addActivityLog(){
    const log_data = {
      role_slug:  this.bankerData?.role_slug,
      app_id: this.app_id,
      backend_user_id: this.bankerData?.user_id,
      user_name: this.bankerData?.full_name,
      activity: 'application_edited'
    };
    this.common.addActivityLog(log_data);
  }

  ngOnDestroy() {
    this.common.updateStepState(0);
  }
}
