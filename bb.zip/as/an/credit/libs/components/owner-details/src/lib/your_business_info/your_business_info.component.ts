import { Component, OnInit, TemplateRef, ViewChild, Inject, OnDestroy } from '@angular/core';
import { TaskInfoService, FormGenerateService, CommonService, MasterDataPipe } from '@rubicon/utils';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { take, distinctUntilChanged } from 'rxjs/operators';
import { ReplaySubject } from 'rxjs';
import { Store } from '@ngrx/store';
import { isArray } from 'ngx-bootstrap/chronos';

@Component({
  selector: 'app-your_business_info',
  templateUrl: './your_business_info.component.html',
  styleUrls: ['./your_business_info.component.scss']
})
export class YourBusinessInfoComponent implements OnInit, OnDestroy {

  slug = '';
  application_status_id = '';
  ownerDetailFormConfig: FormFieldInterface[] = [];
  ownerDetailForm: FormGroup;
  modalRef: BsModalRef;
  app_id: string;
  user_id: string;
  previousTask: string;
  business_id: string;
  compDestroyed$ = new ReplaySubject(1);
  data: any = [];
  ownerData: any = [];
  company_role: any = [];
  owner_type: any = [];
  state: any = [];
  businessData: any = [];
  business_structure_data: any = [];
  company_status: any = [];
  editOwnerData: any = {};
  nextTask: string;
  bankerData : any;
  
  @ViewChild('template') template: TemplateRef<any>;

  constructor(private taskinfoService: TaskInfoService,
    private common: CommonService,
    private modalService: BsModalService,
    private store: Store<any>,
    private formGenerateService: FormGenerateService,
    private masterDataPipe: MasterDataPipe,
    @Inject('environment') private environment,
    @Inject('CONSTANTS') private CONSTANTS) { }

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      if(this.environment.journeyType === 'banker-journey'){
        this.user_id = rootState.appData.userData.user_id;        
        this.bankerData = rootState?.userData;
        this.application_status_id=rootState?.appData?.status_id;
      }else{
        this.user_id = rootState.userData.user_id;
      }
      this.app_id = rootState.appID;
      this.business_id = rootState.businessID
      this.taskinfoService.getTaskInfo({
        slug: this.CONSTANTS.SLUG['another-owner-detail'],
        app_id: this.app_id,
        user_id: this.user_id,
        business_id: this.business_id
      }).subscribe(response => {
        if (response) {
          this.previousTask = response ?.previous_task;
          this.slug = response ?.task_slug;
          this.data = response ?.response_data;
          this.ownerDetailFormConfig = response ?.form_fields;
          this.ownerData = this.data ?.get_owner_data ?.data ?.data;
          this.company_role = this.data ?.company_role ?.data ?.data;
          this.owner_type = this.data ?.owner_type ?.data ?.data;
          this.state = this.data ?.state ?.data ?.data;
          this.businessData = this.data ?.get_business_data ?.data ?.data;
          this.business_structure_data = this.data ?.business_structure ?.data ?.data;
          this.company_status = this.data ?.company_status ?.data ?.data;
        }
        this.common.updateStepState(this.CONSTANTS.APP_STEP[this.slug]);
      })
    });
  }

  openModal2(owner?): void {
    if (owner ?.is_primary) {
      this.common.navigate('owner-details');
      return;
    }
    this.ownerDetailForm = this.formGenerateService.createControl(this.ownerDetailFormConfig);
    this.common.sendMasterDataToFields(this.ownerDetailFormConfig, this.data);
    this.ownerDetailForm.get("owners.business_structure").valueChanges.pipe(
      distinctUntilChanged())
      .subscribe(val=> {
      this.common.sendMasterDataToFields(this.ownerDetailFormConfig, this.data);
      })
    this.modalRef = this.modalService.show(this.template, { class: 'modal-lg thankyouRegister', backdrop: 'static' });
    if (owner) {
      this.formGenerateService.setFormValues(this.ownerDetailForm, { owners: owner });
      this.editOwnerData = owner;
    } else {
      this.editOwnerData = null;
    }
  }

  refresh(owner_id): void {
    this.taskinfoService.getTaskInfo({
      slug: 'get_owner_data',
      app_id: this.app_id,
      user_id: this.user_id,
      owner_id: owner_id
    }).subscribe(response => {
      const ownerData = response?.response_data ?.get_owner_data ?.data ?.data;
      const index = this.ownerData.findIndex(elem=>owner_id===elem._id);
      if(index>=0){
        this.ownerData[index]=ownerData[0];
      }
    })
  }

  getAddress(owner): string {
    const state = this.state.find(res => res.id == owner.state) ?.value;
    const city = owner?.city?.charAt(0) + owner?.city?.slice(1, owner?.city?.length).toLowerCase();
    return `${(owner.streetNo && typeof owner.streetNo !== "undefined" && typeof owner.streetNo === "string") ? owner.streetNo+', ' : ""}${(owner.streetName && typeof owner.streetName !== "undefined" && typeof owner.streetName === "string") ? owner.streetName+', ' : ""}${(city && typeof city !== "undefined" && typeof city === "string") ? city+', ' : ""}${(state && typeof state !== "undefined" && typeof state === "string") ? state+', ' : ""}${(owner.zip_code && typeof owner.zip_code !== "undefined" && typeof owner.zip_code === "string") ? owner.zip_code : ""}`;
  }

  deleteOwner(owner: any): void {
    if (owner ?._id) {
      this.taskinfoService.saveTaskInfo({ slug: this.CONSTANTS.SLUG['delete-owner'] }, { owner_id: owner._id }).subscribe(response => {
        const index = this.ownerData.findIndex(data => data._id === response ?.delete_owner ?.data ?.data ?._id);
        if (index >= 0) {
          this.ownerData.splice(index, 1);
        }
        this.common.popToast('success', '', 'Owner deleted successfully.');
      })
    }
  }

  submitOwner(action: string): void {
    if (this.formGenerateService.validateCustomFormFields(this.ownerDetailForm, action, this.ownerDetailFormConfig)) {
      const payload = {
        app_id: this.app_id,
        user_id: this.user_id,
        action_type: action,
        is_secondary: true,
        // sba_process_status: 0,
        ...this.ownerDetailForm.getRawValue().owners
      }
      if (this.editOwnerData ?._id) {
        payload.owner_id = this.editOwnerData._id;
      }
      this.taskinfoService.saveTaskInfo({ slug: this.CONSTANTS.SLUG['another-owner-detail'] }, payload).subscribe(response => {
        if (response ?.update_owner ?.data ?.data ?._id) {
          const index = this.ownerData.findIndex(data => data._id === response.update_owner.data.data._id);
          if (index < 0) {
            this.ownerData.push(response.update_owner.data.data);
            this.common.popToast('success', '', 'Owner added successfully.');
          } else {
            this.ownerData[index] = response.update_owner.data.data;
            this.common.popToast('success', '', 'Owner updated successfully.');
          }
          this.editOwnerData = {};
          this.modalRef.hide();
        }
      });
    }
  }

  getOwnership(): number {
    return this.ownerData.reduce((sum, item) => sum + item.ownership, 0);
  }

  onPrevious(): void {
    this.common.navigate(this.previousTask);
  }

  submit(action: string): void {
    if (this.getOwnership() !== 100 && action === 'continue') {
      this.common.popToast('error', 'Error', '100% ownership participation is required to process your credit request.');
      return;
    }

    if(this.ownerCountWithoutConsent() > 0 && action === 'continue') {
      this.common.popToast('error', 'Error', 'Please send consent request to all the owners to proceed.');
      return;
    }

    if(this.environment.journeyType === 'banker-journey'){
      this.nextTask = action === 'continue' ? 'documents' : 'manage-loans'
      if(action === 'save' && this.application_status_id!==this.CONSTANTS?.APPLICATION_STATUS?.application_in_progress) {
        this.addActivityLog();
      }
    }else{
      this.nextTask = action === 'continue' ? 'documents' : 'dashboard'
    }
    this.common.navigate(this.nextTask, this.business_id);
  }
  addActivityLog(){
    const log_data = {
      role_slug:  this.bankerData?.role_slug,
      app_id: this.app_id,
      backend_user_id: this.bankerData?.user_id,
      user_name: this.bankerData?.full_name,
      activity: 'application_edited'
    };
    this.common.addActivityLog(log_data);
  }
  sendOwnerConsent(obj): void {
    if (this.getOwnership() !== 100) {
      this.common.popToast('error', 'Error', '100% ownership participation is required to process your credit request.');
      return;
    }
    const payload = {
      app_id: obj.app_id,
      user_id: obj.user_id,
      owner_id: obj._id,
      hash_for: 'owner_consent',
      email_address: obj.email_address,
      to_name: obj.owner_type === 'individual' ? obj.first_name : obj.businessname,
      consent: 'sent',
      header_logo_path_1: this.environment.logo1_path,
      header_logo_path_2: this.environment.logo2_path,
      client_name: this.CONSTANTS.MAIL_TEMPLATE.project_name,
      senders_name: this.CONSTANTS.MAIL_TEMPLATE.senders_name,
      copyright_text: this.CONSTANTS.MAIL_TEMPLATE.copyright_text,
      frontend_url: this.environment.customerJourneyUrl,
      privacy: this.environment.privacy,
      terms: this.environment.terms,
      role: this.masterDataPipe.transform(obj.company_role , this.company_role,'id','value')
    }
    const params = {
      slug: this.CONSTANTS.SLUG['request_owners_consent'],
      app_id: this.app_id,
      user_id: this.user_id,
      owner_id: obj._id,
      business_id: this.business_id
    }
    this.taskinfoService.saveTaskInfo(params, payload).subscribe(response => {
      if (response ?.update_owner_consent ?.data ?.data ?._id) {
        const index = this.ownerData.findIndex(data => data._id === response.update_owner_consent.data.data._id);
        this.ownerData[index] = response.update_owner_consent.data.data;
      }
    })
  }

  ownerCountWithoutConsent() {
      let OwnerWithoutConsentlist = [];
      if(this.ownerData && isArray(this.ownerData)) {
        OwnerWithoutConsentlist = this.ownerData.filter(owner => {
            return !(owner['consent'] === 'received' || owner['consent'] === 'sent')
        });
      }
      return OwnerWithoutConsentlist.length;
  }
  ngOnDestroy() {
    if(this.modalRef) {
      this.modalRef.hide();
    }
    this.common.updateStepState(0);
  }
}
