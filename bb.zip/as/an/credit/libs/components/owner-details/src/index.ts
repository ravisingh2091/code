export * from './lib/owner-details.module';
