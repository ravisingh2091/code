import { Component, OnInit, Input, Inject } from '@angular/core';

@Component({
  selector: 'credit-bench-application-pdf-owner',
  templateUrl: './application-pdf-owner.component.html',
  styleUrls: ['./application-pdf-owner.component.scss']
})
export class ApplicationPdfOwnerComponent implements OnInit {
  @Input() index;
  @Input() owner;
  @Input() business_industry = [];
  @Input() sub_industry= [];
  @Input() company_status = [];
  @Input() business_structure = [];
  @Input() company_role = [];
  @Input() gender = [];
  @Input() veteran = [];
  @Input() race = [];
  @Input() ethnicity = [];
  @Input() marital = [];
  @Input() annual_revenue = [];
  @Input() residence_type = [];
  @Input() productCategory = [];
  @Input() loanPurpose = [];
  @Input() state = [];
  @Input() franchise_business_structure = [];
  @Input() business_franchise_code: any;
  franchise: string;
  others: string;
  customPattern = {'X': {pattern: new RegExp('\\d'), symbol: 'X'}, '0':{pattern:new RegExp('\\d')}};
  constructor(
    @Inject('CONSTANTS') private CONSTANTS) { }

  ngOnInit(): void {
    this.franchise = this.CONSTANTS.BUSINESS_STRUCTURE.franchise;
    this.others = this.CONSTANTS.BUSINESS_STRUCTURE.others
  }

  

}
