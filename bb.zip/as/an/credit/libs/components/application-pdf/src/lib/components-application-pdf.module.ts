import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { ApplicationPdfComponent } from './application-pdf/application-pdf.component';
import { ApplicationPdfOwnerComponent } from './application-pdf/application-pdf-owner/application-pdf-owner.component';

@NgModule({
  imports: [CommonModule, SharedLazyModule],
  declarations: [ApplicationPdfComponent, ApplicationPdfOwnerComponent],
  exports:[ApplicationPdfComponent]
})
export class ComponentsApplicationPdfModule {}
