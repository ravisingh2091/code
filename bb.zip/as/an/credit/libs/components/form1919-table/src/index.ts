export * from './lib/form1919-table.module';
