import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Form1919TableComponent } from './form1919-table/form1919-table.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { DateTimezonePipe } from 'libs/shared-lazy/src/lib/pipes/date-timezone.pipe';

@NgModule({
  declarations: [Form1919TableComponent],
  imports: [
    CommonModule,
    SharedLazyModule
  ],
  providers: [DateTimezonePipe],
  exports: [Form1919TableComponent]
})
export class Form1919TableModule { }
