import { Component, EventEmitter, Inject, OnDestroy, OnInit, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonService, DownloadService, TaskInfoService } from '@rubicon/utils';
import { take } from 'rxjs/operators';
import {DateTimezonePipe} from 'libs/shared-lazy/src/lib/pipes/date-timezone.pipe';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { SendToSbaService } from '@credit-bench/send-to-sba';
import { Subscription } from 'rxjs';
@Component({
  selector: 'form1919-table',
  templateUrl: './form1919-table.component.html',
  styleUrls: ['./form1919-table.component.scss']
})
export class Form1919TableComponent implements OnInit, OnDestroy {
appID: string;
secondaryOwnersData = [];
ownerRefs = [];
userData: any;
business_data: any;
application_no: string;
forEsign = false;
isOpenAccordian = false;
initiateSBA = false;
step_not_required: any;
primaryOwner: any;
loanStatus: string;
sendToSBA;
@Output() otherSbaForms = new EventEmitter();
@Output() allOwnerEsignStatus = new EventEmitter();
SBAActionSubscription: Subscription;

  constructor(
    private taskInfoService: TaskInfoService,
    private commonService: CommonService,
    private store: Store<any>,
    private download: DownloadService,
    @Inject('environment') private environment,
    private dateTimeZone: DateTimezonePipe,
    private sbaService: SendToSbaService
  ) {}
  
  // sba_process_status = 0, mail sent to owner but owner not filled it yet.
  // esign_status = 'pending' , when the owner submitted sba form and esign is pending.
  // esign_status = 'mail send', when owner submitted sba form and mail sent for docusign.
  // esign_status = "sign", when owner successfully signed sba form.
  // esign_status = "decline" means owner decline to sign sba form.

  ngOnInit(): void {
    this.SBAActionSubscription = this.sbaService.SBAActionPerformed().subscribe(data=>{
      setTimeout(()=>{
        this.sendToSBA = true;
      },0);
    })
  }

  getReferenceData(event) {
  if (event){
      this.store.select('app').pipe(take(1)).subscribe(rootState => {
        this.appID = rootState?.appID;
        this.userData = rootState?.userData;
        this.application_no = rootState?.appData?.loan_id;
        this.loanStatus = rootState?.appData?.status_id; 
        let params = {
          slug: CONSTANTS.SLUG['form_1919'],
          app_id: this.appID
        }
        this.taskInfoService.getTaskInfo(params).subscribe(response => {
          this.step_not_required = response?.response_data?.owners_ownerReferences?.data?.data[0]?.business[0]?.step_not_required;
          this.business_data = response?.response_data?.owners_ownerReferences?.data?.data[0]?.business[0];
          if(this.step_not_required){
            this.initiateSBA = this.step_not_required.some(step => step === 'SBA Form');
          }
          this.ownerRefs = response?.response_data?.owners_ownerReferences?.data?.data[0].owner_references;
          let ownersData = response?.response_data?.owners_ownerReferences?.data?.data[0]?.owners;
          this.primaryOwner = ownersData.find(( {is_primary}) => is_primary === true);
          this.sendToSBA =  response?.response_data?.owners_ownerReferences?.data?.data[0]?.business_references?.filter(ref=> ref.type==="send_to_sba")?.pop();
          let flag = true;
          ownersData.forEach(owner=>{
            if(owner.esign_status!=='sign'){
              flag = false;
            }
          });
          this.allOwnerEsignStatus.emit(flag);
          this.forEsign = false;
          this.secondaryOwnersData = [];
          if (this.primaryOwner && this.primaryOwner.sba_process_status && this.primaryOwner.sba_process_status === 1) {
            this.forEsign = true;
            this.secondaryOwnersData = ownersData.filter(( {is_secondary}) => is_secondary === true );
          }
        })
      })
    }
  }

  initiateSBAForm() {
    if (this.primaryOwner) {
      this.step_not_required.splice("SBA Form", 1);
      this.resendLink(this.primaryOwner, this.step_not_required);
    } else {
      this.commonService.popToast('error', '', `Something wrong. Please try again later.`);
    }
  }

  resendLink(owner, updatedSteps?: any) {
    let payload = {
      app_id: this.appID,
      user_id: owner.user_id,
      owner_id: owner._id,
      hash_for: 'form_1919',
      to:owner.email_address,
      business_name: this.business_data.business_name,
      business_id: this.business_data._id,
      application_no: this.application_no,
      header_logo_path_1: this.environment.logo1_path,
      header_logo_path_2: this.environment.logo2_path,
      senders_name: CONSTANTS.MAIL_TEMPLATE.senders_name,
      copyright_text: CONSTANTS.MAIL_TEMPLATE.copyright_text,
      mail_client_name: CONSTANTS.MAIL_TEMPLATE.project_name,
      sba_process_status: 0,
      esign_status: 'pending',
      no_consent_update: true, 
      frontend_url: this.environment.customerJourneyUrl,
      privacy: this.environment.privacy,
      terms: this.environment.terms
    }
    if (owner.owner_type === 'individual') {
      payload['first_name']= owner.first_name
    } else {
      payload['first_name']= owner.businessname
    }
    if (owner?.is_primary) {
      payload['is_primary'] = owner?.is_primary;
    }
    if (updatedSteps) {
      payload['step_not_required'] = updatedSteps;
      payload['initiate_sba_date'] = new Date()
      payload['sba_initiated_by'] = "banker";
    }
    this.taskInfoService.saveTaskInfo({slug: CONSTANTS.SLUG['resend_form_1919']}, payload).subscribe(response => {
      if (response.complete_sbaform.status === 200) {
        if(updatedSteps){
          this.commonService.popToast('success', '', `SBA process has been initiated and Form 1919 link sent successfully.`);
          this.updateActivityLog('initiated');
        }
        else {
          let owner_name = owner.owner_type === 'individual' ? `${owner.first_name}${owner.middle_name? (' '+owner.middle_name): ''} ${owner.last_name}` : owner.businessname;
          this.updateActivityLog('form_resent', owner_name);
          this.commonService.popToast('success', '', `Form 1919 link resent successfully.`);
        }
        this.getReferenceData(true);
        if (updatedSteps) {
          this.otherSbaForms.emit(true);
        }
      }
    })
  } 

  getCreatedOn(owner) {
    let created_date;
    if (this.primaryOwner._id === owner._id) {
      created_date = this?.business_data?.initiate_sba_date;
    } else if (this.forEsign) {
      let createdRef  = (this?.ownerRefs?.find(( {type, owner_id}) => (type === 'form_1919' && owner_id === owner._id)))?.created_at;
      if (createdRef && owner.sba_process_status && owner.sba_process_status === 1)
      created_date = new Date(createdRef * 1000);
    }
    if (created_date === undefined || created_date === null || created_date === '') {
      return '-';
    } else {
      return this.dateTimeZone.transform(created_date,'MM-dd-yyyy/ h:mm a');
    }
  }

  esignLink(ownerDetail) {
    let pdfId = (this.ownerRefs.find(( {type, owner_id}) => (type === 'form_1919_pdf' && owner_id === ownerDetail._id)))?.ref_id;
    let esign_sba_1919_id = (this.ownerRefs.find(( {type, owner_id}) => (type === 'esign_sba_1919' && owner_id === ownerDetail._id)))?._id;
    let payload = {
      doc_id: pdfId,
      app_id: this.appID,
      user_id: ownerDetail.user_id,
      owner_id: ownerDetail._id,
      recipient_mail: ownerDetail?.email_address,
      doc_name: `form1919`,
      email_subject: 'Esign SBA Form 1919',
      esign_status: 'mail sent',
      brand_id: this.environment.brand_id,
      no_consent_update: true  
    };
    if(ownerDetail.owner_type === 'individual'){
      payload['recipient_name'] = `${ownerDetail?.first_name}${ownerDetail.middle_name?(' '+ownerDetail.middle_name+' '):' '}${ownerDetail?.last_name}`
    }
    else{
      payload['recipient_name'] = ownerDetail.businessname
    }
    if (esign_sba_1919_id) {
      payload['esign_sba_1919_id'] = esign_sba_1919_id;
    }
    this.taskInfoService.saveTaskInfo({slug: CONSTANTS.SLUG['esign_sba1919']}, payload).subscribe((response) => {
      this.getReferenceData(true);
      let actionPerformed = esign_sba_1919_id ? 'resent' : 'sent';
      esign_sba_1919_id ? this.updateActivityLog('sba_1919_esign_resent', payload['recipient_name']) : this.updateActivityLog('sba_1919_esign_sent', payload['recipient_name']);
      this.commonService.popToast('success', '', `SBA Form 1919 ${actionPerformed} for esign successfully.`);
    })
  }

  downloadForm(owner) {
    let pdfId;  
    if (owner.esign_status === 'sign') {
      pdfId = (this.ownerRefs.find(( {type, owner_id}) => (type === 'esign_sba_1919_doc' && owner_id === owner._id)))?.ref_id;
    } else {
      pdfId = (this.ownerRefs.find(( {type, owner_id}) => (type === 'form_1919_pdf' && owner_id === owner._id)))?.ref_id;
    }
    if (pdfId) {
      let payload = {doc_id: pdfId};
      this.taskInfoService.saveTaskInfo({slug: 'download_pdf'}, payload).subscribe((data) => {
        if (data?.download_document?.data) {
          let fileName;
          if(owner.owner_type === 'individual') {
            fileName =`${this.application_no}_${owner.first_name}_${owner.last_name}__form1919.pdf`
          } else {
            fileName =`${this.application_no}_${owner.businessname}__form1919.pdf`
          }
          this.download.showPdf(data.download_document.data, fileName);
        }  
      })
    }
}

check_1919status(ownerDetail) {
  if (!ownerDetail.hasOwnProperty('sba_process_status') || ownerDetail.sba_process_status === 0) {
    return 'Pending';
  } else if (this.forEsign && ownerDetail.sba_process_status && ownerDetail.sba_process_status === 1 && ownerDetail.esign_status) {
    if (ownerDetail.esign_status === 'pending') {
      return `Form Completed/Esign pending`;
    } else if (ownerDetail.esign_status === 'mail sent' || ownerDetail.esign_status === 'mail send') {
      return `Sent for Esign`;
    } else if (ownerDetail.esign_status === 'sign') {
      return `Esign Completed`;
    } else if (ownerDetail.esign_status === 'decline') {
      return `Esign Declined`;
    }
  }
}

showAlertMessage() {
  if (
    this.loanStatus === CONSTANTS?.APPLICATION_STATUS?.application_in_progress
  ) {
    return true;
  }
  return false;
}

updateActivityLog(type: any, owner_name? : string) {
  let activityData = {
    role_slug: this.userData.role_slug,
    app_id: this.appID,
    backend_user_id: this.userData.user_id,
    user_name: this.userData.full_name,
  };
  switch (type) {
    case 'initiated':
      activityData ['activity'] = `sba_1919_initiated`;
      break;
    case 'form_resent':
      activityData ['activity'] = `sba_1919_resent`;
      activityData ['note'] = owner_name;
      break;
    case 'sba_1919_esign_resent':
      activityData ['activity'] = `sba_1919_esign_resent`;
      activityData ['note'] = owner_name;
      break;
    case 'sba_1919_esign_sent':
      activityData ['activity'] = `sba_1919_esign_sent`;
      activityData ['note'] = owner_name;
      break;
  }

  this.commonService.addActivityLog(activityData);
}
 
  ngOnDestroy(){
    this.SBAActionSubscription.unsubscribe();
  }

}

