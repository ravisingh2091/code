import { Component, Input, OnInit, ElementRef, ViewChild} from '@angular/core';
import { Store } from '@ngrx/store';
import { addAppDetails, CommonService, TaskInfoService , DownloadService } from '@rubicon/utils';
import { take } from 'rxjs/operators';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';

@Component({
  selector: 'cash-flow',
  templateUrl: './cash-flow.component.html',
  styleUrls: ['./cash-flow.component.scss']
})
export class CashFlowComponent implements OnInit {
  @Input() applicationData: any;
  isEdit = false;
  response: any;
  businessFinancialRef: any;
  OwnerRef: any;
  OwnerBackendUser:any;
  CreatedAt: Date;
  backendUser: String;
  owners = [];
  loading = false;
  constant =  CONSTANTS;
  appData: any;
  appId: string;
  pdfData: any;
  isBusinessOwner: string;
  loanId: string; 
  ownerPdfData : any;
  ownerName : string;
  businessowners = [];
  loan_status_id: string;
  gdscrCreatedData: any;
  gdscrData: any;
  downloadPdf = false;
  business_name: string;
  incomplete_application = CONSTANTS.APPLICATION_STATUS['application_in_progress'];

  constructor(
              private taskInfoService:TaskInfoService,
              private store: Store<any>,
              private common : CommonService,
              private download: DownloadService
              ) {}

  ngOnInit(): void {
    this.loan_status_id = this.applicationData?.status_id;
    this.store.select('app').pipe(take(1)).subscribe((rootState) => {
      this.appData = rootState.appData;
      this.appId = rootState?.appID;
      this.loanId = this.appData?.loan_id;
      this.business_name = this.appData?.business_name;
    });   
  }

  getOwnerReference(isOpen){
    if (isOpen){
      this.taskInfoService.
      getTaskInfo({slug: CONSTANTS.SLUG['get_owner_reference'], app_id:this.appId, type: 'personal_financial'})
      .subscribe((response => {
        this.OwnerRef = response?.response_data?.get_owner_references?.data?.data;
        this.OwnerBackendUser = response?.response_data?.get_backend_user_for_owner?.data?.data;
        this.owners = this.applicationData.owners.filter((owner: any) => owner.owner_type !== "corporate");;
        if(this.OwnerRef && this.OwnerBackendUser && this.owners){
          this.owners.forEach(a => {
            let owner_data  = a;
            let owner_ref = this.OwnerRef.find(owner =>  owner.owner_id === owner_data?._id);
            let owner_CreatedBy = this.OwnerBackendUser.find(owner =>  owner.id === owner_ref?.backend_user_id);
            if(owner_ref && owner_CreatedBy){
              owner_data.owner_CreatedBy = owner_CreatedBy?.name
              owner_data.OwnerCreatedAt = owner_ref?.updated_at
              owner_data.OwnerRefID = owner_ref?.response?.analysis_id,
              owner_data.OwnerRefMainID = owner_ref?._id,
              owner_data.doc_id = owner_ref?.ref_id,
              this.owners.push(...owner_data)
            }
          });
        }
        this.loading = isOpen;
      }))
      

    }
  }
  getBusinessReference(isOpen){
    this.isBusinessOwner = '';
    this.businessFinancialRef = this.applicationData?.business_references.find(
      (ref :any) => ref.type === 'business_financial'
    );
    if(isOpen && this.businessFinancialRef) {
      this.isEdit = true;
      this.CreatedAt= new Date(this.businessFinancialRef.updated_at * 1000);
      this.response=this.businessFinancialRef?.response.action;   
      let params={ 
        slug: CONSTANTS.SLUG['business_financial'],
        analysis_id: this.businessFinancialRef.response.analysis_id,
        backend_user_id: this.businessFinancialRef.backend_user_id
      }
     this.taskInfoService.getTaskInfo({...params}).subscribe((response) => {
       this.backendUser=response?.response_data?.get_backend_user_by_id?.data?.data?.name;
    });
  }
  if(isOpen){
    this.taskInfoService.
    getTaskInfo({slug: CONSTANTS.SLUG['get_owner_reference'], app_id:this.appId, type: 'business_financial'})
    .subscribe((response => {
      this.OwnerRef = response?.response_data?.get_owner_references?.data?.data;
      this.OwnerBackendUser = response?.response_data?.get_backend_user_for_owner?.data?.data;
      this.businessowners = this.applicationData.owners.filter((owner: any) => owner.owner_type === "corporate");
      if(this.OwnerRef && this.OwnerBackendUser && this.businessowners){
        this.businessowners.forEach(a => {
          let owner_data  = a;
          let owner_ref = this.OwnerRef.find(owner =>  owner.owner_id === owner_data?._id);
          let owner_CreatedBy = this.OwnerBackendUser.find(owner =>  owner.id === owner_ref?.backend_user_id);
          if(owner_ref && owner_CreatedBy){
            owner_data.owner_CreatedBy = owner_CreatedBy?.name
            owner_data.OwnerCreatedAt = owner_ref?.updated_at
            owner_data.OwnerRefID = owner_ref?.response.analysis_id,
            owner_data.OwnerRefMainID = owner_ref?._id,
            owner_data.doc_id = owner_ref?.ref_id,
            this.businessowners.push(...owner_data)
          }
        });
      }
    }))
   }
  }

  editPfForm(owner) {
    let editedownerDetails= {
      'owner_type': owner?.owner_type, 
      'owner_id': owner?._id, 
      'analysis_id': owner?.OwnerRefID, 
      'ref_mainid': owner?.OwnerRefMainID, 
      'owner_name': owner?.businessname ? owner?.businessname : `${owner?.first_name}${owner.middle_name? (' '+owner.middle_name+' ') :' '}${owner?.last_name}` 
    }
    if(owner.owner_type === 'individual'){
      this.store.dispatch(addAppDetails({appData: { ...this.appData, OwnerRef: editedownerDetails }}));
      this.common.navigate('personal-financial');
    }
    else{
      this.store.dispatch(addAppDetails({appData: { ...this.appData, businessOwnerRef: editedownerDetails }}));
      this.common.navigate('business-financial');
    }
   
  }

  editForm() {
    this.store.dispatch(addAppDetails({appData: { ...this.appData, businessRef: this.businessFinancialRef }}));
    this.common.navigate('business-financial');
  }
  generateBusinessFinance() {
    this.common.navigate('business-financial');
  }

  generatePersonalFinance(owner) {
    if(owner.owner_type === "individual"){
      let ownerDetails= {
        'owner_type': owner?.owner_type, 
        'owner_id': owner?._id, 
        'owner_name':`${owner?.first_name}${owner.middle_name?' '+owner.middle_name+' ':' '}${owner?.last_name}` 
      }
      this.store.dispatch(addAppDetails({appData: { ...this.appData, pfOwner: ownerDetails }}));
      this.common.navigate('personal-financial');
    }
    else{
      let businessOwnerDetails= {
      'owner_type': owner?.owner_type,
       'owner_id': owner?._id, 
       'business_name': owner?.businessname
      }
      this.store.dispatch(addAppDetails({appData: { ...this.appData, businessOwner: businessOwnerDetails }}));
      this.common.navigate('business-financial');
    }
  }

  generateGdscr() {
    this.common.navigate('gdscr')
  }

  getGdscrInfo(event) {
    if (event) {
      this.downloadPdf = false;
      let params = {
        slug: CONSTANTS.SLUG['gdscr'],
        app_id: this.appId, 
        type: 'gdscr'
      }
      this.taskInfoService.getTaskInfo(params).subscribe(response => {
        let responseData = response?.response_data?.get_analysis_data?.data?.data;
        if (responseData && responseData.length > 0) {
          this.gdscrData = responseData[0];
          let backendUserData = response?.response_data?.get_backend_user_by_analysis?.data?.data;
          if (backendUserData && backendUserData.length > 0) {
            this.gdscrCreatedData = backendUserData[0];
            this.gdscrCreatedData['gdscrCreatedOn'] =  responseData[0].updated_at;
          }
        }
      })
    }
  }

  downloadGdscr() {
    this.downloadPdf = true;
  }

 
  downloadBusinessForm() {   
    let payload = {doc_id: this.businessFinancialRef?.ref_id};
    this.taskInfoService.saveTaskInfo({slug: 'download_pdf'}, payload).subscribe((data) => {
      if (data?.download_document?.data)
        this.download.showPdf(data.download_document.data, `${this.appData?.business_name}_${this.loanId}_business_financial.pdf`);
    })
  }

  downloadOwnerForm(doc_id,pdfSuffix,ownerName){
    let payload = {doc_id: doc_id};
      this.taskInfoService.saveTaskInfo({slug: 'download_pdf'}, payload).subscribe((data) => {
        if (data?.download_document?.data)
          this.download.showPdf(data.download_document.data, `${ownerName}_${this.loanId}${pdfSuffix}`);
      })
  }


  
 
}
