import {Component, Input, OnInit, Inject } from '@angular/core';

@Component({
  selector: 'business-financial-pdf',
  templateUrl: './business-financial-pdf.component.html',
  styleUrls: ['./business-financial-pdf.component.scss']
})
export class BusinessFinancialPdfComponent implements OnInit {
 @Input() pdfData:any;
 @Input() business_name: string;
 @Input() loan_id: string;
 logo1_path: string;
 logo2_path: string;
 year: any[] = []

  constructor(
    @Inject('environment') public environment
  ) { }

  ngOnInit(): void {
    this.logo1_path = this.environment.logo1_path;
    this.logo2_path = this.environment.logo2_path;
  
    this.pdfData.forEach((item,index) => {
       if(Object.keys(item)[0] !== "comment"){
         this.year.push(Number(item['year']))
         this.checkAddMoreTotal(item, index);
       }    
    })
    this.pdfData.sort( this.compare );
  }


  
  compare( a, b ) {
    if ( a.year < b.year ){
      return -1;
    }
    if (  a.year > b.year ){
      return 1;
    }
    return 0;
  }

  checkAddMoreTotal(data, index) {
    for (const value of data.data.adjustments) {
      if(value.adjustment_value && value.adjustment_value !== '') {
        // this.pdfData[index].data.data.edita_group['total_value'] = true
        this.pdfData[index].data.edita_group['total_value'] = true
        break;
      }
    }
    for (const value of data.data.new_purpose_debt_l) {
      if(value.new_purpose_debt_value && value.new_purpose_debt_value !== '') {
        // this.pdfData[index].data.data.other_debts_group_m['total_value_1'] = true
        this.pdfData[index].data.other_debts_group_m['total_value_1'] = true
        break;
      }
    }
    for (const value of data.data.sensitised_proposed_debt_l) {
      if(value.sensitised_proposed_debt_value && value.sensitised_proposed_debt_value !== '') {
        // this.pdfData[index].data.data.other_debts_group_m['total_value_2'] = true
        this.pdfData[index].data.other_debts_group_m['total_value_2'] = true
        break;
      }
    }
    for (const value of data.data.other_debt_l) {
      if(value.other_debt_value && value.other_debt_value !== '') {
        // this.pdfData[index].data.data.total_other_debt_m['total_value_3'] = true
        this.pdfData[index].data.other_debts_group_m['total_value_3'] = true
        break;
      }
    }
  }
}
