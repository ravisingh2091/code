import { Component, OnInit, Input, Inject } from '@angular/core';

@Component({
  selector: 'personal-financial-pdf',
  templateUrl: './personal-financial-pdf.component.html',
  styleUrls: ['./personal-financial-pdf.component.scss']
})
export class PersonalFinancialPdfComponent implements OnInit {
  @Input() pdfData: any;
  @Input() owner_name: string;
  @Input() loan_id: string;
  year: any[] = []
  checkCount = 0;
  logo1_path: string;
  logo2_path: string;

  constructor(
    @Inject('environment') public environment 
    ) { }

  ngOnInit(): void {
    this.logo1_path = this.environment.logo1_path;
    this.logo2_path = this.environment.logo2_path;
  
    this.pdfData.forEach((item,index) => {
      if(Object.keys(item)[0] !== "comment"){
        this.year.push(Number(item['year']))
        this.checkAddMoreTotal(item, index);
      }    
   })
    this.pdfData.sort( this.compare );
 }
 
 compare( a, b ) {
  if ( a.year < b.year ){
    return -1;
  }
  if (  a.year > b.year ){
    return 1;
  }
  return 0;
}

checkAddMoreTotal(data, index) {
  for (const value of data.data.adjustments) {
    if(value.adjustment_value && value.adjustment_value !== '') {
      // this.pdfData[index].data.data.gross_cash_flow_group['total_value'] = true
      this.pdfData[index].data.gross_cash_flow_group['total_value'] = true
      break;
    }
  }
  for (const value of data.data.existing_debt) {
    if(value.existing_debt_value && value.existing_debt_value !== '') {
      // this.pdfData[index].data.data.other_existing['total_value_1'] = true
      this.pdfData[index].data.other_existing['total_value_1'] = true
      break;
    }
  }
}

}
