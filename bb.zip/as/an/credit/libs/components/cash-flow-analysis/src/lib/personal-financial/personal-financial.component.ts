import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormArray } from '@angular/forms';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { TaskInfoService, FormGenerateService, addAppDetails, CommonService } from '@rubicon/utils';
import { debounceTime, distinctUntilChanged, skip, switchMap, take } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { of, timer } from 'rxjs';

@Component({
  selector: 'personal-financial',
  templateUrl: './personal-financial.component.html',
  styleUrls: ['./personal-financial.component.scss']
})
export class PersonalFinancialComponent implements OnInit {
  pfConfig: any;
  commentConfig: any;
  pfForm1: any = [];
  pfForm2: any = [];
  pfForm3: any = [];
  pfForm4: any = [];
  commentForm: any = [];
  years:  any[] = [];
  slug: String;
  appId : String;
  ownerData: any;
  userData: any;
  businessId: String;
  forAddMoreGroup = [];
  personalRefData: any;
  commentSlug: String;
  personalFinanceData: any;
  appData: any;
  owner_name : string;
  ownerPdfData : any;
  loan_id: any;
  @ViewChild("pdfContent1") GeneratePDFComponent1: ElementRef<any>;

  constructor(private taskInfoService: TaskInfoService,
              private formGenerateService: FormGenerateService,  
              private store: Store<any>,
              private common : CommonService
              ) { }
                         
ngOnInit(): void {
  this.store.select('app').pipe(take(1)).subscribe(rootState => {      
    this.appData = {...rootState?.appData};
    this.ownerData = rootState?.appData?.pfOwner; 
    this.appId = rootState.appID;
    this.businessId = rootState.businessID;
    this.userData = rootState.userData;
    this.personalRefData = rootState?.appData?.OwnerRef;
    this.loan_id = rootState?.appData?.loan_id;
    this.owner_name = this.ownerData ? this.ownerData?.owner_name: this.personalRefData.owner_name;
    // this.PersonalFinancialRef = rootState?.appData?.businessRef;
  }); 

  
  this.taskInfoService.getTaskInfo({slug:'cashflow_comment'}).subscribe(response => {
    this.commentConfig = response.form_fields;
    this.commentForm = this.formGenerateService.createControl(this.commentConfig);
    this.commentSlug = response.task_slug
  })
 
    let params= { 
      slug: CONSTANTS.SLUG['personal_financial'], 
      analysis_id: this.personalRefData?.analysis_id,
    }      

  this.taskInfoService.getTaskInfo(this.personalRefData? {...params} : {slug:CONSTANTS.SLUG['personal_financial']})
  .subscribe(response => {
    this.pfConfig = response.form_fields;
    response.form_fields.forEach(field =>{
      if(field?.config?.relatedGrp){
        let details = { value: field.name, relatedGroup: field.config.relatedGrp}
        this.forAddMoreGroup.push(details);
      }
    })

    this.store.select('app').pipe(take(1)).subscribe(rootState => {      
      let storeAppData = {
        ...rootState?.appData,
        addMoreData: this.forAddMoreGroup
      }
      this.store.dispatch(addAppDetails({appData:storeAppData}));
    }); 

    this.personalFinanceData = response?.response_data?.get_analysis_data?.data?.data[0]        
    this.pfForm1 = this.formGenerateService.createControl(this.pfConfig);
    this.pfForm2 = this.formGenerateService.createControl(this.pfConfig);
    this.pfForm3 = this.formGenerateService.createControl(this.pfConfig);
    this.pfForm4 = this.formGenerateService.createControl(this.pfConfig);
    this.slug = response.task_slug;

    for (let i = 3; i >= 0; i--) {
      this.years.push((new Date().getFullYear()) - i);
    }

    if (this.personalFinanceData) {
      this.personalFinanceData?.form_data?.forEach((financial) => {
        if (financial.year) {
          this.years.forEach((main_business_year, index) => {
            let formData = `pfForm${index+1}`;
            if (financial.year === main_business_year) { 
              this.formGenerateService.setFormValues(this[formData], financial.data);
            }
          })
        } else if (financial.comment) {
        this.formGenerateService.setFormValues(this.commentForm, financial);
      }
    })
  }
            
    this.forAddMoreGroup.forEach(addMoreGrp => {
      this.pfForm4.controls[addMoreGrp.value].valueChanges.pipe(debounceTime(500),distinctUntilChanged()).subscribe(data => {
                      const formArray = this.pfForm1.get(addMoreGrp.relatedGroup) as FormArray;
                      const formArray2 = this.pfForm2.get(addMoreGrp.relatedGroup) as FormArray;
                      const formArray3 = this.pfForm3.get(addMoreGrp.relatedGroup) as FormArray;
                      const formArray4 = this.pfForm4.get(addMoreGrp.relatedGroup) as FormArray;
                      let type = (this.pfForm4.controls[addMoreGrp.value].value).split('_')[0];
                      let value = (this.pfForm4.controls[addMoreGrp.value].value).split('_')[1];
                      if( type === 'add') {
                        let group_fields = response.form_fields.find(field => field.name === addMoreGrp.relatedGroup)?.group_fields;
                        formArray.push(this.formGenerateService.createControl(group_fields));
                        formArray2.push(this.formGenerateService.createControl(group_fields));
                        formArray3.push(this.formGenerateService.createControl(group_fields));
                        formArray4.push(this.formGenerateService.createControl(group_fields));
                      } else {
                        let len = formArray.length;
                        if (len === 1) {
              
                        } else {
                          formArray.removeAt(value);
                          formArray2.removeAt(value);
                          formArray3.removeAt(value);
                          formArray4.removeAt(value);
                        }
                      }
                    }) 
    })
  })
}


onBack(){
  this.common.navigate('underWriting');
}
onSubmit(action){
  let PersonalFinancialOwner = [];
  this.years.forEach((ele,ind) => {
    let formData = `pfForm${ind+1}`
    this.forAddMoreGroup.forEach(item => {
      this[formData].removeControl(item['value'])
    });;
    PersonalFinancialOwner.push({year: ele, data: this[formData].getRawValue()});
  })
  PersonalFinancialOwner.push({'comment': this.commentForm.get('comment').value})
  this.ownerPdfData = PersonalFinancialOwner;
  timer(500).pipe(switchMap(res => {
    
    let payload={
      app_id:this.appId,
      backend_user_id:this.userData.user_id,
      user_id: this.appData?.user_id,
      action_type: action,
      form_data: PersonalFinancialOwner,
      type:'personal_financial',
      owner_id: this.ownerData?.owner_id,
      owner_type : this.ownerData?.owner_type
    };

    let params={
      slug:CONSTANTS.SLUG['personal_financial']
    }
      //on updating
    if(this.personalRefData){
      params['analysis_id']=this.personalRefData.analysis_id;
    }
    return this.taskInfoService.saveTaskInfo({ ...params }, payload)
  }),

  switchMap((res => {
    let analysis_id = this.personalRefData ? res.update_cash_flow_form.data.data._id : res.post_cash_flow_forms.data.data._id;
    if(analysis_id){
      
    let payload = {
      ...this.getPdfData(),
      response_to_saved : {action : action, analysis_id: analysis_id},
      app_id:this.appId,
      backend_user_id:this.userData.user_id,
      user_id: this.appData?.user_id,
      type:'personal_financial',
      provider: '5d53fe9fc82e7f05bca235fb',
      owner_id: this.ownerData ? this.ownerData?.owner_id: this.personalRefData.owner_id
    };

    if(this.personalRefData){
      payload['ref_mainid']=this.personalRefData.ref_mainid;
    }
    return this.taskInfoService.saveTaskInfo({slug:CONSTANTS.SLUG['personal_financial_pdf']}, payload)
   }
  }))
  
  ).subscribe(response => {
    if (this.personalRefData) {
      this.common.popToast('success', 'Success', "Personal Financial information updated successfully.");
    } else {
      if (action === 'Save') {
        this.common.popToast('success', 'Success', "Personal Financial information saved successfully.");
      } else {
        this.common.popToast('success', 'Success', "Personal Financial information submitted successfully.");
      }
    }
    this.updateActivityLog();
    this.onBack();
  })

}

getPdfData() {
  let body = [];
      body.push({
        content: this.GeneratePDFComponent1.nativeElement.innerHTML,
        style: `
         body {-webkit-print-color-adjust: exact!important;}
        @media all {
          .page-break {
              display: none;
          }
      }
      
      @media print {
          .page-break {
              display: block;
              page-break-before: always;
          }
      }
      
      body {
          color: #000;
          font-family: Arial, Helvetica, sans-serif;
          font-style: normal;
          font-size: 8pt;
          line-height: 23px;
          margin-bottom: 0;
          margin-top: 0;
      }
      
      .clear {
          margin: 0;
          padding: 0;
          height: 0;
          clear: both;
      }
      
      div,
      p,
      li,
      ul,
      span,
      td,
      th,
      a {
          margin: 0;
          padding: 0;
      }
      
      p {
          padding-bottom: 6px;
      }
      
      .wraperPage {
          width: 100%;
          margin: 10px auto;
      }
      .pfsText{
          font-size:25px; font-weight:600;text-align: right;
      }
      .nameText {
        font-size:20px; font-weight:600;text-align: right;
      }
      .newPage {
          width: 100%;
          display: block;
      }
      
      .wrap {
          width: 100%;
          padding-bottom: 5px;
      }
      .fwb {font-weight: 700 !important;} 
      .wrap {
          width: 100%;
          display: inline-block;
          margin-bottom: 2px;
      }
      
      input[type="checkbox"] {
          margin: 0;
          padding: 2px;
      }
      
      input[type="text"] {
          margin: 0;
          padding: 1px 1%;
          width: 98%;
          border: 0;
          background: none
      }
      
      
      
      tr,
      td,
      ul {
          padding: 0;
          margin: 0;
          line-height: 13px;
      }
      
      
      .lebelText {
          font-size: 8px;
          color: #333;
          text-align: left;
          font-weight: bold;
          padding-bottom: 5px;
      }
      
      .valueText {
          font-size: 9px;
          color: #333;
          text-align: left;
          font-weight: normal;
          padding-bottom: 5px;
      }
      
      
      
      .table {
      width: 100%;
      margin-bottom: 1rem;
      color: #212529;border-collapse: collapse;
      }
      .GreenBgTitle{color: #000;
      text-align: left;
      font-size: 13px;
      font-weight: bold;
      padding: 15px 10px;
      margin-top: 20px;
      background: rgba(42, 81, 53, 0.1);}
      .subTitle{color: #2a5135;
      text-align: left;
      font-size: 20px;
      font-weight: bold;
      padding: 15px 0;
      border-bottom:1px solid #2a5135;}
      .subTitle2{color: #2a5135;
      text-align: left;
      font-size: 14px;
      font-weight: bold;
      padding: 15px 0;}
      .table tr td:first-child,.table tr th:first-child {
      padding-left: 0;
      }
      .table tr td:last-child,.table tr th:last-child {
      padding-right: 0;
      }
      .table td,.table th {
      color: #2a5135;
      border-color: #2a5135;
      vertical-align: middle;
      font-size: 12px;padding: 15px 10px;
      font-weight: 500;}
      .table th{font-weight:bold;}
      .ogText td{ border-top:2px solid #ddd; padding-top:30px;}
      .ogText .lebelText, .ogText .valueText{ font-size:10px; color:#2a5135} 
      .tr{ text-align:right;}
      .logoText td{ padding-bottom:10px;}
      
      
      .mb-40{margin-bottom:40px;}
      .border-bottom{border-bottom:1px solid #666; padding-bottom: 5px;}
      .border-bottom1{border-bottom:1px solid #666; }
      .text-center{text-align: center;}
      .adjust-span{position: relative; top: -9px;}
      .border-bottom-adjust{border-bottom:1px solid #666; padding-bottom: 5px;}
      .border-bottom-ajust-val{border-bottom:1px solid #666; padding-bottom: 5px; min-height: 30px;  padding-top: 10px;}
      `,
      doc_type_id : "60fd0c8ea305adb36dc44b07",
      doc_type_key : "personal_financial_pdf",
      filename : this.loan_id+'_personal_financial.pdf',
      loan_id : this.loan_id
      });
      return body[0];   
}

ngOnDestroy() {
  if (this.ownerData) {
    delete this.appData.pfOwner;
    this.store.dispatch(addAppDetails({appData: {...this.appData}}));
  }
  if(this.personalRefData) {
    delete this.appData.OwnerRef;
    this.store.dispatch(addAppDetails({appData: {...this.appData}}));
  }
}

updateActivityLog() {
  let activityData = {
    role_slug: this.userData.role_slug,
    app_id: this.appId,
    backend_user_id: this.userData.user_id,
    user_name: this.userData.full_name,
    activity: `personal_financial_upadated`,
    note: this.ownerData ? this.ownerData?.owner_name: this.personalRefData.owner_name
  };
  this.common.addActivityLog(activityData);
}
}
