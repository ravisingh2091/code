import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { CommonService, FormGenerateService, TaskInfoService } from '@rubicon/utils';
import { take } from 'rxjs/operators';

@Component({
  selector: 'gdscr',
  templateUrl: './gdscr.component.html',
  styleUrls: ['./gdscr.component.scss']
})
export class GdscrComponent implements OnInit {
  gdscrConfig = [];
  slug: string;
  loading = true;
  gdscrForm1: FormGroup;
  gdscrForm2: FormGroup;
  gdscrForm3: FormGroup;
  gdscrForm4: FormGroup;
  years = [];
  commentForm: any = [];
  commentConfig: any;
  commentSlug: String;
  appID: String;
  appData: any;
  businessID: string;
  userData: any;
  gdscrRefID: string;
  businessFinancialData = [];
  personalFinancialData = [];
  main_business = [];
  constructor(
    private taskInfoService: TaskInfoService,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private commonService: CommonService
  ) { }

  // There is no business references for GDSCR. Get data directly from analysis collection. 

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {      
      this.appData = {...rootState?.appData};
      this.appID = rootState.appID;
      this.businessID = rootState.businessID;
      this.userData = rootState.userData;
    }); 

    this.taskInfoService.getTaskInfo({slug:'cashflow_comment'}).subscribe(response => {
      this.commentConfig = response.form_fields;
      this.commentForm = this.formGenerate.createControl(this.commentConfig);
      this.commentSlug = response.task_slug;
    })

    let params = {
      slug: CONSTANTS.SLUG['gdscr'],
      app_id: this.appID
    }
    this.taskInfoService.getTaskInfo(params).subscribe(response => {
      this.gdscrConfig = response.form_fields;
      this.slug = response.task_slug;
      this.gdscrForm1 = this.formGenerate.createControl(this.gdscrConfig);
      this.gdscrForm2 = this.formGenerate.createControl(this.gdscrConfig);
      this.gdscrForm3 = this.formGenerate.createControl(this.gdscrConfig);
      this.gdscrForm4 = this.formGenerate.createControl(this.gdscrConfig);
      let responseData = response?.response_data?.get_analysis_data?.data?.data;
      let gdscrData = (responseData?.find(({type}) => type === 'gdscr' ));
      if (gdscrData) {
        this.gdscrRefID = gdscrData._id;
        this.commentForm.patchValue({comment : (gdscrData.form_data.find(({comment}) => comment))?.comment} );
      }
      for (let i = 3; i >= 0; i--) {
        this.years.push((new Date()).getFullYear() - i);
      }
      if (responseData && responseData.length > 0) {
        responseData.forEach((data, index) => {
          if (data.type === "personal_financial" || data.type === 'business_financial') {
            data.form_data.forEach(formData =>{
              data[formData.year] = formData.data
            })
            if (data.type === 'business_financial') {
              data?.owner_id  ? this.businessFinancialData.push(data) : this.main_business.push(data);
            } else if (data.type === 'personal_financial') {
              this.personalFinancialData.push(data);
            }
            delete responseData[index].form_data;
          }
        })
        this.calculatedValue('businessFinancialData',['edita_group', 'edita_group','other_debts_group_m'], ['ebitda', 'ebida', 'total_debt_m'], ['related_cash_available_debt_ebitda','related_cash_available_debt_ebida','related_existing_debt_service']);
        this.calculatedValue('personalFinancialData',['less', 'less','other_existing'],['available_debt', 'available_debt', 'total_debt'], ['personal_cash_available_total_1','personal_cash_available_total_2','personal_debt_of_all_guarantors']);
        this.calculatedValue('main_business',['edita_group', 'edita_group', 'other_debts_group_m'],['ebitda', 'ebida', 'total_npd'],['primary_cash_available_debt_ebitda','primary_cash_available_debt_ebida', 'proposed_debt_service']);

        this.moreValues('main_business','other_debts_group_m','total_other_debt_m', 'cpltd_group', 'cpltd','primary_existing_debt_service',);

        this.calculationOwnGroup(["primary_cash_available_debt_ebitda","related_cash_available_debt_ebitda","personal_cash_available_total_1"], "actual_global_available_cash_ebitda");
        this.calculationOwnGroup(['primary_cash_available_debt_ebida', 'related_cash_available_debt_ebida', 'personal_cash_available_total_2'],'actual_global_available_cash_ebida');
        this.calculationOwnGroup(["primary_existing_debt_service","proposed_debt_service","related_existing_debt_service"
        ,"personal_debt_of_all_guarantors"],'total_debt_service');

        this.calculationValue('subtract', 'actual_global_available_cash_ebitda', 'total_debt_service', 'ngcf_ebitda');
        this.calculationValue('subtract', 'actual_global_available_cash_ebida', 'total_debt_service', 'ngcf_ebida');
        this.calculationValue('divide', 'actual_global_available_cash_ebitda', 'total_debt_service',  'dti_ebitda', true);
        this.calculationValue('divide', 'actual_global_available_cash_ebida', 'total_debt_service', 'dti_ebida', true);
        this.calculationValue('divide', 'actual_global_available_cash_ebitda', 'total_debt_service', 'gdscr_ebitda');
        this.calculationValue('divide', 'actual_global_available_cash_ebida', 'total_debt_service', 'gdscr_ebida');
      }
    })
  }

  calculatedValue(arrayName: string, groups: string[], fields: string[], keys: string[]) {
    this.years.forEach((main_business_year, index) => {
        let result1 = 0;
        let result2 = 0;
        let result3 = 0;
        let anyInputValue1 = [];
        let anyInputValue2 = [];
        let anyInputValue3 = [];
        this[arrayName]?.forEach((financial) => {
            let val = financial[main_business_year];
            if(val) {
              if(val[groups[0]]) {
                val[groups[0]][fields[0]] ? anyInputValue1.push(true) : anyInputValue1.push(false);
                result1 += parseInt(val[groups[0]][fields[0]]);
              }
              if (val[groups[1]]) {
                val[groups[1]][fields[1]] ? anyInputValue2.push(true) : anyInputValue2.push(false);
                result2 += parseInt(val[groups[1]][fields[1]]);
              }
              if (val[groups[2]]) {
                val[groups[2]][fields[2]] ? anyInputValue3.push(true) : anyInputValue2.push(false);
                result3 += parseInt(val[groups[2]][fields[2]]);
              }
            }
        })
        let dynFormGroup = `gdscrForm${index+1}`;
        if(anyInputValue1.every(val => val === false )){
          this[dynFormGroup].get(keys[0]).setValue('', { emitEvent: false});
        } else {
          this[dynFormGroup].get(keys[0]).setValue(result1, { emitEvent: false}); 
        }
        if(anyInputValue2.every(val => val === false )){
          this[dynFormGroup].get(keys[1]).setValue('', { emitEvent: false});
        } else {
          this[dynFormGroup].get(keys[1]).setValue(result2, { emitEvent: false}); 
        }
        if(anyInputValue3.every(val => val === false )){
          this[dynFormGroup].get(keys[2]).setValue('', { emitEvent: false});
        } else {
          this[dynFormGroup].get(keys[2]).setValue(result3, { emitEvent: false}); 
        }
    })
  }

  moreValues(arrayName: string, grp1: string, key1: string, grp2: string, key2: string, calculatingkey: string) {
    this.years.forEach((main_business_year, index) => {
      let result = 0;
      let anyInputValue = [];
      this[arrayName]?.forEach((financial) => {
        let val = financial[main_business_year];
        if (val) {
          val[grp1][key1] ? anyInputValue.push(true) : anyInputValue.push(false);
          val[grp2][key2] ? anyInputValue.push(true) : anyInputValue.push(false);
          result = parseInt(val[grp1][key1]) + parseInt(val[grp2][key2]);
        }
      })
      let dynFormGroup = `gdscrForm${index+1}`;
      if(anyInputValue.every(val => val === false )){
        this[dynFormGroup].get(calculatingkey).setValue('', { emitEvent: false});
      } else {
        this[dynFormGroup].get(calculatingkey).setValue(result, { emitEvent: false}); 
      }
    })
  }

  calculationOwnGroup(keysArrayForCalculation, calculatingkey ) {
    this.years.forEach((main_business_year, index) => {
      let dynFormGroup = `gdscrForm${index+1}`;
      let anyInputValue = [];
      let value;
        let result = keysArrayForCalculation.reduce((sum: any, item) => {
          value = this[dynFormGroup].get(item).value;
          anyInputValue.push(value ? true : false);
          if (value) {
            return parseInt(value) + parseInt(sum);
          } else {
            return parseInt(sum);
          }
          
          }, 0);
            if(anyInputValue.every(val => val === false )){
              this[dynFormGroup].get(calculatingkey).setValue('', { emitEvent: false});
            } else {
              this[dynFormGroup].get(calculatingkey).setValue(result, { emitEvent: false}); 
            }
    })
  }

  onSubmit(action: string){
    let gdscrFormData = [];
    this.years.forEach((ele,ind) => {
      let formData = `gdscrForm${ind+1}`;
      gdscrFormData.push({year: ele, data: this[formData].getRawValue()});
    })
    gdscrFormData.push({'comment': this.commentForm.get('comment').value})
    let payload= {
      app_id:this.appID,
      backend_user_id:this.userData.user_id,
      user_id: this.appData?.user_id,
      business_id:this.businessID,
      action_type: action,
      form_data: gdscrFormData,
      type:'gdscr'
    };
    let params={
      slug:CONSTANTS.SLUG['gdscr'],
    }
    if(this.gdscrRefID) {
      params['analysis_id']=this.gdscrRefID;
    }
  
    this.taskInfoService.saveTaskInfo(params, payload).subscribe(response => {
      if (this.gdscrRefID) {
        this.commonService.popToast('success', 'Success', "Global Debt Service Coverage Ratio information updated successfully.");
      } else {
        if (action === 'save') {
          this.commonService.popToast('success', 'Success', "Global Debt Service Coverage Ratio information saved successfully.");
        } else {
          this.commonService.popToast('success', 'Success', "Global Debt Service Coverage Ratio information submitted successfully.");
        } 
      }
      this.updateActivityLog();
      this.onBack();
    })
  }

  compare( a, b ) {
    if ( a.year < b.year ){
      return -1;
    }
    if (  a.year > b.year ){
      return 1;
    }
    return 0;
  }

  calculationValue(operation: string, key1: string, key2: string , calculatingkey: string , toFrom?: boolean) {
    this.years.forEach((main_business_year, index) => {
      let dynFormGroup = `gdscrForm${index+1}`; 
      let val1 = this[dynFormGroup].get(key1).value;
      let val2 = this[dynFormGroup].get(key2).value;
      let result: any = '';
      if (operation === 'subtract' && (val1 || val2)) {
        if ((val1 < 0 && val2 < 0) || (val1 > 0 && val2 > 0) || (val1 < 0 && val2 >= 0) || (val1 === 0 && val2 >= 0) || (val1 === 0 && val2 < 0)) {
          result = val1 - val2;
        } else {
          result=  val1 + val2;
        }
      }
      else if (operation === 'divide'&& (val1 && val2)) {
        if(toFrom) {
          result =  (val2 / val1).toFixed(2);
        } else {
          result = (val1 / val2).toFixed(2);
         }
      }
      this[dynFormGroup].get(calculatingkey).setValue(result, { emitEvent: false}); 
    })
  }

  onBack(){
    this.commonService.navigate('underWriting');
  }

  updateActivityLog() {
    let activityData = {
      role_slug: this.userData.role_slug,
      app_id: this.appID,
      backend_user_id: this.userData.user_id,
      user_name: this.userData.full_name,
      activity: `gdscr_financial_upadated`
    };
    this.commonService.addActivityLog(activityData);
  }

}
