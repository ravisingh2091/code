import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { BusinessFinancialComponent } from './business-financial/business-financial.component';
import { PersonalFinancialComponent } from './personal-financial/personal-financial.component';
import { CashFlowComponent } from './cash-flow/cash-flow/cash-flow.component';
import { GdscrComponent } from './gdscr/gdscr.component';
import { BusinessFinancialPdfComponent } from './business-financial-pdf/business-financial-pdf.component';
import { PersonalFinancialPdfComponent } from './personal-financial-pdf/personal-financial-pdf.component';
import { PrefixValuePipe } from 'libs/shared-lazy/src/lib/pipes/prefix-value.pipe';
import { GdscrPdfComponent } from './gdscr-pdf/gdscr-pdf.component';

@NgModule({
  declarations: [
    BusinessFinancialComponent, 
    PersonalFinancialComponent, 
    CashFlowComponent, 
    GdscrComponent, 
    BusinessFinancialPdfComponent, 
    PersonalFinancialPdfComponent,
    GdscrPdfComponent
  ],
  imports: [
    CommonModule,
    SharedLazyModule
    ],
  providers: [
    PrefixValuePipe
  ],
  exports: [
    CashFlowComponent,
    BusinessFinancialComponent, 
    PersonalFinancialComponent, 
    BusinessFinancialPdfComponent,
    GdscrComponent
  ]
})
export class CashFlowAnalysisModule { }
