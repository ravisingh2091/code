import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormArray } from '@angular/forms';
import { addAppDetails, CommonService, FormGenerateService, TaskInfoService } from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { FormGroup } from '@angular/forms';
import { debounceTime, distinctUntilChanged, skip, switchMap, take } from 'rxjs/operators';
import { Store, select } from '@ngrx/store';
import { of, timer } from 'rxjs';

@Component({
  selector: 'business-financial',
  templateUrl: './business-financial.component.html',
  styleUrls: ['./business-financial.component.scss']
})
export class BusinessFinancialComponent implements OnInit,OnDestroy {
  businessFinancialConfig = [];
  slug: string;
  loading = true;
  businessFinancialForm1: FormGroup;
  businessFinancialForm2: FormGroup;
  businessFinancialForm3: FormGroup;
  businessFinancialForm4: FormGroup;
  years = [];
  forAddMoreGroup = [];
  appData: any;
  commentForm: any = [];
  commentConfig: any;
  commentSlug: String;
  appId : String;
  userData: any;
  businessId: String;
  businessFinancialRef : any;
  businessFinancialData: any;
  businessOwnerData: any;
  businessOwnerRef:any;
  business_name: string;
  errorMsg1 = false;
  errorMsg2 = false;
  errorMsg3 = false;
  errorMsg4 = false;
  loan_id: any;
  pdfData : any;
  @ViewChild('pdfContent') GeneratePDFComponent: ElementRef<any>;

  constructor(
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private formGenerate: FormGenerateService,
    private store: Store<any>
  ) { }

  ngOnInit(): void {
    this.taskInfoService.getTaskInfo({slug:'cashflow_comment'}).subscribe(response => {
      this.commentConfig = response.form_fields;
      this.commentForm = this.formGenerate.createControl(this.commentConfig);
      this.commentSlug = response.task_slug;
    })
    this.store.select('app').pipe(take(1)).subscribe(rootState => {      
      this.appData = {...rootState?.appData}; 
      this.appId = rootState.appID;
      this.businessId = rootState.businessID;
      this.userData = rootState.userData;
      this.businessFinancialRef = rootState?.appData?.businessRef;
      this.businessOwnerData = rootState?.appData?.businessOwner;
      this.businessOwnerRef = rootState?.appData?.businessOwnerRef;
      this.loan_id = rootState?.appData.loan_id;
    }); 
    let params = {slug: CONSTANTS.SLUG['business_financial']};
      if(this.businessFinancialRef){
        params['analysis_id'] = this.businessFinancialRef?.response?.analysis_id;
        params['backend_user_id'] = this.businessFinancialRef?.backend_user_id;
        this.business_name = this.appData?.business_name;
      } 
      else if(this.businessOwnerRef){
        params['analysis_id'] = this.businessOwnerRef?.analysis_id;
        params['businessOwner'] = true;
        this.business_name = this.businessOwnerRef.owner_name;
      } 
      else if (this.businessOwnerData) {
        this.business_name = this.businessOwnerData.business_name;
      } 
      else {
        this.business_name = this.appData?.business_name;
      }
    this.taskInfoService.getTaskInfo(params).subscribe(response => {
      this.businessFinancialConfig = response.form_fields;
      this.slug = response.task_slug;
      response.form_fields.forEach(field =>{
        if(field?.config?.relatedGrp){
          let details = { value: field.name, relatedGroup: field.config.relatedGrp}
          this.forAddMoreGroup.push(details);
        }
      })
      this.store.select('app').pipe(take(1)).subscribe(rootState => {      
        let storeAppData = {
          ...rootState?.appData,
          addMoreData: this.forAddMoreGroup
        }
        this.store.dispatch(addAppDetails({appData:storeAppData}));
      });
      this.businessFinancialData = response?.response_data?.get_analysis_data?.data?.data[0]

      this.businessFinancialForm1 = this.formGenerate.createControl(this.businessFinancialConfig);
      this.businessFinancialForm2 = this.formGenerate.createControl(this.businessFinancialConfig);
      this.businessFinancialForm3 = this.formGenerate.createControl(this.businessFinancialConfig);
      this.businessFinancialForm4 = this.formGenerate.createControl(this.businessFinancialConfig);

      for (let i = 3; i >= 0; i--) {
        this.years.push((new Date().getFullYear()) - i);
      }

      if (this.businessFinancialData) {
          this.businessFinancialData?.form_data?.forEach((financial) => {
            if (financial.year) {
              this.years.forEach((main_business_year, index) => {
                let formData = `businessFinancialForm${index+1}`;
                let errorMsg = `errorMsg${index+1}`
                if (financial.year === main_business_year) {
                  let total_assets = financial.data.balance_sheet.total_assets
                  let total_debts_and_shareholder = financial.data.balance_sheet.total_debts_and_shareholder
                  if (total_assets && total_debts_and_shareholder && total_assets !== total_debts_and_shareholder) {
                    this[errorMsg] = true;
                  }
                  this.formGenerate.setFormValues(this[formData], financial.data);
                }
              })
            } else if (financial.comment) {
            this.commentForm.patchValue({comment: financial.comment});
          }
        })
      }
      for (let i=1; i<=4; i++) {
        let formDataKey =`businessFinancialForm${i}`;
        let errorMsg = `errorMsg${i}`
        this[formDataKey].get('balance_sheet').valueChanges.subscribe(data => {
          setTimeout(() => {
            let total_assets = this[formDataKey].controls['balance_sheet'].get('total_assets').value;
            let total_debts_and_shareholder = this[formDataKey].controls['balance_sheet'].get('total_debts_and_shareholder').value;
            if (total_assets && total_debts_and_shareholder && total_assets !== total_debts_and_shareholder) {
              this[errorMsg] = true;
            } else {
              this[errorMsg] = false;
            }
          }, 100) 
        })
      }
      this.forAddMoreGroup.forEach(addMoreGrp => {
        this.businessFinancialForm4.controls[addMoreGrp.value].valueChanges.pipe(debounceTime(100),distinctUntilChanged()).subscribe(data => {
                        const formArray = this.businessFinancialForm1.get(addMoreGrp.relatedGroup) as FormArray;
                        const formArray2 = this.businessFinancialForm2.get(addMoreGrp.relatedGroup) as FormArray;
                        const formArray3 = this.businessFinancialForm3.get(addMoreGrp.relatedGroup) as FormArray;
                        const formArray4 = this.businessFinancialForm4.get(addMoreGrp.relatedGroup) as FormArray;
                        let type = (this.businessFinancialForm4.controls[addMoreGrp.value].value).split('_')[0];
                        let value = (this.businessFinancialForm4.controls[addMoreGrp.value].value).split('_')[1];
                        if( type === 'add') {
                          let group_fields = response.form_fields.find(field => field.name === addMoreGrp.relatedGroup)?.group_fields;
                          formArray.push(this.formGenerate.createControl(group_fields));
                          formArray2.push(this.formGenerate.createControl(group_fields));
                          formArray3.push(this.formGenerate.createControl(group_fields));
                          formArray4.push(this.formGenerate.createControl(group_fields));
                        } else {
                          let len = formArray.length;
                          if(type === 'remove' && len !== 1) {
                            formArray.removeAt(value);
                            formArray2.removeAt(value);
                            formArray3.removeAt(value);
                            formArray4.removeAt(value);
                            this.businessFinancialForm4.controls[addMoreGrp.value].setValue('0');
                          }
                        }
                
              }) 
      })
    })

  }
  onBack(){
    this.common.navigate('underWriting');
  }

  onSubmit(action: string) {
    let businessFinancial = [];
    this.years.forEach((ele,ind) => {
      let formData = `businessFinancialForm${ind+1}`
      this.forAddMoreGroup.forEach(item => {
        this[formData].removeControl(item['value'])
      });
      businessFinancial.push({year : ele, data: this[formData].getRawValue()});
    })
    businessFinancial.push({'comment': this.commentForm.get('comment').value});
    this.pdfData = businessFinancial;
    timer(500).pipe(switchMap(res => {
        let payload={
          app_id:this.appId,
          backend_user_id:this.userData.user_id,
          action_type: action,
          user_id:this.appData?.user_id,
          form_data: businessFinancial,
          business_id: this.businessId,
          type:'business_financial'
        };
        let params={
            slug:CONSTANTS.SLUG['business_financial']
        }
        // on Generate Business Owner 
        if(this.businessOwnerData){
          params['slug']= CONSTANTS.SLUG['personal_financial'];
          payload['owner_id']= this.businessOwnerData?.owner_id;
        }
        //on Edit Business owner
        if(this.businessOwnerRef){
          params['slug']= CONSTANTS.SLUG['personal_financial'];
          params['analysis_id'] = this.businessOwnerRef?.analysis_id;
        }

        //on Edit Business
        if(this.businessFinancialRef){
          params['slug']= CONSTANTS.SLUG['business_financial'];
          params['analysis_id'] = this.businessFinancialRef?.response?.analysis_id;
        }

        return this.taskInfoService.saveTaskInfo({ ...params }, payload)
    }),

    switchMap(res => {
      let analysis_id = res.post_cash_flow_forms ? res.post_cash_flow_forms.data.data._id : res.update_cash_flow_form.data.data._id;
      if(analysis_id){
        let payload={
          app_id:this.appId,
          response_to_saved : {action : action, analysis_id: analysis_id},
          backend_user_id:this.userData.user_id,
          user_id:this.appData?.user_id,
          business_id: this.businessId,
          type:'business_financial',
          provider: '5d53fe9fc82e7f05bca235fa',
          ...this.getBfData()  
        };
        let params = {}

       
       if(this.businessOwnerData){
         // on Generate Business Owner 
        params['slug']= CONSTANTS.SLUG['personal_financial_pdf'];
        payload['owner_id']= this.businessOwnerData?.owner_id;
      }
      else if(this.businessOwnerRef){
        //on Edit Business owner 
        params['slug']= CONSTANTS.SLUG['personal_financial_pdf'];
        payload['ref_mainid']=this.businessOwnerRef.ref_mainid;
        payload['owner_id']= this.businessOwnerRef?.owner_id;
      }
      else if(this.businessFinancialRef){
        //on Edit Business
        params['slug']= CONSTANTS.SLUG['business_financial_pdf'];
        payload['ref_mainid']=this.businessFinancialRef._id;
      }
      else {
        //on Generate business
        params['slug']= CONSTANTS.SLUG['business_financial_pdf'];
      }      
      return this.taskInfoService.saveTaskInfo({...params}, payload)
      }
      //  return of({})
    })
    ).subscribe(response => {
        if (this.businessOwnerRef || this.businessFinancialRef) {
        this.common.popToast('success', 'Success', "Business Financial information updated successfully.");
      } else {
        if (action === 'save') {
          this.common.popToast('success', 'Success', "Business Financial information saved successfully.");
        } else {
          this.common.popToast('success', 'Success', "Business Financial information submitted successfully.");
        }
      }
      this.updateActivityLog(this.business_name);
      this.onBack();
    })
  }

  getBfData(){
    let body = [];
    body.push({
      content: this.GeneratePDFComponent.nativeElement.innerHTML,
      style: `
      body {-webkit-print-color-adjust: exact!important;}
      @media all {
        .page-break {
            display: none;
        }
      }
      
      @media print {
        .page-break {
            display: block;
            page-break-before: always;
        }
      }
      
      body {
        color: #000;
        font-family: Arial, Helvetica, sans-serif;
        font-style: normal;
        font-size: 8pt;
        line-height: 20px;
        margin-bottom: 0;
        margin-top: 0;
      }
      
      .clear {
        margin: 0;
        padding: 0;
        height: 0;
        clear: both;
      }
      
      div,
      p,
      li,
      ul,
      span,
      td,
      th,
      a {
        margin: 0;
        padding: 0;
      }
      
      p {
        padding-bottom: 6px;
      }
      
      .wraperPage {
        width: 100%;
        margin: 10px auto;
      }
      
      .pfsText{
      font-size:25px; font-weight:600;text-align: right;
      }
      .nameText {
        font-size:20px; font-weight:600;text-align: right;
      }
      
      .newPage {
        width: 100%;
        display: block;
      }
      
      .wrap {
        width: 100%;
        padding-bottom: 5px;
      }
      
      .wrap {
        width: 100%;
        display: inline-block;
        margin-bottom: 2px;
      }
      
      input[type="checkbox"] {
        margin: 0;
        padding: 2px;
      }
      
      input[type="text"] {
        margin: 0;
        padding: 1px 1%;
        width: 98%;
        border: 0;
        background: none
      }
      
      tr,
      td,
      ul {
        padding: 0;
        margin: 0;
        line-height: 13px;
      }
      
      
      .lebelText {
        font-size: 8px;
        color: #333;
        text-align: left;
        font-weight: bold;
        padding-bottom: 5px;
      }
      
      .valueText {
        font-size: 12px;
        color: #333;
        text-align: left;
        font-weight: normal;
        padding-bottom: 5px;
      }
      
      .table {
      width: 100%;
      margin-bottom: 1rem;
      color: #212529;border-collapse: collapse;
      }
      .GreenBgTitle{color: #000;
      text-align: left;
      font-size: 10px;
      font-weight: bold;
      padding: 15px 10px;
      margin-top: 20px;
      background: rgba(42, 81, 53, 0.1);}
      .subTitle{color: #2a5135;
      text-align: left;
      font-size: 10px;
      font-weight: bold;
      padding: 15px 0;
      border-bottom:1px solid #2a5135;}
      .subTitle2{color: #2a5135;
      text-align: left;
      font-size: 14px;
      font-weight: bold;
      padding: 15px 0;}
      .table tr td:first-child,.table tr th:first-child {
      padding-left: 0;
      }
      .table tr td:last-child,.table tr th:last-child {
      padding-right: 0;
      }
      .table td,.table th {
      color: #2a5135;
      border-color: #2a5135;
      vertical-align: middle;
      font-size: 12px;padding: 15px 10px;
      font-weight: 500;}
      .table th{font-weight:bold;}
      .ogText td{ border-top:2px solid #ddd; padding-top:30px;}
      .ogText .lebelText, .ogText .valueText{ font-size:10px; color:#2a5135} 
      .tr{ text-align:right;}
      .logoText td{ padding-bottom:10px;}
      
      .fwb {font-weight: 700 !important;}
      .mb-40{margin-bottom:40px;}
      .border-bottom{border-bottom:1px solid #666; padding-bottom: 5px; min-height: 15px; }
      .border-bottom1{border-bottom:1px solid #666; }
      .text-center{text-align: center;}
      .adjust-span{position: relative; top: -9px;}
      .border-bottom-adjust{border-bottom:1px solid #666; padding-bottom: 5px;}
      .border-bottom-ajust-val{border-bottom:1px solid #666; padding-bottom: 5px; min-height: 30px;  line-height: 10px;}
    `,
      doc_type_id : "60fd0c8ea305adb36dc44b06",
      doc_type_key : "business_financial_pdf",
      filename : this.loan_id+'_business_financial.pdf',
      loan_id : this.loan_id
    });
    return body[0];   
  }

  ngOnDestroy() {
    if (this.businessFinancialRef) {
      delete this.appData.businessRef;
      this.store.dispatch(addAppDetails({appData: {...this.appData}}));
    }
     if(this.businessOwnerData) {
      delete this.appData.businessOwner;
      this.store.dispatch(addAppDetails({appData: {...this.appData}}));
    }
    if(this.businessOwnerRef){
      delete this.appData.businessOwnerRef;
      this.store.dispatch(addAppDetails({appData: {...this.appData}}));
    }
  }

  updateActivityLog(owner_name) {
    let activityData = {
      role_slug: this.userData.role_slug,
      app_id: this.appId,
      backend_user_id: this.userData.user_id,
      user_name: this.userData.full_name,
      activity: `business_financial_upadated`,
      note: owner_name
    };
    this.common.addActivityLog(activityData);
  }
}
