export * from './lib/terms-and-conditions.module';
