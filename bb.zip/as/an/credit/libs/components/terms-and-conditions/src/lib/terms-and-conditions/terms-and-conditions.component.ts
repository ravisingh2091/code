import { Component, OnInit, EventEmitter, Output, Inject } from '@angular/core';

@Component({
  selector: 'terms-and-conditions',
  templateUrl: './terms-and-conditions.component.html',
  styleUrls: ['./terms-and-conditions.component.scss']
})
export class TermsAndConditionsComponent implements OnInit {
  url: string;
  bankName;

  @Output() closeModal = new EventEmitter<string>();
  @Output() agree = new EventEmitter<string>();
  
  constructor(
    @Inject('CONSTANTS') public CONSTANTS
  ) { }
    
  ngOnInit(): void {
    this.url = this.CONSTANTS.CLIENT_CONFIG.client_url;
    this.bankName = this.CONSTANTS.CLIENT_CONFIG.name;
  }

  submit():void {
    this.agree.emit();
  }

  hideModal():void {
    this.closeModal.emit();
  }

}
