import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TermsAndConditionsComponent } from './terms-and-conditions/terms-and-conditions.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';

@NgModule({
  imports: [CommonModule, SharedLazyModule,],
  declarations: [TermsAndConditionsComponent],
  exports: [TermsAndConditionsComponent]
})
export class TermsAndConditionsModule {}
