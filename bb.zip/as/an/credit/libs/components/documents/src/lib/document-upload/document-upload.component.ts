import { Inject, TemplateRef, OnDestroy } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { addAppDetails, addUserDetails, CommonService, TaskInfoService } from '@rubicon/utils';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';

@Component({
  selector: 'document-upload',
  templateUrl: './document-upload.component.html',
  styleUrls: ['./document-upload.component.scss'],
})
export class DocumentUploadComponent implements OnInit, OnDestroy {
  config = {
    uniqueAccordionKey: 1,
    custom_loader: true,
    accordian_visible: true,
    link_bank_account: {
      key: 'bank_statements',
      btn_name: 'Link bank account',
    },
    backendUserList: [],
    timeZone: 'EDT',
    timeFormat: 'MM-dd-yyyy / h:mm a',
    doc_icon_css: 'common-file d-block mr-2',
    document_count: true,
    accordion_css: {
      label_col_css: 'col-12 col-lg-8',
      label_css: 'pt-2 d-inline-block fs16 fwm',
      upload_col_css: 'col-12 col-lg-4 text-right',
    },
    heading_css: 'fs20 fwb m-0 ptc py-3 pt-lg-4 hideLabel',
    app_id: null,
    user_id: null,
    lead_ref_id: null,
    // provider: '5d53fe9fc82e7f05bca235f1',
    refResponseKey: 'get_manual_bank_statement_reference',
    version: 'v2',
    // yodlee_mail_url: 'https://www.w3schools.com/',
    task: {
      url: this.environment.orchUrl + 'v2/tasks',
      download: {
        params: {
          slug: 'download_document',
        },
      },
      upload: {
        params: {
          slug: 'manual-upload-bank-statements',
          backend_user_id: '',
        },
      },
      params_download_all: {
        slug: 'download_all',
      },
      params_yodlee: {
        slug: 'yodlee_mail_template',
      },
      shareAll: {
        params: {
          slug: 'share-all',
        },
        body: {
          share_all_url: 'https://www.w3schools.com/',
          email_address: '',
          subject: '',
          personal_message: '',
        },
      },
      document_type: {
        params: {
          slug: 'documents',
        },
        headers: {},
        method: 'post',
        body: {
          and: "basic_doc",
          basic_doc: true
        },
        response_key: 'document_type_post',
        no_records: 'No record(s) found',
      },

      delete: {
        params: {
          slug: 'delete-documents',
        },
        method: 'post',
        headers: {},
        body: {
          doc_id: '',
        },
      },

      headers: {
        'x-region': 'usa',
        'x-tenant-id': null,
      },
    },

    urls: {
      //   download_url: 'http://localhost:3007/orchbase/DOCUMENT_API/v1/download/',
      //   upload_url: 'http://localhost:3007/document_upload/document/v1/upload',
      // delete_url: 'http://localhost:3007/orchbase/DOCUMENT_API/v1/delete',
      //   service_ref_url:
      //     'http://localhost:3007/orchbase/CASE_API/v1/service/business',
      //   document_types_url:
      //     'http://localhost:3007/orchbase/MASTER_API_URL/v1/document_type',
    },
    share_all: {
      subject: {
        label: 'Subject (optional)',
        id: 'subject',
      },
      personal_message: {
        label: 'Add a personal message (optional)',
        id: 'personal_message',
      },
      email: {
        label:
          'Enter the e-mail address of the person(s) whom you would like to share with. Separate each e-mail with a comma.',
        id: 'email_address',
      },
    },
    document_listing: {
      response: 'get_uploaded_docs',
    },
    document_button: {
      buttons: {
        upload: true,
        download: true,
        delete: false,
        // download_all : true,
        // share_all : true
      },
      upload: {
        visible: true,
        response: 'manual_doc_upload',
        refResponse: 'manual_bank_statement_reference',
        multiple: true,
        max_file_size: 100,
        name: 'Upload',
        submit_css: 'btn btn-default btn-md',
        submitWrapper_css: 'text-center w-100',
        errorMessage: 'Please select a file.'
      },
      download: {
        visible: true,
        response: 'download_document',
        column_class: 'fa downloadIcon fa-lg float-right ml-20',
        css: {
          border: '0',
        },
      },
      delete: {
        title: '',
        confirmationPopup: true,
        text: 'Are you sure, you want to delete this file?',
        submit_css: 'btn btn-primary btn-md',
        noBtn_css: 'btn btn-default btn-md ml-3',
        submitWrapper_css: 'col-12 text-right pt-3',
        response: '',
        column_class: 'mx-2 deleteIcon2 d-inline-block float-right',
        css: { border: 'none' },
      },
      download_all: {
        response: ['download_document_all', 'fileData'],
        column_class: 'btn btn-secondary',
      },
      type: 'document-management',
    },
    credit_bench_loader: true,
  };
  modalRef: BsModalRef;
  appID;
  userID;
  lead_ref_id;
  backend_user_id;
  businessID: string;
  application_status_id: string;
  businessData: any;
  userData: any;
  appData: any;
  previousTask: string;
  bankerUserData : any;
  constructor(
    private common: CommonService,
    private modalService: BsModalService,
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    @Inject('environment') public environment
  ) {}

  ngOnInit(): void {
    this.store
      .select('app')
      .pipe(take(1))
      .subscribe((rootState) => {
        if(this.environment.journeyType === 'banker-journey'){
          this.config.user_id = this.userID = rootState.appData.userData.user_id;
          this.bankerUserData = rootState?.userData;
          this.userData = rootState.appData.userData;
          this.appData = rootState?.appData;
          this.application_status_id=rootState?.appData?.status_id;
        }else{
          this.config.user_id = this.userID = rootState.userData.user_id;
          this.userData = rootState.userData;
        }
        this.config.app_id = this.appID = rootState.appID;
        this.config.lead_ref_id = this.lead_ref_id = rootState.appData.loan_id;        
        this.businessID = rootState.businessID;
        this.common.updateStepState(
          CONSTANTS.APP_STEP[this.config.task.document_type.params.slug]
        );
      });
    this.taskInfoService
      .getTaskInfo({
        slug: CONSTANTS.SLUG['sba-confirmation'],
        business_id: this.businessID,
      })
      .subscribe((response) => {
        this.businessData =
          response.response_data?.get_business_data?.data?.data[0];
      });
  }

  onPrevious() {
    this.common.navigate('another-owner-detail');
  }

  onSubmit(action, sbaConfirmation?: TemplateRef<any>) {
    let navigateTo: string;
    if (action === 'continue') {
      if (!this.businessData.hasOwnProperty('step_not_required')) {
        this.modalRef = this.modalService.show(sbaConfirmation, {
          id: 1,
          class: 'modal-lg thankyouRegister',
          backdrop: 'static',
        });
      } else {
        if (this.businessData.step_not_required.includes("SBA Form") || this.businessData.sba_initiated_by === "banker") {
          this.environment.journeyType === 'banker-journey' ? navigateTo = 'manage-loans' : navigateTo = 'dashboard';
          this.common.navigate(navigateTo);
        } else {
          this.common.navigate('sba-form-1', this.businessID)
        }
      }
    }
    else {
      if(this.application_status_id!==CONSTANTS?.APPLICATION_STATUS?.application_in_progress && this.environment.journey === 'banker-journey') {
        this.addActivityLog();
      }
      this.environment.journeyType === 'banker-journey' ? navigateTo = 'manage-loans' : navigateTo = 'dashboard';
      this.common.navigate(navigateTo);
    }
  }
  addActivityLog(){
    const log_data = {
      role_slug:  this.bankerUserData?.role_slug,
      app_id: this.appID,
      backend_user_id: this.bankerUserData?.user_id,
      user_name: this.bankerUserData?.full_name,
      activity: 'application_edited'
    };
    this.common.addActivityLog(log_data);
  }
  onSbaConfirmation(sbaConf: string) {
    let step_not_required = [];
    let params = {
      slug: CONSTANTS.SLUG['sba-confirmation'],
    };
    // if (sbaConf === 'no') {step_not_required.push('SBA Form'); }
    const payload = {
      step_not_required,
      business_id: this.businessID,
      app_id: this.appID,
      banker_url: this.environment.banker_url,
      header_logo_path_1: this.environment.logo1_path,
      header_logo_path_2: this.environment.logo2_path,
      senders_name: this.environment.client_name,
      copyright_text: this.environment.copyright_text,
      privacy: this.environment.privacy,
      terms: this.environment.terms,
    };
    if (sbaConf === 'no') {
      step_not_required.push('SBA Form');
      payload['user_name'] = this.environment.journeyType === 'banker-journey' ? `${this.bankerUserData.full_name}` : `${this.userData.first_name} ${this.userData.last_name} (Customer)`;
      params['status_id'] = CONSTANTS.APPLICATION_STATUS.app_submitted;
    } else {
      payload['initiate_sba_date'] = new Date();
      this.environment.journeyType === 'banker-journey' ? payload['sba_initiated_by'] = "assistant" : payload['sba_initiated_by'] = "customer";
    }
    this.taskInfoService.saveTaskInfo(params, payload).subscribe((response) => {
      if (response && response.nextTask) {
        this.modalRef.hide();
        if(this.environment.journeyType === 'banker-journey'){
          this.store.dispatch(addAppDetails({
            appData: {
              ...this.appData,
              step_not_required
            }
          }));
        }else{
          this.store.dispatch(addUserDetails({
            userData: {
              ...this.userData,
              step_not_required
            }
          }));
        }
        if(sbaConf === 'yes') { 
          this.common.navigate('sba-form-1', this.businessID)
        } else {
          this.common.popToast('success', '', `Application submitted successfully.`);
          if(this.environment.journeyType === 'banker-journey'){
            this.common.navigate('manage-loans');
          }else{
            this.common.navigate('dashboard');
          }
        } 
      }      
    })
    }
  
  ngOnDestroy() {
    this.common.updateStepState(0);
    (this.modalRef) ? this.modalRef.hide() : "";
  }
}
