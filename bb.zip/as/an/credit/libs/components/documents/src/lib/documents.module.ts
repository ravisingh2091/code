import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { RouterModule, Route } from '@angular/router';
import { UiKitModule } from '@credit-bench/ui-kit';
import { DocumentUploadComponent } from './document-upload/document-upload.component';

export const documentsRoutes: Route[] = [
  {
    path: '',
    component: DocumentUploadComponent,
  },
];
@NgModule({
  imports: [
    CommonModule,
    UiKitModule,
    SharedLazyModule,
    RouterModule.forChild(documentsRoutes),
  ],
  declarations: [DocumentUploadComponent],
})
export class DocumentsModule {}
