import { Component, OnInit, Inject } from '@angular/core';
import { TaskInfoService, CommonService, MasterDataPipe } from '@rubicon/utils';
import { take, pluck } from 'rxjs/operators';
import { Store} from '@ngrx/store';


@Component({
  selector: 'application-info',
  templateUrl: './application-info.component.html',
  styleUrls: ['./application-info.component.scss']
})

export class ApplicationInfoComponent implements OnInit {

  showMe: boolean = false;
  businessDetails: any;
  ownerDetails: any;
  userDetails: any;
  business_industry = [];
  sub_industry= [];
  company_status = [];
  business_structure = [];
  company_role = [];
  gender = [];
  veteran = [];
  race = [];
  ethnicity = [];
  marital = [];
  annual_revenue = [];
  state = [];
  franchise_business_structure = [];
  primaryOwner: any;
  additionalOwnersIndividual: any = [];
  additionalOwnersBusiness: any = [];
  ownerData: any;
  userData: any;
  business_id: string;
  app_id: string;
  user_id: string;
  franchise: string;
  ofac_status: string;
  application_status_id: string;
  others: string;
  residence_type = [];
  productCategory = [];
  ownerRefDetails = [];
  businessRefDetails = [];
  loanPurpose = [];
  isSsnVisible: boolean = true;
  productDetails= {
    product: '',
    name:''
  };
  enableConsentButton : boolean;
  constructor(
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    private common: CommonService,
    private masterDataPipe: MasterDataPipe,
    @Inject('environment') private environment,
    @Inject('CONSTANTS') private CONSTANTS
  ) { }

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.franchise = this.CONSTANTS.BUSINESS_STRUCTURE.franchise;
      this.others = this.CONSTANTS.BUSINESS_STRUCTURE.others
      this.user_id = rootState?.appData?.user_id;
      this.application_status_id = rootState?.appData?.status_id;
      this.app_id  = rootState.appID;
      this.business_id = rootState.businessID;
      this.userData=rootState?.userData;
      let slugData = {
        slug: this.CONSTANTS.SLUG['application_info'],         
        app_id: this.app_id,
        user_id: this.user_id,
        business_id: this.business_id
      }
      this.taskInfoService.getTaskInfo(slugData).subscribe(response => {
        this.businessDetails = response?.response_data?.user_applications?.data?.data[0]?.business[0];
        this.ownerDetails = response?.response_data?.user_applications?.data?.data[0]?.owners;
        this.businessRefDetails = response?.response_data?.user_applications?.data?.data[0]?.business_references;
        this.ownerRefDetails = response?.response_data?.user_applications?.data?.data[0]?.owner_references;
        this.productDetails = {...this.productDetails,...response?.response_data?.user_applications?.data?.data[0]?.products[0]};
        this.userDetails = response?.response_data?.get_user?.data?.data;
        this.primaryOwner = this.ownerDetails.find(res => res.is_primary);
        if (this.primaryOwner) {this.primaryOwner['hideSsn'] = true;};
        if (this.ownerDetails.length > 1) {
          this.ownerDetails.filter(res => {
            if (res.is_secondary) {
              res.owner_type === 'individual'? res['hideSsn'] = true: res['hideTaxid'] = true;
              res.owner_type === 'individual'? this.additionalOwnersIndividual.push(res) :  this.additionalOwnersBusiness.push(res);
            }
          });
        }
        if(this.businessDetails){this.businessDetails['hideTax'] = true;};
        this.company_status = response?.response_data?.company_status?.data?.data;
        this.business_structure = response?.response_data?.business_structure?.data?.data;
        this.company_role = response?.response_data?.company_role?.data?.data;
        this.annual_revenue = response?.response_data?.annual_revenue?.data?.data;
        this.residence_type = response?.response_data?.residence_type?.data?.data;
        this.business_industry = response?.response_data?.business_industry?.data?.data;
        let subIndustry = this.business_industry.find(res => res.id === this.businessDetails.industry);
        this.sub_industry = subIndustry?.sub_industry;
        this.productCategory = response?.response_data?.product_category?.data?.data;
        this.loanPurpose = response?.response_data?.loan_purpose?.data?.data;
        this.gender = response?.response_data?.gender?.data?.data;
        this.race = response?.response_data?.race?.data?.data;
        this.marital = response?.response_data?.marital?.data?.data;
        this.ethnicity = response?.response_data?.ethnicity?.data?.data;
        this.veteran = response?.response_data?.veteran?.data?.data;
        this.franchise_business_structure = response?.response_data?.franchise_business_structure?.data?.data;
        this.state = response?.response_data?.state?.data?.data;
        this.enableConsentButton = (this.primaryOwner && this.primaryOwner.length > 0)? this.enableSendConsent(): false;
        this.getOFACStatus();
      })
    })

    //for getting updated product information
    this.store.select('app').pipe(pluck('appData')).subscribe(rootstate=> {
        let appdata = rootstate;
        this.productDetails['product']= appdata?.product;
        this.productDetails['name'] = appdata?.productName;
    })
  }

  togelIcon() {
    this.showMe = !this.showMe
  }

  getOFACStatus(): void {
    let bridger_business_pulled = [];
    let bridger_individual_pulled = [];
    if(this.businessRefDetails?.length) {
      bridger_business_pulled = this.businessRefDetails.filter(ele=>ele.type == 'bridger-business');
    }
    if(this.ownerRefDetails?.length) {
      bridger_individual_pulled = this.ownerRefDetails.filter(ele=>ele.type == 'bridger-individual');
    }
    if(this.application_status_id === this.CONSTANTS.APPLICATION_STATUS.application_in_progress) {
      this.ofac_status = 'N/A';
    } else {
      const bridger_business = bridger_business_pulled.filter(ele=>ele?.response?.Records);
      const bridger_owner = bridger_individual_pulled.filter(ele=>ele?.response?.Records);
      if(bridger_business.length > 0 || bridger_owner.length > 0) {
        this.ofac_status = 'Yes';
      } else {
        this.ofac_status = 'No';
      }
    }
  }

  changeHideSsn(type, ind?: number, owner_type?: any) {
    if(type === 'primary') {
      this.primaryOwner.hideSsn = !this.primaryOwner.hideSsn;
    } 
    else {
      let additionalOwners = [];
      owner_type==='individual' ? additionalOwners=this.additionalOwnersIndividual : additionalOwners = this.additionalOwnersBusiness;
      if (additionalOwners[ind].hasOwnProperty('hideSsn')){
        additionalOwners[ind].hideSsn = !additionalOwners[ind].hideSsn;
      } else {
        additionalOwners[ind].hideTaxid = !additionalOwners[ind].hideTaxid;
      }
    }
  }
  
  changeHideTax(){
    if(this.businessDetails.hasOwnProperty('hideTax')){
      this.businessDetails.hideTax = !this.businessDetails.hideTax
    }
  }
  
  getAddress(streetno: string, streetname: string, city: string, state: string, zipcode: string){
        zipcode =zipcode?zipcode.toString():'';
    return `${(streetno && typeof streetno !== "undefined" && typeof streetno === "string") ? streetno+', ' : ""}${(streetname && typeof streetname !== "undefined" && typeof streetname === "string") ? streetname+', ' : ""}${(city && typeof city !== "undefined" && typeof city === "string") ? city+', ' : ""}${(state && typeof state !== "undefined" && typeof state === "string") ? state+', ' : ""}${(zipcode && typeof zipcode !== "undefined" && typeof zipcode === "string") ? zipcode : ""}`;
  }
  
  refresh(owner_id, owner_type, type): void {
    this.taskInfoService.getTaskInfo({
      slug: 'get_owner_data',
      app_id: this.app_id,
      user_id: this.user_id,
      owner_id: owner_id
    }).subscribe(response => {
      if(response?.response_data?.get_owner_data?.data?.data[0].consent === 'sent'){
        this.ownerData = response?.response_data ?.get_owner_data ?.data ?.data;
        this.updateOwenrDetails(this.ownerData, owner_id, owner_type, type)
        this.common.popToast("Success","","Consent pending.")
      }
      else{
        this.ownerData = response?.response_data ?.get_owner_data ?.data ?.data;
        this.updateOwenrDetails(this.ownerData, owner_id, owner_type, type)
      }

    })
  }

  updateOwenrDetails(ownerData, owner_id, owner_type?:any, type?:any){
    if (ownerData.length > 0) {
      ownerData[0] = this.refreshEye(ownerData[0])
    }
    if(type==='primary'){
      this.primaryOwner=Array.isArray(ownerData)?ownerData[0]:ownerData;   
    }
    else{
      let additionalOwners = [];
      owner_type==='individual' ? additionalOwners= this.additionalOwnersIndividual : additionalOwners = this.additionalOwnersBusiness
      const index = additionalOwners.findIndex(elem=>owner_id===elem._id);
      if(index>=0){
        additionalOwners[index]=ownerData[0];
      }
    }
  }

  refreshEye(res){
    if (res.is_secondary) {
      res.owner_type === 'individual'? res['hideSsn'] = true: res['hideTaxid'] = true;
      return res;
    }
    else {
      res['hideSsn'] = true;
      return res;
    }
  }

  sendOwnerConsent(obj, owner_type, type): void {
    if (this.getOwnership() !== 100) {
      this.common.popToast('error', 'Error', '100% ownership participation is required to process your credit request.');
      return;
    }
    if(type === 'primary' && !this.enableConsentButton && this.application_status_id === this.CONSTANTS.APPLICATION_STATUS.application_in_progress){
      this.common.popToast('error', 'Error', 'Please Fill all the Owner Details.');
      return;
    }
      const payload = {
        app_id: obj.app_id,
        user_id: obj.user_id,
        owner_id: obj._id,
        hash_for: 'owner_consent',
        email_address: obj.email_address,
        to_name: obj.owner_type === 'individual' ? obj.first_name : obj.businessname,
        consent: 'sent',
        header_logo_path_1: this.environment.logo1_path,
        header_logo_path_2: this.environment.logo2_path,
        client_name: this.CONSTANTS.MAIL_TEMPLATE.project_name,
        senders_name: this.CONSTANTS.MAIL_TEMPLATE.senders_name,
        copyright_text: this.CONSTANTS.MAIL_TEMPLATE.copyright_text,
        frontend_url: this.environment.customerJourneyUrl,
        privacy: this.environment.privacy,
        terms: this.environment.terms,
        role: this.masterDataPipe.transform(obj.company_role , this.company_role,'id','value')
      }
      const params = {
        slug: this.CONSTANTS.SLUG['request_owners_consent'],
        app_id: this.app_id,
        user_id: this.user_id,
        owner_id: obj._id,
        business_id: this.business_id
      }
      this.taskInfoService.saveTaskInfo(params, payload).subscribe(response => {
        if (response?.send_owner_consent?.data?.code == 200) {
          if(response?.update_owner_consent?.data?.data?._id){
            const ownerData = this.refreshEye(response?.update_owner_consent?.data?.data)
            if(type==='primary'){
              this.primaryOwner[0] = ownerData; 
            }
            else{
              let additionalOwners = [...this.additionalOwnersIndividual, ...this.additionalOwnersBusiness];
              const index = additionalOwners.findIndex(data => data._id === ownerData._id);
              additionalOwners[index] = ownerData;
            }
          }
          this.common.popToast('success', '', 'Consent mail sent.');
          this.addActivityLog(obj)
        }
        else if(response?.get_owner_data?.data?.data.length > 0 && response?.get_owner_data?.data?.data[0].consent === 'received'){
          const ownerData2 = response?.get_owner_data ?.data ?.data;
          this.updateOwenrDetails(ownerData2, obj._id, owner_type, type)
          this.common.popToast('success', '', 'Consent already received.')
        }
      })
  }
  addActivityLog(obj){
    const log_data = {
      role_slug:  this.userData?.role_slug,
      app_id: this.app_id,
      backend_user_id: this.userData.user_id,
      user_name: this.userData?.full_name,
      activity: 'consent_mail_sent_to_customer',
      note: obj?.owner_type==="corporate"? obj?.businessname: `${obj?.first_name}${obj.middle_name?(' ' +obj.middle_name+' '):' '}${obj?.last_name}`
    };
    this.common.addActivityLog(log_data);
  }

  enableSendConsent() {
    return !Object.keys(this.primaryOwner).some((key: any) => {
      if(key === 'middle_name' || key === 'deleted_at') return false;
      else if (this.primaryOwner[key] === null || this.primaryOwner[key] === '') return true;
    })
  }
    
  getOwnership(): number {
    return this.ownerDetails.reduce((sum, item) => sum + item.ownership, 0);
  }

}