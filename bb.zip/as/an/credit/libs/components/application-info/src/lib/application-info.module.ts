import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Route, RouterModule } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { PfsModule } from '@credit-bench/components/pfs';
import { PfsBankerComponent } from './application-info/pfs-banker/pfs-banker.component';
import { AdditionalInformationComponent } from './application-info/additional-information/additional-information.component';
import { ApplicationInfoComponent } from './application-info/application-info.component';
import { MasterDataPipe } from '@rubicon/utils';
export const loginRoutes: Route[] = [
  { path: '', component: ApplicationInfoComponent },
];
@NgModule({
  imports: [CommonModule, SharedLazyModule, RouterModule.forChild(loginRoutes), PfsModule],
  declarations: [
    PfsBankerComponent,
    AdditionalInformationComponent,
    ApplicationInfoComponent,
  ],
  providers: [MasterDataPipe]
})
export class ApplicationInfoModule {}
