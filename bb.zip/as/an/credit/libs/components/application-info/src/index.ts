export * from './lib/application-info.module';
