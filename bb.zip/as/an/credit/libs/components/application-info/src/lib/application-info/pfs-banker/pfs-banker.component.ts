import { Component, OnInit } from '@angular/core';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';

@Component({
  selector: 'pfs-banker',
  templateUrl: './pfs-banker.component.html',
  styleUrls: ['./pfs-banker.component.scss']
})
export class PfsBankerComponent implements OnInit {
  showAlert = false;
  constructor(private store: Store<any>) { }

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.show_pfs(rootState?.appData?.status_id ? rootState.appData.status_id:'');
    });
  }

  show_pfs(status_id): void {
    if(!status_id || status_id === CONSTANTS?.APPLICATION_STATUS?.application_in_progress) {
      this.showAlert = true
    }
  }
}
