import { FormGroup } from '@angular/forms';
import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { CommonService, FormGenerateService, TaskInfoService } from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { take, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Subscription } from 'rxjs';
@Component({
  selector: 'additional-information',
  templateUrl: './additional-information.component.html',
  styleUrls: ['./additional-information.component.scss']
})
export class AdditionalInformationComponent implements OnInit, OnDestroy{
  additionalConfig: any;
  additionalForm: any;
  slug:any;
  business_id : String;
  update = false;
  user_id: String;
  additionalData: any;
  interestRateSubscription: Subscription;
  userData: any;
  appID: string;
  businessData : any;

  constructor(
  private taskInfoService : TaskInfoService,
  private formGenerateService: FormGenerateService,  
  private common: CommonService,
  private store: Store<any>
  ) {}

  ngOnInit(): void {}
  
  getAdditionalData(isOpen) {
    if (isOpen) {
      this.store.select('app').pipe(take(1)).subscribe(rootState => {      
        this.business_id = rootState.businessID; 
        this.userData = rootState.userData;
        this.user_id = rootState?.appData?.user_id;
        this.appID = rootState.appID;
      }); 

      let slugData = {
        slug: CONSTANTS.SLUG['additional_information'],         
        app_id: this.appID,
        user_id: this.user_id,
        business_id: this.business_id
      }
      this.taskInfoService.getTaskInfo(slugData).subscribe(response => {
        this.businessData = response.response_data.get_business_data.data.data[0];
        this.additionalData = !this.businessData?.additional_information?.about_us ? {...this.businessData?.additional_information, about_us: response.response_data.get_user.data.data.how_did_you_hear_about_us } : this.businessData?.additional_information;
        this.additionalConfig = response.form_fields;
        this.additionalForm = this.formGenerateService.createControl(this.additionalConfig);
        this.common.sendMasterDataToFields(this.additionalConfig, response?.response_data);
        this.slug = response.task_slug;
        this.update = (this.businessData?.hasOwnProperty('term'))
        this.formGenerateService.setFormValues(this.additionalForm, { additional_information: this.additionalData });
        this.interestRateSubscription = this.additionalForm.get('additional_information').get('interest_rate').valueChanges.pipe(debounceTime(500),distinctUntilChanged()).subscribe(interest_rate => {
          if (interest_rate && (parseFloat(interest_rate) > 100)) {
            const formGroup = this.additionalForm.controls['additional_information'] as FormGroup;
            formGroup.controls['interest_rate'].markAsDirty();
            formGroup.controls['interest_rate'].setErrors({ 'incorrect': true });
          }
        });
        setTimeout(() => {
          for (const key in this.additionalForm.controls.additional_information.controls) {
            if (this.additionalForm.controls.additional_information.controls[key]) {
              this.additionalForm.controls.additional_information.controls[key].markAsPristine();
            }
          }
        }, 0)
      })
    }
  }

  onSubmit(action){
    if(this.formGenerateService.validateCustomFormFields(this.additionalForm, action, this.additionalConfig)) {
      delete this.additionalForm.value['additional_information']['term_label']
      let payload = {
       ...this.additionalForm.value,
        business_id : this.business_id
      }
      this.taskInfoService.saveTaskInfo({slug: this.slug}, payload).subscribe(res => {
        this.updateActivityLog();
        let actionPerformed = this.update ? 'updated' : 'submitted';
        this.common.popToast('success', '', `Additional Information has been ${actionPerformed} successfully.`);
        this.update = true;
      })
    }
  }

  ngOnDestroy() {
    this.interestRateSubscription?.unsubscribe();
  }

  updateActivityLog() {
    let activityData = {
      role_slug: this.userData.role_slug,
      app_id: this.appID,
      backend_user_id: this.userData.user_id,
      user_name: this.userData.full_name,
      activity: `additional_info_submitted`
    };
    this.common.addActivityLog(activityData);
  }
}