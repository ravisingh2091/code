import { Component, Inject, OnInit } from '@angular/core';
import { TaskInfoService, FormGenerateService, onLogout, CommonService} from '@rubicon/utils';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';

@Component({
  selector: 'change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {
  changePasswordConfig: FormFieldInterface[] = [];
  changePasswordForm: FormGroup;
  slug: '';
  user_id: '';
  session_id: string;
  first_name: string;
  email_address: string;
  constructor(
    private taskInfoService : TaskInfoService,
     private formGenerateService: FormGenerateService,
     private  commonService: CommonService,
     private store: Store<any>,
     @Inject('environment') private environment,
  ) { }

  ngOnInit(): void {

    this.store.select('app').pipe(take(1)).subscribe(rootState => {      
      this.user_id = rootState.userData.user_id; 
      this.session_id = rootState.userData.id;
      this.email_address = rootState?.userData?.email_address;
      this.first_name = rootState?.userData?.first_name ? rootState?.userData?.first_name : rootState?.userData?.full_name ;
      }); 
     this.taskInfoService.getTaskInfo({slug:'change-password'}).subscribe(response => {
       this.slug = response.task_slug;
       this.changePasswordConfig = response.form_fields;
       this.changePasswordForm = this.formGenerateService.createControl(this.changePasswordConfig);
     },
     error => {
       console.log("something went wrong!");
     })
  }

  onSubmit(action) {
    if(this.formGenerateService.validateCustomFormFields(this.changePasswordForm, action, this.changePasswordConfig)) {
      let payload =  {
        ...this.changePasswordForm.getRawValue(),
        header_logo_path_1: this.environment.logo1_path,
        header_logo_path_2: this.environment.logo2_path,
        client_name: this.environment.project_name,
        senders_name: this.environment.client_name,
        copyright_text: this.environment.copyright_text,
        privacy: this.environment.privacy,
        terms: this.environment.terms,
        email_address: this.email_address,
        first_name: this.first_name,
        user_id: this.user_id
      };
      if(this.environment.journeyType === "banker-journey"){
        payload['slug'] = 'backend'
      }
      let headers = { 
        "user_session" : this.session_id
      }
      this.taskInfoService.saveTaskInfo({slug: this.slug}, payload, headers).subscribe(res => {
        if(res?.change_password?.data?.code == 200) {
          this.commonService.popToast('success', '', 'Your password has been updated successfully, please login with your new password to access the platform.');
          this.commonService.navigate(res.nextTask.value);
        }
      })
      
  }
}


}
