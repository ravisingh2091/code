import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Route } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { ChangePasswordComponent } from './change-password/change-password.component';

export const changePassRoutes: Route[] = [
  {path:'', component: ChangePasswordComponent},
];

@NgModule({
  declarations: [ChangePasswordComponent],
  imports: [
    CommonModule,
    SharedLazyModule, 
    RouterModule.forChild(changePassRoutes),
  ]
})
export class ChangePasswordModule { }
