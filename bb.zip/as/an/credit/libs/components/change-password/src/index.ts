export * from './lib/change-password.module';
