import { Inject, NgModule, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Route } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { ConnectBankerCustomerComponent } from './connect-banker-customer/connect-banker-customer.component';

const routes: Route[] = [{ path:'', component: ConnectBankerCustomerComponent }];

@NgModule({
  imports: [CommonModule, SharedLazyModule, RouterModule.forChild(routes)],
  declarations: [ConnectBankerCustomerComponent],
})
export class ComponentsConnectBankerCustomerModule {

}
