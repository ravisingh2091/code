import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonService, FormGenerateService, TaskInfoService } from '@rubicon/utils';
import { take, takeUntil } from 'rxjs/operators';
import { ReplaySubject } from 'rxjs';
import { FormGroup } from '@angular/forms';
@Component({
  selector: 'credit-bench-connect-banker-customer',
  templateUrl: './connect-banker-customer.component.html',
  styleUrls: ['./connect-banker-customer.component.scss']
})
export class ConnectBankerCustomerComponent implements OnInit, OnDestroy {
  
  appID;
  source;
  businessID;
  loanId;
  loggedInUserData;
  form_fields = [];
  commentForm: FormGroup;
  compDestroyed$ = new ReplaySubject(1);
  slug = "connect_banker_customer";
  comments = [];
  backendUsers = [];
  banker;
  customer_user;
  rmNumber;
  rmName;
  rmEmail;
  user_id;
  rm_slugs = ["loan_officer_l1", "loan_officer_l2"];
  firstLoad = false;
  appData: any;

  constructor(private commonService: CommonService,
    private formGenerate: FormGenerateService,
    private store: Store<any>,
    private taskInfoService: TaskInfoService,
    @Inject('environment') public environment,
    @Inject('CONSTANTS') private CONSTANTS){
      if(this.environment.journeyType === 'banker-journey'){
        this.source = "banker"; 
      }else{
        this.source = "customer";
      }
    }

  //getting rm details from latest rm before fullfillment services (fulfillment_services_l1 or fulfillment_services_l2)
  ngOnInit(){
    
    this.store.select('app').pipe(
      takeUntil(this.compDestroyed$)
    ).subscribe((rootState) => {
      this.loggedInUserData = rootState.userData;
      this.businessID = rootState.businessID;
      this.appID = rootState.appID;
      this.loanId = rootState?.appData?.loan_id;
      this.user_id = rootState?.appData?.user_id;
      this.appData = rootState?.appData;
      if(this.source === 'customer'){
        this.customer_user = rootState.userData;
      }
      let rm_user;
      let fulfillment_slugs = ["fulfillment_services_l1", "fulfillment_services_l2"]
      let app_assignment = rootState?.appData?.app_assignment;
      if(app_assignment && app_assignment.length >0){
        for(let user of app_assignment){
          if(fulfillment_slugs.includes(user.role_slug)){
            break;
          }
          if(this.rm_slugs.includes(user.role_slug)){
            rm_user = user;
          }
        }
      }

      if(rm_user){
        this.banker = rm_user;
        this.rmNumber = this.maskPhoneNumber(rm_user?.phone);
        this.rmEmail = rm_user?.email_address;
        this.rmName = rm_user?.name;
      }
      if(!this.firstLoad){
        this.firstLoad = true;
        this.taskInfoService
        .getTaskInfo({
          slug: this.slug,
          app_id: this.appID,
          user_id: this.user_id,
          source: this.source
        })
        .subscribe((response) => {
          this.form_fields = response.form_fields;
          this.commentForm = this.formGenerate.createControl(this.form_fields);
          this.comments = response?.response_data?.get_connect_banker_customer_notes?.data?.data || [];
          this.backendUsers = response?.response_data?.all_users?.data?.data || [];
          if(this.source == "banker"){
            this.customer_user = response?.response_data?.get_user?.data?.data;
          }
        });
      }
    });
  }

  maskPhoneNumber(num) {
    if(num && Number(num) !== NaN && Number(num) !== 0 && !isNaN(Number(num))) {
      num = num.toString();
      const phoneNumber = num.match(/(\d{3})(\d{3})(\d{4})/);
      return num.length === 10 ? `(${phoneNumber[1]}) ${phoneNumber[2]}-${phoneNumber[3]}` : '';
    }
    return '';
  }

  onSend(){
    if(this.formGenerate.validateCustomFormFields(this.commentForm, "continue", this.form_fields)) {
      let payload = {
        note: this.commentForm.value.comment,
        type: 'connect_banker_customer',
        source: this.source,
        app_id: this.appID,
        backend_user_id: this.source == "banker"?this.loggedInUserData?.user_id:undefined,
        user_id: this.source == "customer"?this.loggedInUserData?.user_id:undefined,
        role: this.loggedInUserData?.role,
        role_slug: this.loggedInUserData?.role_slug,
        loan_officer_id:this.banker?.id
      }
      let customerName = [(this.customer_user?.first_name || ''), (this.customer_user?.last_name || '')].join(' ');
      let mail_payload = {
        source: this.source,
        // email_address: this.source == "banker"?(this.customer_user?.email_address):(this.banker?.email_address),
        email_address: this.source == "banker"?(this.appData?.primarOwnerEmail_id):(this.banker?.email_address),
        name: this.source == "banker"?(customerName):(this.banker?.name),
        // first_name: this.source == "banker"?(customerName):(this.banker?.name), 
        first_name: this.source == "banker"?(this.appData?.primaryOwnerName):(this.banker?.name), 
        loan_id: this.loanId,
        lo_name:this.rmName,
        loan_officer_email: this.rmEmail,
        customer_name: customerName,
        phone_number: this.rmNumber || '________',
        siteurl: this.source == "banker"?this.environment.customerJourneyUrl: this.environment.banker_url,
        header_logo_path1: this.environment.logo1_path,
        header_logo_path2: this.environment.logo2_path,
        senders_name: this.CONSTANTS.MAIL_TEMPLATE.senders_name,
        copyright_text: this.CONSTANTS.MAIL_TEMPLATE.copyright_text,
        terms: this.environment.terms,
        privacy: this.environment.privacy
      };

      this.taskInfoService.saveTaskInfo({slug: "connect_banker_customer"}, {...payload, ...mail_payload}).subscribe((response) => {
        if (response && response.nextTask != "error") {
          if(response.add_connect_banker_customer_note?.data?.data){
            if(!this.comments){
              this.comments = [];
            }
            this.comments.unshift(response.add_connect_banker_customer_note.data.data);
          }
          this.commentForm.reset();
          this.commonService.popToast("success","", "Inquiry has been updated with a response successfully.")
        }
      });
    
    }
  }

  ngOnDestroy(){
    this.compDestroyed$.next();
    this.compDestroyed$.complete();
  }
}
