import { Component, OnInit, Inject } from '@angular/core';
import { CommonService } from '@rubicon/utils';

@Component({
  selector: 'consent-received',
  templateUrl: './consent-received.component.html',
  styleUrls: ['./consent-received.component.scss']
})
export class ConsentReceivedComponent implements OnInit {

  project: string;
  constructor(
    private common: CommonService,
    @Inject('CONSTANTS') public CONSTANTS
    ) { }

  ngOnInit(): void {
    this.project = this.CONSTANTS.CLIENT_CONFIG.project_name;
    this.common.updateStepState(-1);

  }
  ngOnDestroy() {
    this.common.updateStepState(0);
  }
}
