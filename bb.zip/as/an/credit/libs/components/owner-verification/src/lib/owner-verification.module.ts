import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Route, RouterModule } from '@angular/router';
import { OwnerVerificationComponent } from './owner-verification/owner-verification.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { ConsentReceivedComponent } from './consent-received/consent-received.component';
import { MasterDataPipe } from '@rubicon/utils';

export const OwnerVerificationRoutes: Route[] = [
  {
    path: 'consent-received' , component: ConsentReceivedComponent
  },
  {
    path: ':hash' , component: OwnerVerificationComponent
  }
];

@NgModule({
  imports: [CommonModule,
    SharedLazyModule,
    RouterModule.forChild(OwnerVerificationRoutes)
  ],
  declarations: [
    OwnerVerificationComponent,
    ConsentReceivedComponent
  ],
  providers: [MasterDataPipe]
})
export class OwnerVerificationModule {}
