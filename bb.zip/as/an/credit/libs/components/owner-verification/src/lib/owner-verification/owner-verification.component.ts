import { distinctUntilChanged } from 'rxjs/operators';
import { Component, OnInit, Inject } from '@angular/core';
import { TaskInfoService, CommonService, FormGenerateService, MasterDataPipe } from '@rubicon/utils';
import { ActivatedRoute } from '@angular/router';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'owner-verification',
  templateUrl: './owner-verification.component.html',
  styleUrls: ['./owner-verification.component.scss']
})
export class OwnerVerificationComponent implements OnInit {
  name: string;
  owner_verified = false;
  hash: string = '';
  user_id: string = '';
  app_id: string = '';
  project: string;
  slug = 'verify-owner-consent';
  ownerDetailFormConfig: FormFieldInterface[] = [];
  ownerDetailForm: FormGroup;
  ownerData: any = {};
  ownerDetail: any = {};
  consentRecieved = false;
  hashExpired: boolean;
  company_role = [];

  constructor(private taskInfoService: TaskInfoService,
    private common: CommonService,
    private formGenerateService: FormGenerateService,
    private activatedRoute: ActivatedRoute,
    @Inject('CONSTANTS') public CONSTANTS,
    @Inject('environment') private environment,
    private masterDataPipe: MasterDataPipe
    ) { }

  ngOnInit(): void {
    this.project = this.CONSTANTS.CLIENT_CONFIG.project_name;
    this.name = this.CONSTANTS.CLIENT_CONFIG.name;
    this.hash = this.activatedRoute.snapshot.params.hash;
    this.verifyHash()
  }

  verifyHash() {
    this.taskInfoService.getTaskInfo({
      slug: this.CONSTANTS.SLUG['verify_owner_hash'],
      hash: this.hash,
      hash_for: 'owner_consent',
      // no_encryption: true,
      skip_error: true
    }).subscribe(response => {
      if(response.response_data.verify_owner_hash.errors){
        this.hashExpired = true;
      }
      else{
        this.ownerDetail = response.response_data.verify_owner_hash.data.data[0];
        this.hashExpired = false;
        this.getTaskInfo(response)
      }
    })
  }

  getTaskInfo(data){
    this.taskInfoService.getTaskInfo({
      slug: this.CONSTANTS.SLUG['verify-owner-consent'],
      // no_encryption: true
    }).subscribe(response => {
      if (response) {
        this.company_role = response.response_data?.company_role?.data?.data;
        this.slug = response ?.task_slug;
        this.ownerDetailFormConfig = response ?.form_fields;
        this.ownerDetailForm = this.formGenerateService.createControl(this.ownerDetailFormConfig);
        this.common.sendMasterDataToFields(this.ownerDetailFormConfig, response ?.response_data);
        this.ownerData = data.response_data.verify_owner_hash.data.data[0];
        this.formGenerateService.setFormValues(this.ownerDetailForm, { owners: this.ownerData });
        this.ownerDetailForm.controls['owners'].get('business_structure').valueChanges.subscribe(data => {
          if (data === "5c1ca192eb72d4c894b91611") {
            const tax_id_validations = this.ownerDetailFormConfig[0]?.group_fields?.find(ele=>ele.name==='tax_id')?.validations?.filter(ele=>ele.name!=='required');
            this.ownerDetailForm.controls['owners'].get('tax_id').setValidators(this.createValidation(tax_id_validations));
            this.ownerDetailForm.controls['owners'].get('tax_id').updateValueAndValidity({onlySelf: true});
          } else {
            const tax_id_validations = this.ownerDetailFormConfig[0].group_fields.find(ele=>ele.name==='tax_id')?.validations;
            this.ownerDetailForm.controls['owners'].get('tax_id').setValidators(this.createValidation(tax_id_validations).concat([Validators.required]));
            this.ownerDetailForm.controls['owners'].get('tax_id').updateValueAndValidity({onlySelf: true});
          }
        });
        this.ownerDetailForm.get("owners.business_structure").valueChanges.pipe(
          distinctUntilChanged())
          .subscribe(val=> {
          this.common.sendMasterDataToFields(this.ownerDetailFormConfig, response ?.response_data);
        });
        this.app_id = this.ownerData.app_id;
        this.user_id = this.ownerData.user_id;
        if(this.ownerData.consent==='received'){
          this.consentRecieved = true;
          this.ownerDetailForm.disable();
          this.common.navigate('consent-received');
        }
      }
    });
  }
  createValidation(validations){
    let validList = [];
    validations.forEach(valid=>{
      if(valid.name === 'pattern'){
        if (!Array.isArray(valid.validations)) {
          valid.validations = valid.validations.replace(/^\/|\/$/g, '');
        }
        validList.push(Validators.pattern(valid.validations))
      }
    })
    return validList;
  }
  onSubmit(action: string): void {
    if (this.formGenerateService.validateCustomFormFields(this.ownerDetailForm, action, this.ownerDetailFormConfig)) {
      if (this.ownerData ?._id) {
        let payload = {
          app_id: this.app_id,
          user_id: this.user_id,
          action_type: action,
          owner_id: this.ownerData._id,
          consent: 'received',
          name: this.ownerData.owner_type==="individual"? this.ownerData.first_name: this.ownerData.businessname,
          header_logo_path_1: this.environment.logo1_path,
          header_logo_path_2: this.environment.logo2_path,
          client_name: this.environment.project_name,
          senders_name: this.environment.client_name,
          copyright_text: this.environment.copyright_text,
          privacy: this.environment.privacy,
          terms: this.environment.terms,
          role: this.masterDataPipe.transform(this.ownerDetailForm.getRawValue().owners.company_role , this.company_role,'id','value'),
          ...this.ownerDetailForm.getRawValue().owners
        }
        if(this.ownerDetail.owner_type === "corporate"){
          payload.veteran = "",
          payload.race = "",
          payload.gender = "",
          payload.ethnicity = ""
        }
        if (this.ownerDetailForm.getRawValue().owners ?.agreed_terms_and_condition || action === 'save') {
          this.taskInfoService.saveTaskInfo({ slug: this.CONSTANTS.SLUG['verify-owner-consent'], is_primary: true, app_id: this.app_id,
          user_id: this.user_id, }, payload).subscribe(response => {
            if(response){
              this.consentRecieved = true;
              this.ownerDetailForm.disable();
              this.addActivityLog();
              this.common.popToast('success', '', 'Thank you for your consent on the '+this.project+' Portal.');
              this.common.navigate('consent-received');
            }
          });
        } else {
          this.common.popToast('error', 'Error', 'Please accept the terms and conditions.');
        }
      }
    }
  }
  addActivityLog(){
    const log_data = {
      role_slug:  'customer',
      app_id: this.app_id,
      activity: 'consent_provided_by_customer',
      user_name: this.ownerData.owner_type === 'individual' ? `${this.ownerData.first_name}${this.ownerData.middle_name? ' '+this.ownerData.middle_name: ''} ${this.ownerData.last_name} (Customer)` : `${this.ownerData.businessname} (Customer)`,
      note: this.ownerData.owner_type === 'individual' ? `${this.ownerData.first_name}${this.ownerData.middle_name? ' '+this.ownerData.middle_name: ''} ${this.ownerData.last_name}` : `${this.ownerData.businessname}`
    };
    this.common.addActivityLog(log_data);
  }
  ngOnDestroy() {
    this.common.updateStepState(0);
  }
}
