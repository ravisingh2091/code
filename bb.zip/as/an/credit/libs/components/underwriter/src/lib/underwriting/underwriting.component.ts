import { Component, OnInit,Inject} from '@angular/core';
import { TaskInfoService } from '@rubicon/utils';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';
import { BIZINDIVIDUALCONFIG } from './business-individual-config';

@Component({
  selector: 'underwriting',
  templateUrl: './underwriting.component.html',
  styleUrls: ['./underwriting.component.scss']
})
export class UnderwritingComponent implements OnInit {
  slug: string;
  appId: string;
  applicationData: any;
  cra_reference_data:any;
  userId:  string;
  backendUserId: string;
  bizIndividualConfig: any;
  config_bridger:any= {
    url: this.environment.orchUrl+"v2/tasks",
    css: {
      error: {
        'margin-top': '5px',
        color: '#af000d',
        'font-size': '0.8125rem',
        'text-align': 'left',
        'font-weight': '300',
        'margin-bottom': '0',
        'line-height': '19.2px',
      },
      label: {
        left: '0',
        'text-align': 'left!important',
        'font-size': '0.9375rem',
        'font-weight': '500',
        color: '#000',
      },
      text: {
        'font-size': '12px',
        'font-weight': '400',
        'text-align': 'left',
        color: '#4f4f4f',
        padding: '15px 0',
      }
    
    },
    task: {
      activity_log_business_owner: {
        params: {
          slug: 'activity_logs'
        },
        headers: {},
        body: {
          role: '',
          app_id: '', 
          backend_user_id: '',
          user_name: '',
          activity: 'lexis_nexis',
          note: '',
          owner_id: ''
        }
      },
      state_list: {
        params: {
          slug: 'get_us_states'
        },
        headers: {} 
      },
      business_reference: {
        params: {
          slug: 'get_business_reference',
        },
        headers: {},
      },
      owner_reference: {
        params: {
          slug: 'get_owner_reference',
        },
        headers: {},
      }
    },
    isReadOnly: false
  }
  loanStatus : string;
  loanId;
  userData;
  constructor(
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    @Inject('environment') public environment,
    @Inject('CONSTANTS') public CONSTANTS
  ) { }

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.appId = rootState.appID
      this.userId = rootState?.appData?.user_id;
      this.loanId = rootState?.appData?.loan_id;
      this.userData = rootState?.userData;
      this.backendUserId = this.userData?.user_id;
      this.config_bridger['app_id']=this.appId
      this.config_bridger['user_id']=this.userId
      this.config_bridger['backend_user_id'] = this.backendUserId;
      this.config_bridger['role_slug'] = this.userData?.role_slug;
      this.config_bridger['user_name'] = this.userData.full_name;
      this.config_bridger['loan_id'] = this.loanId;
      this.config_bridger['isReadOnly'] = this.userData.role_slug === this.CONSTANTS.ROLE_SLUGS.admin;
      this.taskInfoService.getTaskInfo({ slug: this.CONSTANTS.SLUG['underwriter_accordion_info'], app_id: this.appId, user_id: this.userId }).subscribe(response => {
          this.applicationData = response?.response_data?.app_detail?.data?.data[0];
          this.loanStatus = this.applicationData?.status_id;
          this.configureBusinessIndividual();
      }) 
    }) 
  }

  configureBusinessIndividual() {
    this.bizIndividualConfig = BIZINDIVIDUALCONFIG;
    this.bizIndividualConfig['app_id'] = this.appId;
    this.bizIndividualConfig['userId'] = this.userId;
    this.bizIndividualConfig['loan_id'] = this.loanId;
    this.bizIndividualConfig['role_slug'] = this.userData?.role_slug;
    this.bizIndividualConfig['user_name'] = this.userData.full_name;
    this.bizIndividualConfig['backendUserId'] = this.backendUserId;
    this.bizIndividualConfig['task']['url'] = this.environment.orchUrl + 'v2/tasks';
    this.bizIndividualConfig['isApplicationIncomplete'] = this.showAlertMessage();
    this.bizIndividualConfig['applicationData'] = this.applicationData;
    this.bizIndividualConfig['isReadOnly'] = this.userData.role_slug === this.CONSTANTS.ROLE_SLUGS.admin;
  }

  showAlertMessage() {
    return this.loanStatus === this.CONSTANTS?.APPLICATION_STATUS?.application_in_progress;
  }


}
