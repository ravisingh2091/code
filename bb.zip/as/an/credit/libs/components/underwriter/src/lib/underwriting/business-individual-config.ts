export const BIZINDIVIDUALCONFIG = {
  accordianName: 'Business/Individual Validation',
  applicationData: null,
  isApplicationIncomplete: false,
  incompleteStatusHtml: `<div role="alert" class="alert alert-danger errmsg" >
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"> </button>
      Application is incomplete. Please complete your application<br>
  </div>`,
  app_id: '',
  user_id: '',
  loan_id: '',
  role_slug: '',
  user_name: '',
  backendUserId: '',
  version: 'v1',
  isReadOnly: false,
  task: {
    url: '',
    state_list: {
      params: {
        slug: 'get_us_states'
      },
      headers: {} 
    },
    business_search: {
      params: {
        slug: 'invoke_business_search'
      },
      body: {
        "action":"business_search",
        "business_name": "",
        "state": "",
        "return_count": "10",
        "starting_record": "1",
        "provider": "LN10",
        "tax_id": ""
      },
      headers: {},
    },
    business_report: {
      params: {
        slug: 'get_business_report'
      },
      body: {
        "provider":"LN10",
        "action":"business_report",
        "search_id":"",
        "search_record_id":"",
        "report_type":"json,html",
        "filename": "business_report.pdf",
        "provider1": "60c8365690c5bc3e4851gb51",
        "doc_type_key": "lexis_nexis_business_report",
        "doc_type_id": "5ef9aad1dc5f787eccbb87ff",
        "user_id": "",
        "app_id": "",
        "response":"",
        "backend_user_id":"",
        "loan_id": ''
      },
      headers: {},
    },
    individual_search: {
      params: {
        slug: 'invoke_individual_search'
      },
      body: {
        "action":"individual_search",
        "owner_name": "",
        "ssn": "",
        "return_count": "10",
        "starting_record": "1",
        "provider": "LN10"
      },
      headers: {},
    },
    individual_report: {
      params: {
        slug: 'get_individual_report',
        skip_error: true
      },
      body: {
        "provider":"LN10",
        "action":"individual_report",
        "owner_name":"",
        "owner_id":"",
        "ssn": "",
        "search_id":"",
        "search_record_id":"",
        "report_type":"json,html",
        "filename": "individual_report.pdf",
        "provider1": "60c8365690c5bc3e4851gb52",
        "doc_type_key": "lexis_nexis_individual_report",
        "doc_type_id": "5ef9aad1dc5f787eccbb88ff",
        "user_id": "",
        "app_id": "",
        "response":"",
        "backend_user_id":"",
        "loan_id": '',
      },
      headers: {},
    },
    document_download: {
      params: {
        slug: 'download_pdf',
      },
      body: {},
      headers: {},
    },
    business_reference: {
      params: {
        slug: 'get_business_reference',
      },
      headers: {},
    },
    owner_reference: {
      params: {
        slug: 'get_owner_reference',
      },
      headers: {},
    },
    activity_log_business: {
      params: {
        slug: 'activity_logs'
      },
      headers: {},
      body: {
        role: '',
        app_id: '', 
        backend_user_id: '',
        user_name: '',
        activity: 'business_validation_pulled',
        note: '',
        owner_id: ''
      }
    },
    activity_log_owner: {
      params: {
        slug: 'activity_logs'
      },
      headers: {},
      body: {
        role: '',
        app_id: '', 
        backend_user_id: '',
        user_name: '',
        activity: 'owner_validation_pulled',
        note: '',
        owner_id: ''
      }
    },
    headers: {
    }
  },
  buttonNames : {
    pullReportButton : 'Pull Report',
    searchButton: 'Search',
    backButton: 'Back',
    continueButton: 'Continue',
    downloadButton: 'Download'
  },
  css: {
    businessSearchButtonCss: {
      buttonCss: 'btn-primary mb-2 float-right',
      columnCss: 'col-sm-2',
      emptyColumnCss: 'col-sm-10',
      rowCss: "pb-3 pt-2"
    },
    individualSearchButtonCss: {
      buttonCss: 'btn-primary mb-2',
      columnCss: 'text-right',
      rowCss: "pb-3"
    },
    backButtonCss: {
      columnCss: 'col-xs-12 col-sm-6 col-lg-6 col-xl-6 text-left',
      buttonCss: 'btn-primary'
    },
    backAndContinueButtonRow: 'btn-row pt-3',
    continueButtonCss: {
      columnCss: 'col-xs-12 col-sm-6 col-lg-6 col-xl-6 text-right',
      buttonCss: 'btn-primary mb-2'
    },
    accordianNameColumnCss: 'col-lg-9',
    pullReportButtonCss: 'btn-primary mb-2 float-right',
    downloadButtonCss: 'btn-primary mb-2',
    businessIndividualDropDown: {
      dropDownCss: '',
      columnCss: 'col-lg-4',
      emptyColumnCss: 'col-lg-8',
      rowCss: "pb-2"
    },
    individualReportTableWidth: '',
    businessReportTableWidth: ''
  }
};