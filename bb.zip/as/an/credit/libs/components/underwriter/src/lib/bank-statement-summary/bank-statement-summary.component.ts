import { Component, OnInit, Inject } from '@angular/core';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { CommonService, MasterDataPipe, TaskInfoService } from '@rubicon/utils';
import { take } from 'rxjs/operators';
import { BankStatementService } from '../../../../../ui-kit/src/lib/services/bank-statement.service';

declare const initScript: any;
declare var $: any;
@Component({
  selector: 'bank-statement-summary',
  templateUrl: './bank-statement-summary.component.html',
  styleUrls: ['./bank-statement-summary.component.scss'],
})
export class BankStatementSummaryComponent implements OnInit {
  constructor(
    private bankStatementService: BankStatementService,
    @Inject('environment') public environment,
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    private masterDataPipe: MasterDataPipe
  ) {}
  businessData: any;
  loanID: string;
  industries: any;
  business_structure: any;
  state: any;
  ngOnInit(): void {
    this.store
      .select('app')
      .pipe(take(1))
      .subscribe((rootState) => {
        this.loanID = rootState.appData.loan_id;
        this.taskInfoService
          .getTaskInfo({
            slug: CONSTANTS.SLUG['bank_statement_summary'],
            app_id: rootState.appID,
            user_id: rootState?.appData?.user_id,
            is_primary: true,
          })
          .subscribe((response) => {
            this.businessData = response?.response_data?.user_applications?.data
              ?.data?.length
              ? response.response_data.user_applications.data.data[0]
              : null;
            this.business_structure =
              response?.response_data?.business_structure?.data?.data;
            this.industries =
              response?.response_data?.business_industry?.data?.data;
            this.state = response?.response_data?.state?.data?.data;
          });
      });
    this.bankStatementService.loadWidgetScript();
  }

  checkWidgetLoaded(count, event, type?) {
    let self = this;
    setTimeout(() => {
      if (typeof initScript != undefined) {
        self.loadWidget(event, type);
      } else {
        if (count < 5) {
          self.checkWidgetLoaded(count + 1, event, type);
        }
      }
    }, 2000);
  }

  getWidget(event: Event, type, open, uniqueWidget): void {
    $("."+uniqueWidget).html("");
    if (!open) {
      this.checkWidgetLoaded(0, event, type);
      this.common.startLoad();
      setTimeout(() => {
        this.common.stopLoad();
      }, 3000);
    }
  }

  loadWidget(event, type) {
    const reference = this.businessData.business_references.filter((x) => {
      return ['bank-statement-auto', 'bank-statement-manual'].includes(x.type);
    });
    let transactionID = [];
    for (let item of reference) {
      if (item && item.response && item.response.transaction_uid) {
        transactionID = [...transactionID, ...item.response.transaction_uid];
      } else if (
        item &&
        item.response &&
        item.response.data &&
        item.response.data.transaction_uid
      ) {
        transactionID = [
          ...transactionID,
          ...item.response.data.transaction_uid,
        ];
      }
    }
    const widgetRequestData = {
      config: {
        consolidated_monthly_activity: {
          clientConfig: { hideBlankRows: true },
          bank_statement_end_point: 'summary',
          json: true,
          columns: {
            month_year: {
              value: ' ',
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            opening_balance: {
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            closing_balance: {
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            transfer_in: {
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            deposits: {
              value: 'Credit',
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            withdrawals: {
              value: 'Debits',
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            transfer_out: {
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            net_cash_flow: {
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            no_of_revenue_transactions: {
              value: '# of Revenue Transactions',
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            no_of_days_with_negative_balance: {
              value: '# of Days with Negative Balance',
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            no_of_nsf: {
              value: '# of NSFs',
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            avg_daily_balance: {
              value: 'Avg. Daily Balance',
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
          },
          html: {
            no_record_found: 'asldkfh lasjdlf;has l;fdal;shj fljkasdf lj;h',
          },
          css: {
            tableHeader: {},
            tableBody: {},
          },
          filter: {
            account_number: {
              default_option: 'All/Consolidated',
              flag: true,
            },
          },
        },
        transactions: {
          json: true,
          value: 'High Value Transactions',
          columns: {
            bank_name: {
              order: 1,
              config: {
                header: {
                  class: 'label-block font-sb',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            account_number: {
              order: 2,
              config: {
                header: {
                  class: 'label-block small-block',
                },
                row: {
                  class: 'label-block small-block',
                },
              },
            },
            transaction_date: {
              order: 3,
              value: 'Date',
              format: ['dd/mm/yyyy', 'mm/dd/yyyy'],
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            month_year: {
              order: 4,
              value: 'Month-Year',
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            description: {
              order: 5,
              value: 'Transaction Description',
              callback: {
                name: 'addMoreTextOnLargeText',
              },
              config: {
                header: {
                  class: 'label-block medium-block',
                },
                row: {
                  class: 'label-block medium-block',
                },
              },
              style: {},
            },
            transaction_type: {
              order: 6,
              value: 'Type',
              callback: {
                name: 'keyToCamelCaseWithUpperCaseString',
              },
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            amount: {
              order: 7,
              callback: {
                name: 'roundOff',
              },
              value: 'Amount',
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            running_balance: {
              value: 'Running Balance',
              order: 8,
              sort_by_header: true,
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block small-block',
                },
                row: {
                  class: 'label-block small-block',
                },
              },
            },
            category: {
              order: 9,
              value: 'Classification',
              config: {
                header: {
                  class: 'label-block small-block',
                },
                row: {
                  class: 'label-block small-block',
                },
              },
            },
            group: {
              order: 10,
              callback: {
                args: 'str',
                body: "return str.length === 0 ? 'Unclassified' : str",
              },
              config: {
                header: {
                  class: 'label-block medium-block',
                },
                row: {
                  class: 'label-block medium-block',
                },
              },
            },
          },
          filter: {
            account_number: {
              default_option: 'All/Consolidated',
              flag: true,
            },
            group: {
              default_option: 'Group/All',
              // "other": [{
              //  "html": "Unclassified",
              //  "value": " "
              // }],
              flag: true,
            },
            transaction_type: {
              default_option: 'Credit/Debit',
              flag: true,
            },
          },
        },
        account_info: {
          json: true,
        },
        ebitda_schedule: {
          json: true,
          value: 'Est. Operating Profit & DSCR',
          content: 'EBITDA SCHEDULE Value',
          gross_annual_revenue: 324,
          pagination: true,
          dscr: true,
          css: {
            tableHeader: {},
            tableBody: {},
            pagination: {
              'border-radius': '50%',
              background: 'black',
              height: '30px',
              width: '30px',
              display: 'inline-block',
              color: 'white',
              'text-align': 'center',
              margin: '5px',
            },
          },
          append: {
            class: {
              pagination: '',
            },
          },
        },
        dscr_schedule: {
          json: true,
          columns: {
            group: {
              value: '<b>( In thousands)</b>',
              config: {
                header: {
                  class: 'col label-block large-block',
                },
                row: {
                  class: 'col label-block large-block',
                },
              },
            },
            yearly: {
              order: 2,
              callback: {
                name: 'separateNumberByDelimiterWithoutSign',
              },
              value: 'Annual',
              config: {
                header: {
                  class: 'col label-block large-block',
                },
                row: {
                  class: 'col label-block large-block',
                },
              },
            },
            half: {
              order: 3,
              callback: {
                name: 'separateNumberByDelimiterWithoutSign',
              },
              value: 'Prior 6 month (actual)',
              config: {
                header: {
                  class: 'col label-block large-block',
                },
                row: {
                  class: 'col label-block large-block',
                },
              },
            },
            quarterly: {
              order: 4,
              callback: {
                name: 'separateNumberByDelimiterWithoutSign',
              },
              value: 'Prior 3 month (actual)',
              config: {
                header: {
                  class: 'col label-block large-block',
                },
                row: {
                  class: 'col label-block large-block',
                },
              },
            },
            monthly: {
              order: 5,
              callback: {
                name: 'separateNumberByDelimiterWithoutSign',
              },
              value: 'Prior 1 month (actual)',
              config: {
                header: {
                  class: 'col label-block large-block',
                },
                row: {
                  class: 'col label-block large-block',
                },
              },
            },
          },
          rows: {
            '3': {},
          },
        },
        consolidated_monthly_line_item: {
          json: true,
          value: 'Monthly Line Items Summary',
          columns: {
            transaction: {
              config: {
                header: {
                  class: 'label-block font-sb col',
                },
                row: {
                  class: 'label-block col',
                },
              },
            },
            category: {
              value: 'Line Item',
              config: {
                header: {
                  class: 'label-block font-sb col',
                },
                row: {
                  class: 'label-block large-block col',
                },
              },
            },
            average: {
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block col',
                },
                row: {
                  class: 'label-block col',
                },
              },
            },
          },
          filter: {
            account_number: {
              default_option: 'All/Consolidated',
              flag: true,
            },
          },
        },
        account_level_monthly_activity: {
          bank_statement_end_point: 'summary',
          json: true,
        },
        account_level_high_value_transactions: {
          bank_statement_end_point: 'summary',
          json: true,
        },
        consolidated_debt_analysis: {
          bank_statement_end_point: 'summary',
          json: true,
          columns: {
            source: {
              config: {
                header: {
                  class: 'label-block font-b',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            measure: {
              config: {
                header: {
                  class: 'label-block',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            total: {
              callback: {
                name: 'roundOff',
              },
              config: {
                header: {
                  class: 'label-block font-b',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
            // average: {
            //   value: 'Avg/Month',
            //   callback: {
            //     name: 'roundOff',
            //   },
            //   config: {
            //     header: {
            //       class: 'label-block font-b',
            //     },
            //     row: {
            //       class: 'label-block',
            //     },
            //   },
            // },
          },
          filter: {
            account_number: {
              default_option: 'All/Consolidated',
              flag: true,
            },
            month: {
              default_option: 'All',
              flag: true,
            },
          },
          rows: {
            exclude: 'even',
          },
        },
        account_level_debt_analysis: {
          bank_statement_end_point: 'summary',
          json: true,
        },
        consolidated_trend_analysis: {
          bank_statement_end_point: 'summary',
          json: true,
          columns: {
            group: {
              config: {
                header: {
                  class: 'label-block font-b',
                },
                row: {
                  class: 'label-block',
                },
              },
            },
          },
          filter: {
            account_number: {
              default_option: 'All/Consolidated',
              flag: true,
            },
            select1: {
              default_option: 'All',
              flag: true,
            },
            select2: {
              default_option: 'All',
              flag: true,
            },
          },
        },
        account_level_trend_analysis: {
          bank_statement_end_point: 'summary',
          json: true,
        },
        account_level_monthly_line_item: {
          json: true,
        },
      },
      security: {
        headers: {
          'X-SESSION-ID':
            'f7097c362000a0e87621aeb9be6aeca89729b3e58ae4822aa6de061beb2144216076d888d5f91d25df4b9e09',
        },
      },
      // "transaction_id": ["607d60ce65dc270001b10f00", "607d615865dc270001b10f31", "607d618565dc270001b10f3a"],
      // "resource": ["consolidated_debt_analysis"],
      // "resource": ["account_info"],
      // "resource": ["consolidated_monthly_activity"],
      // "resource": ["consolidated_trend_analysis"],
      // "resource": ["consolidated_monthly_line_item"],
      resource: [type],
      // "resource": ["transactions"],
      transaction_id: transactionID,
      class:  type,
    };
    var finalobj = {
      widgetType: 'summary-v2',
      widget_service_api: this.environment.orchUrl + 'v2',
      x_tenant_id: this.environment.X_TENANT_ID,
      slugs: { statements: 'wgt_statements' },
      // "widget_service_api": 'http://localhost:3006/',
      // "widget_service_api": 'http://localhost:3007'+'/orchbase/WIDGETBANKSTATEMENT_API/',
      api_urls: {
        img_src: 'https://d36kr2on5nrk8s.cloudfront.net/images/',
      },
      body: widgetRequestData,
    };
    // console.log(pdfV2Template.main)
    initScript.getTemplate(finalobj).then(function (res) {
      console.log(res);
    });
      // let x = initScript.getTemplate(finalobj);

    // const reference = this.businessData.business_references.filter((x) => {
    //   return ['bank-statement-auto', 'bank-statement-manual'].includes(x.type);
    // });
    // let transactionID = [];
    // for (let item of reference) {
    //   if (item && item.response && item.response.transaction_uid) {
    //     transactionID = [...transactionID, ...item.response.transaction_uid];
    //   } else if (
    //     item &&
    //     item.response &&
    //     item.response.data &&
    //     item.response.data.transaction_uid
    //   ) {
    //     transactionID = [
    //       ...transactionID,
    //       ...item.response.data.transaction_uid,
    //     ];
    //   }
    // }
    // let applicationDetails = {
    //   customer_app_id: this.loanID,
    //   industry: this.masterDataPipe.transform(
    //     this.businessData.business[0].industry,
    //     this.industries,
    //     'id',
    //     'value'
    //   ),
    //   business_name: this.businessData.business[0].business_name,
    //   state: this.masterDataPipe.transform(
    //     this.businessData.business[0].state,
    //     this.state,
    //     'id',
    //     'value'
    //   ),
    //   business_structure: this.masterDataPipe.transform(
    //     this.businessData.business[0].business_structure,
    //     this.business_structure,
    //     'id',
    //     'value'
    //   ),
    // };
    // var initScriptObj = {
    //   widget_service_api: this.environment.orchUrl + 'v2',
    //   // widget_service_api: "http://localhost:3006",
    //   //x_tenant_id: 'c1591715-68fd-4d55-abba-f6604dfbf312',
    //   slugs: { statements: 'wgt_statements' },
    //   widgetType: 'summary',
    //   body: {
    //     config: {
    //       transactions: {
    //         application_overview: applicationDetails,
    //         value: 'Transaction Information',
    //         columns: {
    //           bank_name: {
    //             order: 1,
    //           },
    //           month_year: {
    //             value: 'Month-Year',
    //             order: 4,
    //           },
    //           account_number: {
    //             order: 2,
    //             callback: {
    //               args: 'str',
    //               body:
    //                 "return str.replace(/(\\d+)(\\d{4})/gm, (match, start, end) => {let delimiter = 'x';return delimiter.repeat(start.length) + end;});",
    //             },
    //           },
    //           transaction_date: {
    //             value: 'Date',
    //             order: 3,
    //             format: ['dd/mm/yyyy', 'mm-dd-yyyy'],
    //           },

    //           description: {
    //             value: 'Transaction Description',
    //             order: 5,
    //           },
    //           transaction_type: {
    //             value: 'Credit/Debit Item',
    //             order: 6,
    //             callback: {
    //               args: 'header',
    //               body:
    //                 'return header.replace(header[0], header[0].toUpperCase())',
    //             },
    //           },
    //           amount: {
    //             sort_by_header: true,
    //             order: 7,
    //             separate_num: [3, ','],
    //             value: 'Amount ($)',
    //           },
    //           running_balance: {
    //             value: 'Running Balance ($)',
    //             separate_num: [3, ','],
    //             order: 8,
    //           },
    //           yodlee_category: {
    //             order: 9,
    //           },
    //           category: {
    //             value: 'Classification',
    //             order: 10,
    //           },
    //           group: {
    //             order: 11,
    //             value: 'Group',
    //           },
    //           source: {
    //             order: 12,
    //           },
    //           source_class: {
    //             order: 13,
    //           },
    //         },
    //         filter: {
    //           multiple: true,
    //           account_level: {
    //             flag: true,
    //           },
    //           classifications: {
    //             flag: true,
    //           },
    //           group: {
    //             flag: true,
    //           },
    //         },
    //         pagination: true,
    //         items_per_page: [5, 10, 25, 50, 100, 500, 1000],
    //         class: 'lol',
    //         css: {
    //           tableHeader: {
    //             'background-color': '#2a5135',
    //             color: '#fff',
    //           },
    //           tableBody: {
    //             // background: 'black',
    //             // color: 'white'
    //           },
    //           pagination: {},
    //         },
    //       },
    //       transaction_info: {
    //         application_overview: applicationDetails,

    //         columns: {
    //           bank_name: {
    //             order: 1,
    //           },
    //           account_number: {
    //             order: 2,
    //             callback: {
    //               args: 'str',
    //               body:
    //                 "return str.replace(/(\\d+)(\\d{4})/gm, (match, start, end) => {let delimiter = 'x';return delimiter.repeat(start.length) + end;});",
    //             },
    //           },
    //           date: {
    //             order: 3,
    //             format: ['dd/mm/yyyy', 'mm-dd-yyyy'],
    //           },
    //           month_year: {
    //             order: 4,
    //           },
    //           description: {},
    //           transaction_type: {
    //             value: 'Credit/Debit item',
    //           },
    //           amount: {
    //             separate_num: [3, ','],
    //           },
    //           running_balance: {
    //             // value: 'Balance ($)',
    //             separate_num: [3, ','],
    //           },
    //           yodlee_category: {},
    //           Classification: {},
    //           group: {},
    //           source: {},
    //           source_class: {},
    //           /*category: {
    //             value: 'Classification'
    //         },*/
    //         },
    //         css: {
    //           tableHeader: {
    //             'background-color': '#2a5135',
    //             color: '#fff',
    //           },
    //           tableBody: {
    //             // background: 'black',
    //             // color: 'white'
    //           },
    //           pagination: {},
    //         },
    //       },
    //       monthly_line_item: {
    //         content:
    //           'Sum* is the total average that is calculated as a sum of per Account Monthly Average .',
    //         application_overview: applicationDetails,
    //         value: 'Transaction Information',
    //         pagination: true,
    //         items_per_page: [5, 10, 25, 50, 100, 500, 1000],
    //         css: {
    //           tableHeader: {
    //             'background-color': '#2a5135',
    //             color: '#fff',
    //           },
    //           tableBody: {
    //             // background: 'black',
    //             // color: 'white'
    //           },
    //           pagination: {},
    //         },
    //         // headerStyle: 'all_caps',
    //       },
    //       ebitda_schedule: {
    //         value: 'EBITDA Schedule',

    //         application_overview: applicationDetails,
    //         gross_annual_revenue: 450000,
    //         css: {
    //           tableHeader: {
    //             'background-color': '#2a5135',
    //             color: '#fff',
    //           },
    //           tableBody: {
    //             // background: 'black',
    //             // color: 'white'
    //           },
    //           pagination: {},
    //         },
    //         // headerStyle: 'all_caps',
    //       },
    //       account_info: {
    //         application_overview: applicationDetails,
    //         value: 'Bank Statement Accounts',
    //         // headerStyle: 'all_caps',
    //         columns: {
    //           account_number: {
    //             value: 'Account Number',
    //             callback: {
    //               args: 'str',
    //               body:
    //                 "return str.replace(/(\\d+)(\\d{4})/gm, (match, start, end) => {let delimiter = 'x';return delimiter.repeat(start.length) + end;});",
    //             },
    //           },
    //           bank_name: {
    //             value: 'Bank Name',
    //           },
    //           from_date: {
    //             format: ['dd/mm/yyyy', 'mm-dd-yyyy'],
    //             value: 'Month From',
    //           },
    //           to_date: {
    //             format: ['dd/mm/yyyy', 'mm-dd-yyyy'],
    //             value: 'Month To',
    //           },
    //           duration_months: {
    //             value: '# of Months',
    //           },

    //           no_of_credits: {
    //             value: '# Credits',
    //           },
    //           credits: {
    //             value: 'Credits ($)',
    //             separate_num: [3, ','],
    //           },

    //           no_of_debits: {
    //             value: '# Debits',
    //           },

    //           debits: {
    //             value: 'Debits ($)',
    //             separate_num: [3, ','],
    //           },
    //         },
    //         css: {
    //           tableHeader: {
    //             'background-color': '#2a5135',
    //             color: '#fff',
    //           },
    //           tableBody: {
    //             // background: 'black',
    //             // color: 'white'
    //           },
    //           pagination: {},
    //         },
    //       },
    //       high_order_value: {
    //         application_overview: applicationDetails,
    //         value: 'High Value Transaction',
    //         columns: {
    //           bank_name: {
    //             order: 1,
    //           },

    //           account_number: {
    //             order: 2,
    //             callback: {
    //               args: 'str',
    //               body:
    //                 "return str.replace(/(\\d+)(\\d{4})/gm, (match, start, end) => {let delimiter = 'x';return delimiter.repeat(start.length) + end;});",
    //             },
    //           },
    //           transaction_date: {
    //             value: 'Date',
    //             order: 3,
    //             format: ['dd/mm/yyyy', 'mm-dd-yyyy'],
    //           },
    //           month_year: {
    //             value: 'Month-Year',
    //             order: 4,
    //           },

    //           description: {
    //             value: 'Transaction Description',
    //             order: 5,
    //           },

    //           amount: {
    //             order: 6,
    //             sort_by_header: true,
    //             separate_num: [3, ','],
    //             value: 'Amount ($)',
    //           },
    //           running_balance: {
    //             sort_by_header: true,
    //             value: 'Running Balance ($)',
    //             separate_num: [3, ','],
    //             order: 7,
    //           },
    //           group: {
    //             order: 11,
    //             value: 'Credit/Debit item',
    //           },

    //           category: {
    //             value: 'Classification',
    //             order: 8,
    //           },
    //           transaction_type: {
    //             value: 'Type',
    //             callback: {
    //               args: 'header',
    //               body:
    //                 'return header.replace(header[0], header[0].toUpperCase())',
    //             },
    //             order: 9,
    //           },
    //         },
    //         css: {
    //           tableHeader: {
    //             'background-color': '#2a5135',
    //             color: '#fff',
    //           },
    //           tableBody: {
    //             // background: 'black',
    //             // color: 'white'
    //           },
    //           pagination: {},
    //         },
    //         filter: {
    //           classifications: {
    //             flag: true,
    //           },
    //           amount_level: {
    //             flag: true,
    //             lte: {},
    //             gte: {
    //               label: 'At Least ',
    //               value: ['$' + 500, '$' + 1000, '$' + 2000],
    //             },
    //             btw: {},
    //           },
    //           account_level: {
    //             flag: true,
    //           },
    //           transaction_type: {
    //             flag: true,
    //           },
    //           unit_level: {
    //             flag: true,
    //             label: 'Top',
    //           },
    //         },

    //         pagination: true,
    //         items_per_page: [10, 25, 50, 100, 500, 1000],
    //       },
    //       consolidated_monthly_activity: {
    //         application_overview: applicationDetails,
    //         bank_statement_end_point: 'summary',
    //         css: {
    //           tableHeader: {
    //             'background-color': '#2a5135',
    //             color: '#fff',
    //           },
    //           tableBody: {
    //             // background: 'black',
    //             // color: 'white'
    //           },
    //           pagination: {},
    //         },
    //       },
    //       account_level_monthly_activity: {
    //         application_overview: applicationDetails,
    //         value: 'Summary',
    //         json: true,
    //         outlier_report: {
    //           title: 'Summary View & Monthly Activity',
    //           subtitle: ' ',
    //           seriesData: [
    //             {
    //               name: 'Credit',
    //               color: '#9fe3f0',
    //             },
    //             {
    //               name: 'Debit',
    //               color: '#75c19b',
    //             },
    //           ],
    //         },
    //         columns: {
    //           month_year: {
    //             value: 'Month',
    //             order: 1,
    //           },
    //           opening_balance: {
    //             value: 'Opening Balance ($)',
    //             order: 2,
    //             separate_num: [3, ','],
    //           },
    //           closing_balance: {
    //             value: 'Closing Balance ($)',
    //             order: 3,
    //             separate_num: [3, ','],
    //           },
    //           deposits: {
    //             value: 'Deposits ($)',
    //             order: 4,
    //             separate_num: [3, ','],
    //           },
    //           withdrawals: {
    //             value: 'Withdrawals ($)',
    //             order: 5,
    //             separate_num: [3, ','],
    //           },
    //           deposit_transfers: {
    //             value: 'Deposit Transfers ($)',
    //             order: 6,
    //             separate_num: [3, ','],
    //           },
    //           withdrawals_transfers: {
    //             value: 'Withdrawals Transfers ($)',
    //             order: 7,
    //             separate_num: [3, ','],
    //           },
    //           net_transfers: {
    //             value: 'Net Transfers ($)',
    //             order: 8,
    //             separate_num: [3, ','],
    //           },
    //           net_cash_flow: {
    //             value: 'Net Cash Flow ($)',
    //             order: 9,
    //             separate_num: [3, ','],
    //           },
    //           no_of_deposits: {
    //             value: 'No. of Deposits',
    //             order: 10,
    //           },
    //           no_of_days_with_negative_balance: {
    //             value: 'No. of Days with Negative Balance',
    //             order: 11,
    //           },
    //           no_of_nsf: {
    //             value: 'No. of NSF',
    //             order: 12,
    //           },
    //           avg_daily_balance: {
    //             value: 'Avg. Daily Balance ($)',
    //             order: 13,
    //             separate_num: [3, ','],
    //           },
    //           account_number: {
    //             order: 14,
    //             callback: {
    //               args: 'str',
    //               body:
    //                 "return str.replace(/(\\d+)(\\d{4})/gm, (match, start, end) => {let delimiter = 'x';return delimiter.repeat(start.length) + end;});",
    //             },
    //           },
    //         },
    //         css: {
    //           tableHeader: {
    //             'background-color': '#2a5135',
    //             color: '#fff',
    //           },
    //           tableBody: {
    //             // background: 'black',
    //             // color: 'white'
    //           },
    //           pagination: {},
    //         },
    //         bank_statement_end_point: 'summary',
    //         filter: {
    //           account_level: {
    //             default_option: 'Consolidated',
    //             flag: true,
    //           },
    //         },
    //       },
    //     },
    //     transaction_id: transactionID,
    //     resource: type,
    //     class: type,
    //   },
    // };

    //   if (this.environment.X_TENANT_ID) {
    //     initScriptObj['x_tenant_id'] = this.environment.X_TENANT_ID;
    //   }
    //   let x = initScript.getTemplate(initScriptObj);
  }
}
