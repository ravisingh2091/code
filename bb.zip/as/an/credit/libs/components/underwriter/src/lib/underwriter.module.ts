import {
  NgModule,
  CUSTOM_ELEMENTS_SCHEMA,
  NO_ERRORS_SCHEMA,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Route } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { UnderwritingComponent } from './underwriting/underwriting.component';
import { BankStatementSummaryComponent } from './bank-statement-summary/bank-statement-summary.component';
import { IrsModule } from '@credit-bench/components/irs';
import { MasterDataPipe } from '@rubicon/utils';
import { ComponentsCafModule } from '@credit-bench/components/caf';
import { EvaluationModule } from '@credit-bench/components/evaluations';
import { CashFlowAnalysisModule } from '@credit-bench/components/cash-flow-analysis';
import { LexisNexisModule } from 'lexis-nexis';
import {ClearModule} from "clear";
export const UnderwriterRoutes: Route[] = [
  {
    path: '',
    component: UnderwritingComponent,
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(UnderwriterRoutes),
    IrsModule,
    SharedLazyModule,
    ComponentsCafModule,
    EvaluationModule,
    CashFlowAnalysisModule,    
    LexisNexisModule,
    ClearModule
  ],
  declarations: [UnderwritingComponent, BankStatementSummaryComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  providers: [MasterDataPipe],
})
export class UnderwriterModule {}
