import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Route } from '@angular/router';
import { UiKitModule } from '@credit-bench/ui-kit';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { ApplicationListingComponent } from './application-listing/application-listing.component';
import { ApplicationDetailsComponent } from './application-details/application-details.component';
import { LoanActionsComponent } from './loan-actions/loan-actions.component';
import { DocumentsComponent } from './documents/documents.component';
import { NotesComponent } from './notes/notes.component';
import { ManageLoansService } from './services/manage-loans.service';
import { LandlordWaiverComponent } from 'libs/sba-form-landlord/src/lib/landlord-waiver/landlord-waiver.component';
import { CollateralReportableComponent } from 'libs/components/evaluations/src/lib/CollateralReportable/collateral-reportable.component';
import { SbaForm601Component } from 'libs/sba-form601/src/lib/form601/form601.component';
import { SbaForm1050Component } from 'libs/sba-form1050/src/lib/form1050/form1050.component';
import { Sba159Component } from 'libs/sba159/src/lib/sba159/sba159.component';
import { IrsManualFormComponent } from 'libs/components/irs/src/lib/irs-manual-form/irs-manual-form.component';
import { IrsOnlineFormComponent } from 'libs/components/irs/src/lib/irs-online-form/irs-online-form.component';
import { GenerateCAFComponent } from 'libs/components/caf/src/lib/generate-caf/generate-caf.component';
import { Sba1920Component } from 'libs/sba1920/src/lib/sba1920/sba1920.component';
import { BusinessFinancialComponent } from 'libs/components/cash-flow-analysis/src/lib/business-financial/business-financial.component';
import { PersonalFinancialComponent } from 'libs/components/cash-flow-analysis/src/lib/personal-financial/personal-financial.component';
import { DecisionHistoryComponent } from 'libs/components/caf/src/lib/decision_history/decision_history.component';
import { RequestedDocumentsComponent } from './documents/requested-documents/requested-documents.component';
import { NoticeOfIncompletenessComponent } from './notice-of-incompleteness/notice-of-incompleteness.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { GdscrComponent } from 'libs/components/cash-flow-analysis/src/lib/gdscr/gdscr.component';
import { NoticeOfIncompletenessPdfComponent } from './notice-of-incompleteness/notice-of-incompleteness-pdf/notice-of-incompleteness-pdf.component';
import { ComponentsApplicationPdfModule } from '@credit-bench/components/application-pdf';
import { DateTimezonePipe } from 'libs/shared-lazy/src/lib/pipes/date-timezone.pipe';
import { ActivityComponent } from './activity/activity.component';
import { DeclineLetterComponent } from './decline-letter/decline-letter.component';
export const ManageLoansRoutes: Route[] = [
  {
    path: '',
    component: ApplicationListingComponent
  },
  {
    path: 'irs-manual',
    component: IrsManualFormComponent
  },
  {
    path: 'irs-online',
    component: IrsOnlineFormComponent
  },
  {
    path: 'sbaform_601', 
    component: SbaForm601Component
  },
  {
    path: 'sbaform_1050', 
    component: SbaForm1050Component
  },
  {
    path:'form159',
    component: Sba159Component
  },
  {
    path:'landlord_waiver',
    component: LandlordWaiverComponent
  },
  {
    path:'collateral-reportable',
    component: CollateralReportableComponent
  },
  {
    path:'notice-of-incompleteness',
    component: NoticeOfIncompletenessComponent
  },
  {
    path: 'collateral-eval', loadChildren: () => import('@credit-bench/components/collateral-evaluation').then(
      m => m.CollateralEvaluationModule
    )
  },
  {
    path: 'hmda', loadChildren: () => import('@credit-bench/components/hmda').then(
    m => m.HmdaModule
    )
  },
  {
    path:'form1920',
    component: Sba1920Component
  },
  {
    path: 'business-financial', 
    component: BusinessFinancialComponent
  },
  {
    path:'credit-approval-form',
    component: GenerateCAFComponent
  },
  {
    path:'caf-decision-history',
    component: DecisionHistoryComponent
  },
  {
    path: 'personal-financial', 
    component: PersonalFinancialComponent
  },
  {
    path: 'gdscr', 
    component: GdscrComponent
  },
  {
    path: 'application-details',
    component: ApplicationDetailsComponent,
    children: [
      //application->bydefault      {
      {
        path: 'application-info',
        loadChildren: () =>
          import('@credit-bench/components/application-info').then(
            (m) => m.ApplicationInfoModule
          ),
      },
      {
        path: 'underwriting', loadChildren: () => import('@credit-bench/components/underwriter').then(
          m => m.UnderwriterModule
        )
      },
      {
        path: 'documents',
        component: DocumentsComponent,
      },
      {
        path: 'checklist', loadChildren: () => import('@credit-bench/components/checklist').then(
          m => m.ChecklistModule
        )
      },
      {
        path: 'notes', component: NotesComponent
      },
      {
        path: 'activity', component: ActivityComponent
      },
      {
        path: 'sba', loadChildren: () => import('@credit-bench/components/sba-tab').then(
        m => m.SbaTabModule
      )
      },
      {
        path: 'connect-customer', loadChildren: () => import('@credit-bench/components/connect-banker-customer').then(
            m => m.ComponentsConnectBankerCustomerModule
        )
      },
      {
        path: "",
        redirectTo: 'application-info',
        pathMatch: "full"
      },
    ]
  }
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    RouterModule.forChild(ManageLoansRoutes),
    UiKitModule,
    SharedLazyModule,
    BsDatepickerModule.forRoot(),
    ComponentsApplicationPdfModule
  ],
  declarations: [
    ApplicationListingComponent,
    ApplicationDetailsComponent,
    LoanActionsComponent,
    DocumentsComponent,
    NotesComponent,
    ActivityComponent,
    NoticeOfIncompletenessComponent,
    RequestedDocumentsComponent,
    NoticeOfIncompletenessPdfComponent,
    DeclineLetterComponent
  ],
  providers: [
    ManageLoansService,
    DateTimezonePipe
  ]
})
export class ManageLoansModule { }
