import { Component, Inject, Input, OnInit } from '@angular/core';

@Component({
  selector: 'notice-of-incompleteness-pdf',
  templateUrl: './notice-of-incompleteness-pdf.component.html',
  styleUrls: ['./notice-of-incompleteness-pdf.component.scss']
})
export class NoticeOfIncompletenessPdfComponent implements OnInit {
  dateOfCreation = new Date();
  @Input() ownerName;
  @Input() documentList = [];
  @Input() rmName;
  @Input() bankName;
  @Input() rmEmail;
  @Input() rmNumber;
  @Input() deadLineDate;

  bankInfo = {
    name: this.CONSTANTS.CLIENT_CONFIG.name,
    addressl: this.CONSTANTS.CLIENT_CONFIG.addressl,
    address2: this.CONSTANTS.CLIENT_CONFIG.city+', '+ this.CONSTANTS.CLIENT_CONFIG.state+' '+ this.CONSTANTS.CLIENT_CONFIG.zipcode,
    address3: this.CONSTANTS.CLIENT_CONFIG.country
  }

  logo1_path = this.environment.logo1_path;
  logo2_path = this.environment.logo2_path;
  footerText = this.CONSTANTS.FOOTER_CONGIF.footer_text;
  client_config = this.CONSTANTS.CLIENT_CONFIG;

  constructor(
    @Inject('CONSTANTS') private CONSTANTS,
    @Inject('environment') public environment
    ) { }

  ngOnInit(): void {
  }

}
