import { Component, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { ApplicationPdfComponent } from '@credit-bench/components/application-pdf';
import {
  CommonService,
  TaskInfoService,
  addAppID,
  addBusinessID,
  addAppDetails,
  addUserDetails,
} from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import * as _ from 'lodash';
import { ManageLoansService } from '../services/manage-loans.service';
import { getShortRole, COMPLETE_APPLICATION_AVAILABLITY, UPDATE_CATEGORY_AVAILABLITY, SEND_TO_LASERPRO_AVAILABLITY, getStageFromRole, getShortStage} from '../../../../../app-workflow/actions';

@Component({
  selector: 'application-listing',
  templateUrl: './application-listing.component.html',
  styleUrls: ['./application-listing.component.scss'],
})
export class ApplicationListingComponent implements OnInit, OnDestroy {
  slug: string = '';
  userData: any;
  formValues: any;
  status_pipeline_data: any;
  filterForm: FormGroup;
  filterConfig = [];
  globalObj: any = {
    credit_officer: [],
    rm_assigned: [],
  };
  allItems = [];
  allLeadId = [];
  skip: number = 0;
  limit: number = 10;
  totalLeads: number = 0;
  ecoaTotalDays = 31;
  perPageRecords = [];
  app_master_data = [];
  paginationMaxSize = 5;
  currentPage = 1;
  perPageRecordChange = false;
  checkStatusPipeLineFilter = false;
  modalRef: BsModalRef;
  filter_payload = null;
  appInProg = CONSTANTS?.APPLICATION_STATUS?.application_in_progress
  appAssignedToMap = {};
  bankerMap: any = {};
  loanActionInput: any;
  @ViewChild('applicationPdf') applicationPdf: ApplicationPdfComponent;
  subStatusMap: any = {};
  assignedToStageMap: any = {};
  stageAssignedToMap: any = {};
  currentStageSlug: string;
  app_soft_Decline_status = CONSTANTS?.APPLICATION_STATUS?.application_soft_decline;
  constructor(
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    private modalService: BsModalService,
    private manageLoansService: ManageLoansService
  ) {}

  ngOnInit(): void {
    this.perPageRecords = CONSTANTS.PER_PAGE_RECORDS;
    this.store.select('app').pipe(take(1)).subscribe((rootState) => {
      if (rootState?.userData?.id) {
        const userData = rootState.userData;
        this.userData = {...userData};
      }
      if (this.userData.status_pipeline_data) {
        const start_date = (new Date(this.userData.status_pipeline_data.start_date).getTime() / 1000).toString();
        const end_date = (new Date(this.userData.status_pipeline_data.end_date).getTime() /1000).toString();
        this.status_pipeline_data = {
          status_id: this.userData.status_pipeline_data.status_id,
          start_date,
          end_date
        }
      }
    })
    this.getManageLoans();
    let role_id ='loan_officer_l1,loan_officer_l2,underwriter_l1,underwriter_l2';
    this.taskInfoService.getTaskInfo({ slug: CONSTANTS.SLUG['manage_loans_filter'], role_id})
      .subscribe((response) => {
        let role_slug = this.userData.role_slug;
        this.app_master_data = response?.response_data?.app_status?.data?.data;
        let app_status = response?.response_data?.app_status?.data?.data;
        app_status = app_status.filter(elem => elem.filter == true);
        if (role_slug !== 'admin') {
          let stages = getStageFromRole(role_slug);
          response?.response_data?.app_sub_status?.data?.data?.forEach(element => {
            if (stages.includes(element.stage) && element.filter) {
              app_status.push({ ...element, sub_status: true });
              this.app_master_data.push({ ...element, sub_status: true });
            }
          });
        } else {
          response?.response_data?.app_sub_status?.data?.data?.forEach(element => {
            if (element.filter) {
              app_status.push({ ...element, sub_status: true });
              this.app_master_data.push({ ...element, sub_status: true });
            }
          });
        }
        this.filterConfig = response.form_fields;
        this.slug = response.task_slug;
        let get_banker_by_role = response?.response_data?.get_banker_by_role?.data?.data;
        let loan_officer_list = [];
        let underwriter_list = [];
        loan_officer_list = get_banker_by_role.filter(role => role.roles.role_slug === 'loan_officer_l1' || role.roles.role_slug === 'loan_officer_l2' )
        underwriter_list = get_banker_by_role.filter(role =>role.roles.role_slug === 'underwriter_l1' || role.roles.role_slug === 'underwriter_l2')

        this.common.sendMasterDataToFields(this.filterConfig, {
          ...response.response_data,
          filter_type: { data: { data: CONSTANTS.FILTER_TYPE_MANAGE_LOANS } }
        });
        this.common.sendMasterDataToFields(this.filterConfig,{data: { data: app_status}}, 'status');
        this.common.sendMasterDataToFields(this.filterConfig,{data: { data: loan_officer_list}}, 'loan_officer');
        this.common.sendMasterDataToFields(this.filterConfig,{data: { data: underwriter_list}}, 'Credit_Officer');
      });
    this.store.dispatch(addAppID({ appID: null }));
    this.store.dispatch(addBusinessID({ businessID: null }));
    this.store.dispatch(addAppDetails({ appData: null }));
  }

  getManageLoans() {
    let x = { limit: this.limit, start: this.skip };
    let params = {
      ...x ,
      slug: CONSTANTS.SLUG['manage_loans']
    };
    
    if(CONSTANTS.JUNIOR_ROLE_SLUGS.includes(this.userData.role_slug)) params['assigned_to']=this.userData.user_id;    
    
    if (this.status_pipeline_data) {
      params = {
        ...params,
        ...this.status_pipeline_data
      };
    }
    this.formValues = {
      status: this.status_pipeline_data?.status_id
    };

    if (this.filter_payload && !Object.keys(this.filter_payload).map((e) => this.filter_payload[e]).every((x) => x === null || x === '')) {
      params = {
        ...params,
        ...this.filter_payload,
      };
    }
    // if(this.userData.role_slug === CONSTANTS.ROLE_SLUGS.admin) delete params['assigned_to'];
    this.taskInfoService.getTaskInfo(params)
      .subscribe((response) => {
        // this.slug = response.task_slug;
        this.prepareSubStatusMap(response);
        this.allItems = response.response_data.application_listing.data.data;
        this.prepareAssignedToMap();
        this.allLeadId = response?.response_data?.get_customer_list?.data?.data;
        this.customerIdMapping();
        this.totalLeads = response.response_data.application_listing.data.total;
      });
  }

  current_stage(app_id, user_id, index) {
    this.taskInfoService.getTaskInfo({ slug: CONSTANTS.SLUG['application-current-stage'], app_id: app_id,
    user_id: user_id })
    .subscribe((response) => {
      const current_stage = response?.response_data?.get_current_stage?.data?.data?.stage;
      this.currentStageSlug = response?.response_data?.get_current_stage?.data?.data?.stage?.type;
      if(current_stage?.type) {
        if((SEND_TO_LASERPRO_AVAILABLITY[current_stage.type]) && (['closing_team_l1', 'closing_team_l2'].includes(this.userData.role_slug))) {
          this.allItems[index]['sendToLaserPro'] = true
        }
        if(current_stage?.type){
          this.allItems[index]['allow_update_category'] = UPDATE_CATEGORY_AVAILABLITY[current_stage.type];
          this.allItems[index]['complete_application_status'] = COMPLETE_APPLICATION_AVAILABLITY[current_stage.type];
        }
      }
      
    });
  }

  onclick(item) {
    let appData = {
      primaryOwnerName: '',
      primarOwnerEmail_id: '',
      primaryOwnerPhone_no: '',
      loan_id: item.auto_id,
      lead_id: item.user_record_id,
      user_id: item.user_id,
      business_name: item?.business[0]?.business_name,
      app_biz_tax_id: item?.business[0]?.app_biz_tax_id,
      product: item?.business[0]?.product,
      business_structure: item?.business[0]?.business_structure,
      purpose_arr: item?.business[0]?.purpose_arr,
      productName: item?.products[0]?.sub_product_name,
      status_id: item?.status_id,
      stage_data:  item.business[0].stage_data
    };

    if (item.owners.length > 0) {
      let primaryOwnerData = item.owners.find((e) => e.is_primary === true);
      if (primaryOwnerData) {
        appData.primaryOwnerPhone_no = primaryOwnerData.phone;
        appData.primarOwnerEmail_id = primaryOwnerData.email_address;
        appData.primaryOwnerName = primaryOwnerData.first_name;
      }
    }
    this.store.dispatch(addAppDetails({ appData: appData }));
    this.store.dispatch(addAppID({ appID: item._id }));
    this.store.dispatch(addBusinessID({ businessID: item?.business[0]?._id }));
    if (this.userData.status_pipeline_data) {
      let userDataTemp = { ...this.userData };
      delete userDataTemp.status_pipeline_data;
      this.store.dispatch(
        addUserDetails({
          userData: userDataTemp,
        })
      );
    }
    this.common.navigate('application-details');
  }

  onFilter(event) {
    let filter_assigned_to = ''; 
    if (event.loan_officer && event.Credit_Officer) {
      filter_assigned_to = `${event.loan_officer},${event.Credit_Officer}`
    } else {
      filter_assigned_to = event.loan_officer ? event.loan_officer : event.Credit_Officer ? event.Credit_Officer : '';
    }
    this.filter_payload = {
      type: event.Product_Type,
      filter_assigned_to,
    };
    const status = this.app_master_data.find(elem => elem.id == event.status);
    if (status?.sub_status) {
      this.filter_payload['sub_status_id'] = event.status;
    } else {
      this.filter_payload['status_id'] = event.status;
    }

    if (event?.filter_type) {
      const filter_type = CONSTANTS.FILTER_TYPE_MANAGE_LOANS.find((elem) => elem.id === event?.filter_type)?.type;
      if (filter_type)
        this.filter_payload[filter_type] = filter_type === 'loan_id' ? event.loan_id_value : event.business_name_value;
    }
    this.skip = 0;
    this.perPageRecordChange = true;
    this.getManageLoans();
  }

  pageDetail(event) {
    this.perPageRecordChange = event.perPageRecordChange;
    if (this.skip !== event.skip) {
      this.skip = event.skip;
      this.getManageLoans();
    }
    if (this.perPageRecordChange) {
      this.limit = event.limit;
      this.getManageLoans();
    }
  }

  primary_owner(item) {
    let primary_owner = {
      phone: '',
      name: '',
      email: '',
    };
    if (item.owners.length > 0) {
      let primaryOwnerData = item.owners.find((e) => e.is_primary === true);
      if (primaryOwnerData) {
        primary_owner.phone = primaryOwnerData.phone;
        primary_owner.email = primaryOwnerData.email_address;
        primary_owner.name = primaryOwnerData.first_name;
      }
    }
    return primary_owner;
  }

  customerIdMapping() {
    if (this.allItems) {
      for (let i = 0; i < this.allItems?.length; i++) {
        let lead_data = this.allLeadId?.find(({id}) => id === this.allItems[i].user_id);
        this.allItems[i].user_record_id = lead_data?.record_id;
      }
    }
  }

  openModal(template: TemplateRef<any>, actionType: string, item: any) {
    let uiType = '';
    let user_assignments = this.manageLoansService.getUserAssignments(item, this.bankerMap);
    this.loanActionInput = {
      actionType,
      appId: item._id,
      userId: item.user_id,
      loanStatus: item.status_id,
      sub_status_id: item.sub_status_id,
      status_id: item.status_id,
      loan_id: item.auto_id,
      businessId: item.business[0]._id,
      businessCategoryId: item.business[0].product,
      business_structure: item.business[0].business_structure,
      purpose_arr: item.business[0].purpose_arr,
      app_activity: item?.app_activity,
      business_references: item?.business_references,
      app_assignment: user_assignments,
      business_address: {
        name: item.business[0].business_name,
        street_no: item.business[0].street_no,
        street_name: item.business[0].street_name,
        city: item.business[0].city,
        state: item.business[0].state,
        zip_code: item.business[0].zip_code
      }
    }
    if(item?.owners?.length) {
      const primary_owner = item?.owners.find(ele=>ele.is_primary === true);
      this.loanActionInput['primary_owner_name'] = `${primary_owner?.first_name}${primary_owner.middle_name? (' '+primary_owner.middle_name+' ') :' '}${primary_owner?.last_name}`
    }
    switch (actionType) {
      case 'Update Status':
        uiType = 'updateStatus';
        break;
      case 'Add Note':
        uiType = 'thankyouRegister';
        break;
      case 'Assign To':
        uiType = 'updateStatus';
        break;
      case 'Update Loan Product':
        uiType = 'updateCategory';
        break;
      case 'Send To Laserpro':
        uiType = 'sendLaserpro'
        break; 
    }
    this.modalRef = this.modalService.show(template, {
      class: `modal-lg ${uiType}`,
      backdrop: 'static',
    });
  }

  openNOI(item) {
    if(!item?.products?.length){
      this.common.popToast("error", "", "Please go to ‘Action’ and choose a loan product to proceed.");
      return;
    }
    const primaryOwner = this.primary_owner(item);
    const appDataNoi = {
      primaryOwnerName: primaryOwner['name'],
      primarOwnerEmail_id: primaryOwner['email'],
      primaryOwnerPhone_no: primaryOwner['phone'],
      user_id: item.user_id,
      app_id: item._id,
      loan_id: item.auto_id,
      prevRoute: 'manage-loans',
      status_id: item?.status_id,
      business_references: item?.business_references,
    };
    let user_assignments = this.manageLoansService.getUserAssignments(item, this.bankerMap);

    this.store.dispatch(addAppDetails({appData: { appDataNoi: appDataNoi, app_assignment: user_assignments}}))
    this.common.navigate('notice_of_incompleteness');
  }

  onCloseModal(event) {
    if (event) {
      this.getManageLoans();
    }
    this.modalRef.hide();
  }

  getProduct(item) {
    //showing NotApplicable when application is incomplete
    if (item.status_id === CONSTANTS['APPLICATION_STATUS'].application_in_progress) {
      return 'N/A';
    } else if (item.products.length > 0) {
      let productName = [];
      item.products.forEach((product) => {
        productName.push(product.sub_product_name);
      });
      return productName.join(',');
    } else {
      return '-';
    }
  }

  completeApplication(itemUserId) {
    let lead_data = this.allLeadId.find(({id}) => id === itemUserId);
    let application_data = this.allItems.find(({user_id}) => user_id === itemUserId)
    let business_data = application_data?.business[0];
    let data = {
      first_name: lead_data?.first_name, 
      last_name: lead_data?.last_name, 
      email_address : lead_data?.email_address, 
      phone: lead_data?.phone,
      record_id: lead_data.record_id,
      user_id: lead_data.id
     }

    if (lead_data && business_data) {
      this.store.dispatch(addAppID({ appID: business_data.app_id}));
      this.store.dispatch(addBusinessID({ businessID: business_data._id }));
      if (business_data.step_not_required) {
        this.store.dispatch(addAppDetails({ appData: {
          userData: data,
          loan_id: application_data.auto_id,
          step_not_required: business_data.step_not_required,
          sba_initiated_by : business_data?.sba_initiated_by,
          status_id: application_data?.status_id
        }}));
      } else {
        this.store.dispatch(addAppDetails({ appData: {userData: data,  loan_id: application_data.auto_id, status_id: application_data?.status_id}}));
      }
      this.common.navigate(application_data.status_id === CONSTANTS.APPLICATION_STATUS.application_in_progress? business_data.current_state : 'loan-type'); 
    }
  }

  prepareAssignedToMap() {
    this.appAssignedToMap = {};
    this.bankerMap = {};
    this.assignedToStageMap = {};
    this.allItems.forEach((item) => {
      const allAssignment = (item.app_assignment || []).filter((assign) => assign.assigned_to !== undefined);
      // const len = allAssignment.length;
      allAssignment.sort((a, b) => {
        if(a.created_at<b.created_at) return -1;
        if(a.created_at > b.created_at) return 1;
        return 0;
      })
      
      allAssignment.forEach((assignment, index) => {
        if(!this.appAssignedToMap[item._id]) {
          this.appAssignedToMap[item._id] = [];
        }
        
        this.appAssignedToMap[item._id].push(assignment.assigned_to);
        
        if(assignment.stage) {
          // this.assignedToStageMap[assignment.assigned_to] = assignment.stage;
          if(!this.assignedToStageMap[assignment.assigned_to]) {
            this.assignedToStageMap[assignment.assigned_to] = [];
          }
          
          this.assignedToStageMap[assignment.assigned_to].push(assignment.stage);
          // this.assignedToStageMap[assignment.assigned_to].push({stage: assignment.stage, order: index+1});

          // if(!this.stageAssignedToMap[assignment.stage]) {
          //   this.stageAssignedToMap[assignment.stage] = [];
          // }
          // this.stageAssignedToMap[assignment.stage].push(assignment.assigned_to);
        }
      });
      // if(len && allAssignment[len-1]) {
      //   const lastAssignedTo = allAssignment[len-1];
      //     if(!this.appAssignedToMap[item._id]) {
      //       this.appAssignedToMap[item._id] = lastAssignedTo.assigned_to;
      //     }
      // }
    });
   
     let values = Object.keys(this.appAssignedToMap).map(elem=> this.appAssignedToMap[elem]);
     
    if(values?.length) {

      const user_ids = [];
      values.forEach((ids: any) => {
        user_ids.push(...ids);
      });

      const uniqueIds = new Set(user_ids);

      this.taskInfoService.saveTaskInfo({slug: CONSTANTS.SLUG['banker-by-ids']}, {user_ids: Array.from(uniqueIds.values())}).subscribe((res) => {
        const bankers = _.get(res, 'get_banker_by_ids.data.data') || [];
        bankers.forEach((bu) => {
          if(!this.bankerMap[bu.id]) {
            this.bankerMap[bu.id] = bu;
          }
        });
      });
    }
  }

  getBankerName(app) {
    const appId = app._id;
    const bankerIds = this.appAssignedToMap[appId];
    const bankerRoleNames = [];

    const assignments = app.app_assignment;
    assignments.forEach((assignment, index) => {
      const banker = this.bankerMap[assignment.assigned_to];

      if(banker) {
        bankerRoleNames.push({
          role: banker.roles.role_name,
          name: banker.name,
          short_slug: getShortRole(banker.roles.role_slug, assignment.stage),
          stage: assignment.stage,
          backend_user_id: assignment.assigned_to,
          order: index+1
        })
      } else {
        
      }
    });

    
    // if(bankerIds && bankerIds.length > 0){
    // bankerIds.forEach((id, index) => {
    //   const banker = this.bankerMap[id];
    //   const assignedStages = this.assignedToStageMap[id];
    //   if(banker && assignedStages && assignedStages.length) {
    //     const stageSet = new Set(assignedStages);

    //     Array.from(stageSet.values()).forEach((s) => {
    //       bankerRoleNames.push({
    //         role: banker.roles.role_name,
    //         name: banker.name,
    //         short_slug: getShortRole(banker.roles.role_slug, s),
    //         order: index,
    //         stage: s,
    //         backend_user_id: id
    //       })
    //     });
    //   } else if(banker) {
    //     bankerRoleNames.push({
    //       role: banker.roles.role_name,
    //       name: banker.name,
    //       short_slug: getShortRole(banker.roles.role_slug),
    //       stage: undefined,
    //       backend_user_id: id,
    //       order: index+1
    //     })
    //   }
    // });  
    // }

    // const bankerNameMap = {};
    // const names: any = [];
    // bankerRoleNames.forEach((banker) => {
    //   if(banker.stage) {
    //     bankerNameMap[banker.short_slug + '-'+banker.stage] = banker;
    //   } else {
    //     bankerNameMap[banker.backend_user_id] = banker;
    //     // names.push(banker);
    //   }
    // });

    // names.push(...Object.keys(bankerNameMap).map((key) => bankerNameMap[key]));
    // names.sort((a, b) => {
    //   if(a.order < b.order) return -1;
    //   if(a.order > b.order) return 1;
    //   return 0;
    // });

    const uniqueNames = [];

    bankerRoleNames.forEach((b) => {
      if(b.stage) {
        const index = uniqueNames.findIndex((un) => un.stage === b.stage);
        if(index  !== -1) {
          uniqueNames[index] = b;
        } else {
          uniqueNames.push(b);
        }
      } else {
        uniqueNames.push(b);
      }
    })

    return uniqueNames;
    // return bankerRoleNames;
    // return banker && banker.name ? banker.name + (banker.roles ? ` - ${banker.roles.name} `: '') : '-';
  }

  downloadPdf(item){
    this.applicationPdf.downloadPdf(item);
  }

  prepareSubStatusMap(response) {
    const subStatuses = _.get(response, 'response_data.app_sub_status.data.data'); 
    if(subStatuses && subStatuses.length) {
      subStatuses.forEach((status) => {
          this.subStatusMap[status.id] = { value: status.value, type: status.type }
      });
    }
  }

  calculateEcoa(data) { //copied from hsbc 
    let ecoa: any = '--'; 
    data.forEach((element, key) => {
      if (element.type == 'ecoa-status') {
        if (element.response.status == 'START' || element.response.status == 'RESET') {
            var update:any = new Date(element.response.updated_at);
            var signed:any = new Date();
            const diffTime = Math.abs(signed - update);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            ecoa = this.ecoaTotalDays - diffDays;
        } else if (element.response.status == 'PAUSE' || element.response.status == 'STOP') {
          ecoa = element.response.clockTime;
        }
      }
    });
    return ecoa;
  }

  ngOnDestroy(){
    if(this.modalRef){
      this.modalRef.hide();
    }
  }

  checkStatus(type, item) {
    let statusIds = [CONSTANTS.APPLICATION_STATUS.app_completed, 
      CONSTANTS?.APPLICATION_STATUS?.app_hard_withdrawn, CONSTANTS?.APPLICATION_STATUS?.application_hard_decline];
    if ( type === 'forUpdateStatus' || type === 'noi') {
      statusIds.push(CONSTANTS.APPLICATION_STATUS.application_in_progress);
    }
    else if(type === 'assignTo'){
       if (this.userData.role_slug === "closing_team_l2" && this.currentStageSlug === "closing") return false;
       if(this.userData.role_slug === 'loan_officer_l2' && item.status_id === CONSTANTS.APPLICATION_STATUS.application_in_progress) return false;
    }
    return item.status_id && !statusIds.includes(item.status_id) ? true : false;
  }

  showStatus(item){
    let statusIds = [CONSTANTS?.APPLICATION_STATUS?.app_hard_withdrawn, CONSTANTS?.APPLICATION_STATUS?.app_soft_withdrawn,
      CONSTANTS?.APPLICATION_STATUS?.application_soft_decline,CONSTANTS?.APPLICATION_STATUS?.application_hard_decline ]
      return statusIds.includes(item.status_id);
  }
  
}
