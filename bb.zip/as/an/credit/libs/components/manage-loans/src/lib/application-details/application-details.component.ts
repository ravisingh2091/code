import { Component, OnDestroy, OnInit,TemplateRef, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { take, map, switchMap } from 'rxjs/operators';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { ApplicationPdfComponent } from '@credit-bench/components/application-pdf';
import { TaskInfoService, addAppDetails, CommonService, addAppID, addBusinessID } from '@rubicon/utils';
import { ManageLoansService } from '../services/manage-loans.service';
import { UPDATE_CATEGORY_AVAILABLITY, SEND_TO_LASERPRO_AVAILABLITY, COMPLETE_APPLICATION_AVAILABLITY } from '../../../../../app-workflow/actions';

@Component({
  selector: 'application-details',
  templateUrl: './application-details.component.html',
  styleUrls: ['./application-details.component.scss']
})
export class ApplicationDetailsComponent implements OnInit, OnDestroy {
  businessData: any = {};
  completeApplicationData: any;
  lead_data: any;
  appId: string;
  userId: string;
  loanStatus: string;
  businessCategory: string;
  userData: any;
  // business_structure: string;
  // purpose_arr: any;
  businessId: string;
  modalRef: BsModalRef;
  loanId: string;
  banker_details = [];
  loanActionInput: any;
  appInProg = CONSTANTS?.APPLICATION_STATUS?.application_in_progress;
  editActionHide: boolean = false;
  categoryActionHide: boolean = false;
  currentStageSlug: string;
  @ViewChild('applicationPdf') applicationPdf: ApplicationPdfComponent;
  appData;
  bankerMap = {};
  

  constructor(private store: Store<any>,
              private modalService: BsModalService,
              private common: CommonService,
              private taskInfoService: TaskInfoService,
              private manageLoansService: ManageLoansService
    ) { }

  ngOnInit(): void {
    this.getAppData();
  }
  getAppData(){
    this.store.select('app').pipe(
      take(1),
      map(rootState => {
      this.appId = rootState?.appID;
      this.userId = rootState?.appData?.user_id;
      this.businessId = rootState?.businessID;
      this.businessData = {...rootState?.appData};
      if (rootState?.userData?.id) {
        const userData = rootState.userData;
        this.userData = {...userData};
      }
     
     }),switchMap(res=> {
      let slugData = {
        slug: CONSTANTS.SLUG['application_detail'],         
        app_id: this.appId,
        user_id: this.userId
      }
       return  this.taskInfoService.getTaskInfo(slugData)
     }))
    .subscribe(response => {
        const application =  response?.response_data?.app_detail?.data?.data[0];
        this.completeApplicationData = application;
        this.lead_data = response?.response_data?.get_user?.data?.data;
        //updating  latest application status 
        this.businessData.status_id = application?.status_id;
        this.appData = response?.response_data?.app_detail?.data?.data[0];
        let latestAppData = {
          primaryOwnerName: '',
          primarOwnerEmail_id: '',
          primaryOwnerPhone_no: '',
          business_name: application.business[0].business_name,
          app_biz_tax_id: application.business[0].app_biz_tax_id,
          product: application?.business[0]?.product,
          productName: application?.products[0]?.sub_product_name,
          status_id: application?.status_id,
          email_address: this.lead_data?.email_address,
          firstname: this.lead_data?.first_name,
          stage_data: application.business[0].stage_data
        };
    
        if (application.owners.length > 0) {
          let primaryOwnerData = application.owners.find((e) => e.is_primary === true);
          if (primaryOwnerData) {
            latestAppData.primaryOwnerPhone_no = primaryOwnerData.phone;
            latestAppData.primarOwnerEmail_id = primaryOwnerData.email_address;
            latestAppData.primaryOwnerName = primaryOwnerData.first_name;            
          }
        }
        const banker_ids = application.app_assignment.map(element=>element.assigned_to);
        if(banker_ids.length) {
          const unique_banker_ids = Array.from(new Set(banker_ids));
          this.taskInfoService.saveTaskInfo({slug: CONSTANTS.SLUG['banker-by-ids']}, {user_ids: unique_banker_ids}).subscribe((res) => {
            if (res?.get_banker_by_ids?.data?.data?.length) {
              this.banker_details = res.get_banker_by_ids.data.data;
              // let app_assignment:any = {}
              this.banker_details.forEach(element => {
                // const i = application?.app_assignment?.map(item=>item.role_id).lastIndexOf(element.role_id);
                if(!this.bankerMap[element.id]) {
                  this.bankerMap[element.id] = element;
                }
                // if( i >= 0){
                //   app_assignment[element?.roles?.role_slug] = {
                //     name: element.name,
                //     role: element.roles.name
               //   }
                // }              
              });

              let user_assignments = this.manageLoansService.getUserAssignments(application, this.bankerMap);
              
              //dispatching action to  update state with latest application details
              this.store.dispatch(addAppDetails({ appData: {...this.businessData,...latestAppData,
                app_assignment: user_assignments} }));
            }
          });
        }
      }); 
  }
  current_stage(app_id, user_id) {
    this.taskInfoService.getTaskInfo({ slug: CONSTANTS.SLUG['application-current-stage'], app_id: app_id,
    user_id: user_id })
    .subscribe((response) => {
      const current_stage = response?.response_data?.get_current_stage?.data?.data?.stage;
      this.currentStageSlug = response?.response_data?.get_current_stage?.data?.data?.stage?.type;
      if(current_stage?.type) {
        if((SEND_TO_LASERPRO_AVAILABLITY[current_stage.type]) && (['closing_team_l1', 'closing_team_l2'].includes(this.userData.role_slug))) {
          this.appData['sendToLaserPro'] = true
        }
        if(current_stage?.type){
          this.appData['allow_update_category'] = UPDATE_CATEGORY_AVAILABLITY[current_stage.type];
          this.appData['complete_application_status'] = COMPLETE_APPLICATION_AVAILABLITY[current_stage.type];
        }
      }
      
    });
  }
  openModal(template: TemplateRef<any>, actionType: string) {
    let uiType = '';
    let user_assignments = this.manageLoansService.getUserAssignments(this.appData, this.bankerMap);
    this.loanActionInput = {
      actionType,
      appId: this.appId,
      userId: this.userId,
      loanStatus: this.businessData?.status_id,
      loan_id: this.appData.auto_id,
      sub_status_id: this.appData?.sub_status_id,
      businessId: this.businessId,
      businessCategoryId: this.businessData?.product,
      business_structure: this.businessData?.business_structure,
      purpose_arr: this.businessData?.purpose_arr,
      status_id : this.completeApplicationData?.status_id,
      app_activity : this.completeApplicationData?.app_activity,
      business_references: this.appData?.business_references,
      app_assignment: user_assignments,
      business_address: {
        name: this.appData.business[0].business_name,
        street_no: this.appData.business[0].street_no,
        street_name: this.appData.business[0].street_name,
        city: this.appData.business[0].city,
        state: this.appData.business[0].state,
        zip_code: this.appData.business[0].zip_code
      }
    }
    if(this.appData?.owners?.length) {
      const primary_owner = this.appData?.owners.find(ele=>ele.is_primary === true);
      this.loanActionInput['primary_owner_name'] = `${primary_owner?.first_name}${primary_owner.middle_name? (' '+primary_owner.middle_name+' ') :' '}${primary_owner?.last_name}`
    }
    switch (actionType) {
      case 'Update Status':
        uiType = 'updateStatus'
        break;
      case 'Add Note':
        uiType = 'thankyouRegister'
        break;
      case 'Update Loan Product':
        uiType = 'updateCategory'
        break;
      case 'Assign To':
        uiType = 'updateStatus'
        break;
      case 'Send To Laserpro':
        uiType = 'sendLaserpro'
        break;   
  }
    this.modalRef = this.modalService.show(template, { class: `modal-lg ${uiType}`, backdrop: 'static' });
  }

  onCloseModal(event){
    if(event) {
      this.getAppData();
    }
    this.modalRef.hide();
  }

  openNOI() {
    if(!this.appData?.products?.length){
      this.common.popToast("error", "", "Please go to ‘Action’ and choose a loan product to proceed.");
      return;
    }
    const appDataNoi = {
      primarOwnerEmail_id: this.businessData.primarOwnerEmail_id,
      primaryOwnerName: this.businessData.primaryOwnerName.split(' ')[0],
      primaryOwnerPhone_no: this.businessData.primaryOwnerPhone_no,
      user_id: this.businessData.user_id,
      loan_id: this.businessData.loan_id,
      app_id: this.appId,
      prevRoute: 'application-details',
      status_id: this.businessData?.status_id,
      business_references: this.appData?.business_references,
    }
    let user_assignments = this.manageLoansService.getUserAssignments(this.appData, this.bankerMap);

    this.store.dispatch(addAppDetails({appData: {...this.businessData, appDataNoi: appDataNoi, app_assignment: user_assignments}}))
    this.common.navigate('notice_of_incompleteness');
  }

  completeApplication() {
    let data = {
      first_name: this.lead_data?.first_name, 
      last_name: this.lead_data?.last_name, 
      email_address : this.lead_data?.email_address, 
      phone: this.lead_data?.phone,
      record_id: this.lead_data.record_id,
      user_id: this.lead_data.id
     }
    this.store.dispatch(addAppID({ appID: this.appId}));
    this.store.dispatch(addBusinessID({ businessID: this.businessId }));
    if (this.completeApplicationData.business[0].step_not_required) {
      this.store.dispatch(addAppDetails({ appData: {userData: data,  loan_id : this.completeApplicationData.auto_id, 
      step_not_required: this.completeApplicationData.business[0].step_not_required, sba_initiated_by : this.completeApplicationData.business[0]?.sba_initiated_by,
      status_id: this.completeApplicationData?.status_id}}));
    } else {
      this.store.dispatch(addAppDetails({ appData: {userData: data,  loan_id : this.completeApplicationData.auto_id, status_id: this.completeApplicationData?.status_id}}));
    }
    this.common.navigate(this.businessData.status_id === CONSTANTS.APPLICATION_STATUS.application_in_progress ? this.completeApplicationData.business[0].current_state : 'loan-type'); 
  }

  downloadPdf(){
    this.applicationPdf.downloadPdf(this.appData);
  }

checkStatus(type) {
  let statusIds = [CONSTANTS.APPLICATION_STATUS.app_completed, CONSTANTS.APPLICATION_STATUS.app_hard_withdrawn,CONSTANTS?.APPLICATION_STATUS?.application_hard_decline];
    if ( type === 'forUpdateStatus' || type === 'noi') {
      statusIds.push(CONSTANTS.APPLICATION_STATUS.application_in_progress);
    }
    else if(type === 'assignTo'){
      if (this.userData.role_slug === "closing_team_l2" && this.currentStageSlug === "closing") return false;
      if(this.userData.role_slug === 'loan_officer_l2' && this.appData.status_id === CONSTANTS.APPLICATION_STATUS.application_in_progress) return false;
    }
    return this.appData.status_id && !statusIds.includes(this.appData.status_id) ? true : false;
  }

  ngOnDestroy(){
    if(this.modalRef){
      this.modalRef.hide();
    }
  }
}
