import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { CommonService, TaskInfoService } from '@rubicon/utils';
import { DateTimezonePipe } from 'libs/shared-lazy/src/lib/pipes/date-timezone.pipe';
import { take } from 'rxjs/operators';

@Component({
  selector: 'requested-documents',
  templateUrl: './requested-documents.component.html',
  styleUrls: ['./requested-documents.component.scss'],
})
export class RequestedDocumentsComponent implements OnInit {
  @Output() callRequestedDoc = new EventEmitter<boolean>();
  documentType = [];
  mailArr = [];
  originalDocumentType = [];
  selectedItemsList = [];
  oldItemsList = [];
  savedDocs: any;
  appID: string;
  userID: string;
  minDate: any;
  email_address: string;
  firstname: string;
  loanID: any;
  userData: any;
  submitDisabled = true;
  app_assignment: any;
  constructor(
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    @Inject('environment') private environment,
    private common: CommonService,
    private dateTimeZone: DateTimezonePipe,
  ) {}

  ngOnInit(): void {
    this.store
      .select('app')
      .pipe(take(1))
      .subscribe((rootState) => {
        this.appID = rootState.appID;
        this.userID = rootState?.appData?.user_id;
        // this.email_address = rootState?.appData?.email_address;
        // this.firstname = rootState?.appData?.firstname;
        this.app_assignment = rootState?.appData?.app_assignment;
        this.email_address = rootState?.appData?.primarOwnerEmail_id
        this.firstname = rootState?.appData?.primaryOwnerName;
        this.loanID = rootState?.appData?.loan_id;
        this.userData = rootState.userData;
        this.minDate = new Date();
        this.taskInfoService
          .getTaskInfo({
            slug: CONSTANTS.SLUG['requested_documents'],
            requested_document: true,
            and: 'requested_document',
            app_id: this.appID,
            user_id: this.userID,
          })
          .subscribe((response) => {
            this.documentType = [
              ...response.response_data.document_type.data.data,
            ];
            this.originalDocumentType = this.documentType.map(a => ({ ...a }));
            
            if (response.response_data.get_saved_requested_docs) {
              this.savedDocs =
                response.response_data?.get_saved_requested_docs?.data?.data;
            }
            this.documentType.forEach((elem) => {
              elem.isChecked = false;
              elem.disabled = false;
            });
            if (this.savedDocs) {
              this.savedDocs?.doc_data.forEach((doc) => {
                this.documentType.forEach((elem) => {
                  if (doc.doc_type_key === elem.key) {
                    elem.isChecked = true;
                    elem.mailed = true;
                    elem.description = doc.comment ? doc.comment : '';
                    elem.due_date = new Date(doc.due_date);
                    elem.disabled = true;
                  }
                });
                this.originalDocumentType.forEach((elem) => {
                  if (doc.doc_type_key === elem.key) {
                    elem.isChecked = true;
                    elem.mailed = true;
                    elem.description = doc.comment ? doc.comment : '';
                    elem.due_date = new Date(doc.due_date);
                    elem.disabled = true;
                  }
                });
              });
            }
            this.oldItemsList = this.documentType.filter((value, index) => {
              return value.disabled;
            });
          });
      });
  }

  onChangeComment(i, event) {
    if (this.oldItemsList.length > 0) {
      if (this.originalDocumentType[i].description !== event.target.value && this.originalDocumentType[i].isChecked === true) {
        if (!this.mailArr.includes(this.originalDocumentType[i].key)) {
          this.mailArr.push(this.originalDocumentType[i].key);
        }
      }
      if (this.originalDocumentType[i].description === event.target.value) {
        if (this.mailArr.includes(this.originalDocumentType[i].key)) {
          this.mailArr = this.mailArr.filter(e => e !== this.originalDocumentType[i].key);
        }
      }
    }    
    if (this.mailArr.length > 0 || this.selectedItemsList.length > 0) {
      this.submitDisabled = false;
    } else {
      this.submitDisabled = true;
    }
  }
  onChangeDate(i, event) { 
    this.documentType[i].requiredError = false;
    if (this.oldItemsList.length > 0) {
      let due_date = new Date(this.originalDocumentType[i].due_date);
      let event_date = new Date(event);
      if (due_date.getTime() !== event_date.getTime() && this.originalDocumentType[i].isChecked === true) {
        if (!this.mailArr.includes(this.originalDocumentType[i].key)) {
          this.mailArr.push(this.originalDocumentType[i].key);
        }
      }
      if (due_date.getTime() === event_date.getTime()) {
        if (this.mailArr.includes(this.originalDocumentType[i].key)) {
          this.mailArr = this.mailArr.filter(e => e !== this.originalDocumentType[i].key);
        }
      }
    }
    if (this.mailArr.length > 0 || this.selectedItemsList.length > 0) {
      this.submitDisabled = false;
    } else {
      this.submitDisabled = true;
    }
  }
  onChangeCheck() {
    this.selectedItemsList = this.documentType.filter((value, index) => {
      return value.isChecked && !value.disabled;
    });
    if (this.selectedItemsList.length > 0 || this.mailArr.length > 0) {
      this.submitDisabled = false;
    } else {
      this.submitDisabled = true;
    }
  }
  submit(type) {
    if (type === 'submit') {
      const mailArrData = [];
      let selectedMailArr = [];
      let docData = [];
      let queryParams;
      let requiredError = false;

      this.selectedItemsList = this.documentType.filter((value, index) => {
        return value.isChecked && !value.disabled;
      });

      this.oldItemsList.forEach((elem) => {
        docData.push({
          doc_type_key: elem.key,
          value: true,
          comment: elem.description ? elem.description : '',
          due_date: elem.due_date,
        });
      });

      this.selectedItemsList.forEach((elem) => {
        docData.push({
          doc_type_key: elem.key,
          value: true,
          comment: elem.description ? elem.description : '',
          due_date: elem.due_date,
        });
        if (!elem.due_date) {
          elem.requiredError = true;
          requiredError = true;
        }
        if (!selectedMailArr.includes(elem.key) && elem.due_date) {
          selectedMailArr.push(elem.key);
        }
      });

      this.documentType.forEach((elem) => {
        [...selectedMailArr, ...this.mailArr].forEach((mail) => {
          if (mail === elem.key) {
            mailArrData.push({
              title: elem.value,
              due_date: elem.due_date,
              comment: elem.description ? elem.description : '',
            });
          }
        })
      });
      let tableContent = this.getMailTemplate(mailArrData);
      const uniqueBanker = this.getBankerName(this.app_assignment);
      let bankerPhone = uniqueBanker.find(elem => elem.stage === 'loan_officer').phone_no;
      bankerPhone = this.maskPhoneNumber(bankerPhone);
      const payload = {
        app_id: this.appID,
        user_id: this.userID,
        doc_data: docData,
        table_content: tableContent,
        header_logo_path_1: this.environment.logo1_path,
        header_logo_path_2: this.environment.logo2_path,
        client_name: CONSTANTS.MAIL_TEMPLATE.project_name,
        senders_name: CONSTANTS.MAIL_TEMPLATE.senders_name,
        copyright_text: CONSTANTS.MAIL_TEMPLATE.copyright_text,
        // siteurl: this.environment.customerJourneyUrl,
        loan_id: this.loanID,
        email_address: this.email_address,
        first_name: this.firstname,
        terms: this.environment.terms,
        privacy: this.environment.privacy,
        email_address_banker: uniqueBanker.map(tup => tup.email_address).filter((elem, index, self)=> {
          return index === self.indexOf(elem);
        }),
        first_name_banker: uniqueBanker.map(tup => tup.name).filter((elem, index, self)=> {
          return index === self.indexOf(elem);
        }),
        banker_siteurl: this.environment.banker_url,
        banker_phone_number: bankerPhone? bankerPhone : '(XXX) XXX-XXXX'
      };

      if (this.savedDocs?.id) {
        queryParams = {
          slug: CONSTANTS.SLUG['update_requested_docs'],
          id: this.savedDocs.id,
        };
      } else {
        queryParams = {
          slug: CONSTANTS.SLUG['requested_documents'],
        };
      }
      if (mailArrData.length > 0 && !requiredError) {          
        this.taskInfoService
          .saveTaskInfo({ ...queryParams, skip_error: true }, payload)
          .subscribe((res) => {
            if (res?.update_requested_docs?.data?.code === 200) {
              this.callRequestedDoc.emit(true);
              if (res?.requested_doc_mail?.data?.code === 200) {
                this.common.popToast('success', '', 'Additional documents list has been updated.');
                this.addActivityLog();
              } else {
                this.common.popToast('error', 'Error', 'Failed to send documents list via email.');
              }
            } else if (res?.post_requested_docs?.data?.code === 200) {
              this.callRequestedDoc.emit(true);
              if (res?.requested_doc_mail?.data?.code === 200) {
                this.common.popToast('success', '', 'Additional documents list has been updated.');
                this.addActivityLog();
              } else {
                this.common.popToast('error', 'Error', 'Failed to send documents list via email.');
              }
            } else {
              this.common.popToast('error', 'Error', 'Failed to save additional document list.');
            }
          });
      } else {
        if (requiredError) {
          this.common.popToast('error', 'Error', 'Due date is required for selected document(s).');
        }
        // window.scroll(0, 0);
        const formGroupInvalid = document.body.querySelectorAll('input.ng-invalid, select.ng-invalid');
        formGroupInvalid[0]?(formGroupInvalid[0] as HTMLInputElement).focus():'';
      }
    } else {
      this.callRequestedDoc.emit(true);
    }
  }
  addActivityLog(){
    const log_data = {
      role_slug:  this.userData?.role_slug,
      app_id: this.appID,
      backend_user_id: this.userData?.user_id,
      user_name: this.userData?.full_name,
      activity: 'additional_request_sent_to_customer',
    };
    this.common.addActivityLog(log_data);
  }
  getMailTemplate(mailArrData) {
    let array = [];
    let string = '';
    mailArrData.forEach(element => {
      element.due_date = this.dateTimeZone.transform(element.due_date,'MM-dd-yyyy');
      array.push(`<tr> <td style=\"color:#575756;font-size:14px;font-family:Arial,Helvetica,sans-serif;text-align:left;margin:0;padding:5px 10px;line-height:22px;border-bottom:1px solid #eee;border-right:1px solid #eee\">${element.title}</td> <td align=\"left\" style=\"color:#575756;font-size:14px;font-family:Arial,Helvetica,sans-serif;text-align:left;margin:0;padding:5px 10px;line-height:22px;border-bottom:1px solid #eee;border-right:1px solid #eee\">${element.due_date}</td> <td align=\"left\" style=\"color:#575756;font-size:14px;font-family:Arial,Helvetica,sans-serif;text-align:left;margin:0;padding:5px 10px;line-height:22px;border-bottom:1px solid #eee\">${element.comment}</td> </tr>`);
    });
    string = array.join("");
    return string;
  }


  getBankerName(app_assignment) {
    
    const uniqueNames = [];

    app_assignment.forEach((b) => {
      if(b.stage) {
        const index = uniqueNames.findIndex((un) => un.stage === b.stage);
        if(index  !== -1) {
          uniqueNames[index] = b;
        } else {
          uniqueNames.push(b);
        }
      } else {
        uniqueNames.push(b);
      }
    })

    return uniqueNames;
  }

  maskPhoneNumber(num) {
    if(num && Number(num) !== NaN && Number(num) !== 0 && !isNaN(Number(num))) {
      num = num.toString();
      const phoneNumber = num.match(/(\d{3})(\d{3})(\d{4})/);
      return num.length === 10 ? `(${phoneNumber[1]}) ${phoneNumber[2]}-${phoneNumber[3]}` : '';
    }
    return '';
  }
}
