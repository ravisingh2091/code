import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { DownloadService, TaskInfoService } from '@rubicon/utils';
import { take } from 'rxjs/operators';
import * as _ from 'lodash';
import { DOUMENT_CONFIG, CONFIG_TYPES } from '../constants/document.const';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { ManageLoansService } from '../services/manage-loans.service';
import { forkJoin, Subscription } from 'rxjs';
@Component({
  selector: 'documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss'],
})
export class DocumentsComponent implements OnInit, OnDestroy {
  productEventSubscription: Subscription;
  config: any = {};
  configTypes = CONFIG_TYPES;
  docReferences = [];
  uploadedDocs = [];
  backendUserList = [];
  reqDocKeys = [];
  allNotes = [];
  miscellaneousDocKeys = [];
  allDocumentTyes = [];
  stages_docs = [];
  statusOptions = [];
  currentProduct: string;
  business_structure: string;
  loan_purpose: string;
  appID: string;
  userID: string;
  businessID: string;
  backend_user_id: string;
  didDataCall: boolean;
  requestedDocPage: boolean;
  status_id: string;
  stageData = [];
  refreshData = true;
  role_slug: any;
  loanID: any;
  allowedStagesToRole = {
    stages: [],
    assignedBankers: [],
    enable_functions: []
  };
  application_hard_decline = CONSTANTS.APPLICATION_STATUS.application_hard_decline;
  application_in_progress = CONSTANTS.APPLICATION_STATUS.application_in_progress;
  constructor(
    private store: Store<any>,
    private taskInfoService: TaskInfoService,
    private manageLoanService: ManageLoansService,
    private download: DownloadService,
    @Inject('environment') public environment
  ) {}

  ngOnInit(): void {
    this.store
      .select('app')
      .pipe(take(1))
      .subscribe((rootState) => {
        this.currentProduct = rootState?.appData?.product;
        this.status_id = rootState.appData.status_id;
        this.business_structure = rootState?.appData?.business_structure;
        this.role_slug = rootState?.userData?.role_slug;
        this.stageData = rootState.appData?.stage_data
          ? rootState.appData?.stage_data
          : [];        
        if (rootState?.appData?.purpose_arr) {
          this.loan_purpose = rootState.appData.purpose_arr
            .map((tup) => {
              return tup.purpose;
            })
            .join(',');
        }
        this.backend_user_id = rootState.userData.user_id;
        this.appID = rootState.appID;
        this.userID = rootState?.appData?.user_id;
        this.loanID = rootState.appData?.loan_id;
        this.getCurrentStage();
        this.reqDocsStage();
        this.proceedToCommonWidegtData();
      });
    
    this.productEventSubscription = this.manageLoanService
      .productChangeEvent()
      .subscribe((product: string) => {
        // if (!this.currentProduct) {
          this.refreshData = false;
        // }
        this.currentProduct = product;
        setTimeout(() => {
          // if (!this.refreshData) {
            this.refreshData = true;
          // } else {
            /**To re render dom document-management element*/
            this.stages_docs = [];
            let changeable_config = _.cloneDeep(CONFIG_TYPES);
            delete changeable_config.config_8;
            Object.keys(changeable_config).forEach((item) => {
              if (this.config[item]) {
                this.config[item].setup_done = false;
                // this.configSetup(item);
                this.allDocumentTyes = [];
              }
            });
          // }
        }, 0);
      });
  }
  getCurrentStage() {
    this.taskInfoService
      .getTaskInfo({
        slug: 'get_stages_for_role',
        role_slug: this.role_slug,
        app_id: this.appID
      })
      .subscribe((response) => {  
        let flag = false;
        this.allowedStagesToRole.stages = _.get(response, 'response_data.get_stages_for_role.data.data.stages');
        this.allowedStagesToRole.assignedBankers = _.get(response, 'response_data.get_assignment_app.data.data');
        this.allowedStagesToRole?.stages?.forEach((stage) => {
          this.allowedStagesToRole?.assignedBankers?.forEach((banker) => {
            if (banker.stage === 'quality_assurance') {
              flag = true;
            }
            if (banker.stage === 'closing' && stage.type === banker.stage && this.backend_user_id === banker.assigned_to) {
              this.allowedStagesToRole.enable_functions.push(stage._id);
            }
          });
        })
        if (!flag) {
          this.allowedStagesToRole?.stages?.forEach((stage) => {
            this.allowedStagesToRole?.assignedBankers?.forEach((banker) => {
              if (stage.type === banker.stage && this.backend_user_id === banker.assigned_to) {
                if (!this.allowedStagesToRole.enable_functions.includes(stage._id))
                  this.allowedStagesToRole.enable_functions.push(stage._id)
              }
            });
          })
        }
      });
  }
  reqDocsStagePreCheck() {
    this.requestedDocPage = false;
    if (this.config?.config_8?.setup_done) {
      this.reqDocsStage();
    }
  }
  async reqDocsStage() {
    if(this.reqDocKeys.length === 0){
    await this.taskInfoService
      .getTaskInfo({
        slug: CONSTANTS.SLUG.requested_documents,
        requested_document: true,
        and: 'requested_document',
        app_id: this.appID,
        user_id: this.userID,
        only_selected_docs: true,
      })
      .toPromise()
      .then((response) => {
        this.reqDocKeys = [];
        const doc_data =
          response.response_data?.get_saved_requested_docs?.data?.data.doc_data;
        doc_data?.forEach((doc_type) => {
          this.reqDocKeys.push(doc_type.doc_type_key);
        });
        if (this.config.config_8 && this.config.config_8.setup_done) {
          this.config.config_8.task.document_type.body = {
            key: this.reqDocKeys,
          };
          this.bringDocStructure('config_8');
          // if (this.config?.config_9?.setup_done) {
          //   this.miscellaneousDocsStage();
          // }
        }
      });
    }
  }

  async miscellaneousDocsStage() {
 /*    let params = {
      slug: 'miscellaneous-documents',
      // basic_doc: true,
      // and: 'basic_doc',
      app_id: this.appID,
      user_id: this.userID,
    };
    // let payload;
    let payload = {
      orIn: 'business_structure,loan_purpose',
      and: 'requested_document',
      andIn: 'product,stage',
      nin: 'rejected_specific_business_structure',
      or: 'bypass_business_structure_and_loan_purpose,bypass_loan_purpose',
      bypass_business_structure_and_loan_purpose: 'true',
      bypass_loan_purpose: 'true',
      requested_document: 'false',
      isArray: 'loan_purpose,stage',
      loan_purpose: this.loan_purpose,
      business_structure: this.business_structure,
      product: this.currentProduct,
      rejected_specific_business_structure: this.business_structure,
    };
    Object.keys(this.configTypes)
      .slice(0, -2)
      .forEach((item) => {
        if (!this.config[item]?.setup_done) {
          payload['stage'] = payload['stage']
            ? `${payload['stage']},${this.configTypes[item].value}`
            : this.configTypes[item].value;
        }
      });
    if (!payload['stage']) {
      params['dont_call_stage_data'] = true;
    } */

    let obs = [];
    let configArray = [];
    for(let item of Object.keys(this.configTypes).slice(0, -2)) {
        if (!this.config[item]?.setup_done) {
          this.configSetup(item, true);          
          const doc = this.config[item].task.document_type;
          configArray.push(item);
          obs.push(this.taskInfoService.saveTaskInfo({ ...doc.params, app_id: this.appID, user_id: this.userID }, doc.body));
      }
    }
    // if (!this.config?.config_8?.setup_done) {
    //   this.reqDocsStage();
    // }
    await forkJoin(obs)
      .toPromise()
      .then((response) => { 
        response?.forEach((res: any, index) => {
          this.allDocumentTyes.push({response: res?.document_type_post?.data?.data, type: configArray[index]});
        });
        response?.forEach((res: any) => {
          this.stages_docs.push(...res.document_type_post.data.data);
        });
        let ignored_docs = [
          ...this.stages_docs.map((doc) => doc.key),
          ...this.reqDocKeys,
        ];
        let considered_doc = [];
        this.uploadedDocs.forEach((doc) => {
          if (
            !ignored_docs.includes(doc.doc_type_key) &&
            !considered_doc.includes(doc.doc_type_key)
          ) {
            considered_doc.push(doc.doc_type_key);
          }
        });

        this.miscellaneousDocKeys = considered_doc;
        if (this.config.config_9 && this.config.config_9.setup_done) {
          this.config.config_9.task.document_type.body = {
            key: this.miscellaneousDocKeys,
          };
          setTimeout(() => {
            this.bringDocStructure('config_9');
          }, 0);
        }
      });
 /*    if (this.config?.config_8?.setup_done) {
      params['dont_call_saved_requested_docs'] = true;
    } */
    // this.allDocumentTyes = [];
/*     await this.taskInfoService
      .saveTaskInfo(params, payload)
      .toPromise()
      .then((response) => {
         let stages_docs = []; */
        // let basic_docs = [];
        // if (response?.get_saved_requested_docs?.data?.data.doc_data) {
        //   this.reqDocKeys = [];
        //   const doc_data =
        //     response?.get_saved_requested_docs?.data?.data.doc_data;
        //   doc_data?.forEach((doc_type) => {
        //     this.reqDocKeys.push(doc_type.doc_type_key);
        //   });
        // }
        // if (response?.document_type?.data?.data) {
        //   basic_docs = response?.document_type?.data?.data;
        // }
/*         if (response?.document_type_post?.data?.data) {
          stages_docs = response?.document_type_post?.data?.data;
          // this.allDocumentTyes = [...response?.document_type_post?.data?.data];
        } */
/*         if (this.stages_docs.length > 0) {
          this.stages_docs = [...this.stages_docs, ...stages_docs];
        } else {
          this.stages_docs = [...stages_docs];
        } */


        // basic_docs.forEach((doc) => {
        //   considered_doc.push(doc.key);
        // });

      // });

      }

  openStage(item) {
    if (!this.didDataCall && this.currentProduct) {
      this.didDataCall = true;
      this.proceedToGetBackendUser(item);
    } else if (this.didDataCall && this.currentProduct && !this.config[item]?.setup_done) {
      this.configSetup(item);
    }
  }

  proceedToCommonWidegtData() {
    const params = {
      slug: CONSTANTS.SLUG.document_widget_data,
      app_id: this.appID,
      user_id: this.userID,
      type: 'document',
      skip_error: true,
    };
    this.taskInfoService.getTaskInfo(params).subscribe((res) => {
      if (res.response_data) {
        this.docReferences = res.response_data
          ?.get_manual_bank_statement_reference?.data?.data
          ? res.response_data.get_manual_bank_statement_reference.data.data
          : [];
        this.allNotes = res.response_data?.get_notes?.data?.data
          ? res.response_data.get_notes.data.data
          : [];
        this.uploadedDocs = res.response_data?.get_uploaded_docs?.data?.data
          ? res.response_data.get_uploaded_docs.data.data
          : [];
        this.statusOptions = res.response_data?.get_master_document_status
          ?.data?.data
          ? res.response_data.get_master_document_status.data.data
          : [];
      }
      // this.proceedToGetBackendUser(item);
    });
  }

  proceedToGetBackendUser(item) {
    let user_ids = [this.backend_user_id];
    [...this.docReferences, ...this.allNotes].forEach((tuple) => {
      if (tuple.backend_user_id && !user_ids.includes(tuple.backend_user_id))
        user_ids.push(tuple.backend_user_id);
    });
    this.taskInfoService
      .saveTaskInfo({ slug: CONSTANTS.SLUG.get_backend_users }, { user_ids })
      .subscribe((users) => {
        this.backendUserList = users?.get_backend_users?.data?.data ? users.get_backend_users.data.data : [];
        this.configSetup(item);
      });
  }
  
  downloadAll() {
    let ids = this.uploadedDocs.map(tup => tup.doc_id).join(",");
    let request_params = {
      slug: 'download_all',
      ids: ids
    };
    if (ids) {
      this.taskInfoService.getTaskInfo(request_params)
        .subscribe((response: any) => {
          // const downloadLink = document.createElement('a');
          const data = response.response_data.download_document_all.data.data.fileData;
          // downloadLink.href = 'data:' + ';base64,' + data;
          // downloadLink.download = 'documents.zip';
          this.download.showPdf(data, 'documents.zip');
          // downloadLink.click();
        },
        );
    }
  }
  async configSetup(item, call_sync?) {
    this.config[item] = _.cloneDeep(DOUMENT_CONFIG);
    this.config[item].uniqueAccordionKey = this.configTypes[item].value;
    this.config[item].user_id = this.userID;
    this.config[item].app_id = this.appID;
    this.config[item].lead_ref_id = this.loanID;
    this.config[item].task.url = `${this.environment.orchUrl}v2/tasks`;
    this.config[item].docReferences = this.docReferences;
    this.config[item].uploadedDocs = this.uploadedDocs;
    this.config[item].document_button.update_status.statusOptions = this.statusOptions;
    this.config[item].backendUserList = this.backendUserList;
    this.config[item].allNotes = this.allNotes;
    this.config[item].currentStage = this.configTypes[item].value;
    this.config[item].task = {
        ...this.config[item].task,
        document_type: {
          ...this.config[item].task.document_type,
          body: ['config_8', 'config_9'].includes(item) ? await this.syncDocQuerySetup(item) : this.docQuerySetup(item),
        },
        upload: {
          params: {
            ...this.config[item].task.upload.params,
            backend_user_id: this.backend_user_id,
          },
        },
        notes: {
          ...this.config[item].task.notes,
          params: {
            ...this.config[item].task.notes.params,
            backend_user_id: this.backend_user_id,
          },
        },
    }
      this.config[item].document_button = {
        ...this.config[item].document_button,
        buttons: {
          upload: false,
          download: true,
          delete: false,
          rename: false,
          notes: false,
          update_status: false,
          status_text: true,
        },
      };
    this.allowedStagesToRole.enable_functions.forEach((elem) => {
      if (this.configTypes[item].value === elem) {
        this.config[item].document_button = {
          ...this.config[item].document_button,
          buttons: {
            upload: true,
            download: true,
            delete: true,
            rename: true,
            notes: true,
            update_status: true,
            status_text: true,
          },
        };
      }
    });
    if (this.role_slug !== 'admin') { 
      if (['config_8', 'config_9'].includes(item)) {
        this.config[item].document_button = {
          ...this.config[item].document_button,
          buttons: {
            upload: true,
            download: true,
            delete: true,
            rename: true,
            notes: true,
            update_status: true,
            status_text: true,
          },
        };
      }
    }
    if (!call_sync) {
      this.bringDocStructure(item);
    }
  }

  bringDocStructure(item) {
    const doc = this.config[item].task.document_type;
    if (item === 'config_8' && !this.reqDocKeys.length) {
      this.config[item].documentTypes = [];
      this.config[item].setup_done = true;
      return;
    }
    if (item === 'config_9' && !this.miscellaneousDocKeys.length) {
      this.config[item].documentTypes = [];
      this.config[item].setup_done = true;
      return;
    }
    if (this.allDocumentTyes.length > 0 && item !== 'config_8' && item !== 'config_9') {
      this.config[item].documentTypes = [];
      this.allDocumentTyes.forEach((docType) => {
        if (docType.type === item) {
          this.config[item].documentTypes.push(...docType.response);
        }
      });
      this.config[item].setup_done = true;
    } else {
      this.config[item].documentTypes = [];
    this.taskInfoService
      .saveTaskInfo(
        { ...doc.params, app_id: this.appID, user_id: this.userID },
        doc.body
    ).subscribe((res) => { 
      if (item === 'config_9') {
        res?.document_type_post?.data?.data?.forEach(element => {
          if (element?.parent_key) {
            delete element.parent_key;
          }
        });
        }
        // if (item === 'config_9') {
        // this.config[item].documentTypes = res?.document_type_post?.data?.data;
        // this.config[item].documentTypes.sort((element: any) => {
        //   if (!element.filter_conditions.basic_doc) {
        //     return -1;
        //   }
        //   return 0;
        // });
        // } else {
      res?.document_type_post?.data?.data?.forEach(element => {
        if (!element?.hide_accordian) {
          if (item === 'config_9') {
            if (element.key === 'decline_letter' && this.application_hard_decline === this.status_id) {
              this.config[item].documentTypes.push(element);
            } else if (element.key !== 'decline_letter') {
              this.config[item].documentTypes.push(element);
            }
          } else {
            this.config[item].documentTypes.push(element);
          }
        }
      });
        // this.config[item].documentTypes = res?.document_type_post?.data?.data || [];
        if (this.stages_docs.length > 0) {
          this.stages_docs = [
            ...this.stages_docs,
            ...this.config[item].documentTypes,
          ];
        } else {
          this.stages_docs = [...this.config[item].documentTypes];
        }
        // }
        this.config[item].setup_done = true;
      });
    }
  }

  async syncDocQuerySetup(item) {
    let obj;
    switch (item) {
      case 'config_8':
        await this.reqDocsStage();
        obj = {
          ...this.config[item].task.document_type.body,
          key: this.reqDocKeys,
        };
        break;
      case 'config_9':
        await this.miscellaneousDocsStage();
        obj = {
          ...this.config[item].task.document_type.body,
          key: this.miscellaneousDocKeys,
        };
        break;
      default:
        obj = {};
        break;
    }
    return obj;
  }
  
  docQuerySetup(item) {
    // let obj;
    // switch (item) {
    //   case 'config_8':
    //     this.reqDocsStage();
    //     obj = {
    //       ...this.config[item].task.document_type.body,
    //       key: this.reqDocKeys,
    //     };
    //     break;
    //   case 'config_9':
    //     this.miscellaneousDocsStage();
    //     obj = {
    //       ...this.config[item].task.document_type.body,
    //       key: this.miscellaneousDocKeys,
    //     };
    //     break;
    //   default:
      return {
          ...this.config[item].task.document_type.body,
          orIn: 'business_structure,loan_purpose',
          and: 'requested_document,stage',
          andIn: 'product',
          nin: 'rejected_specific_business_structure',
          or: 'bypass_business_structure_and_loan_purpose,bypass_loan_purpose',
          bypass_business_structure_and_loan_purpose: 'true',
          bypass_loan_purpose: 'true',
          requested_document: 'false',
          isArray: 'loan_purpose',
          stage: this.configTypes[item].value,
          loan_purpose: this.loan_purpose,
          business_structure: this.business_structure,
          product: this.getStageCategory(this.configTypes[item].value),
          rejected_specific_business_structure: this.business_structure,
        };
        // break;
    // }
    // return obj;
  }
  getStageCategory(stage) {
    let particularStage = this.stageData.find((elem) => elem.stage === stage);
    if (particularStage) {
      return particularStage.product;
    }
    return this.currentProduct;
  }

  toggleRequestedDoc() {
    this.requestedDocPage = !this.requestedDocPage;
  }

  ngOnDestroy() {
    this.productEventSubscription.unsubscribe();
  }
}
