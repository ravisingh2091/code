import { Component, EventEmitter, Input, OnInit, Output, Inject, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { addAppDetails, CommonService, FormGenerateService, TaskInfoService } from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { FormGroup } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { take, switchMap, catchError, map } from 'rxjs/operators';
import { ManageLoansService } from '../services/manage-loans.service';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import * as  _ from 'lodash';
import { getAssignmentAction, 
         ROLE_LISTING, 
         getStatusAction, 
         getNextSubStatus, 
         isAppSoftDecline, 
         isStageActionAllowed, 
         getNextStage,
         getisUnassign,
        isAppResume,
        isAppSoftWithdrawn,
        ASSIGNMENT_CONDITIONS,
        isFilteredAssignment,
        getRoleName
        } from '../../../../../app-workflow/actions';
import { KEYS } from '@credit-bench/send-to-sba';


@Component({
  selector: 'loan-actions',
  templateUrl: './loan-actions.component.html',
  styleUrls: ['./loan-actions.component.scss']
})
export class LoanActionsComponent implements OnInit {
  @Input() applicationData: any;
  actionType: string;
  @Output() closeModal = new EventEmitter<boolean>();
  actionConfig = [];
  actionForm: FormGroup;
  slug: string;
  author_name: string;
  backend_user_id: string;
  showAlert = false;
  caf_generated = false;
  appData: any = null;
  productData: any;
  currentProduct: any;
  backendUserData: any;
  selectListData: any = [];
  statusData: any = [];
  product_category: any = [];
  stage_data = [];
  states = [];
  current_stage: any;
  backendUsers: any;

  @ViewChild('declineLetter') declineLetterTemplate: ElementRef<any>;
  currentStageAllowed: boolean;
  nextStageActions= ['SENIOR_LO_ASSIGN_TO_SENIOR_FS',
        'JUNIOR_LO_ASSIGN_TO_SENIOR_FS',
        'SENIOR_FS_ASSIGN_TO_PRE_UW_SR_LO',
        'JUNIOR_FS_ASSIGNED_TO_PRE_UW_SR_LO',
        'SENIOR_PRE_UW_LO_ASSIGN_TO_SR_UW',
        'JUNIOR_PRE_UW_LO_ASSIGN_TO_SR_UW',
        'SENIOR_UW_ASSIGN_TO_PRE_CLOSING_SR_Closing',
        'JUNIOR_UW_ASSIGN_TO_PRE_CLOSING_SR_Closing',
        'SENIOR_PRE_Closing_ASSIGN_TO_QA',
        'JUNIOR_PRE_Closing_ASSIGN_TO_QA',
        'SENIOR_QA_ASSIGN_TO_CLOSING',
        'JUNIOR_QA_ASSIGN_TO_CLOSING'
      ];
  etranScoreCheckActions = [
    'SENIOR_UW_ASSIGN_TO_PRE_CLOSING_SR_Closing',
    'JUNIOR_UW_ASSIGN_TO_PRE_CLOSING_SR_Closing'
  ];
  etranSubmissionCheckActions = [
    'SENIOR_PRE_Closing_ASSIGN_TO_QA',
    'JUNIOR_PRE_Closing_ASSIGN_TO_QA'
  ];
  
  constructor(
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private formGenerate: FormGenerateService,
    private manageLoansService: ManageLoansService,
    private store: Store<any>,
    private route: Router,
    @Inject('environment') private environment
      ) { }

  ngOnInit(): void {
    this.actionType = this.applicationData.actionType;
    this.store.pipe(select('app'), take(1)).subscribe(rootState => {
      this.appData = rootState.appData;
      this.author_name = rootState.userData.full_name;
      this.backend_user_id = rootState.userData.user_id;
      this.backendUserData = rootState.userData;
    })
    let slugData:any = {};
    if (this.actionType === 'Update Status') {
      // slugData = {slug: CONSTANTS.SLUG['update_loan_status'], visible: true};
      slugData = {
        slug: CONSTANTS.SLUG['get-current-stage'],
        app_id: this.applicationData.appId,
        user_id: this.applicationData.userId
      };
    } else if (this.actionType === 'Add Note') {
      slugData = {slug: CONSTANTS.SLUG['add_loan_notes']};
    } else if(this.actionType === 'Update Loan Product') {
      slugData = {
        slug: CONSTANTS.SLUG['update_product'],
        app_id: this.applicationData.appId
      };
    } else if(this.actionType === 'Assign To') {
      slugData = {
        slug: CONSTANTS.SLUG['get-current-stage'],
        app_id: this.applicationData.appId,
        user_id: this.applicationData.userId
      };
      // slugData = {slug: CONSTANTS.SLUG['assign_to'], app_id: this.appId, user_id: this.userId };
    }

    if(slugData.slug){
      this.currentStageAllowed = false;
      this.taskInfoService.getTaskInfo(slugData).pipe(
        switchMap((res) => {
          if(this.actionType === 'Assign To') {
             this.stage_data=  _.get(res, 'response_data.get_business_data.data.data[0].stage_data');   
            if(!this.stage_data) this.stage_data = [];       
            this.current_stage = _.get(res, 'response_data.get_current_stage.data.data.stage');
            if(this.current_stage) {
              this.currentStageAllowed = isStageActionAllowed(this.current_stage.type, this.backendUserData.role_slug);
              let role_id;
              const roles = ROLE_LISTING[this.current_stage.type][this.backendUserData.role_slug] || [];
              role_id = roles.join(',');
              if (this.applicationData.loanStatus === CONSTANTS.APPLICATION_STATUS.application_in_progress) {
                this.backendUserData.role_slug === "loan_officer_l1" ? role_id='loan_officer_l1,loan_officer_l2' : role_id='null';
              }
              return this.taskInfoService.getTaskInfo({slug: CONSTANTS.SLUG['assign_to'], role_id})
            }
          } else if(this.actionType === 'Update Status') {
            const stage = _.get(res, 'response_data.get_current_stage.data.data.stage');
            this.currentStageAllowed = isStageActionAllowed(stage.type, this.backendUserData.role_slug);
            const params = {slug: CONSTANTS.SLUG['loan-sub-status'], visible: true, stage: stage.type};
  
            return this.taskInfoService.getTaskInfo(params);
          }
  
          return of(res);
        })
    ).subscribe(response => {
      this.actionConfig = response.form_fields;
      this.slug = response.task_slug;
      this.actionForm = this.formGenerate.createControl(this.actionConfig);
      if (this.actionType === 'Update Status') {
        this.common.sendMasterDataToFields(this.actionConfig, response.response_data);
        const formData = {sub_status_id: this.applicationData?.sub_status_id};
        const withdraw_reasons = response.response_data?.app_withdrawn_reasons?.data?.data;        
        this.states = response?.response_data?.state?.data?.data;        
        if(this.applicationData?.status_id === CONSTANTS.APPLICATION_STATUS.app_soft_withdrawn) {
          let withdraw_note = this.applicationData.app_activity[this.applicationData?.app_activity.map(item=>item?.hasOwnProperty("note")&& item.status_id===CONSTANTS?.APPLICATION_STATUS?.app_soft_withdrawn)?.lastIndexOf(true)]?.note;
          if(withdraw_note){
          if(withdraw_reasons.some(masterData => masterData?.value === withdraw_note)) formData['withdraw_reason'] = withdraw_note;
          else formData['withdraw_reason'] = 'Other'; formData['other_withdraw_reason'] = withdraw_note;
        }
        }
        this.formGenerate.setFormValues(this.actionForm, formData);
        if(this.applicationData?.status_id === CONSTANTS?.APPLICATION_STATUS?.application_soft_decline) {
          const note = this.applicationData.app_activity[this.applicationData?.app_activity.map(item=>item?.hasOwnProperty("note")&& item.status_id===CONSTANTS?.APPLICATION_STATUS?.application_soft_decline)?.lastIndexOf(true)]?.note;
          const decline_reason = note.includes(', ')? note.split(", ") : [note];
          this.actionForm.patchValue({decline_reason: decline_reason});
        }
        this.statusData = _.get(response.response_data, 'app_sub_status.data.data') || [];
        this.showAlertMessage(); 
      } else if (this.actionType === 'Update Loan Product') {
        this.currentProduct = response?.response_data?.get_products?.data?.data[0];
        this.product_category = response?.response_data?.product_category?.data?.data;
        const business_references = response?.response_data?.get_business_reference?.data?.data;
        if(business_references.length){
          const index = business_references.map(elem=>elem.type).lastIndexOf('offer_management');
          if(index >= 0){
            this.caf_generated = true;
          }
        }
        
        this.productData = response?.response_data?.products_type.data.data; 
        this.common.sendMasterDataToFields(this.actionConfig, response.response_data);
        this.common.sendMasterDataToFields(this.actionConfig, {  }, 'products_type');          
        this.formGenerate.setFormValues(this.actionForm, {category_id: this.applicationData.businessCategoryId, products_type: this.currentProduct?.sub_product_type  });
        this.showAlertMessage();
      } else if (this.actionType === 'Assign To') {
        this.backendUsers = response?.response_data?.get_banker_by_role?.data?.data || [];
         this.selectListData = this.backendUsers.map((backend_user) => {
          let roles_data =  {
            role_name: backend_user?.roles?.role_name,
            role_slug: backend_user?.roles?.role_slug,
            banker_name: backend_user.name,
            id: backend_user.id,
            role_id: backend_user?.roles?.id,
            email_address: backend_user.email_address,
            }
          let rolename = getRoleName(this.current_stage.type , backend_user.roles.role_slug);
          if(rolename) roles_data['role_name'] = rolename;

          if(backend_user?.email_address === this.backendUserData.email_address) {
            roles_data['banker_name'] = 'Assign to me';
            roles_data['role_name'] = 'Other';
          }
           return roles_data;
        });
        
        let app_assignment = this.applicationData?.app_assignment;
          let assignment_filter_data = app_assignment.filter((data) => {
            return data.stage ===  ASSIGNMENT_CONDITIONS[this.current_stage.type]?.stage;
          });
          console.log(app_assignment);
          let assign_to_me = app_assignment.some((data) => data.id === this.backendUserData.user_id)
          this.selectListData = this.selectListData.filter((sl) => {
            if(sl.id === this.backendUserData.user_id && assign_to_me) return false;
            if(isFilteredAssignment(this.current_stage.type , sl.role_slug)){
              return sl.id === assignment_filter_data[assignment_filter_data.length - 1]?.id ? sl: false;
            }
            return sl;
          })
        this.common.sendMasterDataToFields(this.actionConfig, {assign_to:{data:{data: this.selectListData}}});
        // this.formGenerate.setFormValues(this.actionForm, {category_id: this.businessCategory, products_type: this.currentProduct?.sub_product_type  });
       
      }
    })
  }
  }

  showAlertMessage(): void {
    if(!this.applicationData.loanStatus || this.applicationData.loanStatus === CONSTANTS?.APPLICATION_STATUS?.application_in_progress) {
      this.showAlert = true
    }
  }
  onSubmit(action: string) {
    if(this.formGenerate.validateCustomFormFields(this.actionForm,action,this.actionConfig )) {
      switch (this.actionType) {
        case 'Update Status':
          this.onUpdateSubStatus();
          break;
        case 'Add Note':
          this.addLoanNote();
          break;
        case 'Update Loan Product':
            this.updateProduct();
          break;  
        case 'Assign To':
            this.assignApp();
          break;
      }
    }
  }

  updateProduct() {
    let selectedProduct = this.productData.find(product => product.type === this.actionForm.value.products_type)
    
    let payload = {
        product: this.actionForm.value.category_id,
        business_id: this.applicationData.businessId ,
        app_id: this.applicationData.appId,
        user_id: this.applicationData.userId,
        name: selectedProduct.name,
        type: selectedProduct.type,
        product_code:selectedProduct.product_code,
        sub_product: selectedProduct.id
    };
    if(this.currentProduct) {
      payload['product_id']=this.currentProduct._id;
    }

    this.taskInfoService.saveTaskInfo({slug: this.slug},payload).subscribe(response => {
      if (response?.update_business_loan_category?.data?.code === 200) {
        this.common.popToast('success', '', `Category and product updated successfully.`);
        this.addActivityLog('product_category_updated', this.product_category.find(ele=>ele?.id===payload?.product)?.name)
        if(this.appData){
          let storeData = {...this.appData,  
            product : this.actionForm.value.category_id,
            productName: payload.name }
          this.store.dispatch(addAppDetails({ appData: storeData}));
          this.manageLoansService.changesProduct(this.actionForm.value.category_id);
        }
        this.closeModal.emit(true);
      }
    })
  }

  addActivityLog(activity, note?) {
    let log_data;
    if (activity === 'ecoa_reset' || activity === 'ecoa_stop') {
      log_data = {
        role_slug: this.backendUserData?.role_slug,
        app_id: this.applicationData.appId,
        backend_user_id: this.backendUserData?.user_id,
        user_name: 'system',
        activity: activity
      };
    } else {
      log_data = {
        role_slug: this.backendUserData?.role_slug,
        app_id: this.applicationData.appId,
        backend_user_id: this.backendUserData?.user_id,
        user_name: this.backendUserData?.full_name,
        activity: activity
      };
    }
    if(note) {
      log_data['note'] = Array.isArray(note)? note.join(", ") : note;
    }
    this.common.addActivityLog(log_data);
  }

  addLoanNote() {  
    const uniqueBanker = this.getBankerName(this.applicationData.app_assignment);
    let payload = {
      note: this.actionForm.value.note,
      app_id: this.applicationData.appId,
      backend_user_id: this.backend_user_id,
      type: 'case_note',
      header_logo_path_1: this.environment.logo1_path,
      header_logo_path_2: this.environment.logo2_path,
      senders_name: CONSTANTS.MAIL_TEMPLATE.senders_name,
      copyright_text: CONSTANTS.MAIL_TEMPLATE.copyright_text,
      client_name: CONSTANTS.MAIL_TEMPLATE.project_name,
      siteurl: this.environment.banker_url,
      loan_id: this.applicationData.loan_id,
      email_address: uniqueBanker.map(tup => tup.email_address).filter((elem, index, self)=> {
        return index === self.indexOf(elem);
      }),
      to_name: uniqueBanker.map(tup => tup.name).filter((elem, index, self)=> {
        return index === self.indexOf(elem);
      }),
      privacy: this.environment.privacy,
      terms: this.environment.terms
    }; 
    this.taskInfoService.saveTaskInfo({slug: this.slug},payload).subscribe(response => {
      if (response?.create_loan_notes?.data?.code === 201) {
        this.common.popToast('success', '', `Note added successfully.`);
        this.addActivityLog('notes_added');
        this.manageLoansService.notesAdded(true)
        this.closeModal.emit(false);
      }
    })
  }

  onCancel() {
    this.closeModal.emit(false);
  }

  sendLaserpro(){
    let payload = {
      app_id: this.applicationData.appId
    };
    let params = {slug: CONSTANTS.SLUG['send-to-laserpro'], skip_error: true };
    this.taskInfoService.saveTaskInfo(params, payload).subscribe(response => {
      if (response?.send_to_laserpro?.data?.code === 201){
        this.common.popToast('success', '', `Sent to LaserPro successfully.`);
        this.addActivityLog('send_to_laserpro_success', response?.send_to_laserpro?.data?.data?.data?.transactionNumber);
      }
      else if(response?.send_to_laserpro?.errors?.errors[0]?.message === "Error occur while running the application. Error: References not are defined in business_references."){
        this.common.popToast('error', '', `Please submit CAF before clicking LaserPro link.`);
        this.addActivityLog('send_to_laserpro_failed');
      }
      else{
        this.common.popToast('error','',`Something went wrong.`);
        this.addActivityLog('send_to_laserpro_failed');
      }
      this.onCancel();
    })
  }


  assignApp() {
    
    if(!this.actionForm.value.assign_to) { return;  }
    const assignedToUserData = this.selectListData.find((user) => user.id === this.actionForm.value.assign_to);
    if(!assignedToUserData) { return; }

    // check if application is already assigned to the assigned to
      // get current stage
        // get current action being performed
          //check whether checklist and documents of current stage are completed 
           //  performed the current action

    this.taskInfoService.getTaskInfo({slug: 'get-app-assignment', app_id: this.applicationData.appId}).pipe(
      switchMap((res) => {
        // const assignments = _.get(res, 'response_data.get_assignment_app.data.data') || [];
        // if(assignments && assignments.length && assignments.find((app) => app.assigned_to === assignedToUserData.id)) {
        //   return throwError({ alreadyAssigned: true });
        // }
        if(this.applicationData.status_id === CONSTANTS.APPLICATION_STATUS.app_soft_withdrawn)
          {
            return throwError({soft_withdrawn: true, message:CONSTANTS.DECLINE_WITHDRAW_MESSAGE.soft_withdrawn })
          }
          else if(this.applicationData.status_id === CONSTANTS.APPLICATION_STATUS.application_soft_decline)
          {
            return throwError({soft_declined: true, message: CONSTANTS.DECLINE_WITHDRAW_MESSAGE.soft_decline})
          }
        return this.taskInfoService.getTaskInfo({ 
          slug: 'get-current-stage',
          app_id: this.applicationData.appId,
          user_id: this.applicationData.userId 
        })
      }),
      //
    switchMap((res) => {
      const stage = _.get(res, 'response_data.get_current_stage.data.data.stage');
      if(stage) {
        const currentAction = getAssignmentAction(stage.type, this.backendUserData.role_slug, assignedToUserData.role_slug);
        if(this.nextStageActions.includes(currentAction)) {
          let payload = {
            orIn: 'business_structure,loan_purpose',
            and: 'requested_document,stage',
            andIn: 'product',
            nin: 'rejected_specific_business_structure',
            or: 'bypass_business_structure_and_loan_purpose,bypass_loan_purpose',
            bypass_business_structure_and_loan_purpose: 'true',
            bypass_loan_purpose: 'true',
            requested_document: 'false',
            isArray: 'loan_purpose',
            stage: stage._id,
            loan_purpose: this.applicationData.purpose_arr.map(tup =>  tup.purpose).join(','),
            business_structure: this.applicationData.business_structure,
            product: this.applicationData.businessCategoryId,
            rejected_specific_business_structure: this.applicationData.business_structure,
            
          }

          return this.taskInfoService.saveTaskInfo({ slug: 'document-checklist-list',  app_id: this.applicationData.appId },payload)
            .pipe(switchMap((res) => {
                let checklistResult = this.checklistCheck(res);
                let documentResult = this.documentCheck(res);
                if(!checklistResult.nextStageCheck &&!documentResult.nextStageCheck) {
                    return throwError({nextStageCheck: false, message: CONSTANTS.CHECKLIST_DOCUMENT_MESSAGE['checklist_document_error'] })
                }
                if(!documentResult.nextStageCheck && checklistResult.nextStageCheck) {
                  return throwError({nextStageCheck: false, message: CONSTANTS.CHECKLIST_DOCUMENT_MESSAGE['document_error']})
                } 
                if(!checklistResult.nextStageCheck && documentResult.nextStageCheck){
                  return throwError({nextStageCheck: false, message: CONSTANTS.CHECKLIST_DOCUMENT_MESSAGE['checklist_error']})
                }

                return of({currentAction,stage});           
              }),
              switchMap(res=>{
                if(this.etranScoreCheckActions.includes(res?.currentAction)){
                  const loan_amount =  this.applicationData.purpose_arr.reduce((acc,tup) =>  acc + parseFloat(tup.amount_field),0);
                  if(loan_amount<=KEYS.ORIGINATION_SCORE_PULL_LIMIT){
                    const params = {
                      slug: "send-to-sba",
                      app_id: this.applicationData.appId,
                      user_id: this.applicationData.userId,
                      get_sba_details: true,
                      skip_error: true
                    }
                    return this.taskInfoService.getTaskInfo(params).pipe(
                      map(resp=>{
                        let sba_data = resp?.response_data?.get_send_to_sba_data?.data?.data?.origination_score.Results;
                        if(!sba_data){
                          throw { nextStageCheck: false, message: CONSTANTS.ETRAN_MESSAGE.score_error };
                        }
                        return res;
                      })
                    )
                  }
                  return of(res);
                } else if(this.etranSubmissionCheckActions.includes(res?.currentAction)){
                  const params = {
                    slug: "send-to-sba",
                    app_id: this.applicationData.appId,
                    user_id: this.applicationData.userId,
                    get_sba_details: true,
                    skip_error: true
                  }
                  return this.taskInfoService.getTaskInfo(params).pipe(
                    map(resp=>{
                      let sba_details = resp?.response_data?.get_send_to_sba_data?.data?.data?.originate_status?.Results;
                      if(!sba_details){
                        throw { nextStageCheck: false, message: CONSTANTS.ETRAN_MESSAGE.submission_error};
                      }
                      return res;
                    })
                  )
                }
                return of(res); 
              })
            )          
        } else {
          return of({currentAction,stage})
        }
      } 
      return of({notAssigned: true});
    }), 

      switchMap((res:any) => {
        if(res.stage) {
          const nextSubStatusId = getNextSubStatus(res.stage.type, this.backendUserData.role_slug, assignedToUserData.role_slug);
          /* Unassign last banker when moving in same stage */
          let lastAssignedTo : any;
          let unassignLastBanker = getisUnassign(res.stage.type, this.backendUserData.role_slug, assignedToUserData.role_slug);
          if(unassignLastBanker){
            const assignedUsers = (this.applicationData.app_assignment || []).filter((assign : any) => assign.stage === this.current_stage.type);
            lastAssignedTo = this.backendUsers.find((user :any) => user.id === assignedUsers[assignedUsers.length - 1].id);
          }

          if(res.currentAction) {
            // make action right
            const assignData: any = {
              "app_id": this.applicationData.appId,
              "role": this.backendUserData.role_slug,
              "action": res.currentAction,
              "assigned_to": assignedToUserData.id,
              "role_id": assignedToUserData.role_id,
              "last_assignee_role_id": lastAssignedTo?.role_id,
              "sub_status_id" : nextSubStatusId,
              "backend_user_id": this.backendUserData.user_id,
              "header_logo_path_1": this.environment.logo1_path,
              "header_logo_path_2": this.environment.logo2_path,
              "banker_url": this.environment.banker_url,
              stage: getNextStage(res.stage.type, this.backendUserData.role_slug, assignedToUserData.role_slug),
              senders_name: CONSTANTS.MAIL_TEMPLATE.senders_name,
              copyright_text: CONSTANTS.MAIL_TEMPLATE.copyright_text,
              unassign: unassignLastBanker,
              mail_client_name: CONSTANTS.MAIL_TEMPLATE.project_name,
              privacy: this.environment.privacy,
              terms: this.environment.terms
            };
            if (this.applicationData?.business_address?.name) {
              assignData.business_name_template = `<b>Business Name:-</b>${this.applicationData.business_address.name}<br/>`;
            } else {
              assignData.business_name_template = "<p></p>";
            }
            if(this.nextStageActions.includes(res.currentAction)) {
              let currentStageData = {
                stage: res.stage._id,
                product: this.applicationData.businessCategoryId
              }
              this.stage_data.push(currentStageData);
              assignData['stage_data'] =[...this.stage_data];
              assignData['business_id']= this.applicationData.businessId;
            }
            if (this.applicationData?.loanStatus === CONSTANTS.APPLICATION_STATUS.app_underwiter && this.applicationData.business_references.length) {
              let ecoa_ref_id = this.applicationData.business_references.find( ({type, response}) => type === 'ecoa-status' && response.status === "STOP");
              if (!ecoa_ref_id) {
                assignData['ecoa_stop'] = true;
              } else {
                assignData['ecoa_stop'] = false;
              }
            }
            return this.taskInfoService.saveTaskInfo({slug: 'assign-to' }, assignData);
          }
        }
       
        return of({notAssigned: true});
      }),
      catchError((err) => {
        if(err.alreadyAssigned) {
          this.common.popToast('info', 'Alert', `Case APP ${this.applicationData.loan_id} is already assigned to ${assignedToUserData.banker_name} (${assignedToUserData.email_address}).`);
        }
        if(err.nextStageCheck === false || err.soft_withdrawn === true || err.soft_declined === true) { 
          this.common.popToast('error', 'Error', `${err.message}`);
        }
        return of({err:true});        
      })
    ).subscribe((res) => {
        
          if(!res.notAssigned && !res.err) {
            // success and assigned to assignedToUserData.name
            this.common.popToast('success', 'Success', `Case APP ${this.applicationData.loan_id} has been assigned to ${assignedToUserData.banker_name} (${assignedToUserData.email_address}).`);
            this.addActivityLog('application_assigned_to',assignedToUserData.banker_name+"("+assignedToUserData?.role_name+")")
            this.closeModal.emit(true);
            this.manageLoansService.changeAssignTo(true);
            return;
          }
        
         
      
       // error could not assign application
       if(!res.err){
        this.common.popToast('error', 'Error', `Case APP ${this.applicationData.loan_id} could not be assigned to ${assignedToUserData.banker_name} (${assignedToUserData.email_address}).`);
       }      
       this.closeModal.emit();
    });
  }

  onUpdateSubStatus() {
    if(!this.actionForm.value.sub_status_id) { return; }
    let currentStage;
    let currentSubStatus;
    this.taskInfoService.getTaskInfo({ 
      slug: 'get-current-stage',
      app_id: this.applicationData.appId,
      user_id: this.applicationData.userId
    }).pipe(
      switchMap((res) => {
        let businessCategory= this.applicationData.businessCategoryId
        if(this.actionForm.value.decline_reason && (businessCategory == undefined || businessCategory == null)){
          return of({productNotUpdated : true, error: true});
        }
        const stage = _.get(res, 'response_data.get_current_stage.data.data.stage');
        if(stage) {
          currentStage = stage;

          const currSubStatus = this.statusData.find((sd) => sd.id === this.actionForm.value.sub_status_id);

          currentSubStatus = currSubStatus;

          const currentAction = getStatusAction(stage.type, this.backendUserData.role_slug, currSubStatus.action);
          const uniqueBanker = this.getBankerName(this.applicationData.app_assignment);

          if(currentAction) {
            // make action right
            const data = {
              "app_id": this.applicationData.appId,
              "user_id": this.applicationData.userId,
              "role": this.backendUserData.role_slug,
              "action": currentAction.action,
              "sub_status_id": this.actionForm.value.sub_status_id,
              "backend_user_id": this.backendUserData.user_id,
              "header_logo_path_1": this.environment.logo1_path,
              "header_logo_path_2": this.environment.logo2_path,
              "banker_url": this.environment.banker_url,
              "email_address": uniqueBanker.map(tup => tup.email_address).filter((elem, index, self)=> {
                return index === self.indexOf(elem);
              }),
              "to_name": uniqueBanker.map(tup => tup.name).filter((elem, index, self)=> {
                return index === self.indexOf(elem);
              }),
              "case_id": this.applicationData.loan_id,
              "senders_name": this.environment.client_name,
              "business_name" : this.applicationData.business_address?.name,
              "copyright_text" : this.environment.copyright_text,
              "privacy" : this.environment.privacy,
              "terms" : this.environment.terms,
              ...currentAction.params
            };
            if(this.actionForm.value.decline_reason) {
              data['note'] = Array.isArray(this.actionForm.value.decline_reason)? this.actionForm.value.decline_reason.join(", ") : this.actionForm.value.decline_reason;
              data['user_name'] =  'System';
              data['activity'] =  'Application_SOFT_DECLINED';
            }
            else if(this.actionForm.value.withdraw_reason){
              data['note'] = this.actionForm.value.withdraw_reason === 'Other' ? this.actionForm.value.other_withdraw_reason : this.actionForm.value.withdraw_reason;
              data['user_name'] =  'System';
              data['activity'] =  'app_soft_withdrawn';
            }
            return this.taskInfoService.saveTaskInfo({slug: 'loan-sub-status'}, data);
          }
        }

        return of({error: true});
      }),
      switchMap((res) => {
        if (!res.error) {
          const isAppResumeCheck = isAppResume(currentStage.type, this.backendUserData.role_slug, currentSubStatus.action);
          if (isAppResumeCheck) {
            let businessReferences = this.applicationData.business_references;
            if (businessReferences.length > 0) {
              businessReferences = businessReferences.filter(
                (data) => data.type === 'ecoa-status'
              );
              businessReferences.sort((a, b) => {
                return (+new Date(b.response.updated_at) - +new Date(a.response.updated_at));
              });
            }
            if (businessReferences[0].response.status.toUpperCase() !== 'PAUSE') {
              return of({ecoaUpdated: false});
            }
            return this.taskInfoService.saveTaskInfo({ slug: 'ecoa_status' },
              { status: 'RESET', app_id: this.applicationData.appId, user_id: this.applicationData.userId })
              .pipe( map((res) => {
                this.addActivityLog('ecoa_reset');
                return of(res);
              })
            );
          }
        }
        
        if(!res.error) {
          const allAssignedLo = (this.applicationData.app_assignment || []).filter((assign) => assign.stage === "loan_officer");
          const assignLoDetails =  allAssignedLo[allAssignedLo.length - 1];
          const isSoftDecline = isAppSoftDecline(currentStage.type, this.backendUserData.role_slug, currentSubStatus.action);
          if(isSoftDecline) {
            const html = this.declineLetterTemplate.nativeElement.innerHTML;
            const pdf_style = `body {
              -webkit-print-color-adjust: exact !important;
            }
        
            @media all {
              .page-break {
                display: none;
              }
            }
        
            @media print {
              .page-break {
                display: block;
                page-break-before: always;
              }
            }
        
            body {
              color: #000;
              font-family: Arial, Helvetica, sans-serif;
              font-style: normal;
              font-size: 9.4pt;
              line-height: 18px;
              margin-bottom: 0;
              margin-top: 0;
            }
        
            .clear {
              margin: 0;
              padding: 0;
              height: 0;
              clear: both;
            }
        
            div,
            p,
            li,
            ul,
            span,
            td,
            th,
            a {
              margin: 0;
              padding: 0;
              font-family: Arial, Helvetica, sans-serif;
            }
        
            p {
              padding-bottom: 5px;
            }
        
            .wraperPage {
              width: 100%;
              margin: 10px auto;
            }
        
            .pfsText {
              font-size: 20px;
              font-weight: 600;
              text-align: right;
            }
        
            .newPage {
              width: 100%;
              display: block;
            }
        
            .wrap {
              width: 100%;
              padding-bottom: 5px;
            }
        
            input[type="checkbox"] {
              margin: 0;
              padding: 2px;
            }
        
            input[type="text"] {
              margin: 0;
              padding: 1px 1%;
              width: 98%;
              border: 0;
              background: none
            }
        
        
        
            tr,
            td,
            ul {
              padding: 0;
              margin: 0;
              line-height: 10px;
            }
        
        
            .lebelText {
              font-size: 12px;
              color: #333;
              text-align: left;
              font-weight: bold !important;
              padding-bottom: 5px;
            }
        
            .valueText {
              font-size: 12px;
              color: #333;
              text-align: left;
              font-weight: normal !important;
              padding-bottom: 5px;
              line-height: 18px;
            }
        
            .table {
              border: 1px solid #666666;
              width: 100%;
              margin-bottom: 1rem;
              color: #333;
              border-collapse: collapse;
            }
        
            .GreenBgTitle {
              color: #fff;
              text-align: center;
              font-size: 20px;
              font-weight: bold;
              padding: 14px 0;
              margin-top: 20px;
              background-color: #666666;
            }
        
            .loanid {
              color: #666666;
              text-align: right;
              font-size: 15px;
              font-weight: bold;
              padding: 4px 0;
              border-top: 1px solid #666666;
              border-bottom: 1px solid #666666;
            }
        
            .subTitle2 {
              color: #666666;
              text-align: left;
              font-size: 16px;
              font-weight: bold;
              padding: 13px 0;
            }
        
            .subTitle3 {
              color: #666666;
              text-align: left;
              font-size: 14px;
              font-weight: bold;
              padding: 13px 0;
            }
        
            .table td,
            .table th {
              color: #666666;
              border-color: #666666;
              vertical-align: middle;
              font-size: 14px;
              padding: 14px 10px;
              font-weight: 500;
              border-bottom: 1px solid #666666;
              border-right: 1px solid #666666;
            }
        
            .table th {
              font-weight: bold;
            }
        
            .ogText td {
              border-top: 2px solid #ddd;
              padding-top: 30px;
            }
        
            .ogText .lebelText,
            .ogText .valueText {
              font-size: 20px;
              color: #666666
            }
        
            .tr {
              text-align: right;
            }
        
            .logoText td {
              padding-bottom: 9px;
            }
        
            .listStyle {
              margin-left: 30px;
            }
        
            .listStyle li {
              list-style-type: disc;
              color: #333;
              font-size: 13px;
              padding-bottom: 9px;
            }`;
            return this.taskInfoService.saveTaskInfo({slug: 'html-to-pdf'}, {content: html, style: pdf_style}).pipe(
              switchMap((res) => {
                if(res && res.html_to_pdf && res.html_to_pdf.data && res.html_to_pdf.data.data) {
                  let decline_letter_obj = null;
                  if(this.applicationData?.business_references?.length) {
                    decline_letter_obj = this.applicationData?.business_references.find(ele=>{
                      return ((ele?.type ==="document-management") && (ele?.response?.type == "decline_letter"));
                    });
                  }

                  const allAssignments = (this.applicationData.app_assignment || []).filter((assign) => assign.stage === "loan_officer");
                  const lastAssignedTo = allAssignments[allAssignments.length - 1];
                  const data = {
                    pdf_file: res.html_to_pdf.data.data,
                    filename: this.applicationData.loan_id+'_adverse_action_letter.pdf',
                    doc_type_key: 'decline_letter',
                    doc_type_id: '60db7c6122d89a762442d7c5',
                    backend_user_id: this.backendUserData.user_id,
                    app_id: this.applicationData.appId,
                    user_id: this.applicationData.userId,
                    ref_id: this.applicationData.loan_id,
                    response_to_be_saved: {
                      type: 'decline_letter',
                      filename: this.applicationData.loan_id+'_adverse_action_letter.pdf',
                      customer_url : this.environment.customerJourneyUrl,
                      copyright_text : this.environment.copyright_text,
                      senders_name : this.environment.client_name,
                      header_logo_path1 : this.environment.logo1_path,
                      header_logo_path2 : this.environment.logo2_path,
                      privacy : this.environment.privacy,
                      terms : this.environment.terms,
                      banker_phone_number : this.maskPhoneNumber(lastAssignedTo?.phone_no) || '(XXX) XXX-XXXX'
                    }
                  };
                  if(decline_letter_obj?._id) {
                    data['decline_letter_main_ref_id'] = decline_letter_obj._id;
                  }
                  return this.taskInfoService.saveTaskInfo({ slug: 'upload-decline-letter' }, data);
                }
          
                return of({uploaded: false});
              })
            );
          }
          const isSoftWithdrawn = isAppSoftWithdrawn(currentStage.type, this.backendUserData.role_slug, currentSubStatus.action);
          
          if(isSoftWithdrawn) {
            let withdraw_reference: any;
            if(this.applicationData?.business_references?.length) {
              withdraw_reference = this.applicationData?.business_references.find(ele=>ele?.type ==="withdraw_ref");
            }
           let payload= {
            app_id : this.applicationData.appId,
            user_id : this.applicationData.userId,
            ref_id: this.applicationData.status_id,
            type: 'withdraw_ref',
            backend_user_id: this.backendUserData.user_id,
            provider : "611276affb6a3804d9b6b16a",
            response_to_be_saved: {
              rm_name : assignLoDetails?.name,
              rm_email : assignLoDetails?.email_address,
              customer_url : this.environment.customerJourneyUrl,
              copyright_text : this.environment.copyright_text,
              senders_name : this.environment.client_name,
              header_logo_path1 : this.environment.logo1_path,
              header_logo_path2 : this.environment.logo2_path,
              privacy : this.environment.privacy,
              terms : this.environment.terms,
              banker_phone_number : this.maskPhoneNumber(assignLoDetails?.phone_no) || '(XXX) XXX-XXXX'
            }
           
           }
           if(withdraw_reference?._id) {
            payload['withdraw_ref_id'] = withdraw_reference._id;
          }
           return this.taskInfoService.saveTaskInfo({slug: 'withdrawn_job'}, payload);

          }
         return of(res);
        }
        return of(res);
      })
    ).subscribe((res) => {
      if(!res.error) {
        this.common.popToast('success', 'Success','Application status has been updated.');
        this.addActivityLog('application_status_updated', this.statusData.find(ele=>ele.id===this.actionForm.value.sub_status_id)?.value)
        this.closeModal.emit(true);
        return;
      }
      else if(res.error && res.productNotUpdated)
      {
        this.common.popToast('error', 'Error','Please update Product Category.');
      }
      else{
        this.common.popToast('error', 'Error','Unable to update the status, please try again later.');
      }
    });

    // let payload = {
    //   sub_status_id: this.actionForm.value.status_id,
    //   app_id: this.appId 
    // };
    // this.taskInfoService.saveTaskInfo({slug: this.slug},payload).subscribe(response => {
    //   if (response?.update_app_status?.data?.code === 200) {
    //     this.common.popToast('success', '', `Status updated successfully.`);
    //     if(this.appData){
    //       this.store.dispatch(addAppDetails({ appData: {...this.appData, sub_status_id: this.actionForm.value.status_id}}));
    //       if(this.route.url.includes('application-details')) {
    //         this.common.navigate('application-details');
    //       }
         
    //     }
    //     this.closeModal.emit(true);
    //   }
    // })
  }

  // uploadDeclineLetter() {
  //   const html = this.declineLetterTemplate.nativeElement.innerHTML;
  //   this.taskInfoService.saveTaskInfo({slug: 'html-to-pdf'}, {content: html, style: '.row{}'}).pipe(
  //     switchMap((res) => {
  //       if(res && res.html_to_pdf && res.html_to_pdf.data && res.html_to_pdf.data.data) {
  //         const data = {
  //           pdf_file: res.html_to_pdf.data.data,
  //           filename: 'decline-letter.pdf',
  //           doc_type_key: 'decline_letter',
  //           doc_type_id: '60db7c6122d89a762442d7c5',
  //           backend_user_id: this.backendUserData.user_id,
  //           app_id: this.appId,
  //           user_id: this.userId,
  //           response_to_be_saved: {
  //             type: 'decline_letter'
  //           }
  //         };
  
  //         return this.taskInfoService.saveTaskInfo({ slug: 'upload-decline-letter' }, data);
  //       }
  
  //       return of({uploaded: false});
  //     })
  //   )
  //   .subscribe((res) => {
  //     console.log(res);
  //   });
  // }

  otherActions() {
    return this.actionType !== 'Assign To' &&  this.actionType !== 'Update Status';
  }

  allowFormRender() {
    if(
      (( this.actionType === 'Assign To' ||  this.actionType === 'Update Status' ) && this.currentStageAllowed) ||
      ( this.otherActions() ) ) {
        return true;
    }
  }

  isCurrentStageInActive() {
    if(
      (( this.actionType === 'Assign To' ||  this.actionType === 'Update Status' ) && !this.currentStageAllowed)) {
        return true;
    }
  }

  //checking status of checklist for current stage
  checklistCheck(res) {
    let checklistMasterList = _.get(res,'get_master_checklist.data.data[0].checklist');
    
    if(checklistMasterList && checklistMasterList.length ) {
      checklistMasterList = checklistMasterList.filter(res=>res.product.includes(this.applicationData.businessCategoryId));
      let stageSaveChecklist = _.get(res,'get_checklist.data.data[0].checklist');
      if(!stageSaveChecklist) {
        return { nextStageCheck: false };
      } 
      let stageProduct = _.get(res,'get_checklist.data.data[0].product');
      if(stageProduct !== this.applicationData.businessCategoryId){
        return {nextStageCheck: false} //checking product save in db is equal to current product
      }
      let IncompleteChecklist =   stageSaveChecklist.find(checklist =>checklist.checklist_value === null);   
         
      if(IncompleteChecklist) {
        return { nextStageCheck: false};
      }  
    }
    return {nextStageCheck: true};
  }

 //checking status of document for current stage
 documentCheck(res) {
  let documentMasterList = _.get(res,'document_type_post.data.data');  
  if(documentMasterList && documentMasterList.length) {
      //for filter out parent components , we dont show them on banker portal
    documentMasterList = documentMasterList.filter(doc => doc.key !== 'documents_credit_approval' && doc.key !== 'documents_loan_closing');
    let documentNotes = _.get(res,'get_notes.data.data');
    if(!documentNotes) {
      return { nextStageCheck: false};
    }
    let documentKeys = documentNotes.map(doc => doc.doc_type_key);
    for(let i = 0; i<documentMasterList.length;i++ ) {
      if(!documentKeys.includes(documentMasterList[i].key)) {
          return  { nextStageCheck: false};
      }
    }
  }
   return {nextStageCheck: true}
  }
  
  getBankerName(app_assignment) {
    
    const uniqueNames = [];

    app_assignment.forEach((b) => {
      if(b.stage) {
        const index = uniqueNames.findIndex((un) => un.stage === b.stage);
        if(index  !== -1) {
          uniqueNames[index] = b;
        } else {
          uniqueNames.push(b);
        }
      } else {
        uniqueNames.push(b);
      }
    })

    return uniqueNames;
  }
  
  maskPhoneNumber(num) {
    if(num && Number(num) !== NaN && Number(num) !== 0 && !isNaN(Number(num))) {
      num = num.toString();
      const phoneNumber = num.match(/(\d{3})(\d{3})(\d{4})/);
      return num.length === 10 ? `(${phoneNumber[1]}) ${phoneNumber[2]}-${phoneNumber[3]}` : '';
    }
    return '';
  }

}
