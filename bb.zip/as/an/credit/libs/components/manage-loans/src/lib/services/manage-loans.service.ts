import { Injectable } from "@angular/core";
import { BehaviorSubject, Subject } from "rxjs";

@Injectable()
export class ManageLoansService {

   private notes_added = new BehaviorSubject(false);
   private updatedProduct = new Subject();
   private updateAssignTo = new Subject();
   data$ = this.notes_added.asObservable();

   notesAdded(data: boolean) {
      this.notes_added.next(data);
   }

   changesProduct(data){
      this.updatedProduct.next(data);
   }

   productChangeEvent(){
      return this.updatedProduct.asObservable();
   }

   changeAssignTo(data){
      this.updateAssignTo.next(data);
   }

   AssignToChangeEvent(){
      return this.updateAssignTo.asObservable();
   }

   getUserAssignments(application, bankerMap){
      const allAssignment = (application?.app_assignment || []).filter((assign) => assign.assigned_to !== undefined);
      let user_assignments = [];
      if(allAssignment && allAssignment.length){
        user_assignments = allAssignment.map((assignment)=>{
          let user = bankerMap[assignment.assigned_to];
          if(user){
            return { 
              id: user.id,
              name: user.name,
              role: user.roles.name,
              role_slug: user.roles.role_slug,
              email_address: user.email_address,
              phone_no: user.phone_number,
              stage: assignment.stage
            }
          }
          return null;
        }).filter(user=>user); 
      }
      return user_assignments;
   }
}