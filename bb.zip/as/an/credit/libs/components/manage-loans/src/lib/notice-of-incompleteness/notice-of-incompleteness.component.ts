import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Store } from '@ngrx/store';
import { addAppDetails, CommonService, TaskInfoService } from '@rubicon/utils';

@Component({
  selector: 'credit-bench-notice-of-incompleteness',
  templateUrl: './notice-of-incompleteness.component.html',
  styleUrls: ['./notice-of-incompleteness.component.scss']
})
export class NoticeOfIncompletenessComponent implements OnInit {

  @ViewChild('pdfContent', { read: ElementRef }) pdfContent : ElementRef<any>;
  informationLetter = this.fb.group({
    deadLineDate: ['',[Validators.required]],
    documents: new FormArray([this.newDocument()]),
  });
  today;
  businessDetails = { 
    'business_name': ''
  };
  ownerDetails = {
    permanent_address: '',
    owner_id: ''
  };
  ownerName;
  ownerEmail;
  appData;
  appDataNoi;
  appID;
  userID;
  previousRoute = 'manage-loans';
  dateOfCreation = new Date();
  rmEmail;
  rmName;
  rmNumber;
  bankName;
  documentList = [];
  backendUserId;
  loanStatus = false;
  user_data: any;
  loanId;
  businessReferences = [];
  app_assignment: any;
  rm_slugs = ["loan_officer_l1", "loan_officer_l2"];
  get documents(): FormArray {
    return this.informationLetter.get('documents') as FormArray;
  }

  get deadLineDate(): FormArray {
    let dd = this.informationLetter.get('deadLineDate').value;
    if(dd.toString() === 'Invalid Date') {
      dd = '';
    }
    return dd;
  }
  
  newDocument(): FormGroup {
    return this.fb.group({
      document_name: ['',[Validators.required, Validators.minLength(1)]],
      notes_comments: '',
    })
  }

  bankInfo = {
    name: this.CONSTANTS.CLIENT_CONFIG.name,
    addressl: this.CONSTANTS.CLIENT_CONFIG.addressl,
    address2: this.CONSTANTS.CLIENT_CONFIG.city+', '+ this.CONSTANTS.CLIENT_CONFIG.state+' '+ this.CONSTANTS.CLIENT_CONFIG.zipcode,
    address3: this.CONSTANTS.CLIENT_CONFIG.country
  }

  constructor(
    private fb: FormBuilder,
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    @Inject('environment') private environment,
    @Inject('CONSTANTS') private CONSTANTS,
    private el: ElementRef
  ) { }

  ngOnInit(): void {
    this.getappDataNoi(); 
    this.informationLetter.get('documents').valueChanges.subscribe((value)=>{
      this.addDocumentToPdf();
    })
  }

  getappDataNoi() {
    this.store.select('app').pipe().subscribe(rootState => {
      this.appData = rootState?.appData;
      this.userID = this.appData?.appDataNoi?.user_id;
      this.appID = this.appData?.appDataNoi?.app_id;
      this.loanStatus = this.appData?.appDataNoi?.status_id;
      this.loanId = this.appData?.appDataNoi?.loan_id;
      this.previousRoute = this.appData?.appDataNoi?.prevRoute;
      this.ownerName = this.appData?.appDataNoi?.primaryOwnerName;
      this.ownerEmail = this.appData?.appDataNoi?.primarOwnerEmail_id;
      this.businessReferences = this.appData?.appDataNoi?.business_references;
      this.app_assignment = this?.appData?.app_assignment;
      let rm_user;
      let fulfillment_slugs = ["fulfillment_services_l1", "fulfillment_services_l2"]
      let app_assignment = rootState?.appData?.app_assignment;
      if(app_assignment && app_assignment.length >0){
        for(let user of app_assignment){
          if(fulfillment_slugs.includes(user.role_slug)){
            break;
          }
          if(this.rm_slugs.includes(user.role_slug)){
            rm_user = user;
          }
        }
      }

      if(rm_user){
        this.rmNumber = this.maskPhoneNumber(rm_user?.phone);
        this.rmEmail = rm_user?.email_address;
        this.rmName = rm_user?.name;
      }
      this.bankName = this.CONSTANTS.MAIL_TEMPLATE.senders_name;
      this.backendUserId = rootState?.userData?.user_id;
      this.user_data = rootState?.userData;
    });
  }

  onSubmit() {
    if (this.informationLetter.invalid) {
      const invalidControl = this.el.nativeElement.querySelector('input.ng-invalid');
      this.informationLetter.markAllAsTouched();
      if (invalidControl) {
        invalidControl.focus();
      }
      return;
    }

    const uniqueBanker = this.getBankerName(this.app_assignment);

    let payload = {
      filename: `${this.loanId}_noi.pdf`,
      doc_type_id: '5ef9aad1dc5f787eccbb86ee',
      doc_type_key: 'notice_of_incompleteness_pdf',
      provider: '60c317284f1cbf129c707770',
      email_address: this.ownerEmail,
      content: this.pdfContent.nativeElement.innerHTML,
      app_id: this.appID,
      user_id: this.userID,
      lo_name: this.rmName, 
      lo_email: this.rmEmail,
      loan_id: this.loanId,
      name: this.ownerName,
      // loan_officer_email: this.rmEmail,
      response: this.documentList,
      header_logo_path1: this.environment.logo1_path,
      header_logo_path2: this.environment.logo2_path,
      senders_name: this.CONSTANTS.MAIL_TEMPLATE.senders_name,
      copyright_text: this.CONSTANTS.MAIL_TEMPLATE.copyright_text,
      backend_user_id: this.backendUserId,
      phone_number: this.rmNumber || '________',
      first_name: this.ownerName,
      privacy:this.environment.privacy,
      terms: this.environment.terms,
      siteurl: this.environment.banker_url,
      email_address_banker: uniqueBanker.map(tup => tup.email_address).filter((elem, index, self)=> {
        return index === self.indexOf(elem);
      }),
      first_name_banker: uniqueBanker.map(tup => tup.name).filter((elem, index, self)=> {
        return index === self.indexOf(elem);
      }),
    };
    if (this.businessReferences.length > 0) {
      this.businessReferences = this.businessReferences.filter(
        (data) => data.type === 'ecoa-status'
      );
    }
    if (this.businessReferences.length > 0) {
      this.businessReferences.sort((a, b) => {
        return (+new Date(b.response.updated_at) - +new Date(a.response.updated_at));
      });
      if (
        this.businessReferences[0].response.status.toUpperCase() === 'START' ||
        this.businessReferences[0].response.status.toUpperCase() === 'RESET'
      ) {
        if (['underwriter_l1', 'underwriter_l2'].includes(this.user_data?.role_slug)) {
          payload['status'] = 'PAUSE';
        }
      }
    }

      let params = {
        slug: this.CONSTANTS.SLUG['send_notice_of_incompleteness']
      }
      this.taskInfoService.saveTaskInfo(params, payload).subscribe((response => {
        this.common.popToast('success', '', `NOI Submitted successfully.`);
        this.addActivityLog('notice_of_incompleteness_sent');
        if (payload['status'] === 'PAUSE') {
          this.addActivityLog('ecoa_pause');
        }
        this.common.navigate(this.previousRoute);
      }))
  }
  addActivityLog(activity?: any) {
    let log_data;
    if (activity === 'ecoa_pause') {
      log_data = {
        role_slug: this.user_data?.role_slug,
        app_id: this.appID,
        backend_user_id: this.backendUserId,
        user_name: 'system',
        activity: activity
      };
    } else {
      log_data = {
        role_slug: this.user_data?.role_slug,
        app_id: this.appID,
        backend_user_id: this.backendUserId,
        user_name: this.user_data?.full_name,
        activity: activity
      };
    }
    this.common.addActivityLog(log_data);
  }
  maskPhoneNumber(num) {
    if(num && Number(num) !== NaN && Number(num) !== 0 && !isNaN(Number(num))) {
      num = num.toString();
      const phoneNumber = num.match(/(\d{3})(\d{3})(\d{4})/);
      return num.length === 10 ? `(${phoneNumber[1]}) ${phoneNumber[2]}-${phoneNumber[3]}` : '';
    }
    return '';
  }

  addDocumentToPdf(){
    this.documentList = this.documents.controls.map((v, index) => v.value);    
  }

  onBack() {
    this.common.navigate(this.previousRoute);
  }

  addDocument() {
    if (this.documents.length < 6) {
      this.documents.push(this.newDocument());
    } 
  }

  removeDocument(i) {
    this.documents.removeAt(i);
  } 

  getBankerName(app_assignment) {
    
    const uniqueNames = [];

    app_assignment.forEach((b) => {
      if(b.stage) {
        const index = uniqueNames.findIndex((un) => un.stage === b.stage);
        if(index  !== -1) {
          uniqueNames[index] = b;
        } else {
          uniqueNames.push(b);
        }
      } else {
        uniqueNames.push(b);
      }
    })

    return uniqueNames;
  }

  ngOnDestroy() {
    if(this.appData && this.appData.appDataNoi) {
      const appObj = Object.assign({},this.appData);
      delete appObj.appDataNoi;
      this.store.dispatch(addAppDetails({appData: {...appObj}}));
    }
  }
}
