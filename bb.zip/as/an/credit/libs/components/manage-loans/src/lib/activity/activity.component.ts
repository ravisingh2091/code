import { Component, Inject, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { CommonService, TaskInfoService } from '@rubicon/utils';
import { take } from 'rxjs/operators';
import { ManageLoansService } from '../services/manage-loans.service';
import { ActivityName } from './activity';

@Component({
  selector: 'activity',
  templateUrl: './activity.component.html',
  styleUrls: ['./activity.component.scss']
})
export class ActivityComponent implements OnInit {
  appID: string;
  all_activities: any;
  activities_status = ActivityName;
  banker_roles=[];
  owners: any = {};
  constructor(
    private store: Store<any>,
    private taskInfoService: TaskInfoService,
    private common: CommonService,
    @Inject('environment') public environment
  ) { }

  ngOnInit(): void {
    this.store
      .select('app')
      .pipe(take(1))
      .subscribe((rootState) => {
        this.appID = this.appID = rootState.appID;
        this.getData();
      });
  }

  getData() {
    this.common.activityAddedObervable.subscribe(()=> {
      this.taskInfoService.getTaskInfo({ slug: 'activity_logs', app_id: this.appID }).subscribe(res => {
        let all_activities_data = res?.response_data?.get_activity_log?.data?.data;
        let owner_data = res?.response_data?.business_owners?.data?.data[0]?.owners;
        let business_data = res?.response_data?.business_owners?.data?.data[0]?.business[0];
        if(owner_data?.length) {
          owner_data.forEach(owner => {
            let owner_id = owner._id;
            this.owners[owner_id] = {
              owner_name: owner.owner_type === 'individual' ? `${owner.first_name}${owner.middle_name? ' '+owner.middle_name: ''} ${owner.last_name}` : `${owner.businessname}`
            }
          })
        }
        this.all_activities = [];
        if(all_activities_data?.length){
          all_activities_data?.forEach(activity => {
            let act_string = `${this.activities_status[activity?.activity]}`;
            let activity_exist = (act_string !== 'undefined'  && act_string !== undefined  &&  act_string !== "") ? true: false;
            if(activity?.docket_status) {
              act_string = `${act_string} ${activity.docket_status === 'sign' ? 'completed': 'declined'}`
            }
            if(activity?.owner_id) {
              act_string = `${act_string} - ${this.owners[activity.owner_id]?.owner_name}`
            } else if (activity?.business_id) {
              act_string = `${act_string} - ${business_data.business_name}`
            }
            if (activity?.note) {
              act_string = `${act_string} - ${activity.note}`
            }
            if (activity_exist) {
              this.all_activities.push({ 
                activity: act_string,
                createdAt: activity.createdAt,
                user_name: activity?.user_name? activity.user_name: (activity?.role?.slug==='customer'? 'Customer' : '')
              });
            }
          });
          this.all_activities = this.all_activities.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        }
      });
    });
  }
}
