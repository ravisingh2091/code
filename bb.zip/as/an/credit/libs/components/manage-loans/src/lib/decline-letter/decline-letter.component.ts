import { Component, Inject, Input, OnInit } from '@angular/core';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';

@Component({
  selector: 'decline-letter',
  templateUrl: './decline-letter.component.html',
  styleUrls: ['./decline-letter.component.scss']
})
export class DeclineLetterComponent implements OnInit {
  bank_details = CONSTANTS.CLIENT_CONFIG;
  footerText = CONSTANTS.FOOTER_CONGIF.footer_text;
  currentDate = new Date();
  decline_letter_date = this.currentDate.setDate(this.currentDate.getDate() + 6);
  @Input() declineReason: any;
  @Input() appData: any;
  @Input() states: any;
  constructor( @Inject('environment') public environment
      ) { }

  ngOnInit(): void {}
}
