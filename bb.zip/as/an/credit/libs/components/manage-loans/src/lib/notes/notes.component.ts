import { Component, Inject, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { TaskInfoService } from '@rubicon/utils';
import { take } from 'rxjs/operators';
import { ManageLoansService } from '../services/manage-loans.service';

@Component({
  selector: 'notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss']
})
export class NotesComponent implements OnInit {
  appID: string;
  userID: string;
  notes_data: any = null;
  all_users: any = null;
  constructor(
    private store: Store<any>,
    private taskInfoService: TaskInfoService,
    private manageLoansService: ManageLoansService,
    @Inject('environment') public environment
  ) { }

  ngOnInit(): void {
    this.store
    .select('app')
    .pipe(take(1))
    .subscribe((rootState) => {
      this.userID = this.userID = rootState.userData.user_id;
      this.appID = this.appID = rootState.appID;
      this.manageLoansService.data$.subscribe(res => {
        this.getData();
      });
    });
  }

  getData() {
    this.taskInfoService.getTaskInfo({slug: 'get_notes', app_id: this.appID, type: 'case_note'}).subscribe(res=> {
      this.notes_data = res?.response_data?.get_notes?.data?.data ? res.response_data.get_notes.data.data: null;
      this.all_users = res?.response_data?.get_banker_users?.data?.data ? res.response_data.get_banker_users.data.data: null;
      if (this.notes_data?.length)
        this.notes_data.forEach(element => {
          element.createdby= this.all_users.find(elem=>elem.id===element.backend_user_id).name
        });
    });
  }
}
