export * from './lib/forget-password.module';
