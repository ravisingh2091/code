import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Route } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';

export const forgetPassRoutes: Route[] = [
  {path:'', component: ForgetPasswordComponent},
  {path:':hash', component: ResetPasswordComponent},
];

@NgModule({
  declarations: [ForgetPasswordComponent, ResetPasswordComponent],
  imports: [
    CommonModule,
    SharedLazyModule, 
    RouterModule.forChild(forgetPassRoutes),
  ]
})
export class ForgetPasswordModule { }
