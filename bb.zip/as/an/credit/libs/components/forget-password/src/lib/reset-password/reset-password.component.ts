import { Component, OnInit ,Inject} from '@angular/core';
import { TaskInfoService, FormGenerateService, onLogout, CommonService} from '@rubicon/utils';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { Store } from '@ngrx/store';
import { ActivatedRoute } from '@angular/router';
import { map } from 'rxjs/operators';

@Component({
  selector: 'reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  resetPassConfig: FormFieldInterface[] = [];
  resetPassForm: FormGroup;
  slug: '';
  hash: '';
  hashExpired = false;
  nextTask: string = '';
  email_address: string = '';
  firstName = '';
  constructor( private taskInfoService : TaskInfoService,
    private formGenerateService: FormGenerateService,
    private  commonService: CommonService,
    private store: Store<any>,
    private actRoute: ActivatedRoute,
    @Inject('environment') private environment,

    ) { }

    ngOnInit(): void {
      this.hash = this.actRoute.snapshot.params.hash;
      this.taskInfoService.getTaskInfo({slug:'reset-password'}).subscribe(response => {
        this.slug = response.task_slug;
        this.resetPassConfig = response.form_fields;
        this.resetPassForm = this.formGenerateService.createControl(this.resetPassConfig);
      },
      error => {
        if (error.verify_hash.status ===  404) {
         this.hashExpired = true;
        }
      })
      this.taskInfoService.saveTaskInfo({slug: 'verify_hash'}, {hash: this.hash}, {})
      .pipe(map(data=>{
       return data
     })).subscribe(res=>{
       if (res && res.verify_hash.status === 200) {
         this.firstName = res.verify_hash.data.data.name;         
         this.email_address  = res.verify_hash.data.data.email_address;
       }
     },
     error => {
       this.hashExpired = true;
    })
    }
  
    onSubmit(action) {
      if(this.formGenerateService.validateCustomFormFields(this.resetPassForm, action, this.resetPassConfig)) {
        let formData = this.resetPassForm.value;
        if(formData.new_password === formData.confirm_new_password) {
          const data = {
            new_password: formData.new_password,
            confirm_new_password: formData.new_password,
            token: this.hash,
            email_address: this.email_address,
            no_verification_required: true,
            header_logo_path_1: this.environment.logo1_path,
            header_logo_path_2: this.environment.logo2_path,
            client_name: this.environment.project_name,
            senders_name: this.environment.client_name,
            copyright_text: this.environment.copyright_text,
            privacy: this.environment.privacy,
            terms: this.environment.terms,
            first_name: this.firstName
           };
           if(this.environment.journeyType === "banker-journey"){
            data['slug'] = "backend"
          }
          else{
            data['slug'] = this.slug
          }
           this.taskInfoService.saveTaskInfo({slug: this.slug}, data, {})
           .pipe(map(data=>{
            return data
          })).subscribe(res=>{
            if (res && res.update_password && res.update_password.data && res.update_password.data.status ==="success") {
              this.commonService.popToast('success', '', 'Your password has been updated successfully, please login with your new password to access the platform.');
              this.commonService.navigateByUrl(this.nextTask);
            }
          })
       }
      }
    }


}
