import { Component, OnInit, Inject } from '@angular/core';
import { TaskInfoService, FormGenerateService, onLogout, CommonService} from '@rubicon/utils';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
@Component({
  selector: 'forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {
  fpConfig: FormFieldInterface[] = [];
  fpForm: FormGroup;
  slug: '';
  nextTask: string = '';

  constructor( private taskInfoService : TaskInfoService,
     private formGenerateService: FormGenerateService,
     private  commonService: CommonService,
     private router : Router,
     @Inject('environment') private environment,
     @Inject('CONSTANTS') private CONSTANTS ) { }

  ngOnInit(): void {
     this.taskInfoService.getTaskInfo({slug: this.CONSTANTS.SLUG['forget-password']}).subscribe(response => {
       this.slug = response.task_slug;
       this.fpConfig = response.form_fields;
       this.fpForm = this.formGenerateService.createControl(this.fpConfig);
     },
     error => {
       console.log("something went wrong!");
     })
  }

  onSubmit(action) {
    if(this.formGenerateService.validateCustomFormFields(this.fpForm, action, this.fpConfig)) {
        const data = {
          header_logo_path_1: this.environment.logo1_path,
          header_logo_path_2: this.environment.logo2_path,
          client_name: this.CONSTANTS.MAIL_TEMPLATE.project_name,
          senders_name: this.CONSTANTS.MAIL_TEMPLATE.senders_name,
          copyright_text: this.CONSTANTS.MAIL_TEMPLATE.copyright_text,
          email_address: this.fpForm.value.email_address  ?this.fpForm.value.email_address.toLowerCase() : '',
          user_type : this.router.url.split('/')[1],
          privacy: this.environment.privacy,
          terms: this.environment.terms
        };
        if(this.environment.journeyType === "banker-journey"){
          data['slug'] = "backend"
        }
        this.taskInfoService.saveTaskInfo({slug: this.slug, skip_error: true}, data, {})
        .pipe( 
          map(data=>{
            return data
          })).subscribe(res=>{
            if(res?.email_hash?.errors?.errors[0]?.type === 'RATE_LIMIT_REACHED'){
              this.nextTask = res.nextTask.value;
              this.commonService.popToast('error', '', 'The rate limit for Forget Password is reached.');
              this.commonService.navigateByUrl(this.nextTask); 
            }
            else{
            this.nextTask = res.nextTask.value;
            this.commonService.popToast('success', '', 'If your email address exists in our system, you will receive a password recovery link at your email address in a few minutes.');
            this.commonService.navigateByUrl(this.nextTask); 
            }
          })
     }
  }


}
