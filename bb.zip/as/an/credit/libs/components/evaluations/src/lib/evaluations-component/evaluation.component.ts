import {
  Component,
  Input,
  OnInit,
  ViewChildren,
  QueryList,
  ElementRef,
} from '@angular/core';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { CalculationService } from 'libs/components/collateral-evaluation/src/lib/services/calculation.service';
import { Store } from '@ngrx/store';
import {
  CommonService,
  addAppDetails,
  TaskInfoService,
  DownloadService,
} from '@rubicon/utils';
import { take } from 'rxjs/operators';

@Component({
  selector: 'evaluation-component',
  templateUrl: './evaluation.component.html',
  styleUrls: ['./evaluation.component.scss'],
})
export class EvaluationComponent implements OnInit {
  productName: string;
  cra_reference_data: any;
  craEdit: boolean = false;
  craPdfData: any;
  appData: any;
  craReportable: any;
  updatedAt: Date;
  username: string;
  loanID: string;
  currentAction: string;
  userID: string;
  appID: string;
  loanStatus: string;
  backendUserID: string;
  product: string;
  @ViewChildren('pdfContent') GeneratePDFComponent: QueryList<ElementRef>;
  hmda_username: string;
  hmda_reference_data: any;
  isHMDAEdit: boolean = false;
  hmda_updatedAt: Date;
  hmdaPdfData: any;
  collateral_evaluation_analysis_data;
  collateral_backend_user;
  collateral_reference;
  collateral_pdf_reference;
  visited_accordions = {}; 
  loadedCollateral = false;
  businessName;
  collateral_data;
  @ViewChildren('hmdapdfContent') GenerateHMDAPDFComponent: QueryList<ElementRef>;
  download_collateral = false;

  constructor(
    private commonService: CommonService,
    private store: Store<any>,
    private taskInfoService: TaskInfoService,
    private download: DownloadService,
    private calculationService: CalculationService
  ) {}
  @Input() applicationData;

  ngOnInit() {
    this.loanStatus = this.applicationData?.status_id;
    this.cra_reference_data = this.applicationData?.business_references.find(
      (ref) => ref.type == 'cra-analysis'
    );

    if (this.cra_reference_data) {
      this.craEdit = true;
      this.updatedAt = new Date(this.cra_reference_data.updated_at * 1000);
      
      if (this.cra_reference_data.response !== 'undefined')
        this.craReportable = this.cra_reference_data?.response;
      else this.craReportable = '-';
    }
    
    this.hmda_reference_data = this.applicationData?.business_references.find(
      (ref) => ref.type == 'hmda-form'
    );
    if (this.hmda_reference_data) {
      this.isHMDAEdit = true;
      this.hmda_updatedAt = new Date(
        this.hmda_reference_data.updated_at * 1000
      );
    }
    this.store.select('app').subscribe((rootState) => {
      this.appData = rootState.appData;
      this.userID = this.appData?.user_id;
      this.appID = rootState.appID;
      this.loanID = this.appData?.loan_id;
      this.backendUserID = rootState?.userData?.user_id;
      this.product = this.appData?.product;
      this.productName = this.appData?.productName;
      this.businessName = rootState?.appData?.business_name;
      
    });
  }

  loadCollateralData(){
    let query = {
      slug: CONSTANTS.SLUG['collateral_evaluation_analysis'],
      app_id: this.appID,
      user_id: this.userID,
      skip_master_apis: true
    };
    if(this.download_collateral){
      query['download_pdf'] = true;
    }
    this.taskInfoService.getTaskInfo(query).subscribe(res => {
      if(res && res.response_data && res.response_data.get_collateral_evaluation && res.response_data.get_collateral_evaluation.data
         && res.response_data.get_collateral_evaluation.data.data && res.response_data.get_collateral_evaluation.data.data.id){
           this.loadedCollateral = true;
           this.collateral_evaluation_analysis_data = res.response_data.get_collateral_evaluation.data.data;
      }
      if(res && res.response_data && res.response_data.get_collateral_backend_user_by_id && res.response_data.get_collateral_backend_user_by_id.data
         && res.response_data.get_collateral_backend_user_by_id.data.data && res.response_data.get_collateral_backend_user_by_id.data.data.id){
           this.collateral_backend_user = res.response_data.get_collateral_backend_user_by_id.data.data;
      }
      if(res && res.response_data && res.response_data.get_collateral_evaluation_reference && res.response_data.get_collateral_evaluation_reference.data
        && res.response_data.get_collateral_evaluation_reference.data.data){
          if(res.response_data.get_collateral_evaluation_reference.data.data[0]){
            this.collateral_reference = res.response_data.get_collateral_evaluation_reference.data.data[0];
          }else{
            this.loadedCollateral = true;
          }
      }

      

      if(res && res.response_data && res.response_data.get_collateral_pdf_reference && res.response_data.get_collateral_pdf_reference.data
        && res.response_data.get_collateral_pdf_reference.data.data && res.response_data.get_collateral_pdf_reference.data.data[0]){
        this.collateral_pdf_reference = res.response_data.get_collateral_pdf_reference.data.data[0]    
      }

      if(res && res.response_data && res.response_data.get_collateral_evaluation && res.response_data.get_collateral_evaluation.data
        && res.response_data.get_collateral_evaluation.data.data && res.response_data.get_collateral_evaluation.data.data.id){
       let service_data = this.calculationService.serviceToFormData(res.response_data.get_collateral_evaluation.data.data); 
       this.collateral_data = {...service_data, loanID: this.loanID, businessName: this.businessName};
      
      }
        
      if(!this.loadedCollateral){
        this.commonService.popToast('error', 'Error', 'Failed to load.');
      }
    },()=>{
      this.commonService.popToast('error', 'Error', 'Failed to load.');
    });
  }

  showAlertMessage() {
    if (
      this.loanStatus === CONSTANTS?.APPLICATION_STATUS?.application_in_progress
    ) {
      return true;
    }
    return false;
  }
  showProductMessage() {
    if (this.product) {
      return false;
    }
    return true;
  }

  openCRA() {
    this.commonService.navigate('collateral-reportable');
  }

  editForm() {
    this.store.dispatch(
      addAppDetails({
        appData: { ...this.appData, craReference: this.cra_reference_data },
      })
    );
    this.commonService.navigate('collateral-reportable');
  }

  viewForm() {
    let craReference = this.cra_reference_data;
    craReference['view'] = true;
    this.store.dispatch(
      addAppDetails({
        appData: { ...this.appData, craReference: this.cra_reference_data },
      })
    );
    this.commonService.navigate('collateral-reportable');
  }

  isOpened(is_opened, accordionName){
    switch(accordionName){
      case 'collateralEvaluationAnalysis':
        if(is_opened){
          if(!this.visited_accordions[accordionName]){
            this.visited_accordions[accordionName] = true;
            this.loadCollateralData();
          }
        }
        break;
    }
  }

  downloadForm() {
    let body = [];
    for (let child of this.GeneratePDFComponent.toArray()) {
      body.push({
        content: child.nativeElement.innerHTML,
        style: `
        body {-webkit-print-color-adjust: exact!important;}
        @media all {
          .page-break {
              display: none;
          }
      }
      @media print {
          .page-break {
              display: block;
              page-break-before: always;
          }
      }
      body {
          color: #000;
          font-family: Arial, Helvetica, sans-serif;
          font-style: normal;
          font-size: 9.4pt;
          line-height: 20px;
          margin-bottom: 0;
          margin-top: 0;
      }
      .clear {
          margin: 0;
          padding: 0;
          height: 0;
          clear: both;
      }

      div,p,li,ul,span,td,th,a {
          margin: 0;
          padding: 0;
      }

      p {
          padding-bottom: 6px;
      }

      .wraperPage {
          width: 100%;
          margin: 10px auto;
      }
      .pfsText{
        font-size:25px; font-weight:600;text-align: right;
      }
      .newPage {
          width: 100%;
          display: block;
      }

      .wrap {
          width: 100%;
          padding-bottom: 5px;
      }
      .wrap {
          width: 100%;
          display: inline-block;
          margin-bottom: 2px;
      }

      input[type="checkbox"] {
          margin: 0;
          padding: 2px;
      }

      input[type="text"] {
          margin: 0;
          padding: 1px 1%;
          width: 98%;
          border: 0;
          background: none
      }

    
      tr,td,ul {
          padding: 0;
          margin: 0;
          line-height: 13px;
      }


      .lebelText {
          font-size: 12px;
          color: #333;
          text-align: left;
          font-weight: bold;
          padding-bottom: 5px;
      }

      .valueText {
          font-size: 12px;
          color: #333;
          text-align: left;
          font-weight: normal;
          padding-bottom: 5px;
      }

      
      
      .table {
      border: 1px solid #2a5135;
      width: 100%;
      margin-bottom: 1rem;
      color: #212529;border-collapse: collapse;
      }
    .GreenBgTitle{color: #fff!important;
      text-align: center;
      font-size: 16px!important;
      font-weight: bold!important;
      padding: 15px 0;
      background-color: #2a5135;}
    .subTitle{color: #2a5135;
      text-align: left;
      font-size: 20px;
      font-weight: bold;
      padding: 15px 0;
      border-bottom:1px solid #2a5135;}
    .subTitle2{color: #2a5135;
      text-align: left;
      font-size: 14px;
      font-weight: bold;
      padding: 15px 0;}

    .table td,.table th {
      color: #2a5135;line-height: 17px;
      border-color: #2a5135;
      vertical-align: middle;
      font-size: 14px;padding: 15px 10px;
      font-weight: 500;border-bottom: 1px solid #2a5135;border-right: 1px solid #2a5135;}
    .table th{font-weight:bold;}
    .ogText td{ border-top:2px solid #ddd; padding-top:30px;}
    .ogText .lebelText, .ogText .valueText{ font-size:20px; color:#2a5135} 
    .tr{ text-align:right;}
    .logoText td{ padding-bottom:10px;}​​​​​​​​`,
      });
    }

    this.taskInfoService
      .saveTaskInfo(
        { slug: CONSTANTS.SLUG['download_analyis_pdf'] },
        { ...body[0] }
      )
      .subscribe((response) => {
        if (response.get_base64_pdf.data.data) {
          this.download.showPdf(
            response.get_base64_pdf.data.data,
            `${this.loanID}_Collateral_Reportable.pdf`
          );
        }
      });
  }
  generateHMDA() {
    this.commonService.navigate('hmda');
  }

  getReferenceData(isOpen) {
    if (isOpen && this.cra_reference_data) {
      let params = {
        slug: CONSTANTS.SLUG['evaluation_cra'],
        refId: this.cra_reference_data.ref_id,
        analysis_id : this.cra_reference_data.ref_id,
        backend_user_id: this.cra_reference_data.backend_user_id,
      };
      this.taskInfoService.getTaskInfo({ ...params }).subscribe((response) => {
        this.username =
          response?.response_data?.get_backend_user_by_id?.data?.data?.name;
        this.currentAction =
          response?.response_data.get_analysis_data?.data?.data[0]?.action_type;
        this.craPdfData = response?.response_data;
      });
    }
  }
  getHmdaReferenceData(isOpen) {
    if (isOpen && this.hmda_reference_data) {
      let params = {
        slug: CONSTANTS.SLUG['hmda'],
        refId: this.hmda_reference_data.ref_id,
        backend_user_id: this.hmda_reference_data.backend_user_id,
        app_id: this.appID,
      };

      this.taskInfoService.getTaskInfo({ ...params }).subscribe((response) => {
        this.hmda_username =response?.response_data?.get_backend_user_by_id_hmda?.data?.data?.name;
        this.hmdaPdfData = response?.response_data;
      });
    }
  }
  editHMDAForm() {
    this.store.dispatch(
      addAppDetails({
        appData: { ...this.appData, hmdaReference: this.hmda_reference_data },
      })
    );
    this.commonService.navigate('hmda');
  }

  downloadHMDAForm() {
    let body = [];
    for (let child of this.GenerateHMDAPDFComponent.toArray()) {
      body.push({
        content: child.nativeElement.innerHTML,
        style: `
        body {-webkit-print-color-adjust: exact!important;}
        @media all {
          .page-break {
              display: none;
          }
      }
  
      @media print {
          .page-break {
              display: block;
              page-break-before: always;
          }
      }
  
      body {
          color: #000;
          font-family: Arial, Helvetica, sans-serif;
          font-style: normal;
          font-size: 9.4pt;
          line-height: 20px;
          margin-bottom: 0;
          margin-top: 0;
      }
  
      .clear {
          margin: 0;
          padding: 0;
          height: 0;
          clear: both;
      }
  
      div,
      p,
      li,
      ul,
      span,
      td,
      th,
      a {
          margin: 0;
          padding: 0;
      }
  
      p {
          padding-bottom: 6px;
      }
  
      .wraperPage {
          width: 1000px;
          margin: 10px auto;
      }
      .pfsText{
          font-size:16px; font-weight:600;text-align: right;
      }
      .newPage {
          width: 100%;
          display: block;
      }
  
      .wrap {
          width: 100%;
          padding-bottom: 5px;
      }
  
      
  
    
  
      .wrap {
          width: 100%;
          display: inline-block;
          margin-bottom: 2px;
      }
  
      input[type="checkbox"] {
          margin: 0;
          padding: 2px;
      }
  
      input[type="text"] {
          margin: 0;
          padding: 1px 1%;
          width: 98%;
          border: 0;
          background: none
      }
  
      
  
      tr,
      td,
      ul {
          padding: 0;
          margin: 0;
          line-height: 13px;
      }
  
  
      .lebelText {
          font-size: 14px;
          color: #333;
          text-align: left;
          font-weight: bold!important;
          padding-bottom: 5px;
      }
  
      .valueText {
          font-size: 14px;
          color: #333;
          text-align: left;
          font-weight: normal!important;
          padding-bottom: 5px;
      }
  
      
      
      .table {
  border: 1px solid #2a5135;
  width: 100%;
  margin-bottom: 1rem;
  color: #212529;border-collapse: collapse;
  }
  .GreenBgTitle{color: #fff;
  text-align: center;
  font-size: 20px;
  font-weight: bold;
  padding: 15px 0;    margin-top: 20px;
  background-color: #2a5135;}
  .loanid{color: #2a5135;
  text-align: right;
  font-size: 18px;
  font-weight: bold;
  padding: 15px 0;
  border-top:1px solid #2a5135;
  border-bottom:1px solid #2a5135;}
  .subTitle2{color: #2a5135;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
  padding: 15px 0;}
  .subTitle3{color: #2a5135;
  text-align: left;
  font-size: 14px;
  font-weight: bold;
  padding: 15px 0;}
  
  .table td,.table th {
  color: #2a5135;
  border-color: #2a5135;
  vertical-align: middle;
  font-size: 14px;padding: 15px 10px;
  font-weight: 500;border-bottom: 1px solid #2a5135;border-right: 1px solid #2a5135;}
  .table th{font-weight:bold;}
  .ogText td{ border-top:2px solid #ddd; padding-top:30px;}
  .ogText .lebelText, .ogText .valueText{ font-size:20px; color:#2a5135} 
  .tr{ text-align:right;}
  .logoText td{ padding-bottom:10px;}`,
      });
    }

    this.taskInfoService.saveTaskInfo(
        { slug: CONSTANTS.SLUG['download_analyis_pdf'] },
        { ...body[0] }
      )
      .subscribe((response) => {
        if (response.get_base64_pdf.data.data) {
          this.download.showPdf(
            response.get_base64_pdf.data.data,
            `${this.loanID}_hmda.pdf`
          );
        }
      });
  }
}
