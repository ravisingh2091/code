import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import {
  addAppDetails,
  CommonService,
  FormGenerateService,
  TaskInfoService,
} from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { Store, select } from '@ngrx/store';
import { take } from 'rxjs/operators';


@Component({
  selector: 'collateral-reportable',
  templateUrl: './collateral-reportable.component.html',
  styleUrls: ['./collateral-reportable.component.scss'],
})
export class CollateralReportableComponent implements OnInit {
  formConfig: FormFieldInterface[] = [];
  form: FormGroup;
  slug: string;
  yes = '5e8723158f2f4e3ac475fab6';
  no = '5e8723158f2f4e3ac475fab7';
  app_id: string;
  user_id: string;
  business_id: string;
  backend_user_id:string;
  productName:string;
  craReference:any;
  viewMode:boolean=false;
  appData:any;
  userData: any;

  constructor(
    private common: CommonService,
    private store: Store<any>,
    private taskInfoService: TaskInfoService,
    private formGenerate: FormGenerateService
  ) {}

  ngOnInit() {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.user_id = rootState.userData.user_id;
      this.userData = rootState.userData;
      this.app_id = rootState.appID;
      this.appData = {...rootState.appData};
      this.business_id = rootState.businessID;
      this.backend_user_id=rootState.userData.user_id;
      this.productName=rootState.appData.productName;
      this.craReference=rootState?.appData?.craReference;
      let params={ slug: CONSTANTS.SLUG['evaluation_cra'] }
     
      if(this.craReference)
      {
        params['analysis_id']=this.craReference.ref_id
      }

      this.taskInfoService.getTaskInfo({...params}).subscribe((response) => {
        this.formConfig = response.form_fields;
        this.form = this.formGenerate.createControl(this.formConfig);
        this.slug = response.task_slug;
        this.common.sendMasterDataToFields(
          this.formConfig,
          response?.response_data
        );
        let craData=response?.response_data?.get_analysis_data?.data?.data.find((ele)=>{
          if(ele.type=='cra-analysis')
          return ele;
        })

        let craForm=craData?.form_data[0];
        if(craForm){
          this.formGenerate.setFormValues(this.form,craForm);
        }
        if(this.craReference?.view){
          this.form.disable();
          this.viewMode = true;
        }
        this.forCRALoan();
      });
    })
    
  }
  forCRALoan() {
    this.form.get('evaluation_cra_radio_1').valueChanges.subscribe((res) => {
      if(res==this.yes)
        this.patchFormValues(1);
      else
        this.form.get('CRA_Loan_Result').setValue('No');
       
    });
    this.form.get('evaluation_cra_radio_2').valueChanges.subscribe((res) => {
      if(res==this.yes)
        this.patchFormValues(2);
      else
        this.form.get('CRA_Loan_Result').setValue('No');
    });
    this.form.get('evaluation_cra_radio_3').valueChanges.subscribe((res) => {
      if(res==this.yes)
        this.patchFormValues(3);
      else
        this.form.get('CRA_Loan_Result').setValue('No');
    });
    this.form.get('evaluation_cra_radio_4').valueChanges.subscribe((res) => {
      if(res==this.yes)
        this.patchFormValues(4);
      else
        this.form.get('CRA_Loan_Result').setValue('No');
    });
    
  }
  objectToArray = obj => {
    let sol = [];
    for (let key in obj) {
      sol.push([key, obj[key]]);
  }
  return sol;
};
  patchFormValues(index) {
    const res = { ...this.form.getRawValue() };
    const data = {};
    this.objectToArray(res).forEach(([key, value]) => {
      if (key.indexOf(`evaluation_cra_radio_`) > -1 &&
        !(key.indexOf(`evaluation_cra_radio_${index}`) > -1)
      ) {
        value = this.no;
      }
      data[key] = value;
    });
    if (index == 3 || index == 4) {
      data['CRA_Loan_Result'] = 'Yes';
    } else {
      data['CRA_Loan_Result'] = 'No';
    }
    this.form.patchValue(data, { onlySelf: true, emitEvent: false });
  }

  backToUnderwriting() {
    this.common.navigate('underWriting');
  }

  onSubmit(action: any) {
    
    let formData = this.form.getRawValue();
    if (this.formGenerate.validateCustomFormFields(this.form, action, this.formConfig)) {
      let payload={
        app_id:this.app_id,
        backend_user_id:this.backend_user_id,
        action_type:'save',
        form_data:[{...formData,productName:this.productName}],
        type:'cra-analysis'
        
      };
      let params={
        slug:CONSTANTS.SLUG['evaluation_cra'],
        app_id:this.app_id,
        user_id:this.user_id,
        response_to_be_saved:formData['CRA_Loan_Result'],      
      }
      if(this.craReference){
        params['refId']=this.craReference.ref_id;
        params['cra_ref_mainid']=this.craReference._id;
      }
      this.taskInfoService.saveTaskInfo({ slug: CONSTANTS.SLUG['evaluation_cra'], ...params}, payload).subscribe(response => {
        this.common.popToast('success', 'Success', 'CRA Reportable Questionnaire submitted successfully.');
        this.addActivityLog();
        this.common.navigate('underWriting');
      })
    }
  }
  addActivityLog(){
    const log_data = {
      role_slug:     this.userData.role_slug,
      app_id: this.app_id,
      backend_user_id: this.backend_user_id,
      user_name: this.userData.full_name,
      activity: 'cra_updated'
    };
    this.common.addActivityLog(log_data);
  }
  ngOnDestroy() {
    if (this.craReference) {
      delete this.appData.craReference;
      this.store.dispatch(addAppDetails({appData: {...this.appData}}));
    }
  }
  }

