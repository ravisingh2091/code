import { Component, OnInit, Input, Inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';

@Component({
  selector: 'collateral-reportable-pdf',
  templateUrl: './collateral-reportable-pdf.component.html',
  styleUrls: ['./collateral-reportable-pdf.component.scss']
})
export class CollateralReportablePdfComponent implements OnInit {
  logo1_path: string;
  logo2_path: string;
  @Input() pdfData: any; 
  annualSales: any;
  annualBusinessSales: any;
  formData: any;
  yesNodata: any;
  loanId: string;
  businessName: string;
  constructor(
    private store: Store<any>,
    @Inject('environment') public environment
  ) { }

  ngOnInit(): void {
    this.logo1_path = this.environment.logo1_path;
    this.logo2_path = this.environment.logo2_path;
  
    if(this.pdfData) {
         this.annualSales = this.pdfData?.annual_sales?.data?.data;
         this.annualBusinessSales = this.pdfData?.annual_business_sales?.data?.data;
         this.formData = this.pdfData.get_analysis_data.data.data[0].form_data[0];
         this.yesNodata = this.pdfData?.yes_no?.data?.data;
         this.store.select('app').pipe(take(1)).subscribe(rootstate => {
            this.loanId = rootstate.appData.loan_id;
            this.businessName = rootstate.appData.business_name;
         })
    }
  }

}
