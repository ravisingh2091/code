import { Component, ElementRef, Inject, Input, OnChanges, OnInit, QueryList, SimpleChanges, ViewChildren } from '@angular/core';
import { Router } from '@angular/router';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import {CommonService, DownloadService, TaskInfoService} from '@rubicon/utils';
import { CalculationService} from 'libs/components/collateral-evaluation/src/lib/services/calculation.service';
import { of, throwError, timer } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

@Component({
  selector: 'collateral-main',
  templateUrl: './collateral-main.component.html',
  styleUrls: ['./collateral-main.component.scss']
})
export class CollateralMainComponent implements OnInit, OnChanges {
  hasCollateral:boolean = false;
  @Input() init_data;
  @Input() collateral_backend_user;
  @Input() collateral_reference;
  @Input() loaded;
  @Input() collateral_pdf_reference;
  @Input() productName;
  @Input() loanID;
  @Input() collateral_data;
  @Input() download_collateral;
  master_data;

  @ViewChildren('pdfCollateral') GenerateCollateralPDFComponent: QueryList<ElementRef>;

  ngOnChanges(simpleChanges: SimpleChanges){
    if(simpleChanges && simpleChanges.init_data && simpleChanges.init_data.currentValue){
      this.hasCollateral = true;
    }
  }
  constructor(private commonService:CommonService, private _router: Router, @Inject('APP_ROUTES') private APP_ROUTES,
  private taskInfoService:TaskInfoService, private downloadService: DownloadService,
  private calculationService: CalculationService
  ) { }

  ngOnInit(): void {}

  openCollateralEval(isViewMode: boolean) {
    if(isViewMode){
      this._router.navigate([this.APP_ROUTES['collateral-eval']],{fragment: 'view'});
    }else{
      this.commonService.navigate('collateral-eval');
    }
  }

  getCombCollatCovRatio(){
    if(this.init_data && this.init_data.total_collaterals && this.init_data.total_collaterals.length > 0){
      let aba_data = this.init_data.total_collaterals.find(collateral=>collateral.collateral_key == "aba");
      if(aba_data && aba_data.hasOwnProperty('combined_collateral_coverage_ratio') && aba_data.combined_collateral_coverage_ratio != 'null'){
        return aba_data.combined_collateral_coverage_ratio;
      }
    }
    return '-';
  }

  downloadCollateralPDFFromUI(){
    let get_master_api = this.taskInfoService.getTaskInfo({
      slug: CONSTANTS.SLUG['collateral_evaluation_masters'],
    }).pipe(map((res:any)=>{
      if (res?.response_data?.nextTask?.value == CONSTANTS.SLUG['collateral_evaluation_masters']) {
        let { all_collateral_type, cities, lein_value, percentage, state, valuation_source, yes_no, collateral_appraisal_type} = res.response_data;
        this.master_data = {
          all_collateral_type: (all_collateral_type && all_collateral_type.data && all_collateral_type.data.data && all_collateral_type.data.data.length > 0) ? all_collateral_type.data.data : [],
          // aba_asset_description: (aba_asset_description && aba_asset_description.data && aba_asset_description.data.data && aba_asset_description.data.data.length > 0) ? aba_asset_description.data.data : [],
          cities: (cities && cities.data && cities.data.data && cities.data.data.length > 0) ? cities.data.data : [],
          // collateral: (collateral && collateral.data && collateral.data.data && collateral.data.data.length > 0) ? collateral.data.data : [],
          lein_value: (lein_value && lein_value.data && lein_value.data.data && lein_value.data.data.length > 0) ? lein_value.data.data : [],
          percentage: (percentage && percentage.data && percentage.data.data && percentage.data.data.length > 0) ? percentage.data.data : [],
          state: (state && state.data && state.data.data && state.data.data.length > 0) ? state.data.data : [],
          valuation_source: (valuation_source && valuation_source.data && valuation_source.data.data && valuation_source.data.data.length > 0) ? valuation_source.data.data : [],
          yes_no: (yes_no && yes_no.data && yes_no.data.data && yes_no.data.data.length > 0) ? yes_no.data.data : [],
          collateral_appraisal_type: (collateral_appraisal_type && collateral_appraisal_type.data && collateral_appraisal_type.data.data && collateral_appraisal_type.data.data.length > 0) ? collateral_appraisal_type.data.data : [],
        };
        return this.master_data;
      } 
      throw res;
    }));

    if(this.master_data){
      get_master_api = of(this.master_data);
    }
    
    get_master_api.pipe(switchMap((master_data)=>{
      return timer(1).pipe(switchMap(()=>{
        let body = this.calculationService.getCollateralEvalHtml(this.GenerateCollateralPDFComponent, this.loanID);
        return this.taskInfoService.saveTaskInfo(
        { slug: CONSTANTS.SLUG['download_analyis_pdf'] },
        { ...body })
      }));
    })).subscribe((response) => {
      if (response.get_base64_pdf.data.data) {
        this.downloadService.showPdf(
          response.get_base64_pdf.data.data,
          `${this.loanID}_collateral_evaluation.pdf`
        );
      }else{
        this.commonService.popToast("error", "", "Failed to download document.");
      }
    },()=>{
      this.commonService.popToast("error", "", "Failed to download document.");
    });
  }

  downloadCollateralPDF(){
    this.taskInfoService.saveTaskInfo(
      { slug: CONSTANTS.SLUG['download-document'] },
      { doc_id: this.collateral_pdf_reference.ref_id },
    ).subscribe((response: any) => {
        if (response?.download_document_v2?.data) {
          this.downloadService.showPdf(
            response.download_document_v2.data,
            this.collateral_pdf_reference.response.filename
          );
        }else{
          this.commonService.popToast("error", "", "Failed to download document.");
        }
      },()=>{
        this.commonService.popToast("error", "", "Failed to download document.");
      });
  }
}
