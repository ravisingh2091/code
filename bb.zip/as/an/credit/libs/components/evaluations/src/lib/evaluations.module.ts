import {
  NgModule,
  CUSTOM_ELEMENTS_SCHEMA,
  NO_ERRORS_SCHEMA,
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { Route, RouterModule } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { CollateralReportableComponent } from './CollateralReportable/collateral-reportable.component';
import { EvaluationComponent } from './evaluations-component/evaluation.component';
import { CollateralMainComponent } from './evaluations-component/collateral-main/collateral-main.component';
import { CollateralReportablePdfComponent } from './collateral-reportable-pdf/collateral-reportable-pdf.component';
import {HmdaModule} from '@credit-bench/components/hmda';
import { CollateralEvaluationEagerModule } from 'libs/components/collateral-evaluation/src/lib/collateral-evaluation-eager.module';

export const evaluationRoutes: Route[] = [
  { path: 'collateral-reportable', component: CollateralReportableComponent },
];


@NgModule({
  declarations: [CollateralReportableComponent,EvaluationComponent, CollateralMainComponent, CollateralReportablePdfComponent],
  imports: [
    CommonModule,
    SharedLazyModule,
    RouterModule.forChild(evaluationRoutes),
    HmdaModule,
    CollateralEvaluationEagerModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
  exports: [EvaluationComponent],
})
export class EvaluationModule {}
