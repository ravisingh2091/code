import { Component, OnInit } from '@angular/core';
import { CommonService, TaskInfoService } from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';

@Component({
  selector: 'caf-decision-history',
  templateUrl: './decision_history.component.html',
  styleUrls: ['./decision_history.component.scss'],
})
export class DecisionHistoryComponent implements OnInit {
  product_list: any = [];
  backend_user: any = [];
  caf_data = null;
  loan_decision = [];
  loan_decision_history = [];
  appID: string;
  constructor(
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private store: Store<any>
  ) { }

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.appID = rootState?.appID;
      this.taskInfoService.getTaskInfo({slug: CONSTANTS.SLUG['get_caf_decision_history'], app_id:this.appID}).subscribe(response => {
        if (response) {
          const all_bus_ref= response?.response_data?.get_business_reference?.data?.data;
          this.loan_decision= response?.response_data?.loan_decision?.data?.data;
          this.backend_user= response?.response_data?.get_backend_user?.data?.data;
          this.loan_decision_history = all_bus_ref.filter(res => res?.type==="offer_management")
          this.loan_decision_history.forEach(elem=>{
            if(elem?.response) {
              elem.response = JSON.parse(elem.response);
            }
          });
          this.loan_decision_history = this.loan_decision_history.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        }})
    })
  }
  backToUnderwriting() {
    this.common.navigate('underWriting');
  }
}
