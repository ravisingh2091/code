import { Component, OnInit, Input, ViewChild, ElementRef, Inject } from '@angular/core';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { DownloadService, TaskInfoService } from '@rubicon/utils';
import { Subscription } from 'rxjs';

@Component({
  selector: 'caf-pdf',
  templateUrl: './caf-pdf.component.html',
  styleUrls: ['./caf-pdf.component.scss']
})
export class CafPdfComponent implements OnInit {

  cdnURL;
  logo1;
  logo2;

  @Input() pdfData: any;
  @Input() bankerData: any = null;
  @Input() productName: string;
  cafData: any;
  masterData: any;
  loan_decision_obj = {
    approve: '5e8723158f2f4e2ac476fae6',
    decline: '5e8723158f2f4e2ac476fae7',
    counter_offer: '5e8723158f2f4e2ac476fae8',
    withdrawn: '5e8723158f2f4e2ac476fae9',
    pending: '5e8723158f2f4e2ac476fae5'
  };
  logo1_path: string;
  logo2_path: string;
  @ViewChild("cafpdfContent") cafpdfContent: ElementRef<any>;
  downloadPDfSubscription: Subscription;

  constructor(
    private download: DownloadService,
    private taskInfoService: TaskInfoService,
    @Inject('environment') private environment,
  ) { }

  ngOnInit(): void {
    this.logo1_path = this.environment.logo1_path;
    this.logo2_path = this.environment.logo2_path;
  
    this.cdnURL = this.environment.cdnURL;
    
    if (this.pdfData) {
      this.cafData = this.pdfData?.get_caf_data?.data?.data;
      this.masterData = JSON.parse(JSON.stringify(this.pdfData));
      if (this.masterData?.get_caf_data) {
        delete this.masterData.get_caf_data;
      }
      if (this.masterData?.loanID) {
        delete this.masterData.loanID;
      }
      setTimeout(() => {
        this.downloadCAFForm();
      }, 200);
    }
  }

  downloadCAFForm() {
    let body = [];
    body.push({
      content: this.cafpdfContent.nativeElement.innerHTML,
      style: `
        body {-webkit-print-color-adjust: exact!important;}
        @media all {
          .page-break {
              display: none;
          }
      }
      @media print {
          .page-break {
              display: block;
              page-break-before: always;
          }
      }
      body {
          color: #000;
          font-family: Arial, Helvetica, sans-serif;
          font-style: normal;
          font-size: 9.4pt;
          line-height: 20px;
          margin-bottom: 0;
          margin-top: 0;
      }
      .clear {
          margin: 0;
          padding: 0;
          height: 0;
          clear: both;
      }
      div,
      p,
      li,
      ul,
      span,
      td,
      th,
      a {
          margin: 0;
          padding: 0;
      }
      p {
          padding-bottom: 6px;
      }
      .wraperPage {
          width: 100%;
          margin: 10px auto;
      }
      .pfsText{
        font-size:16px; font-weight:600;text-align: right;
      }
      .newPage {
          width: 100%;
          display: block;
      }
      .wrap {
          width: 100%;
          padding-bottom: 5px;
      }
      .wrap {
          width: 100%;
          display: inline-block;
          margin-bottom: 2px;
      }
      input[type="checkbox"] {
          margin: 0;
          padding: 2px;
      }
      input[type="text"] {
          margin: 0;
          padding: 1px 1%;
          width: 98%;
          border: 0;
          background: none
      }
      tr,
      td,
      ul {
          padding: 0;
          margin: 0;
          line-height: 13px;
      }
      .lebelText {
          font-size: 14px;
          color: #333;
          text-align: left;
          font-weight: bold!important;
          padding-bottom: 5px;
      }
      .valueText {
          font-size: 14px;
          color: #333;
          text-align: left;
          font-weight: normal!important;
          padding-bottom: 5px;
      }
      .table {
        border: 1px solid #2a5135;
        width: 100%;
        margin-bottom: 1rem;
        color: #212529;border-collapse: collapse;
      }
    .GreenBgTitle{color: #fff;
      text-align: center;
      font-size: 20px;
      font-weight: bold;
      padding: 15px 0;    margin-top: 20px;
      background-color: #2a5135;}
    .loanid{color: #2a5135;
      text-align: right;
      font-size: 18px;
      font-weight: bold;
      padding: 15px 0;
      border-top:1px solid #2a5135;
      border-bottom:1px solid #2a5135;}
    .subTitle2{color: #2a5135;
      text-align: left;
      font-size: 16px;
      font-weight: bold;
      padding: 15px 0;}
    .subTitle3{color: #2a5135;
      text-align: left;
      font-size: 14px;
      font-weight: bold;
      padding: 15px 0;}

    .table td,.table th {
      color: #2a5135;
      border-color: #2a5135;
      vertical-align: middle;
      font-size: 14px;padding: 15px 10px;
      font-weight: 500;border-bottom: 1px solid #2a5135;border-right: 1px solid #2a5135;}
    .table th{font-weight:bold;}
    .ogText td{ border-top:2px solid #ddd; padding-top:30px;}
    .ogText .lebelText, .ogText .valueText{ font-size:20px; color:#2a5135} 
    .tr{ text-align:right;}
    .logoText td{ padding-bottom:10px;},`});
    this.downloadPDfSubscription = this.taskInfoService.saveTaskInfo(
      { slug: CONSTANTS.SLUG['download_analyis_pdf'] },
      { ...body[0] }
    ).subscribe((response) => {
      if (response.get_base64_pdf.data.data) {
        this.download.showPdf(
          response.get_base64_pdf.data.data,
          `${this.pdfData.loanID}_caf.pdf`
        );
      }
    });
  }

  getAddress(address, cra?) {
    if (cra) {
      const state = this.masterData?.state?.data?.data?.length ? this.masterData.state.data.data.find(res => res.id == address?.cra_state)?.value : '';
      const city = address?.cra_city?.charAt(0) + address?.cra_city?.slice(1, address?.cra_city?.length).toLowerCase();
      return `${(address.cra_street_no && typeof address.cra_street_no !== "undefined" && typeof address.cra_street_no === "string") ? address.cra_street_no+', ' : ""}${(address.cra_street_name && typeof address.cra_street_name !== "undefined" && typeof address.cra_street_name === "string") ? address.cra_street_name+', ' : ""}${(typeof city !== "undefined" && typeof city === "string") ? city+', ' : ""}${(typeof state !== "undefined" && typeof state === "string") ? state+', ' : ""}${(address.cra_zip_code && typeof address.cra_zip_code !== "undefined" && typeof address.cra_zip_code === "string") ? address.cra_zip_code : ""}`
    } else {
      const state = this.masterData?.state?.data?.data?.length ? this.masterData.state.data.data.find(res => res.id == address?.state)?.value : '';
      const city = address?.city?.charAt(0) + address?.city?.slice(1, address?.city?.length).toLowerCase();
      return `${(address.street_no && typeof address.street_no !== "undefined" && typeof address.street_no === "string") ? address.street_no+', ' : ""}${(address.street_name && typeof address.street_name !== "undefined" && typeof address.street_name === "string") ? address.street_name+', ' : ""}${(typeof city !== "undefined" && typeof city === "string") ? city+', ' : ""}${(typeof state !== "undefined" && typeof state === "string") ? state+', ' : ""}${(address.zip_code && typeof address.zip_code !== "undefined" && typeof address.zip_code === "string") ? address.zip_code : ""}`
    }
  }

  getRole(approval) {
    const banker_role = this.bankerData.find(ele=>ele?.id===approval?.backend_user_id)?.roles?.name;
    return banker_role + ' Approval';
  }

  getBankerDetail(approval) {
    const banker_name = this.bankerData.find(ele=>ele?.id===approval?.backend_user_id)?.name;
    return banker_name;
  }

  ngOnDestroy() {
    this.downloadPDfSubscription?.unsubscribe();
  }

}
