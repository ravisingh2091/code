import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { addAppDetails, CommonService, TaskInfoService } from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { Store } from '@ngrx/store';
import { distinctUntilChanged, pluck, take } from 'rxjs/operators';
import { Subscription } from 'rxjs';

@Component({
  selector: 'underwriter-caf',
  templateUrl: './caf.component.html',
  styleUrls: ['./caf.component.scss'],
})
export class CAFComponent implements OnInit {
  product_list: any = [];
  bankerData: any = [];
  caf_data = null;
  loan_decision = [];
  loanID: string;
  productName: string;
  business_industry: string;
  loan_status_id: string;
  incomplete_application = CONSTANTS.APPLICATION_STATUS['application_in_progress'];
  appData: any = {};
  caf_pdf_data: any;
  userData: any;
  last_loan_decision_value: string;
  loan_decision_obj = {
    approve: '5e8723158f2f4e2ac476fae6',
    decline: '5e8723158f2f4e2ac476fae7',
    counter_offer: '5e8723158f2f4e2ac476fae8',
    withdrawn: '5e8723158f2f4e2ac476fae9',
    pending: '5e8723158f2f4e2ac476fae5'
  }
  disableCaf = true;
  @Input() applicationData: any;
  storeSubscription: Subscription;
  getDataSubscription: Subscription;
  pdfDataSubscription: Subscription;
  
  constructor(
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private store: Store<any>
  ) { }

  ngOnInit(): void { }

  getCaf(event) {
    if (event) {
      if (this.applicationData) {
        let offer_management_ref_index;
        if(this.applicationData?.business_references?.length) {
          const save_caf_ref_index = this.applicationData?.business_references.map(elem => elem.type).lastIndexOf('caf_saved');
          offer_management_ref_index = this.applicationData?.business_references.map(elem => elem.type).lastIndexOf('offer_management');
          if (save_caf_ref_index > offer_management_ref_index) {
            this.caf_data = this.applicationData?.business_references[save_caf_ref_index];
          } else if (save_caf_ref_index < offer_management_ref_index) {
            this.caf_data = this.applicationData?.business_references[offer_management_ref_index];
          }
        }        
        this.loanID = this.applicationData?.auto_id;
        this.loan_status_id = this.applicationData?.status_id;
        this.business_industry = this.applicationData?.business.length && this.applicationData.business[0].industry ? this.applicationData.business[0].industry : null;
        const queryParams = {
          slug: CONSTANTS.SLUG['get_caf_data'],
          app_id: this.applicationData?._id
        }
        if (this.caf_data) {
          queryParams['backend_user_id'] = this.caf_data?.backend_user_id;
          if (typeof this.caf_data?.response === 'string') {
            this.caf_data.response = JSON.parse(this.caf_data?.response);
          }
          this.caf_data['loan_id'] = this.loanID;
          this.caf_data['business_industry'] = this.business_industry;
        }
        
        this.storeSubscription = this.store.select('app').pipe(distinctUntilChanged()).subscribe((rootState) => {
          this.appData = rootState?.appData;
          this.productName = this.appData.productName;
          queryParams['user_id'] = this.appData.user_id;
          this.userData = rootState?.userData;
          if (this.productName && this.loan_status_id !== this.incomplete_application) {
            this.getDataSubscription = this.taskInfoService.getTaskInfo(queryParams).pipe(take(1)).subscribe(response => {
              this.product_list = response?.response_data?.get_products?.data?.data;
              const current_stage = response?.response_data?.get_current_stage?.data?.data?.stage;
              if ((current_stage?.type === 'underwriting' || current_stage?.type === 'pre_closing')&& (['underwriter_l1', 'underwriter_l2'].includes(this.userData?.role_slug))) {
                this.disableCaf = false;
              }
              if (this.caf_data) {
                this.loan_decision = response?.response_data?.loan_decision?.data?.data;
                this.caf_data.backend_user_name = response?.response_data?.get_backend_user_by_id?.data?.data?.name;
              }
            });
          }
          if(offer_management_ref_index>=0){
            const offer_management_data = this.applicationData?.business_references[offer_management_ref_index];
            if (typeof offer_management_data?.response === 'string') {
              offer_management_data.response = JSON.parse(offer_management_data?.response);
            }
            this.last_loan_decision_value = offer_management_data?.response?.status_id;
          }
        })
      }
    }
  }

  editCAF(action, product_id): void {
    this.store.dispatch(addAppDetails({
      appData: {
        ...this.appData, caf: {
          editCAF: action,
          loan_offer_id: this.caf_data?.ref_id,
          caf_business_ref_main_id: this.caf_data?._id,
          caf_business_ref_type: this.caf_data?.type,
          product_id: product_id,
          loan_id: this.loanID,
          business_industry: this.business_industry,
          last_loan_decision_value: this.last_loan_decision_value
        }
      }
    }));
    this.common.navigate('credit-approval-form');
  }

  downloadCAFForm() {
    let caf_submitted = [];
    const queryparams = {
      slug: CONSTANTS.SLUG['caf_pdf_data'],
      app_id: this.caf_data?.app_id,
      business_industry: this.caf_data?.business_industry,
      loan_offer_id: this.caf_data?.ref_id,
      loan_decision: this.caf_data?.response?.loan_decision
    };    
    if(this.caf_data?.response?.loan_decision===this.loan_decision_obj.approve || this.caf_data?.response?.loan_decision===this.loan_decision_obj.counter_offer) {
      caf_submitted = this.applicationData?.business_references.filter(ele=>{
        if(ele.type==='offer_management' && ele.response) {
          if (typeof ele?.response === 'string') {
            ele.response = JSON.parse(ele?.response);
          }
          if(ele?.response?.status_id === this.loan_decision_obj.approve || ele?.response?.status_id === this.loan_decision_obj.counter_offer) {
            return ele;
          }
        }
      });
      const unique_banker_ids = Array.from(new Set(caf_submitted.map(element=>element.backend_user_id)));
      if(unique_banker_ids.length){
        const body = {
          loan_decision: this.caf_data?.response?.loan_decision,
          user_ids: unique_banker_ids
        }
        this.taskInfoService.saveTaskInfo({slug: CONSTANTS.SLUG['caf_pdf_data']}, body).subscribe(res => {
          this.bankerData = res.get_banker_by_ids.data.data
        });
      }      
    }
   
    this.pdfDataSubscription = this.taskInfoService.getTaskInfo(queryparams).subscribe(response => {
      if (response) {
        const caf_pdf_data = {
          ...response?.response_data,
          loanID: this.loanID
        }
        if(caf_submitted?.length){
          caf_pdf_data.approvals = caf_submitted;
        }
        this.caf_pdf_data = caf_pdf_data;
      }
    });
  }

  ngOnDestroy() { 
    this.storeSubscription?.unsubscribe();
    this.getDataSubscription?.unsubscribe();
    this.pdfDataSubscription?.unsubscribe();
  }
}
