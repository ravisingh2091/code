//to add decline and withdrawn option for loan decision update option in offer_status.json master
//refer https://code.b2cdev.com/credit-bench/assets/masters/merge_requests/215
import { Component, Inject, OnInit } from '@angular/core';
import { addAppDetails, CommonService, FormGenerateService, MasterDataPipe, TaskInfoService } from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { select, Store } from '@ngrx/store';
import { debounceTime, distinctUntilChanged, take, takeUntil } from 'rxjs/operators';
import { merge, ReplaySubject, Subscription } from 'rxjs';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { FormArray, FormGroup } from '@angular/forms';

@Component({
  selector: 'generate-caf',
  templateUrl: './generate-caf.component.html',
  styleUrls: ['./generate-caf.component.scss'],
})

export class GenerateCAFComponent implements OnInit {
  caf_config: FormFieldInterface[] = [];
  caf_form: FormGroup;
  loan_approval_form_config: FormFieldInterface[] = [];
  loan_approval_form: FormGroup;
  datahub_info_config: FormFieldInterface[] = [];
  datahub_info_form: FormGroup;
  silverlake_info_config: FormFieldInterface[] = [];
  silverlake_info_form: FormGroup;
  slug = CONSTANTS.SLUG['credit_approval_form'];
  loan_decision_slug = null;
  app_data: any = null;
  caf_data: any = null;
  rm_obj: any = null;
  loan_decision_array = [];
  datahub_info_slug: string = "datahub_info_form";
  silverlake_info_slug: string = "silverlake_form";
  compDestroyed$ = new ReplaySubject(1);
  productId: string;
  appID: string;
  userID: string;
  backendUserID: string;
  total_amount = 0;
  application_loan_amount = 0;
  loan_offer_id: string;
  caf_business_ref_main_id: string;
  caf_business_ref_type: string;
  editCAF = true;
  appData: any = null;
  userData: any = null;
  last_loan_decision_value: string;
  last_status_id_value: string;
  loan_decision_obj = {
    approve: '5e8723158f2f4e2ac476fae6',
    decline: '5e8723158f2f4e2ac476fae7',
    counter_offer: '5e8723158f2f4e2ac476fae8',
    withdrawn: '5e8723158f2f4e2ac476fae9',
    pending: '5e8723158f2f4e2ac476fae5'
  }
  request_type_obj = {
    new: '5e8723158f2f4e8ac476fae6',
    refinance: '5e8723158f2f4e8ac476fae4',
    secured_renewal: '5e8723158f2f4e8ac476fae7',
    unsecured_renewal: '5e8723158f2f4e8ac476fae5'
  }
  interest_type = {
    fixed: '5e8723158f2f5e7ac476fae6',
    variable: '5e8723158f2f5e7ac476fae7'
  }
  possessory_type = {
    deposits_or_cds: '5efda2521cdbd96830a1990f',
    life_insurance: '5efda2521cdbd96830a19915'
  }
  disableCaf = true;
  rm_key = 'loan_officer_l1';
  openAccordian = false;
  latest_credit_analyst = null;
  latest_loan_officer = null;
  storeSubscription: Subscription;
  getDataSubscription: Subscription;
  submitDataSubscription: Subscription;
  loanDecisionChangeSubscription: Subscription;
  loanDecisionFormSubscription: Subscription;
  interestTypeSubscription: Subscription;
  standardProductIdSubscription: Subscription;
  interestRateSubscription: Subscription;
  floorRateSubscription: Subscription;
  SBAGntyPctSubscription: Subscription;
  FloodCommunityNumberSubscription: Subscription;
  requestTypeSubscription: Subscription;
  amountSubscription: Subscription;
  requestedNewMoney: Subscription;
  requestedNewMoneyRequired: Subscription;
  totalExposureSubscription: Subscription;
  datahubFormSubscription: Subscription;
  silverlakeFormSubscription: Subscription;

  constructor(
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    private formGenerateService: FormGenerateService,
    @Inject('environment') private environment,
  ) { }

  ngOnInit(): void {
    this.storeSubscription = this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.appID = rootState?.appID;
      this.appData = rootState?.appData;
      this.userID = this.appData?.user_id;
      this.backendUserID = rootState?.userData?.user_id;
      this.userData = rootState?.userData;
      this.loan_offer_id = this.appData?.caf?.loan_offer_id;
      this.caf_business_ref_main_id = this.appData?.caf?.caf_business_ref_main_id;
      this.caf_business_ref_type = this.appData.caf?.caf_business_ref_type;
      this.editCAF = this.appData?.caf ? this.appData?.caf?.editCAF : true;
      this.productId = this.appData?.caf?.product_id;
      this.last_loan_decision_value = this.appData?.caf?.last_loan_decision_value;
      this.latest_credit_analyst = this.getUnderwriter();
      this.latest_loan_officer = this.getLoanOfficer();
      const queryparams = { slug: this.slug, app_id: this.appID, visible: true, user_id: this.appData?.user_id };
      if (this.loan_offer_id) {
        queryparams['loan_offer_id'] = this.loan_offer_id;
      }
      this.getDataSubscription = this.taskInfoService.getTaskInfo(queryparams).subscribe(response => {
        if (response) {
          this.caf_config = response.form_fields;
          this.caf_form = this.formGenerateService.createControl(this.caf_config);
          this.common.sendMasterDataToFields(this.caf_config, response.response_data);
          this.loan_decision_array = response?.response_data?.loan_decision?.data?.data;
          this.loanDecisionChange();
          const current_stage = response?.response_data?.get_current_stage?.data?.data?.stage;
          if ((current_stage?.type === 'underwriting' || current_stage?.type === 'pre_closing') && (['underwriter_l1', 'underwriter_l2'].includes(this.userData?.role_slug))) {
            this.disableCaf = false;
          }
          if (response?.response_data?.app_detail) {
            this.app_data = response?.response_data?.app_detail?.data?.data[0];
            this.populateAppData(this.app_data, 'get_caf_data' in response?.response_data);
          }
          if (response?.response_data?.get_caf_data) {
            this.caf_data = response?.response_data?.get_caf_data?.data?.data;
            this.total_amount = this.caf_data.amount;
            this.last_status_id_value = this.caf_data?.status_id;
            this.formGenerateService.setFormValues(this.caf_form, this.caf_data?.loan_offer_data);
            if (!this.editCAF) {
              this.caf_form.disable();
            }
            if (this.latest_credit_analyst && (this.caf_data?.loan_offer_data?.banker_info?.credit_analyst !== this.latest_credit_analyst)) {
              this.caf_form.get('banker_info').patchValue({ 'credit_analyst': this.latest_credit_analyst });
            }
          }
          this.openAccordian = true;
        }
      });
    });
  }

  loanDecisionChange() {
    this.loanDecisionChangeSubscription = this.caf_form.get('loan_decision').valueChanges.pipe(distinctUntilChanged()).subscribe(loan_decision_value => {
      if (loan_decision_value === this.loan_decision_obj.approve || loan_decision_value === this.loan_decision_obj.counter_offer) {
        this.loan_decision_slug = CONSTANTS.SLUG['approval_decision_form'];
      } else if (loan_decision_value == this.loan_decision_obj.decline) {
        this.loan_decision_slug = CONSTANTS.SLUG['decline_decision_form'];
      } else if (loan_decision_value == this.loan_decision_obj.withdrawn) {
        this.loan_decision_slug = CONSTANTS.SLUG['withdrawn_decision_form'];
      }
      if (this.loan_decision_slug) {
        this.loanDecisionFormSubscription = this.taskInfoService.getTaskInfo({ slug: this.loan_decision_slug }).subscribe(res => {
          this.loan_approval_form_config = res.form_fields;
          this.loan_approval_form = this.formGenerateService.createControl(this.loan_approval_form_config);
          this.common.sendMasterDataToFields(this.loan_approval_form_config, res.response_data);
          if (this.app_data && (loan_decision_value !== this.caf_data?.loan_decision)) {
            this.loan_approval_form.reset();
            this.populateLoanDecisionForm(this.app_data);
          }
          if (loan_decision_value === this.loan_decision_obj.approve || loan_decision_value === this.loan_decision_obj.counter_offer) {
            this.interestTypeSubscription = this.loan_approval_form.get('interest_schedule').get('interest_type').valueChanges.subscribe(interest_type_value => {
              if (interest_type_value === this.interest_type.variable) {
                this.common.sendMasterDataToFields(this.loan_approval_form_config, res.response_data);
              }
            });
            this.interestRateSubscription = this.loan_approval_form.get('interest_schedule').get('interest_rate').valueChanges.pipe(debounceTime(500), distinctUntilChanged()).subscribe(interest_rate_value => {
              if (interest_rate_value && (parseFloat(interest_rate_value) > 100)) {
                const formGroup = this.loan_approval_form.controls['interest_schedule'] as FormGroup;
                formGroup.controls['interest_rate'].markAsDirty();
                formGroup.controls['interest_rate'].setErrors({ 'incorrect': true });
              }
            });
            this.standardProductIdSubscription = this.caf_form.get('banker_info').get('standard_product_id').valueChanges.pipe(takeUntil(this.compDestroyed$)).subscribe(standard_product_id_value => {
              this.setInterestType(standard_product_id_value);
            });
            if (this.caf_form.get('banker_info').get('standard_product_id')?.value) {
              this.setInterestType(this.caf_form.get('banker_info').get('standard_product_id')?.value);
            }
            this.floorRateSubscription = this.loan_approval_form.get('interest_schedule').get('floor_rate').valueChanges.pipe(debounceTime(500), distinctUntilChanged()).subscribe(floor_rate_value => {
              if (floor_rate_value && (parseFloat(floor_rate_value) > 100)) {
                const formGroup = this.loan_approval_form.controls['interest_schedule'] as FormGroup;
                formGroup.controls['floor_rate'].markAsDirty();
                formGroup.controls['floor_rate'].setErrors({ 'incorrect': true });
              }
            });
            this.SBAGntyPctSubscription = this.loan_approval_form.get('recap_of_total_exposure').get('sba_gnty_pct').valueChanges.pipe(debounceTime(500), distinctUntilChanged()).subscribe(sba_gnty_pct => {
              if (sba_gnty_pct && (parseFloat(sba_gnty_pct) > 90)) {
                const formGroup = this.loan_approval_form.controls['recap_of_total_exposure'] as FormGroup;
                formGroup.controls['sba_gnty_pct'].markAsDirty();
                formGroup.controls['sba_gnty_pct'].setErrors({ 'incorrect': true });
              }
            });
            this.loan_approval_form.get('interest_schedule').get('share_of_total_pct').valueChanges.pipe(debounceTime(500), distinctUntilChanged()).subscribe(share_of_total_pct_value => {
              if (share_of_total_pct_value && (parseFloat(share_of_total_pct_value) > 100)) {
                const formGroup = this.loan_approval_form.controls['interest_schedule'] as FormGroup;
                formGroup.controls['share_of_total_pct'].markAsDirty();
                formGroup.controls['share_of_total_pct'].setErrors({ 'incorrect': true });
              }
            });
            this.requestTypeSubscription = this.loan_approval_form.get('facility_information').get('request_type').valueChanges.subscribe(request_type_value => {
              if (request_type_value === this.request_type_obj.new) {
                this.loan_approval_form.get('facility_information').patchValue({ 'requested_new_money': this.application_loan_amount });
                this.loan_approval_form.get('facility_information').patchValue({ 'requested_new_money_required': this.application_loan_amount });
                this.loan_approval_form.get('facility_information').get('requested_new_money').enable();
              } else if (request_type_value === this.request_type_obj.refinance) {
                this.loan_approval_form.get('facility_information').patchValue({ 'requested_new_money': null });
                this.loan_approval_form.get('facility_information').get('requested_new_money').enable();
              } else if (request_type_value === this.request_type_obj.secured_renewal || request_type_value === this.request_type_obj.unsecured_renewal) {
                this.loan_approval_form.get('facility_information').patchValue({ 'requested_new_money': null });
                this.loan_approval_form.get('facility_information').get('requested_new_money').disable();
              }
            });
            this.amountSubscription = this.loan_approval_form.get('facility_information').get('amount').valueChanges.pipe(debounceTime(500), takeUntil(this.compDestroyed$)).subscribe(amount_value => {
              if (Number(amount_value) > Number(this.application_loan_amount)) {
                const formGroup = this.loan_approval_form.controls['facility_information'] as FormGroup;
                formGroup.controls['amount'].markAsDirty();
                formGroup.controls['amount'].setErrors({ 'incorrect': true });
              }
              if (loan_decision_value === this.loan_decision_obj.counter_offer) {
                if (Number(amount_value) <= Number(this.application_loan_amount)) {
                  this.loan_approval_form.get('recap_of_total_exposure').patchValue({ 'transaction': amount_value })
                }
              } else if (loan_decision_value === this.loan_decision_obj.approve) {
                this.loan_approval_form.get('recap_of_total_exposure').patchValue({ 'transaction': this.application_loan_amount })
              } else {
                this.total_amount = this.application_loan_amount;
              }
            });
            const facility_information_formGroup = this.loan_approval_form.controls['facility_information'] as FormGroup;
            this.requestedNewMoney = facility_information_formGroup.controls['requested_new_money'].valueChanges.pipe(debounceTime(500)).subscribe(requested_new_money_value => {
              if (Number(requested_new_money_value) > Number(this.application_loan_amount)) {
                facility_information_formGroup.controls['requested_new_money'].markAsDirty();
                facility_information_formGroup.controls['requested_new_money'].setErrors({ 'incorrect': true });
              }
            });
            this.requestedNewMoneyRequired = facility_information_formGroup.controls['requested_new_money_required'].valueChanges.pipe(debounceTime(500)).subscribe(requested_new_money_value => {
              if (Number(requested_new_money_value) > Number(this.application_loan_amount)) {
                if (!facility_information_formGroup.get('request_type')?.value || facility_information_formGroup.get('request_type')?.value === this.request_type_obj.new) {
                  facility_information_formGroup.controls['requested_new_money_required'].markAsDirty();
                  facility_information_formGroup.controls['requested_new_money_required'].setErrors({ 'incorrect': true });
                }
              }
              if (Number(requested_new_money_value) <= 0) {
                facility_information_formGroup.patchValue({ requested_new_money_required: null })
              }
            });
          }
          if (this.caf_data && (this.caf_data?.loan_decision == loan_decision_value)) {
            this.formGenerateService.setFormValues(this.loan_approval_form, this.caf_data?.loan_offer_data);
            if (!this.editCAF) {
              this.loan_approval_form.disable();
            }
          }
          if (this.last_loan_decision_value && this.editCAF) {
            this.loan_approval_form.patchValue({ 'last_loan_decision_taken': this.last_loan_decision_value });
          }
        });
      }
    });
  }

  setInterestType(standard_product_id_value) {
    const formGroup = this.loan_approval_form.controls['interest_schedule'] as FormGroup;
    if (standard_product_id_value === '5e8723158f2f4e9ac476fae6' || standard_product_id_value === '5e8723158f2f4e9ac476fae7' || standard_product_id_value === '60bf70d8b59c55d033e8c787') {
      formGroup.patchValue({ interest_type: '5e8723158f2f5e7ac476fae6' });
    } else if (standard_product_id_value === '60bf711cb59c55d033e8c788' || standard_product_id_value === '60bf714eb59c55d033e8c789' || standard_product_id_value === '60bf71deb59c55d033e8c78a') {
      formGroup.patchValue({ interest_type: '5e8723158f2f5e7ac476fae7' });
    }
  }
  populateLoanDecisionForm(obj) {
    if (this.loan_decision_slug === CONSTANTS.SLUG['approval_decision_form']) {
      const form_data = {
        cra_information: {
          cra_address: {
            cra_street_no: obj.business[0].street_no,
            cra_street_name: obj.business[0].street_name,
            cra_zip_code: obj.business[0].zip_code,
            cra_state: obj.business[0].state,
            cra_city: obj.business[0].city
          }
        },
        facility_information: {
          requested_new_money: this.total_amount,
          requested_new_money_required: this.total_amount
        },
        recap_of_total_exposure: {
          transaction: this.total_amount,
          total: this.total_amount
        }
      }
      this.totalExposureSubscription = merge(this.loan_approval_form.get('recap_of_total_exposure').get('transaction').valueChanges,
        this.loan_approval_form.get('recap_of_total_exposure').get('direct_debt').valueChanges,
        this.loan_approval_form.get('recap_of_total_exposure').get('related_debt').valueChanges).pipe(debounceTime(500), takeUntil(this.compDestroyed$)).subscribe(res => {
          const total_exposure = (this.loan_approval_form.get('recap_of_total_exposure') as FormArray).getRawValue();
          const sum = Object.keys(total_exposure).reduce((acc, value) => {
            if (value !== 'total' && value !== 'degree_of_commitment' && value !== 'drawdown_status' && value !== 'previous_expiration_date' && value !== 'proposed_expiration_date')
              return acc + (total_exposure[value] ? Number(total_exposure[value]) : 0);
            else
              return acc + 0;
          }, 0);
          form_data.recap_of_total_exposure['total'] = sum;
          this.loan_approval_form.get('recap_of_total_exposure').patchValue({ total: sum });
        });
      this.formGenerateService.setFormValues(this.loan_approval_form, form_data);
    }
  }

  populateAppData(obj: any, caf: boolean): void {
    this.application_loan_amount = obj.business[0].purpose_arr.reduce(function (accumulator, currentValue) {
      return accumulator + Number(currentValue.amount_field)
    }, 0);
    this.total_amount = this.application_loan_amount;
    if (!caf) {
      const form_data = {
        'banker_info': this.getBankerInfo(obj),
        'obligator_info': this.getObligatorInfo(obj.business),
        'guarantor_info': this.getOwnerInfo(obj.owners)
      };
      this.formGenerateService.setFormValues(this.caf_form, form_data);
    }
  }

  getOwnerInfo(owners) {
    const guarantor_info = []
    const primaryowner = owners?.find(item => item.is_primary == true);
    guarantor_info.push(this.setGuarantor(primaryowner))
    owners.forEach(element => {
      if (element.is_secondary == true) {
        guarantor_info.push(this.setGuarantor(element))
      }
    });
    return guarantor_info;
  }

  getUnderwriter(): string {
    const jr_uw = this.appData?.app_assignment.map(elem => elem.role_slug).lastIndexOf('underwriter_l2');
    const sr_uw = this.appData?.app_assignment.map(elem => elem.role_slug).lastIndexOf('underwriter_l1');
    const index = jr_uw > sr_uw ? jr_uw : sr_uw;
    if (index >= 0) {
      return this.appData?.app_assignment[index]?.name;
    }
  }

  getLoanOfficer(): string {
    const loan_officers = this.appData?.app_assignment.filter(elem => elem.stage === 'loan_officer')
    const jr_rm = loan_officers.map(elem => elem.role_slug).lastIndexOf('loan_officer_l2');
    const sr_rm = loan_officers.map(elem => elem.role_slug).lastIndexOf('loan_officer_l1');
    const index = jr_rm > sr_rm ? jr_rm : sr_rm;
    if (index >= 0) {
      this.rm_obj = loan_officers[index];
      return loan_officers[index]?.name;
    }
  }
  getBankerInfo(obj) {
    return {
      bank_name: CONSTANTS.CLIENT_CONFIG['name'],
      application_date: obj.created_at,
      line_of_business: obj.business[0].sub_industry,
      relationship_manager: this.latest_loan_officer,
      credit_analyst: this.latest_credit_analyst,
      business_industry: obj.business[0].industry,
      cost_center: obj?.business[0]?.additional_information?.cost_center
    }
  }

  getObligatorInfo(business) {
    return {
      borrower: business[0].business_name,
      entity_type: business[0].business_structure,
      address: {
        street_no: business[0].street_no,
        street_name: business[0].street_name,
        zip_code: business[0].zip_code,
        state: business[0].state,
        city: business[0].city,
      },
      annual_sales: business[0].annual_revenue,
      tax_id: business[0].app_biz_tax_id,
      specific_services_or_product: business[0].industry,
      naics_code: business[0].naics,
      regulation_o: 'No'

    }
  }

  setGuarantor(owner) {
    if (owner) {
      return {
        //selected: null,
        guarantor_name: owner.owner_type == "corporate" ? owner.businessname : `${owner.first_name}${owner.middle_name ? (' ' + owner.middle_name + ' ') : ' '}${owner.last_name}`,
        tax_id: owner.owner_type == "corporate" ? owner.tax_id : null,
        ssn: owner.owner_type == "individual" ? owner.ssn : null,
        fico_score: '',
        control_interest_type: null,
        date: owner.owner_type == "corporate" ? owner.date_of_incorporation : owner.dob,
        type_of_guarantee: owner.owner_type,
        ownership_percentage: owner.ownership,
        owner_id: owner._id
      }
    }
  }

  datahubForm(accordian_open) {
    if (accordian_open && !this.datahub_info_form) {
      this.datahubFormSubscription = this.taskInfoService.getTaskInfo({ slug: this.datahub_info_slug }).subscribe(res => {
        this.datahub_info_config = res.form_fields;
        this.datahub_info_form = this.formGenerateService.createControl(res.form_fields);
        const possessory_type = res?.response_data?.possessory_type?.data?.data;
        if (possessory_type?.length) {
          const collateral_possessory_type = possessory_type.filter(elem => elem.id === this.possessory_type.deposits_or_cds);
          const life_insurance_type = possessory_type.filter(elem => elem.id === this.possessory_type.life_insurance);
          res.response_data = {
            ...res.response_data,
            collateral_possessory_type: { data: { data: collateral_possessory_type } },
            collateral_possessory_subtype: { data: { data: collateral_possessory_type[0]?.subtype } },
            life_insurance_type: { data: { data: life_insurance_type } },
            life_insurance_subtype: { data: { data: life_insurance_type[0]?.subtype } }
          }
        }
        this.common.sendMasterDataToFields(this.datahub_info_config, res.response_data);
        if (!this.editCAF) {
          this.datahub_info_form.disable();
        }
        if (this.caf_data?.datahub_info) {
          this.formGenerateService.setFormValues(this.datahub_info_form, this.caf_data.datahub_info)
        }
        this.FloodCommunityNumberSubscription = this.datahub_info_form.get('real_state_and_flood_insurance_details').get('flood_community_number').valueChanges.pipe(debounceTime(500)).subscribe(flood_community_number => {
          if (flood_community_number && !(/^(\d{5}|\d{9})$/.test(flood_community_number))) {
            const formGroup = this.datahub_info_form.controls['real_state_and_flood_insurance_details'] as FormGroup;
            formGroup.controls['flood_community_number'].markAsDirty();
            formGroup.controls['flood_community_number'].setErrors({ 'incorrect': true });
          }
        });
      })
    }
  }

  silverlakeForm(accordian_open) {
    if (accordian_open && !this.silverlake_info_form) {
      this.silverlakeFormSubscription = this.taskInfoService.getTaskInfo({ slug: this.silverlake_info_slug }).subscribe(res => {
        this.silverlake_info_config = res.form_fields;
        this.silverlake_info_form = this.formGenerateService.createControl(res.form_fields);
        this.common.sendMasterDataToFields(this.silverlake_info_config, res.response_data);
        if (!this.editCAF) {
          this.silverlake_info_form.disable();
        }
        if (this.caf_data?.silverlake_info) {
          this.formGenerateService.setFormValues(this.silverlake_info_form, this.caf_data.silverlake_info)
        }
      })
    }
  }

  onSubmit(action): void {
    // if (action == 'continue' && this.caf_form.get('guarantor_info').value.filter(res => res.selected)?.length <= 0) {
    //   const guarantorFormArray = this.caf_form.controls.guarantor_info as FormGroup;
    //   const formGroup = guarantorFormArray.controls[0] as FormGroup
    //   formGroup.controls['selected'].markAsDirty();
    //   formGroup.controls['selected'].setErrors({ 'incorrect': true });
    //   this.common.popToast('error', 'Error', 'Please select at least one guarantor.');
    //   return;
    // }
    if (action == 'continue' && this.datahub_info_form) {
      this.validateDatahubFields();
    }
    if (this.formGenerateService.validateCustomFormFields(this.caf_form, action, this.caf_config)) {
      if ((this.loan_approval_form && this.formGenerateService.validateCustomFormFields(this.loan_approval_form, action, this.loan_approval_form_config)) || action == 'save') {
        if (this.caf_form.get('loan_decision')?.value == this.loan_decision_obj.approve || this.caf_form.get('loan_decision')?.value == this.loan_decision_obj.counter_offer) {
          const formGroup = this.loan_approval_form.controls['facility_information'] as FormGroup;
          this.total_amount = this.loan_approval_form.get('recap_of_total_exposure').get('transaction')?.value;
          if (!formGroup.get('request_type')?.value || formGroup.get('request_type')?.value === this.request_type_obj.new) {
            formGroup.patchValue({ requested_new_money: formGroup.get('requested_new_money_required')?.value });
          } else {
            formGroup.patchValue({ requested_new_money_required: formGroup.get('requested_new_money')?.value });
          }
          const formGroup_interest_schedule = this.loan_approval_form.controls['interest_schedule'] as FormGroup;
          if (parseFloat(formGroup_interest_schedule?.get('floor_rate')?.value) > 100 || parseFloat(formGroup_interest_schedule?.get('share_of_total_pct')?.value) > 100) {
            if (parseFloat(formGroup_interest_schedule?.get('floor_rate')?.value) > 100) {
              formGroup_interest_schedule.controls['floor_rate'].markAsDirty();
              formGroup_interest_schedule.controls['floor_rate'].setErrors({ 'incorrect': true });
            }
            if (parseFloat(formGroup_interest_schedule?.get('share_of_total_pct')?.value) > 100) {
              formGroup_interest_schedule.controls['share_of_total_pct'].markAsDirty();
              formGroup_interest_schedule.controls['share_of_total_pct'].setErrors({ 'incorrect': true });
            }
            this.formGenerateService.validateCustomFormFields(this.loan_approval_form, action, this.loan_approval_form_config)
            return;
          }
        }
        if (!this.datahub_info_form || (this.datahub_info_form && this.formGenerateService.validateCustomFormFields(this.datahub_info_form, action, this.datahub_info_config))) {
          if (!this.silverlake_info_form || (this.silverlake_info_form && this.formGenerateService.validateCustomFormFields(this.silverlake_info_form, action, this.silverlake_info_config))) {
            const payload = {
              amount: this.total_amount,
              product: this.productId,
              loan_decision: this.caf_form.get('loan_decision')?.value ? this.caf_form.get('loan_decision').value : this.loan_decision_obj.pending,
              status_id: action == 'save' ? (this.last_loan_decision_value === this.caf_form.get('loan_decision').value ? this.caf_form.get('loan_decision').value : this.loan_decision_obj.pending) : this.caf_form.get('loan_decision').value,
              loan_offer_data: { ...this.caf_form.getRawValue(), ...this.loan_approval_form?.getRawValue() },
              datahub_info: this.datahub_info_form ? this.datahub_info_form.getRawValue() : this.caf_data?.datahub_info,
              silverlake_info: this.silverlake_info_form ? this.silverlake_info_form.getRawValue() : this.caf_data?.silverlake_info,
              check_key: false,
              credit_analyst: this.caf_form.get('banker_info').get('credit_analyst').value,
              action_type: 'save'
            }
            const queryparams = {
              slug: this.slug,
              user_id: this.userID,
              backend_user_id: this.backendUserID,
              app_id: this.appID,
              action: action,
              response_to_be_saved: JSON.stringify({
                product: this.productId,
                amount: payload.amount,
                loan_decision: payload.loan_decision,
                status_id: payload.status_id
              })
            }
            if (this.caf_business_ref_type === 'caf_saved') {
              if (this.loan_offer_id) {
                queryparams['loan_offer_id'] = this.loan_offer_id;
              }
              if (this.caf_business_ref_main_id) {
                queryparams['caf_business_ref_main_id'] = this.caf_business_ref_main_id;
              }
            }
            if (action === 'continue' && this.last_loan_decision_value !== this.caf_form.get('loan_decision').value) {
              if (this.caf_form.get('loan_decision').value === this.loan_decision_obj?.approve) {
                queryparams['send_mail_for'] = 'application_approved';
                queryparams['loan_status'] = 'Approved';
              } else {
                queryparams['send_mail_for'] = 'counter_offer';
                queryparams['loan_status'] = 'Counter Offer'
              }
              const uniqueBanker = this.getBankerName(this.appData?.app_assignment);
              payload['email_address_banker'] = uniqueBanker.map(tup => tup.email_address).filter((elem, index, self) => {
                return index === self.indexOf(elem);
              });
              payload['first_name_banker'] = uniqueBanker.map(tup => tup.name).filter((elem, index, self) => {
                return index === self.indexOf(elem);
              });
              const formatter = new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD',
                minimumFractionDigits: 2
              })
              queryparams['loan_amount'] = formatter.format(this.total_amount);
              queryparams['product_name'] = this.appData?.productName;
              queryparams['terms'] = CONSTANTS.CLIENT_CONFIG.terms_url;
              queryparams['privacy'] = CONSTANTS.CLIENT_CONFIG.privacy_url;
              queryparams['customer_url'] = this.environment.customerJourneyUrl;
              queryparams['copyright_text'] = CONSTANTS.MAIL_TEMPLATE.copyright_text;
              queryparams['senders_name'] = CONSTANTS.MAIL_TEMPLATE.senders_name;
              queryparams['header_logo_path_1'] = this.environment.logo1_path;
              queryparams['header_logo_path_2'] = this.environment.logo2_path;
              queryparams['loan_id'] = this.appData?.loan_id;
              queryparams['banker_number'] = this.maskPhoneNumber(this.rm_obj?.phone_no) || '(XXX) XXX-XXXX';
              const primary_owner = this.app_data?.owners?.find(ele => ele.is_primary === true);
              queryparams['name'] = primary_owner?.first_name;
              queryparams['email_address'] = primary_owner?.email_address;
            }
            this.submitDataSubscription = this.taskInfoService.saveTaskInfo(queryparams, payload).subscribe(res => {
              const message = action === 'save' ? 'CAF information saved successfully.' : 'CAF information submitted successfully.';
              const activity = action === 'save' ? 'caf_saved' : 'offer_management';
              this.addActivityLog(activity, payload?.status_id, action);
              if (action === 'continue') {
                this.checkECOAStatus();
              }
              this.common.popToast('success', '', message);
              this.common.navigate('underWriting');
            });
          } else {
            this.common.popToast('error', 'Error', 'Please provide valid values of the required field(s) in the Silverlake information section.');
          }
        } else {
          this.common.popToast('error', 'Error', 'Please provide valid values of the required field(s) in the DataHub information section.');
        }
      } else {
        this.common.popToast('error', 'Error', 'Please provide valid values of the required field(s) in CAF section.');
      }
    } else {
      this.common.popToast('error', 'Error', 'Please provide valid values of the required field(s) in CAF section.');
    }
  }

  maskPhoneNumber(num) {
    if (num && Number(num) !== NaN && Number(num) !== 0 && !isNaN(Number(num))) {
      num = num.toString();
      const phoneNumber = num.match(/(\d{3})(\d{3})(\d{4})/);
      return num.length === 10 ? `(${phoneNumber[1]}) ${phoneNumber[2]}-${phoneNumber[3]}` : '';
    }
    return '';
  }

  getBankerName(app_assignment) {
    const uniqueNames = [];
    app_assignment.forEach((b) => {
      if (b.stage) {
        const index = uniqueNames.findIndex((un) => un.stage === b.stage);
        if (index !== -1) {
          uniqueNames[index] = b;
        } else {
          uniqueNames.push(b);
        }
      } else {
        uniqueNames.push(b);
      }
    })

    return uniqueNames;
  }

  checkECOAStatus() {
    const ecoa_stopped_obj = this.app_data?.business_references.find(ele => {
      if (ele?.type === 'ecoa-status') {
        if (typeof ele?.response === 'string') {
          ele.response = JSON.parse(ele.response);
        }
        if (ele?.response?.status === "STOP") {
          return true;
        }
      }
    });
    if (!ecoa_stopped_obj) {
      const queryparams = {
        slug: 'ecoa_status',
        app_id: this.appID
      }
      const payload = {
        status: 'STOP',
        user_id: this.userID,
        app_id: this.appID
      }
      this.taskInfoService.saveTaskInfo(queryparams, payload).subscribe(res => {
        this.addActivityLog('ecoa_stop');
      });
    }
  }
  addActivityLog(activity, status_id?, action?) {
    let log_data;
    if (activity === 'ecoa_stop') {
      log_data = {
        role_slug: this.userData?.role_slug,
        app_id: this.appID,
        backend_user_id: this.backendUserID,
        user_name: 'system',
        activity: activity,
      };
    } else {
      log_data = {
        role_slug: this.userData?.role_slug,
        app_id: this.appID,
        backend_user_id: this.backendUserID,
        user_name: this.userData?.full_name,
        activity: activity,
      };
    }
    if (action === 'continue' && status_id) {
      log_data['note'] = this.loan_decision_array.find(ele => ele?.id === status_id)?.name;
    }
    this.common.addActivityLog(log_data);
  }

  validateDatahubFields() {
    const sba_and_ucc_check = Object.values(this.datahub_info_form.get('sba_and_ucc_details').value).every(x => (x === null || x === ''));
    const equipment_details_check = Object.values(this.datahub_info_form.get('equipment_details').value).every(x => (x === null || x === ''));
    const life_insurance_check = Object.values(this.datahub_info_form.get('life_insurance_details').value).every(x => (x === null || x === ''));
    const real_state_and_flood_insurance_check = Object.values(this.datahub_info_form.get('real_state_and_flood_insurance_details').value).every(x => (x === null || x === ''));
    const collateral_info_check = Object.values(this.datahub_info_form.get('collateral_information').value).every(x => (x === null || x === ''));
    if (!sba_and_ucc_check) {
      const formGroup = this.datahub_info_form.controls.sba_and_ucc_details as FormGroup;
      if (!formGroup.get('law_state')?.value) {
        formGroup.controls['law_state'].markAsDirty();
        formGroup.controls['law_state'].setErrors({ 'incorrect': true });
      }
    }
    if (!equipment_details_check) {
      const formGroup = this.datahub_info_form.controls.equipment_details as FormGroup;
      if (!formGroup.get('equipment_subtype')?.value) {
        formGroup.controls['equipment_subtype'].markAsDirty();
        formGroup.controls['equipment_subtype'].setErrors({ 'incorrect': true });
      }
      if (!formGroup.get('law_state')?.value) {
        formGroup.controls['law_state'].markAsDirty();
        formGroup.controls['law_state'].setErrors({ 'incorrect': true });
      }
    }
    if (!life_insurance_check) {
      const formGroup = this.datahub_info_form.controls.life_insurance_details as FormGroup;
      if (!formGroup.get('life_insurance_type')?.value) {
        formGroup.controls['life_insurance_type'].markAsDirty();
        formGroup.controls['life_insurance_type'].setErrors({ 'incorrect': true });
      }
      if (!formGroup.get('life_insurance_subtype')?.value) {
        formGroup.controls['life_insurance_subtype'].markAsDirty();
        formGroup.controls['life_insurance_subtype'].setErrors({ 'incorrect': true });
      }
      if (!formGroup.get('law_state')?.value) {
        formGroup.controls['law_state'].markAsDirty();
        formGroup.controls['law_state'].setErrors({ 'incorrect': true });
      }
    }
    if (!real_state_and_flood_insurance_check) {
      const formGroup = this.datahub_info_form.controls.real_state_and_flood_insurance_details as FormGroup;
      if (!formGroup.get('law_state')?.value) {
        formGroup.controls['law_state'].markAsDirty();
        formGroup.controls['law_state'].setErrors({ 'incorrect': true });
      }
      if (!formGroup.get('agent')?.value) {
        formGroup.controls['agent'].markAsDirty();
        formGroup.controls['agent'].setErrors({ 'incorrect': true });
      }
      if (!formGroup.get('agency')?.value) {
        formGroup.controls['agency'].markAsDirty();
        formGroup.controls['agency'].setErrors({ 'incorrect': true });
      }
    }
    if (!collateral_info_check) {
      const formGroup = this.datahub_info_form.controls.collateral_information as FormGroup;
      if (!formGroup.get('law_state')?.value) {
        formGroup.controls['law_state'].markAsDirty();
        formGroup.controls['law_state'].setErrors({ 'incorrect': true });
      }
      if (!formGroup.get('collateral_possessory_type')?.value) {
        formGroup.controls['collateral_possessory_type'].markAsDirty();
        formGroup.controls['collateral_possessory_type'].setErrors({ 'incorrect': true });
      }
      if (!formGroup.get('collateral_possessory_subtype')?.value) {
        formGroup.controls['collateral_possessory_subtype'].markAsDirty();
        formGroup.controls['collateral_possessory_subtype'].setErrors({ 'incorrect': true });
      }
    }
  }
  backToUnderwriting() {
    this.common.navigate('underWriting');
  }

  ngOnDestroy() {
    const appData = JSON.parse(JSON.stringify(this.appData));
    if (appData?.caf) {
      delete appData.caf;
      this.store.dispatch(addAppDetails({ appData: { ...appData } }));
    }
    this.storeSubscription?.unsubscribe();
    this.getDataSubscription?.unsubscribe();
    this.submitDataSubscription?.unsubscribe();
    this.loanDecisionChangeSubscription?.unsubscribe();
    this.loanDecisionFormSubscription?.unsubscribe();
    this.interestTypeSubscription?.unsubscribe();
    this.requestTypeSubscription?.unsubscribe();
    this.amountSubscription?.unsubscribe();
    this.requestedNewMoney?.unsubscribe();
    this.requestedNewMoneyRequired?.unsubscribe();
    this.totalExposureSubscription?.unsubscribe();
    this.datahubFormSubscription?.unsubscribe();
    this.silverlakeFormSubscription?.unsubscribe();
    this.interestRateSubscription?.unsubscribe();
    this.standardProductIdSubscription?.unsubscribe();
    this.FloodCommunityNumberSubscription?.unsubscribe();
    this.floorRateSubscription?.unsubscribe();
    this.SBAGntyPctSubscription?.unsubscribe();
  }
}
