import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { RouterModule, Route } from '@angular/router';
import { CAFComponent } from './caf/caf.component';
import { GenerateCAFComponent } from './generate-caf/generate-caf.component';
import { DecisionHistoryComponent } from './decision_history/decision_history.component';
import { CafPdfComponent } from './caf-pdf/caf-pdf.component';

export const cafRoutes: Route[] = [
  {path:'credit-approval-form', component: GenerateCAFComponent},
  {path:'caf-decision-history', component: DecisionHistoryComponent}
];
@NgModule({
  imports: [CommonModule,
    SharedLazyModule,
    RouterModule.forChild(cafRoutes)],
  declarations: [
    CAFComponent,
    GenerateCAFComponent,
    DecisionHistoryComponent,
    CafPdfComponent
  ],
  exports: [
    CAFComponent
  ]
})
export class ComponentsCafModule {}
