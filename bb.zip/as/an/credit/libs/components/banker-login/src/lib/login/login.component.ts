import { Component, OnInit } from '@angular/core';
import { TaskInfoService, FormGenerateService, onLogout, CommonService, addUserDetails, addAppDetails } from '@rubicon/utils';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { Store } from '@ngrx/store';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginConfig: FormFieldInterface[] = [];
  loginForm: FormGroup;
  slug:string = '';
  email_address:string = '';
  nextTask: string = '';

  constructor( private taskInfoService : TaskInfoService,
     private formGenerateService: FormGenerateService,
     private commonService: CommonService,
     private store: Store<any> ) { }

  ngOnInit(): void {
    this.store.dispatch(onLogout({}));
     this.taskInfoService.getTaskInfo({slug:CONSTANTS.SLUG['banker_signin']}).subscribe(response => {
       this.slug = response?.task_slug;
       this.loginConfig = response?.form_fields;
       this.loginForm = this.formGenerateService.createControl(this.loginConfig);
      });
  }

  onNavigate(){
    this.store.dispatch(addAppDetails({
      appData: {
        isSignButton: true
      }
    }))
    this.commonService.navigate('reset-password')
  }

  onSubmit(action) {
    if(this.formGenerateService.validateCustomFormFields(this.loginForm, action, this.loginConfig)) {
      const data = {...this.loginForm.value};
      const token = btoa(data.email_address + ":" + data.password);
      const headers = { Authorization: "Basic " + token };
      this.taskInfoService.saveTaskInfo({slug: this.slug, skip_error: true}, data,headers).subscribe(res => { 
        if (res?.backend_session_login?.data ?.data ) {
            const data = res.backend_session_login.data.data;
            const userData = data.user;
            this.store.dispatch(addUserDetails({
              userData: {
                email_address: userData.email_address,
                user_id: userData.id,
                phone: userData.phone,
                id: data.id,
                full_name: userData.name,
                role: userData.role_id.name || userData.role_id.role,
                role_slug: userData.role_id.role_slug || userData.role_id.slug,
                role_id: userData.role_id.id,
                reporting_to : userData.reporting_to
              }
            }));
            this.nextTask = res.nextTask.value;
            this.commonService.navigate(this.nextTask);
          }
          else if(res?.generate_session?.errors?.errors?.length > 0 || res?.nextTask?.value === "error"){
            this.commonService.popToast('error','Error','You may have entered the wrong Email or Password.');
          }
        })
    }
  }
}
