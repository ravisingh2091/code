import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Route, RouterModule } from '@angular/router';
import { LoginComponent } from '../lib/login/login.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';


export const loginRoutes: Route[] = [
  {path:'', component: LoginComponent}
];

@NgModule({
  imports: [
    CommonModule,
    SharedLazyModule,
    RouterModule.forChild(loginRoutes),
  ],
  declarations: [LoginComponent]
})
export class BankerLoginModule {}
