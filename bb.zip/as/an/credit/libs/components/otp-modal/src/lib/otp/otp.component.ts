import { Component, OnInit, Output, EventEmitter, Inject, Injectable, Input } from '@angular/core';
import { CommonService, TaskInfoService, FormGenerateService, addUserDetails } from '@rubicon/utils';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.scss']
})

export class OtpComponent implements OnInit {
  @Output() closeModal = new EventEmitter<string>();
  @Output() triggerForcePassword = new EventEmitter<string>();
  @Input() email_address: string;
  @Input() nextTask: string = null;
  form: FormGroup;
  slug: string;
  formConfig: FormFieldInterface[] = [];
  userData: any = {};
  appID: string;
  user_name: string;
  banker_contact_number: string;
  app_created_by_banker:boolean;
  businessData: any = {};

  constructor(
    private commonService: CommonService,
    private formGenerateService: FormGenerateService,
    private taskinfoService: TaskInfoService,
    private store: Store<any>,
    @Inject('environment') private environment
  ) { }

  ngOnInit() {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.appID = rootState ?.appID;
      this.taskinfoService.getTaskInfo({
        slug: CONSTANTS.SLUG['otp-verification'],
        email_address: this.email_address,
        header_logo_path_1: this.environment.logo1_path,
        header_logo_path_2: this.environment.logo2_path,
        client_name: CONSTANTS.MAIL_TEMPLATE.project_name,
        senders_name: CONSTANTS.MAIL_TEMPLATE.senders_name,
        copyright_text: CONSTANTS.MAIL_TEMPLATE.copyright_text,
        app_id: this.appID,
        no_reply_mail: CONSTANTS.MAIL_TEMPLATE.no_reply_mail,
        privacy: this.environment.privacy,
        terms: this.environment.terms,
        match : 'email_address',
        use_filter : true
      }).subscribe(response => {
        if (response) {
          this.generateForm(response);
        }
      }, err => this.generateForm(err));
    });
  }

  generateForm(response): void {
    this.slug = response?.task_slug;
    this.formConfig = response?.form_fields;
    this.form = this.formGenerateService.createControl(this.formConfig);
    this.user_name = response?.response_data?.get_user?.data?.data?.result[0].first_name;
    this.app_created_by_banker = response?.response_data?.get_user?.data?.data?.result[0].system_password;
  }

  hideModal(): void {
    this.closeModal.emit();
  }

  onSubmit(action): void {
    if (this.formGenerateService.validateCustomFormFields(this.form, action, this.formConfig)) {
      const token = btoa(
        this.email_address + ':' + this.form.getRawValue().otp
      );
      const headers = { authorization: 'Basic ' + token };
      const payload = {
        ...this.form.getRawValue(),
        email_address: this.email_address,
        privacy: this.environment.privacy,
        terms: this.environment.terms,
        header_logo_path_1: this.environment.logo1_path,
        header_logo_path_2: this.environment.logo2_path,
        client_name: CONSTANTS.MAIL_TEMPLATE.project_name,
        senders_name: CONSTANTS.MAIL_TEMPLATE.senders_name,
        copyright_text: CONSTANTS.MAIL_TEMPLATE.copyright_text,
        to_name: this.user_name,
        app_id: this.appID
      };
      const queryParams = { slug: CONSTANTS.SLUG['otp-verification']}
      if(this.app_created_by_banker) {
        queryParams['app_created_by_banker'] = this.app_created_by_banker;
      }
      this.taskinfoService
        .saveTaskInfo(
          queryParams,
          payload,
          headers
        )
        .subscribe((res) => {
          if (res ?.generate_session ?.data ?.data) {
            const data = res.generate_session.data.data;
            const userData = data.user;
            if(!userData.system_password){
              this.store.dispatch(
                addUserDetails({
                  userData: {
                    email_address: userData ?.email_address,
                    user_id: userData ?.id,
                    phone: userData ?.phone,
                    id: data ?.id,
                    first_name: userData ?.first_name,
                    last_name: userData ?.last_name,
                    record_id: userData?.record_id
                  },
                })
              );
            }
            if(userData.system_password){
              this.hideModal();
              this.triggerForcePassword.emit({...userData,session_id: data?.id});
            }
            else if (this.nextTask)
              this.commonService.navigate(this.nextTask);
            else {
              this.store.select('app').pipe(take(1)).subscribe(data => {
                let businessId = data ?.businessID;
                this.commonService.navigate(res ?.nextTask ?.value, businessId);
              });
            }
            this.hideModal();
          }
        });
    }
  }

  resendOtp(): void {
    const payload = {
      email_address: this.email_address,
      first_name: this.userData.first_name,
      header_logo_path_1: this.environment.logo1_path,
      header_logo_path_2: this.environment.logo2_path,
      client_name: CONSTANTS.MAIL_TEMPLATE.project_name,
      senders_name: CONSTANTS.MAIL_TEMPLATE.senders_name,
      copyright_text: CONSTANTS.MAIL_TEMPLATE.copyright_text,
      no_reply_mail: CONSTANTS.MAIL_TEMPLATE.no_reply_mail,
      privacy: this.environment.privacy,
      terms: this.environment.terms
    };
    this.taskinfoService
      .saveTaskInfo(
      { 
        slug: CONSTANTS.SLUG['resend-otp'], 
        match : 'email_address',
        use_filter : true 
      }, 
      payload)
      .subscribe((res) => {
        if (res) {
          this.commonService.popToast(
            'success',
            'Success',
            'OTP sent successfully on email ' + this.email_address
          );
        }
      });
  }
}
