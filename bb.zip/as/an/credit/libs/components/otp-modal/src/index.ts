export * from './lib/otp-modal.module';
