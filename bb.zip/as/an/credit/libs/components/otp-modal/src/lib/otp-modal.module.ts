import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OtpComponent } from './otp/otp.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { Route, RouterModule } from '@angular/router';

export const otpRoutes: Route[] = [
  {path:'otp-modal', component: OtpComponent}
];

@NgModule({
  imports: [CommonModule,
    SharedLazyModule,
    RouterModule.forChild(otpRoutes),
  ],
  declarations: [
    OtpComponent
  ],
  exports: [
    OtpComponent
  ]
})
export class OtpModalModule {}
