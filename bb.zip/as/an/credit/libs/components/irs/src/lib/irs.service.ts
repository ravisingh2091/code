import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IrsService {
  
  private irsData$: BehaviorSubject<any> = new BehaviorSubject(null);


  constructor() { }

  getData(): Observable<any> {
    return this.irsData$.asObservable();
}

setData(profile: any) {
    this.irsData$.next(profile);
}

  // sendForESign(data, custData, isUser, jobDataBody) {
  //   console.log("esign data",data);
  //   let slug = "e-sign";
  //   let docType = "irs_4506t_form_online"; // TODO replace with irs_4506t_form_online before pushing as name modied
  //   return this.http
  //     .post(environment.orchestrationUrl + apiUrls.saveTaskInfo, data, {
  //       params: { slug: slug }
  //     })
  //     .pipe(
  //       mergeMap(res => {
  //         return this.saveReferenceAndUploadData(res, slug, custData, docType);
  //       }),
  //       switchMap(resp => {
  //         let appDetails = this.security.getSession("appDetails", true);
  //         let param: any = {
  //           jobid: "5d1b16a5453ddf44b8238f2c",
  //           appid: appDetails.id
  //         };
  //         if (
  //           (isUser &&
  //             isUser.owner_type &&
  //             isUser.owner_type == "Individual") ||
  //           isUser.owner_type == "entity"
  //         ) {
  //           param["jobid"] =
  //             isUser.owner_type == "Individual"
  //               ? "5d1b86a5453ddf44b7238f2d"
  //               : "5d1b16a5453ddf44b7238f2d";
  //           param["owner_id"] = isUser._id;
  //           param["user_id"] = appDetails.user_id;
  //         }
  //         param = { ...param, ...jobDataBody };
  //         let slug = {
  //           slug: 'schedule-cron'
  //         }
  //         return this.http.post(`${environment.orchestrationUrl}${apiUrls.saveInfoNew}`, param, { params: slug })
  //           .pipe(
  //             map((res: any) => {
  //               const resdata = res[0] ? res[0] : res;
  //               if (
  //                 resdata.code === 200 ||
  //                 resdata.code === 201 ||
  //                 resdata.status === "success"
  //               ) {
  //                 //fork join response
  //                 this.workflowService.updateActivityLog(
  //                   this.security.getSession("app_id"),
  //                   "IRS submission initiated of " + data.name
  //                 );
  //                 this.msgService.showMessage([
  //                   { message: "IRS form sent for e-sign." }
  //                 ]);
  //               }
  //               return resdata;
  //             })
  //           );
  //       })
  //     );
  // }
}
