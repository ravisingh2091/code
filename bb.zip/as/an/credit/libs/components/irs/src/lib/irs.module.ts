import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IrsManualFormComponent } from './irs-manual-form/irs-manual-form.component';
import { IrsOnlineFormComponent } from './irs-online-form/irs-online-form.component';
import { IrsComponent } from './irs/irs.component';
import { RouterModule, Route } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';


@NgModule({
  imports: [CommonModule,SharedLazyModule],
  declarations: [IrsManualFormComponent, IrsOnlineFormComponent, IrsComponent],
  exports:[IrsManualFormComponent,IrsOnlineFormComponent,IrsComponent]
})
export class IrsModule {}
