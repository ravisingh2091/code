import { Component, Inject, OnInit } from '@angular/core';
import { CommonService, TaskInfoService , addAppID,
  addBusinessID,FormGenerateService, 
  addAppDetails} from '@rubicon/utils';
  import { CONSTANTS } from '@banker-journey-assets/constant/constant';
  import { FormGroup } from '@angular/forms';
  import {IrsService} from '../irs.service'
  import { select, Store } from '@ngrx/store';
  import { take, retryWhen } from 'rxjs/operators';

@Component({
  selector: 'irs-online-form',
  templateUrl: './irs-online-form.component.html',
  styleUrls: ['./irs-online-form.component.css']
})
export class IrsOnlineFormComponent implements OnInit {

  actionConfig
  slug
  actionForm:FormGroup
  transcriptRequested=''
  tax_year='2018-2020'
  data:any
  state = [];
  application_data = null;
  company_role=[];
  irs_form=[];
  backend_user_data: any;


  constructor(private commonService: CommonService,
    @Inject('environment') private environment,
    private taskInfoService: TaskInfoService,private store: Store<any>,
    private formGenerate: FormGenerateService,private IrsService:IrsService) { }

    setTranscriptRequested(data) {
      if ("owner_type" in data && data.owner_type=="Individual") {
        this.transcriptRequested = "1040";
      } else {
        if ("business_id" in data && data.business_return_type) {
          this.transcriptRequested = data.business_return_type;
        } else {
          // It means Additional Owner Business
          this.transcriptRequested = "";
        }
      }
    }
  

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.data=rootState.userData.Irs_data_to;
      this.backend_user_data = rootState.userData;
      if(("business_id" in this.data) ||this.data?.owner_type=="corporate") {
        this.taskInfoService.getTaskInfo({slug: CONSTANTS.SLUG['irs_online_Business'], app_id:this.data?.app_id }).subscribe(response => {
         // console.log("get response",response);
          this.actionConfig = response.form_fields;
          this.slug = response.task_slug;
          this.actionForm  = this.formGenerate.createControl(this.actionConfig);
          this.formGenerate.setFormValues(this.actionForm, {transcript_requested:{transcript_request: "1040"}});
          this.application_data = response?.response_data?.app_detail?.data?.data[0];
          this.company_role=response?.response_data?.company_role?.data?.data;
          this.irs_form=response?.response_data?.irs_form?.data?.data;
          this.commonService.sendMasterDataToFields(this.actionConfig, response.response_data);
          this.setTranscriptRequested(this.data);
          if("business_id" in this.data){
            this.formGenerate.setFormValues(this.actionForm, {business_info:{business_name: this.data.business_name,business_title:this.application_data?.owners?.find((x)=>x?.is_primary==true)?.owner_title,tax_id:this.data.app_biz_tax_id,email:this.application_data?.owners?.find((x)=>x?.is_primary==true)?.email_address,phone:this.data.biz_phone_no}});
            this.formGenerate.setFormValues(this.actionForm, {current_address:{address: `${(this.data.street_no && typeof this.data.street_no !== "undefined" && typeof this.data.street_no === "string") ? this.data.street_no : ""}${(this.data.street_name && typeof this.data.street_name !== "undefined" && typeof this.data.street_name === "string") ? ', '+this.data.street_name : ""}` ,state:this.data.state,city:this.data.city,zip_code:this.data.zip_code}});
          }
          else{
            this.formGenerate.setFormValues(this.actionForm, {business_info:{business_name: this.data.businessname,business_title:'',tax_id:this?.data?.tax_id,email:this.data?.email_address,phone:this.data.phone}});
            this.formGenerate.setFormValues(this.actionForm, {current_address:{address: `${(this.data.streetNo && typeof this.data.streetNo !== "undefined" && typeof this.data.streetNo === "string") ? this.data.streetNo : ""}${(this.data.streetName && typeof this.data.streetName !== "undefined" && typeof this.data.streetName === "string") ? ', '+this.data.streetName : ""}` ,state:this.data.state,city:this.data.city,zip_code:this.data.zip_code}});
          }
          this.formGenerate.setFormValues(this.actionForm, {mortage_information:{company: "Equifax Verification Services" ,mortage_address:"11432 Lackland Rd",mortage_phone:8887494411,mortage_zip_code:63146,mortage_city:"st. louis",mortage_state:"Missouri"}});
          this.formGenerate.setFormValues(this.actionForm, {transcript_requested:{irs_form: this.transcriptRequested}});
          this.commonService.sendMasterDataToFields(this.actionConfig, response.response_data);
          // console.log("application_data",this.application_data);
        })
      } else {
        this.taskInfoService.getTaskInfo({slug: CONSTANTS.SLUG['irs_online_owner'], app_id:this.data?.app_id }).subscribe(response => {
          this.actionConfig = response.form_fields;
          this.slug = response.task_slug;
          this.actionForm  = this.formGenerate.createControl(this.actionConfig);
          this.setTranscriptRequested(this.data);
          this.application_data = response?.response_data?.app_detail?.data?.data[0];
          this.irs_form=response?.response_data?.irs_form?.data?.data;
          this.formGenerate.setFormValues(this.actionForm, {personal_info:{first_name: this.data.first_name,Last_name:this?.data.last_name,ssn_no:this?.data.ssn,email:this.data.email_address,phone:this.data.phone}});
          this.formGenerate.setFormValues(this.actionForm, {current_address:{address: `${(this.data.streetNo && typeof this.data.streetNo !== "undefined" && typeof this.data.streetNo === "string") ? this.data.streetNo : ""}${(this.data.streetName && typeof this.data.streetName !== "undefined" && typeof this.data.streetName === "string") ? ', '+this.data.streetName : ""}` ,state:this.data.state,city:this.data.city,zip_code:this.data.zip_code}});
          this.formGenerate.setFormValues(this.actionForm, {mortage_information:{company: "Equifax Verification Services" ,mortage_address:"11432 Lackland Rd",mortage_phone:8887494411,mortage_zip_code:63146,mortage_city:"st. louis",mortage_state:"Missouri"}});
          this.formGenerate.setFormValues(this.actionForm, {transcript_requested:{irs_form: this.transcriptRequested}});
          this.state = response?.response_data?.state?.data?.data;
          this.commonService.sendMasterDataToFields(this.actionConfig, response.response_data);
        })
      }
      // console.log("data",this.data);
      
    })

    // console.log(this.application_data );
  }

  onBack() {
    this.commonService.navigate('underWriting');
  }

  getAddress(data): string {
    console.log(data)
    return data?.address +  ', ' + data?.city + ', ' + data?.state + ', ' + data?.zip_code;
  }
  getPreviousAddress(data): string {
    if(data)
    return (data?.prev_address?data?.prev_address:'') + ' ' + (data?.city?data?.city:'') + ' ' +( data?.state?data?.state:'') + ' ' + (data?.prev_zip_code?data?.prev_zip_code:'');
    else
    return '';
  }

  onSubmit(action) {
    const form_data = this.actionForm.getRawValue()
    

    // console.log("form data",form_data);
        

    if(this.formGenerate.validateCustomFormFields(this.actionForm, action, this.actionConfig)) {
      if(("business_id" in this.data) ) {
        let irsdata_business=  {
          app_id: this.data?.app_id,
          user_id: this.data?.user_id,
          auto_id: this.application_data.auto_id,
          account_transcript: form_data?.checklist?.account_transcript,
          application_id_number: this.application_data?.auto_id,
          business_title: form_data?.business_info?.business_title,
          current_address: this.getAddress(form_data?.current_address),
          doc_name:this.application_data?.auto_id.toString(),
          form_series_transcript: form_data?.checklist?.verification_of_nonfiling,
          ives_detail: "Equifax Verification Services, 11432 Lackland Rd, st. louis, Missouri, 63146, 8887494411",
          mortgage_address: "11432 Lackland Rd",
          mortgage_city: "St. louis",
          mortgage_company: "Equifax Verification Services",
          mortgage_phone: 8887494411,
          mortgage_state: "Missouri",
          mortgage_zip: 63146,
          name: form_data?.business_info?.business_name,
          phone_number: form_data?.business_info?.phone,
          id:this.data._id,
          recipient_mail: form_data?.business_info?.email,
          recipient_name: form_data?.business_info?.business_name,
          record_of_account: form_data?.checklist?.record_of_account,
          return_transcript: form_data?.checklist?.return_transcript,
          rm_assigned: "",
          tax_id: form_data?.business_info?.tax_id,
          tax_year: this.tax_year,
          transcript_requested: this.irs_form.find((x)=>x.id==form_data?.transcript_requested?.irs_form).value,
          verification_of_nonfiling: false,
          fedein:form_data?.business_info?.tax_id,
          tax_year_irs_filled:"2020-2019-2018",
          brand_id: this.environment.brand_id
         
        }  
        
        
        
        this.taskInfoService.saveTaskInfo({slug: 'irs_online_Business'}, irsdata_business).subscribe({next:(end) => {
  
          this.updateActivityLog();
          this.commonService.popToast('success', '', `Sent For E-Sign.`);
          this.commonService.navigate('underWriting');
        },
        error:()=>{
          console.log('error');
        }})
      }
      else if(this.data.owner_type=="corporate")
      {
        let irsdata_business=  {
          owner_id:this.data?._id,
          app_id: this.data?.app_id,
          user_id: this.data?.user_id,
          auto_id: this.application_data.auto_id,
          account_transcript: form_data?.checklist?.account_transcript,
          application_id_number: this.application_data?.auto_id,
          business_title: form_data?.business_info?.business_title,
          current_address: this.getAddress(form_data?.current_address),
          doc_name:this.application_data?.auto_id.toString(),
          form_series_transcript: form_data?.checklist?.verification_of_nonfiling,
          ives_detail: "Equifax Verification Services, 11432 Lackland Rd, st. louis, Missouri, 63146, 8887494411",
          mortgage_address: "11432 Lackland Rd",
          mortgage_city: "St. louis",
          mortgage_company: "Equifax Verification Services",
          mortgage_phone: 8887494411,
          mortgage_state: "Missouri",
          mortgage_zip: 63146,
          name: form_data?.business_info?.business_name,
          phone_number: form_data?.business_info?.phone,
          business_name:form_data?.business_info?.business_name,
          recipient_mail: form_data?.business_info?.email,
          recipient_name: form_data?.business_info?.business_name,
          record_of_account: form_data?.checklist?.record_of_account,
          return_transcript: form_data?.checklist?.return_transcript,
          rm_assigned: "",
          tax_id: form_data?.business_info?.tax_id,
          tax_year: this.tax_year,
          transcript_requested: this.irs_form.find((x)=>x.id==form_data?.transcript_requested?.irs_form).value,
          verification_of_nonfiling: false,
          fedein:form_data?.business_info?.tax_id,
          tax_year_irs_filled:"2020-2019-2018",
          brand_id: this.environment.brand_id
        } 
        this.taskInfoService.saveTaskInfo({slug: 'irs_online_owner' },irsdata_business ).subscribe({next:(end) => {
  
          this.updateActivityLog();
          this.commonService.popToast('success', '', `Sent For E-Sign.`);
          this.commonService.navigate('underWriting');
        },
        error:()=>{
          console.log('error');
        }})
      }
      else
      {
        let irsdata_primary={
          owner_id:this.data?._id,
          app_id: this.data?.app_id,
          user_id: this.data?.user_id,
          auto_id: this.application_data.auto_id,
          account_transcript: form_data?.checklist?.account_transcript,//yes
          application_id_number: this.application_data?.auto_id,
          current_address: this.getAddress(form_data?.current_address),
          doc_name: this.application_data?.auto_id.toString(),
          form_series_transcript: form_data?.checklist?.verification_of_nonfiling,
          ives_detail: "Equifax Verification Services, 11432 Lackland Rd, st. louis, Missouri, 63146, 8887494411",
          mortgage_address: "11432 Lackland Rd",
          mortgage_city: "St. louis",
          mortgage_company: "Equifax Verification Services",
          mortgage_phone: 8887494411,
          mortgage_state: "Missouri",
          mortgage_zip: 63146,
          name: form_data?.personal_info?.first_name+' '+form_data?.personal_info?.Last_name,
          first_name: form_data?.personal_info?.first_name,
          last_name:form_data?.personal_info?.Last_name,
          phone_number: form_data?.personal_info?.phone,
          prev_address: this.getPreviousAddress(form_data?.previous_address),
          recipient_mail:form_data?.personal_info?.email,
          recipient_name:form_data?.personal_info?.first_name+' '+form_data?.personal_info?.Last_name,
          record_of_account: form_data?.checklist?.record_of_account,
          return_transcript: form_data?.checklist?.return_transcript,
          rm_assigned: "",
          spouse_name: (form_data?.joint_return_form?.spouse_first_name?form_data?.joint_return_form?.spouse_first_name:'') + ' ' + (form_data?.joint_return_form?.spouse_Last_name?form_data?.joint_return_form?.spouse_Last_name:''),
          spouse_ssn: form_data?.joint_return_form?.spouse_ssn_no?form_data?.joint_return_form?.spouse_ssn_no:'',
          eiv_id: form_data?.personal_info?.ssn_no,
          tax_year: this.tax_year,
          transcript_requested:this.irs_form.find((x)=>x.id==form_data?.transcript_requested?.irs_form).value,
          verification_of_nonfiling: false,
          tax_year_irs_filled:"2020-2019-2018",
          tax_id: form_data?.personal_info?.ssn_no,
          brand_id: this.environment.brand_id
        }
      
      
        this.taskInfoService.saveTaskInfo({slug: 'irs_online_owner' },irsdata_primary ).subscribe({next:(end) => {
  
          this.updateActivityLog();
            this.commonService.popToast('success', '', `Sent For E-Sign.`);
            this.commonService.navigate('underWriting');
          },
          error:()=>{
            console.log('error');
          }}
         
        )
      }
    }  
  }

  updateActivityLog() {
    let owner_name;
    if (this.data.business_id) {
      owner_name = this.data.business_name
    } else if (this.data.owner_type == "individual") {
      owner_name = `${this.data.first_name}${this.data.middle_name? ' '+this.data.middle_name: ''} ${this.data.last_name}`;
    } else if (this.data.owner_type == "corporate"){
      owner_name = this.data.businessname
    }
    let activityData = {
      app_id: this.data.app_id,
      activity: `irs_esign_sent`,
      note: owner_name,
      backend_user_id: this.backend_user_data.user_id,
      user_name: this.backend_user_data.full_name,
      role_slug: this.backend_user_data.role_slug
    };
    this.commonService.addActivityLog(activityData);
  }
}
