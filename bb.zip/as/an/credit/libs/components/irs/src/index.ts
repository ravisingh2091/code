export * from './lib/irs.module';
