import { Component, OnInit,TemplateRef,ViewChild, Input, OnDestroy } from '@angular/core';
import { CommonService, TaskInfoService,FormGenerateService, addUserDetails,DownloadService} from '@rubicon/utils';
  import { BsModalService } from 'ngx-bootstrap/modal';
  import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { FormGroup } from '@angular/forms';
import { Store} from '@ngrx/store';
import { take } from 'rxjs/operators';
import {IrsService} from '../irs.service'



@Component({
  selector: 'irs',
  templateUrl: './irs.component.html',
  styleUrls: ['./irs.component.css']
})
export class IrsComponent implements OnInit, OnDestroy {
  actionConfig
  slug
  actionForm:FormGroup
  modalRef
  app_id
  owners=[{is_primary:true,first_name:'assss',last_name:"qwww"},{is_primary:false,first_name:'ss',last_name:"w"}]
  business: any;
  dataToSend
  userData
  irs_business_status=''
  esign_business_status='NotInitiated'
  loanStatus: string;
  @ViewChild('template') template: TemplateRef<any>;
  @Input() applicationData: any;

  constructor(private commonService: CommonService,
    private taskInfoService: TaskInfoService,
    private formGenerate: FormGenerateService,
    private modalService: BsModalService,
    private Download: DownloadService,
    private IrsService:IrsService,
    private store: Store<any>) { }


  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      this.app_id=rootState.appID;
      this.userData=rootState.userData;
      this.loanStatus = this.applicationData?.status_id;
      this.taskInfoService.getTaskInfo({slug: CONSTANTS.SLUG['select_irs_type'],app_id:this.app_id }).subscribe(response => {
      response.form_fields[0]["options"]=[
        {   type:"Yes",
            value: "Yes (Please ensure the 4506-C form pdf file is duly signed by the applicant)",
            id: "5c20bf7e27105c78ad7f9281"
            
        },
        {
            type:"No",
            value: "No (I would like to fill the online form to generate 4506-C pdf file)",
            id: "5c20bf7e27105c78ad7f9282"
        }
    ]
      this.actionConfig = response.form_fields;
      this.slug = response.task_slug;
      this.actionForm  = this.formGenerate.createControl(this.actionConfig);
      
      this.business= this.applicationData.business[0];
      this.owners= this.applicationData.owners;
      this.checkIrsStausBusiness();
      this.checkEsignStatusBusiness();
   
     // this.commonService.sendMasterDataToFields(this.actionConfig, response.response_data);
      
    
    })
  })
  }


  openModal(data)
  {
   this.dataToSend=data;
    this.modalRef = this.modalService.show(this.template, { class: 'modal-lg updateCategory', backdrop: 'static' });
  }

  onCancel() {
    this.modalRef.hide();
  }

  checkIrsStausBusiness()
  {
   let busRef=this.applicationData.business_references;
    if(busRef.find((x)=>x.type=="irs-file"))
    {
     return "Completed"
    }
    else if(busRef.find((x)=>x.type=="irs"))
    {
      return "Submitted"
    }
    else{
      return'';

    }

  }

  checkEsignStatusBusiness()
  {
    let busRef=this.applicationData.business_references;
    if(busRef.find((x)=>x.type=="e-sign-manual"||(x.type=="e-sign"&&x?.response=="completed")))
    {
     return "Completed"
    }
    else if(busRef.find((x)=>x.type=="e-sign"))
    {
      return"Pending"
    }
    else{
      return 'NotInitiated';

    }
  }

  checkIrsStausOwner(owner)
  {
    let OwnRef=this.applicationData.owner_references;
    if(OwnRef?.find((x)=>x.type=="irs-file"&&owner._id==x.owner_id))
    {
     return "Completed";
    }
    else if(OwnRef.find((x)=>x.type=="irs"&&owner._id==x.owner_id))
    {
      return"Submitted"
    }
    else{
      return'';

    }
  }

  checkEsignStatusOwner(owner)
  {
    let OwnRef=this.applicationData.owner_references;
    if(OwnRef?.find((x)=>(x.type=="e-sign-manual"||(x.type=="e-sign"&&x?.response=="completed"))&&(owner._id==x.owner_id)))
    {
     return "Completed"
    }
    else if(OwnRef.find((x)=>(x.type=="e-sign")&&(owner._id==x.owner_id)))
    {
      return"Pending"
    }
    else{
      return 'NotInitiated';

    }
  }

  downloadsignedFormBusiness()
  {
    let busRef=this.applicationData.business_references;
    let ref_esign;
    if(busRef.find((x)=>x.type=="e-sign-manual"))
    {
      ref_esign=busRef.find((x)=>x.type=="e-sign-manual")?.ref_id;
    }
    else{
let ref1=    busRef.find((x)=>x.type=="e-sign"&&x?.response=="completed")?.ref_id;
 ref_esign=busRef.find((x)=>x.type=="document-management"&&x?.response==ref1)?.ref_id;
    }

this.getbase64(ref_esign).subscribe(res => {
     
  this.Download.showPdf(res?.getting_base64?.data?.data?.body, '4506C.pdf');
 });
  }
  downloadsignedFormOwner(owner)
  {
    let OwnRef=this.applicationData.owner_references;
    let ref_esign;
    if( OwnRef.find((x)=>(x.type=="e-sign-manual"&&owner._id==x.owner_id)))
    {
      ref_esign=OwnRef.find((x)=>x.type=="e-sign-manual"&&owner._id==x.owner_id)?.ref_id;
    }
    else
    {
let ref1=    OwnRef.find((x)=>x.type=="e-sign"&&x?.response=="completed"&&owner._id==x.owner_id)?.ref_id;
ref_esign=OwnRef.find((x)=>x.type=="document-management"&&x?.response==ref1&&x.owner_id==owner._id)?.ref_id;

    }
this.getbase64(ref_esign).subscribe(res => {
     
  this.Download.showPdf(res?.getting_base64?.data?.data?.body, '4506C.pdf');
 });
  }

  downloadTaxTranscriptBusiness()
  {
    let busRef=this.applicationData.business_references;
    let ref1=    busRef.find((x)=>x.type=="irs-file")?.ref_id;
    let ref2=busRef.find((x)=>x.type=="document-management"&&x?.response==ref1)?.ref_id;
    console.log("ref",ref1,ref2);
    this.getbase64(ref2).subscribe(res => {
         
      this.Download.showPdf(res?.getting_base64?.data?.data?.body, 'TaxTranscript.pdf');
     });
  }
  downloadTaxTranscriptOwner(owner)
  {
    let OwnRef=this.applicationData.owner_references;
    console.log(OwnRef);
let ref1=    OwnRef.find((x)=>x.type=="irs-file"&&owner._id==x.owner_id)?.ref_id;
let ref2=OwnRef.find((x)=>x.type=="document-management"&&x?.response==ref1&&x.owner_id==owner._id)?.ref_id;
console.log("ref_shakti",ref1,ref2);
this.getbase64(ref2).subscribe(res => {
     
  this.Download.showPdf(res?.getting_base64?.data?.data?.body, 'TaxTranscript.pdf');
 });

  }
  onSubmit(action) {
    
    if(this.formGenerate.validateCustomFormFields(this.actionForm,action,this.actionConfig )) {
      //this.IrsService.setData(this.dataToSend);
      this.userData = {
        ...this.userData,
        Irs_data_to: {
        ...this.dataToSend
        }
      }
      this.store.dispatch(addUserDetails({ userData: this.userData}));
      if(this.actionForm.value.irs_type=='5c20bf7e27105c78ad7f9281')
      {
      this.commonService.navigate('irs-manual');
      this.modalRef.hide();
      }

      if(this.actionForm.value.irs_type=='5c20bf7e27105c78ad7f9282')
      {
      this.commonService.navigate('irs-online');
      this.modalRef.hide();
      }
    }
  }

  getbase64(ref_id)
  {
   return this.taskInfoService.saveTaskInfo({slug: 'getting_base64'}, {doc_id:ref_id});
  }
  showAlertMessage(){
    if( this.loanStatus === CONSTANTS?.APPLICATION_STATUS?.application_in_progress) {
       return true;
    } 
    return false;
  }

  ngOnDestroy(){
    if(this.modalRef){
      this.modalRef.hide();
    }
  }
}
