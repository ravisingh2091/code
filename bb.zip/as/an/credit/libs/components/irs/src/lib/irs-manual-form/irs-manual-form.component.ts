import { Component, OnInit } from '@angular/core';
import { CommonService, TaskInfoService , addAppID,
  addBusinessID,FormGenerateService, UploadService,
  addAppDetails} from '@rubicon/utils';
  import { CONSTANTS } from '@banker-journey-assets/constant/constant';
  import { FormGroup } from '@angular/forms';
  import {IrsService} from '../irs.service'
  import { select, Store } from '@ngrx/store';
  import { take } from 'rxjs/operators';
  import { forkJoin } from 'rxjs';

@Component({
  selector: 'irs-manual-form',
  templateUrl: './irs-manual-form.component.html',
  styleUrls: ['./irs-manual-form.component.css']
})
export class IrsManualFormComponent implements OnInit {
  actionConfig
  slug
  progress = undefined;
  actionForm:FormGroup
  data
  irs_form=[]
  application_data
 
  transcriptRequested=''
  tax_year="2018-2020"
  backend_user_data: any;

  constructor(private commonService: CommonService,
    private taskInfoService: TaskInfoService,private store: Store<any>,
    private formGenerate: FormGenerateService,private IrsService:IrsService,
    
    private uploadService: UploadService) { }

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
        this.data=rootState.userData.Irs_data_to;
        this.backend_user_data = rootState.userData;
      if(("business_id" in this.data) ||this.data.owner_type=="corporate") 
  {
    this.taskInfoService.getTaskInfo({slug: CONSTANTS.SLUG['irs_manual_business'],app_id:this.data?.app_id }).subscribe(response => {
     
     

    
      this.actionConfig = response.form_fields;
      this.slug = response.task_slug;
      this.actionForm  = this.formGenerate.createControl(this.actionConfig);
      this.irs_form=response?.response_data?.irs_form?.data?.data;
      this.application_data = response?.response_data?.app_detail?.data?.data[0];
      this.commonService.sendMasterDataToFields(this.actionConfig, response.response_data);
      if("business_id" in this.data)
      {
      this.formGenerate.setFormValues(this.actionForm, {personal_info:{business_name: this.data.business_name,tax_id:this.data.app_biz_tax_id,email:this.application_data?.owners?.find((x)=>x?.is_primary==true)?.email_address,phone:this?.data?.biz_phone_no}});
      }
      else
      {
        this.formGenerate.setFormValues(this.actionForm, {personal_info:{business_name: this.data.businessname,tax_id:this.data.tax_id,email:this.data.email_address,phone:this.data.phone}});
      }
    
   
    
    })
  }
  else
  {
    this.taskInfoService.getTaskInfo({slug: CONSTANTS.SLUG['irs_manual_owner'] }).subscribe(response => {
     
     

    
      this.actionConfig = response.form_fields;
      this.slug = response.task_slug;
      this.actionForm  = this.formGenerate.createControl(this.actionConfig);
      this.irs_form=response?.response_data?.irs_form?.data?.data;
      this.application_data = response?.response_data?.app_detail?.data?.data[0];
      this.commonService.sendMasterDataToFields(this.actionConfig, response.response_data);
      this.formGenerate.setFormValues(this.actionForm, {personal_info:{first_name: this.data.first_name,Last_name:this.data.last_name,ssn_no:this.data.ssn,email:this.data.email_address,phone:this.data.phone,middle_name:this.data.middle_name}})
   
    
    })
  }

  })
  }

  uploadDocuments() {
    const form_data = this.actionForm.getRawValue();
    

    
    
    if(("business_id" in this.data) )
    {
      let uploadData_business = {
        app_id:this.data.app_id,user_id:this.data.user_id,
        auto_id:this.application_data.auto_id,
          file_name:"450C.pdf",
          tax_year:this.tax_year,
          
          transcript_requested : this.irs_form.find((x)=>x.id==form_data.personal_info.irs_form).value ,
          business_name : form_data.personal_info.business_name,
          fedein :form_data.personal_info.tax_id

       
      }

      

      this.progress = this.uploadService.uploadFile(this.actionForm.value.file_data,{ slug: CONSTANTS.SLUG['irs_manual_business'],fileKey:'file'},uploadData_business, 'upload_file_data', 'document_upload_reference_irs_business');
      console.log("progress",this.progress);
      let allProgressObservables = [];
      for (let key in this.progress) {
        allProgressObservables.push(this.progress[key].progress);
        }
      return forkJoin(allProgressObservables);
     
    
    }
    else if(this.data?.owner_type=="corporate")
    {
      let uploadData_business = {
        app_id:this.data.app_id,user_id:this.data.user_id,
        owner_id:this.data._id,
        auto_id:this.application_data.auto_id,
        
          file_name:"450C.pdf",
          tax_year:this.tax_year,
          
          transcript_requested : this.irs_form.find((x)=>x.id==form_data.personal_info.irs_form).value ,
          business_name : form_data.personal_info.business_name,
          fedein :form_data.personal_info.tax_id
       
      }
      console.log(this.actionForm.value.file_data,this.actionForm.value.file);
      this.progress = this.uploadService.uploadFile(this.actionForm.value.file_data,{ slug: CONSTANTS.SLUG['irs_manual_owner'],fileKey:'file'},uploadData_business, 'upload_file_data', 'document_upload_reference_owner');
      console.log("progress",this.progress);
      let allProgressObservables = [];
      for (let key in this.progress) {
        allProgressObservables.push(this.progress[key].progress);
        }
      return forkJoin(allProgressObservables);
    }
    else
    {
      let uploadData={
        app_id:this.data.app_id,user_id:this.data.user_id,
        auto_id:this.application_data.auto_id,
       
        owner_id:this.data._id,
        file_name:"450C.pdf",
        tax_year:this.tax_year,
        first_name:form_data.personal_info.first_name,
        last_name:form_data.personal_info.Last_name,
        transcript_requested :this.irs_form.find((x)=>x.id==form_data.personal_info.irs_form).value,
       
        eiv_id : form_data.personal_info.ssn_no
              
            
            
  
      }
      console.log(this.actionForm.value.file_data,this.actionForm.value.file);

      this.progress = this.uploadService.uploadFile(this.actionForm.value.file_data,{ slug: CONSTANTS.SLUG['irs_manual_owner'],fileKey:'file'},uploadData, 'upload_file_data', 'document_upload_reference_owner');
      console.log("progress",this.progress);
      let allProgressObservables = [];
      for (let key in this.progress) {
        allProgressObservables.push(this.progress[key].progress);
        }
      return forkJoin(allProgressObservables);
    }
    
  
  
  }

  onSubmit(action)
  {
    console.log(this.actionForm);
    
    if(this.formGenerate.validateCustomFormFields(this.actionForm, action, this.actionConfig)) 
    {
 console.log(this.actionForm);
 this.uploadDocuments.call(this).subscribe({next:(end) => {
  
  this.updateActivityLog();
  this.commonService.popToast('success', '', `IRS submitted successfully.`);
  this.commonService.navigate('underWriting');
},
error:()=>{
  console.log('error');
}});
    }
  }

  onBack()
  {
    this.commonService.navigate('underWriting');
  }

  updateActivityLog() {
    let owner_name;
    if (this.data.business_id) {
      owner_name = this.data.business_name
    } else if (this.data.owner_type === 'individual') {
      owner_name = `${this.data.first_name}${this.data.middle_name? ' '+this.data.middle_name: ''} ${this.data.last_name}`;
    } else if (this.data.owner_type === 'coperate'){
      owner_name = this.data.businessname
    }
    let activityData = {
      app_id: this.data.app_id,
      activity: `irs_submitted`,
      note: owner_name,
      backend_user_id: this.backend_user_data.user_id,
      user_name: this.backend_user_data.full_name,
      role_slug: this.backend_user_data.role_slug
    };
    this.commonService.addActivityLog(activityData);
  }

}
