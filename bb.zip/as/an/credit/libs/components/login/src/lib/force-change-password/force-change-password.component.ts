import { Component, Inject, OnInit, Output,Input, EventEmitter } from '@angular/core';
import { TaskInfoService, FormGenerateService, onLogout, CommonService} from '@rubicon/utils';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { Store } from '@ngrx/store';
import { take } from 'rxjs/operators';


@Component({
  selector: 'force-change-password',
  templateUrl: './force-change-password.component.html',
  styleUrls: ['./force-change-password.component.scss']
})
export class ForceChangePasswordComponent implements OnInit {
  changePasswordConfig: FormFieldInterface[] = [];
  changePasswordForm: FormGroup;
  slug: '';
  @Output() closeModal = new EventEmitter<string>();
  @Input() user_id: string;
  @Input() session_id: string;
  @Input() userData: any;
  constructor(
    private taskInfoService : TaskInfoService,
    private formGenerateService: FormGenerateService,
    private  commonService: CommonService,
    private store: Store<any>,
    @Inject('environment') private environment,
    @Inject('CONSTANTS') private CONSTANTS,
  ) { }

  ngOnInit(): void {
     this.taskInfoService.getTaskInfo({slug:this.CONSTANTS.SLUG['force-change-password']}).subscribe(response => {
       this.slug = response.task_slug;
       this.changePasswordConfig = response.form_fields;
       this.changePasswordForm = this.formGenerateService.createControl(this.changePasswordConfig);
     },
     error => {
       console.log("something went wrong!");
     })
  }
  hideModal(): void {
    this.closeModal.emit();
  }

  onSubmit(action) {
    if(this.formGenerateService.validateCustomFormFields(this.changePasswordForm, action, this.changePasswordConfig)) {
      let payload =  {
       ...this.changePasswordForm.getRawValue(),
        user_id: this.user_id,
        header_logo_path_1: this.environment.logo1_path,
        header_logo_path_2: this.environment.logo2_path,
        client_name: this.environment.project_name,
        senders_name: this.environment.client_name,
        copyright_text: this.environment.copyright_text,
        privacy: this.environment.privacy,
        terms: this.environment.terms,
        email_address: this.userData.email_address,
        first_name: this.userData.first_name
        //  'x-session-id': this.session_id
      };
      let headers = { 
        "user_session" : this.session_id
      }
      this.taskInfoService.saveTaskInfo({slug: this.slug}, payload, headers).subscribe(res => {
        if(res?.change_password?.data?.code == 200) {
          this.commonService.popToast('success', '', 'Your password has been updated successfully, please login with your new password to access the platform.');
          this.hideModal();
        }
      })
      
  }
  }

}
