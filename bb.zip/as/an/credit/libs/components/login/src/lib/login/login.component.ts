import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { TaskInfoService, FormGenerateService, onLogout, CommonService, addUserDetails,addAppID, addAppDetails } from '@rubicon/utils';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { Store } from '@ngrx/store';
import { CONSTANTS } from '@customer-journey-assets/constant/constant';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginConfig: FormFieldInterface[] = [];
  loginForm: FormGroup;
  slug:string = '';
  email_address:string = '';
  nextTask: string = '';
  user_id: string;
  session_id: string;
  userData:any;
  modalRef2: BsModalRef;
  modalRef3: BsModalRef;
  modalRef4: BsModalRef;
  @ViewChild('template2') template2: TemplateRef<any>;
  @ViewChild('template3') template3: TemplateRef<any>;
  @ViewChild('template4') template4: TemplateRef<any>;
  
  constructor( private taskInfoService : TaskInfoService,
     private formGenerateService: FormGenerateService,
     private commonService: CommonService,
     private modalService: BsModalService,
     private store: Store<any> ) { }

  ngOnInit(): void {
    this.store.dispatch(onLogout({}));
     this.taskInfoService.getTaskInfo({slug:CONSTANTS.SLUG.signin}).subscribe(response => {
       this.slug = response?.task_slug;
       this.loginConfig = response?.form_fields;
       this.loginForm = this.formGenerateService.createControl(this.loginConfig);
      });
  }

  onSubmit(action) {
    if(this.formGenerateService.validateCustomFormFields(this.loginForm, action, this.loginConfig)) {
      const data = {...this.loginForm.value};
      const token = btoa(data.email_address + ":" + data.password);
      const headers = { Authorization: "Basic " + token };
      this.taskInfoService.saveTaskInfo(
      {
        slug: this.slug, 
        skip_error: true,
        match : "email_address", 
        use_filter: true
      }, data, headers).subscribe(res => {
        if( res?.check_email?.data?.data?.isExists && !res?.check_email?.data?.data?.isVerified) {
          this.email_address = data?.email_address;
          this.store.dispatch(
            addAppID({ appID: res ?.get_user_application ?.data ?.data[0]?._id })
          );
          this.openModal2();
        } else  {
          if (res?.generate_session ?.data ?.data ) {
            const data = res.generate_session.data.data;
            const userData = data.user;
            this.userData = {
              email_address: userData ?.email_address,
              user_id: userData?.id,
              phone: userData?.phone,
              id: data?.id,
              first_name: userData?.first_name,
              last_name: userData?.last_name,
              record_id: userData?.record_id
            };
            this.user_id = userData?.id;
            this.nextTask = res?.nextTask?.value? res?.nextTask?.value : 'dashboard';
            if(userData.system_password){
              this.openChangePasswordModal({...userData,session_id: data?.id});
            }else if(userData?.agreed_terms_and_conditions === false){
              this.openTncModal();
            }
            else{
              this.store.dispatch(addUserDetails({
                userData: this.userData
              }));
              this.commonService.navigate(this.nextTask);
            }
          }else if(res?.generate_session?.errors?.errors?.length > 0 || res?.nextTask?.value === "error"){
            this.commonService.popToast('error','Error','You may have entered the wrong Email or Password.');
          }
        }
      })
     }
  }

  agreeConditions(){
    let payload = {
      user_id: this.user_id,
      agreed_terms_and_conditions: true
    }
    this.taskInfoService.saveTaskInfo({slug: CONSTANTS.SLUG['agreed_terms_and_condition']}, payload).subscribe(res => {
      if(res?.update_user ?.data ?.data?. agreed_terms_and_conditions){
        this.closeTncModal();
        this.store.dispatch(addUserDetails({
          userData: this.userData
        }));
        this.commonService.navigate(this.nextTask)
      }
    })
  }
  onNavigate(key){
    this.store.dispatch(addAppDetails({
      appData: {
        isSignButton: true
      }
    }))
    this.commonService.navigate(key)
  }
  openModal2(): void {
    this.modalRef2 = this.modalService.show(this.template2, { class: 'modal-lg thankyouRegister', backdrop: 'static' });
  }
  openChangePasswordModal(data): void {
    this.session_id =  data.session_id;
    this.user_id = data?.id;
    this.userData = data;
    this.modalRef3 = this.modalService.show(this.template3, { class: 'modal-lg changePasswordModel', backdrop: 'static' });
  }
  openTncModal(): void {
    this.modalRef4 = this.modalService.show(this.template4, { class: 'modal-lg TermsandCondition', backdrop: 'static' });
  }
  closeModal(): void {
    this.modalRef2.hide();
  }
  closePasswordModal(): void {
    this.modalRef3.hide();
  }
  closeTncModal(): void {
    this.modalRef4.hide();
  }
}

