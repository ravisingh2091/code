import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Route } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { ForceChangePasswordComponent } from './force-change-password/force-change-password.component';
import { OtpModalModule } from '@credit-bench/components/otp-modal';
import { TermsAndConditionsModule } from '@credit-bench/components/terms-and-conditions';

export const loginRoutes: Route[] = [
  {path:'', component: LoginComponent}
];

@NgModule({
  imports: [
    CommonModule,
    SharedLazyModule,
    OtpModalModule,
    TermsAndConditionsModule,
    RouterModule.forChild(loginRoutes),
  ],
  declarations: [LoginComponent, ForceChangePasswordComponent],
})
export class LoginModule {}
