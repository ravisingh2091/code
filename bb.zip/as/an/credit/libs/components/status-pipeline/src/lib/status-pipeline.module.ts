import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { StatusPipelineComponent } from './status-pipeline/status-pipeline.component';
import { Route, RouterModule } from '@angular/router';
import { DashboardModule } from 'status-pipeline';
import { UiKitModule } from '@credit-bench/ui-kit';
export const routes: Route[] = [
  {path: '', component: StatusPipelineComponent}
]

@NgModule({
  imports: [
    CommonModule,
    SharedLazyModule,
    DashboardModule,
    UiKitModule,
    RouterModule.forChild(routes)
  ],
  declarations: [StatusPipelineComponent],
})
export class StatusPipelineModule {
  
  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();

  constructor() {}
}
