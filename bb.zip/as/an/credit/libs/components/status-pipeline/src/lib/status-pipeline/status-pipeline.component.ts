import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormFieldInterface } from '@credit-bench/interface/form-field';
import { select, Store } from '@ngrx/store';
import { addUserDetails, CommonService, FormGenerateService, TaskInfoService } from '@rubicon/utils';
import { take } from 'rxjs/operators';

@Component({
  selector: 'status-pipeline',
  templateUrl: './status-pipeline.component.html',
  styleUrls: ['./status-pipeline.component.scss']
})
export class StatusPipelineComponent implements OnInit {
  config:any = {
    version: 'v2',
    showTotal: true,
    task: {
      url: this.environment.orchUrl + 'v2/tasks',
      params: {
        slug: "backend-dashboard"
      },
      headers: {
        'x-region': this.environment.region,
      },
      key: 'app_count_by_status'
    },
    queryparams: {
      from_date: '',
      to_date: '',
      assigned_to: ''
    },
    params: {
      role_id: '',
    },
    response_key: 'role_id',
    not_allowed_status: [
      'Application Submitted',
      'Additional Items - Requested',
      'Application - Term Letter Pending',
      'Application - Commitment Letter Pending',
      'Application - Signature Pending',
      'Application Approved'
    ],
    css: {
      rounded_circle: {
        'border-radius': '7px',
        'background': '#ffffff',
        'min-height': '137px', 
        'cursor': 'pointer',
        'flex-direction': 'column',
        'box-shadow': '0 2px 35px 0 rgb(0 0 0 / 10%)',
        'font-size': '40px',
        'color': '#2a5135',
        'font-weight': '500',
        'text-align': 'center',
        'padding': '3rem',
        'margin-bottom': '1rem',
      },
      col: {
        'text-align': 'center',
        'display': 'inline-block',
        'flex': '0 0 16.6666666667%',
        'max-width': '16.6666666667%',
        'margin-bottom': '3rem',
        'color': '#ffffff',
        'font-size': '14px',
      },
      header: {
        'color': '#ffffff',
        'font-weight': '500',
        'font-size': '20px',
        'padding-bottom': '1rem',
      }
    },
    class: {
      total: 'showTotalAppCount'
    },
    urls: {}
  }
  slug: string;
  fpConfig: FormFieldInterface[] = [];
  fpForm: FormGroup;
  userData: any;
  userRoleId: string;
  constructor(private store: Store<any>, @Inject('environment') private environment,
  private taskInfoService : TaskInfoService,
     private formGenerateService: FormGenerateService,
     private  commonService: CommonService) { }

  ngOnInit(): void {
    this.store.pipe(select('app'), take(1))
      .subscribe(rootState => {
        this.userRoleId = rootState.userData.role_id;
        this.userData = rootState.userData;
        if (rootState?.userData?.status_pipeline_data) {
          this.userData = {
            ...this.userData,
            status_pipeline_data: null
          }
          this.store.dispatch(addUserDetails({ userData: this.userData}));
        }
        this.taskInfoService.getTaskInfo({slug:'backend-dashboard-filter-form'}).subscribe(response => {
          this.slug = response.task_slug;
          this.fpConfig = response.form_fields;
          this.fpForm = this.formGenerateService.createControl(this.fpConfig);
          this.getMonthYearFilter();
        });
      });
  }

  onPipelineClick(event):void {
    this.userData = {
      ...this.userData,
      status_pipeline_data: {
        ...this.fpForm.getRawValue(),
        status_id: event
      }
    }
    this.store.dispatch(addUserDetails({ userData: this.userData}));
    this.commonService.navigate('manage-loans')
  }
  getMonthYearFilter(): void {
    const currentDate = new Date();
    const selectedYear = currentDate.getFullYear();
    const selectedMonth = currentDate.getMonth();
    const start_date = new Date(currentDate.setFullYear(selectedYear, selectedMonth, 1)).setHours(0, 0, 0, 0);
    const end_date = new Date(currentDate.setFullYear(selectedYear, selectedMonth + 1, 0)).setHours(23, 59, 59, 0);
    this.fpForm.patchValue({
      start_date: new Date(start_date),
      end_date: new Date(end_date)
    });
    this.applyFilter();
  }

  applyFilter():void {
    const start_date=(this.fpForm.getRawValue()?.start_date.getTime()/1000).toString();
    const end_date=(this.fpForm.getRawValue()?.end_date.getTime()/1000).toString();
    const config_data = this.config;
    if(start_date < end_date) {
      config_data.params.role_id = this.userRoleId;
      config_data.task.params ={...config_data.task.params,start_date,end_date, assigned_to:this.userData.user_id};
      if(this.userData.role_slug === "admin") delete config_data.task.params.assigned_to;
      this.config={...config_data}; 
    } else {
      this.commonService.popToast('error','','Start date cannot be greater than end date.')
    }
  }
}
