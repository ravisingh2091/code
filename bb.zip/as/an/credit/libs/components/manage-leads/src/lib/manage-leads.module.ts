import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageLeadsComponent } from './manage-leads/manage-leads.component';
import { Route, RouterModule } from '@angular/router';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { UiKitModule } from '@credit-bench/ui-kit';
import { LeadDetailsComponent } from './lead-details/lead-details.component';
import { LeadNotesComponent } from './lead-details/lead-notes/lead-notes.component';
import { LoanDetailsComponent } from './lead-details/loan-details/loan-details.component';
import { LeadActionsComponent } from './lead-actions/lead-actions.component';
import { ManageLeadsService } from './services/manage-leads.service';
import { ComponentsApplicationPdfModule } from '@credit-bench/components/application-pdf';


export const manageLeadsRoute: Route[] = [
  {
    path:'' , component: ManageLeadsComponent
  },
  { path: ':id', component: LeadDetailsComponent,
  children: [
    {
      path: 'lead-notes' , component: LeadNotesComponent
    },
    {
      path: 'loan-details', component: LoanDetailsComponent,
      children: [
        {
          path: 'documents' ,  loadChildren: () => import('@credit-bench/components/documents').then(
            m => m.DocumentsModule
        )
        }
      ]
    }
  ] }
];

@NgModule({
  declarations: [
   ManageLeadsComponent, 
   LeadDetailsComponent, 
   LeadNotesComponent, 
   LoanDetailsComponent,
   LeadActionsComponent
   ],
  imports: [
    RouterModule.forChild(manageLeadsRoute),
    CommonModule,
    UiKitModule,
    SharedLazyModule,
    ComponentsApplicationPdfModule
  ],
  providers: [
    ManageLeadsService
  ]
})
export class ManageLeadsModule { }
