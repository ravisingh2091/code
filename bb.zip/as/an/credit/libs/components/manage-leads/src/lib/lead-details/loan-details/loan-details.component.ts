import { Component, Inject, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { addAppDetails, addAppID, addBusinessID, CommonService, TaskInfoService } from '@rubicon/utils';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ManageLeadsService } from '../../services/manage-leads.service';
import { ApplicationPdfComponent } from '@credit-bench/components/application-pdf';
import { CONFIG_TYPES, DOUMENT_CONFIG } from './document.const';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import * as _ from 'lodash';
import { take } from 'rxjs/operators';
import { forkJoin, Subscription } from 'rxjs';

@Component({
  selector: 'loan-details',
  templateUrl: './loan-details.component.html',
  styleUrls: ['./loan-details.component.scss'],
})
export class LoanDetailsComponent implements OnInit, OnDestroy {
  appInProg = CONSTANTS?.APPLICATION_STATUS?.application_in_progress;
  @ViewChild('applicationPdf') applicationPdf: ApplicationPdfComponent;
  modalRef: BsModalRef;
  notes_data: any = null;
  id: String;
  role_slug: string;
  role_id: string;
  appList: any = [];
  app_master_data: any = [];
  start: number = 0;
  limit: number = 10;
  total: number = 0;
  perPageRecordChange = false;
  userData: any = [];
  user_status_id: string = '';
  showDocument = {
    id: null,
  };
  appID: string;
  configtypes = CONFIG_TYPES;
  backend_user_id: string;
  subStatusMap: any = {};
  app_soft_Decline_status = CONSTANTS?.APPLICATION_STATUS?.application_soft_decline;
  application_in_progress = CONSTANTS.APPLICATION_STATUS.application_in_progress;
  application_hard_decline = CONSTANTS.APPLICATION_STATUS.application_hard_decline;
  constructor(
    private taskInfoService: TaskInfoService,
    private ActivateRoute: ActivatedRoute,
    private common: CommonService,
    private manageLeadsService: ManageLeadsService,
    private modalService: BsModalService,
    private store: Store<any>,
    @Inject('environment') public environment
  ) { }

  ngOnInit(): void {
    this.store
      .select('app')
      .pipe(take(1))
      .subscribe((rootState) => {
        this.backend_user_id = rootState.userData.user_id;    
        this.role_slug = rootState.userData?.role_slug;
        this.role_id = rootState.userData?.role_id;
      });
    this.id = this.ActivateRoute.parent.snapshot.params.id;
    this.get_loan_data(this.limit, this.start);
  }
  
  get_loan_data(limit: number, start: number) {
    this.taskInfoService
      .getTaskInfo({
        slug: CONSTANTS.SLUG['loan-applications'],
        user_id: this.id,
        limit,
        start,
        sort_by: '-created_at',
        is_deleted : false
      }).subscribe((response) => {
        this.prepareSubStatusMap(response);
        this.appList = response?.response_data?.app_listing?.data?.data;        
        this.app_master_data = response?.response_data?.app_status?.data?.data;
        this.total = response?.response_data?.app_listing?.data?.total;
        this.userData = response?.response_data?.get_user?.data?.data;
        this.set_Status(this.userData?.status_id);
        if (this.perPageRecordChange) {
          this.limit = limit;
        }
      });
  }

  set_Status(status_id): void {
    if(status_id) {
      this.manageLeadsService.status_updated(status_id);
      this.manageLeadsService.data1$.subscribe(res => {
        if(res)
          this.user_status_id = res;
      })
    }
  }
  onclick(item) {
    if(item?.app_assignment?.length){
      const ifAssigned = !item?.app_assignment.some((ele:any) => ele.assigned_to === this.backend_user_id)
      if(ifAssigned && this.role_slug === CONSTANTS.ROLE_SLUGS.junior_LO){
        this.common.popToast('error', 'Error', 'You are not authorized to access this application.');
          return;
      }
    }
    let appData = {
      primaryOwnerName: '',
      primarOwnerEmail_id: '',
      primaryOwnerPhone_no: '',
      loan_id: item.auto_id,
      lead_id: this.userData.record_id,
      user_id: item.user_id,
      business_name: item.business[0].business_name,
      app_biz_tax_id: item.business[0].app_biz_tax_id,
      product: item?.business[0]?.product,
      business_structure: item?.business[0]?.business_structure,
      purpose_arr: item?.business[0]?.purpose_arr,
      productName: item?.products[0]?.sub_product_name,
      status_id: item.status_id,
      stage_data:  item.business[0].stage_data
    }

    if (item.owners.length > 0) {
      let primaryOwnerData = item.owners.find(e => e.is_primary === true);
       if (primaryOwnerData) {
        appData.primaryOwnerPhone_no = primaryOwnerData.phone;
        appData.primarOwnerEmail_id = primaryOwnerData.email_address;
        appData.primaryOwnerName = primaryOwnerData.first_name;
      }

    }
    this.store.dispatch(addAppDetails({ appData: appData }));
    this.store.dispatch(
      addAppID({ appID: item._id })
    );
    this.store.dispatch(
      addBusinessID({ businessID: item.business[0]._id })
    );
    this.common.navigate('application-details');
  }

  prepareSubStatusMap(response) {
    const subStatuses = _.get(response, 'response_data.app_sub_status.data.data'); 
    if(subStatuses && subStatuses.length) {
      subStatuses.forEach((status) => {
          this.subStatusMap[status.id] = { value: status.value, type: status.type }
      });
    }
  }
  
  pageDetail(event) {
    this.perPageRecordChange = event.perPageRecordChange;
    this.get_loan_data(event.limit, event.skip);
  }

  openModal(template: TemplateRef<any>, item) {
    this.modalRef = this.modalService.show(template, {
      id: 1,
      class: 'uwRequest',
      backdrop: 'static',
    });
    if (item?._id) {
      this.taskInfoService.getTaskInfo({ slug: 'get_notes', app_id: item._id, type: 'case_note' }).subscribe(res => {
        this.notes_data = res?.response_data?.get_notes?.data?.data ? res.response_data.get_notes.data.data : null;
        const all_users = res?.response_data?.get_banker_users?.data?.data ? res.response_data.get_banker_users.data.data : null;
        if (this.notes_data?.length)
          this.notes_data.forEach(element => {
            element.createdby = all_users.find(elem => elem.id === element.backend_user_id).name
          });
      });
    }
  }

  toogleDocuments(app, index) {
    if(!app.config){
      app.config = {};
    }
    // if(!app?.business[0]?.product){
    //   this.openStage(app, 'config_0');
    // }
    this.appList.forEach((app_t) => {
      if (app._id !== app_t._id) {
        app_t.showDocuments = false;
      }
    });    
    this.appList[index].showDocuments = !app.showDocuments;
    if (app.showDocuments) {
      this.reqDocsStage(app);
    }
  }
  openStage(app, item?) {
    if(!app.didDataCall){
      app.didDataCall = true;
      this.proceedToCommonWidegtData(app, item);
      this.getCurrentStage(app);
      app.stages_docs = [];
      app.allDocumentTyes = [];
      app.allowedStagesToRole = {
        stages: [],
        assignedBankers: [],
        enable_functions: []
      };
    } else if(app.didDataCall && !app.config[item]?.setup_done){
      this.configSetup(app, item);
    }
  }
  getCurrentStage(app) {
    this.taskInfoService
      .getTaskInfo({
        slug: 'get_stages_for_role',
        role_slug: this.role_slug,
        app_id: app._id
      })
      .subscribe((response) => {
        let flag = false;
        app.allowedStagesToRole.stages = _.get(response, 'response_data.get_stages_for_role.data.data.stages');
        app.allowedStagesToRole.assignedBankers = _.get(response, 'response_data.get_assignment_app.data.data');
        app.allowedStagesToRole?.stages?.forEach((stage) => {
          app.allowedStagesToRole?.assignedBankers?.forEach((banker) => {
            if (banker.stage === 'quality_assurance') {
              flag = true;
            }
            if (banker.stage === 'closing' && stage.type === banker.stage && this.backend_user_id === banker.assigned_to) {
              app.allowedStagesToRole.enable_functions.push(stage._id);
            }
          });
        })
        if (!flag) {
          app.allowedStagesToRole?.stages?.forEach((stage) => {
            app.allowedStagesToRole?.assignedBankers?.forEach((banker) => {
              if (stage.type === banker.stage && this.backend_user_id === banker.assigned_to) {
                if (!app.allowedStagesToRole.enable_functions.includes(stage._id))
                  app.allowedStagesToRole.enable_functions.push(stage._id)
              }
            });
          })
        }
      });
  }
  proceedToCommonWidegtData(app, item){
    const params = {
      slug: CONSTANTS.SLUG.document_widget_data,
      app_id: app._id,
      user_id: app.user_id,
      type: "document",
      skip_error: true
    }
    this.taskInfoService.getTaskInfo(params).subscribe(res=>{
      if(res.response_data) {
        app.docReferences = res.response_data?.get_manual_bank_statement_reference?.data?.data ? res.response_data.get_manual_bank_statement_reference.data.data : [];
        app.uploadedDocs = res.response_data?.get_uploaded_docs?.data?.data ? res.response_data.get_uploaded_docs.data.data : [];
        app.allNotes = res.response_data?.get_notes?.data?.data ? res.response_data.get_notes.data.data : [];
        app.statusOptions = res.response_data?.get_master_document_status?.data?.data ? res.response_data.get_master_document_status.data.data : [];
      }
      this.proceedToGetBackendUser(app, item);
    })
  }

  proceedToGetBackendUser(app, item){
    let user_ids = [this.backend_user_id];
    app.docReferences.forEach(tuple=>{
      if(tuple.backend_user_id && !user_ids.includes(tuple.backend_user_id)) 
      user_ids.push(tuple.backend_user_id)
    });
    if(user_ids.length){
      this.taskInfoService.saveTaskInfo({slug: CONSTANTS.SLUG.get_backend_users}, {user_ids}).subscribe(users=>{
        app.backendUserList = users?.get_backend_users?.data?.data ? users.get_backend_users.data.data: [];
        this.configSetup(app, item);
      })
    } else{
      this.configSetup(app, item);
    }
  }

  async configSetup(app, item, call_sync?) {
      app.config[item] = _.cloneDeep(DOUMENT_CONFIG);
      app.config[item].uniqueAccordionKey = this.configtypes[item];
      app.config[item].user_id = app.user_id;
      app.config[item].app_id = app._id;
      app.config[item].lead_ref_id = app.auto_id;
      app.config[item].task.url = `${this.environment.orchUrl}v2/tasks`;
      app.config[item].docReferences = app.docReferences || [];
      app.config[item].uploadedDocs = app.uploadedDocs || [];
      app.config[item].document_button.update_status.statusOptions = app.statusOptions || [];
      app.config[item].backendUserList = app.backendUserList || [];
      app.config[item].allNotes = app.allNotes || [];
      app.config[item].currentStage = this.configtypes[item].value;
      app.config[item].task = {
        ...app.config[item].task,
        document_type: {
          ...app.config[item].task.document_type,
          body: ['config_8', 'config_9'].includes(item) ? await this.syncDocQuerySetup(app, item) : this.docQuerySetup(app, item),
        },
        upload: {
          params: {
            ...app.config[item].task.upload.params,
            backend_user_id: this.backend_user_id,
          },
        },
        notes: {
          ...app.config[item].task.notes,
          params: {
            ...app.config[item].task.notes.params,
            backend_user_id: this.backend_user_id,
          },
        }
      };
      app.config[item].document_button = {
        ...app.config[item].document_button,
        buttons: {
          upload: false,
          download: true,
          delete: false,
          rename: false,
          notes: false,
          update_status: false,
          status_text: true
        }
   };
   app.allowedStagesToRole.enable_functions.forEach((elem) => {
    if (this.configtypes[item].value === elem) {
      app.config[item].document_button = {
        ...app.config[item].document_button,
        buttons: {
          upload: true,
          download: true,
          delete: true,
          rename: true,
          notes: true,
          update_status: true,
          status_text: true,
        },
      };
    }
  });
  if (['config_8', 'config_9'].includes(item)) {
    app.config[item].document_button = {
      ...app.config[item].document_button,
      buttons: {
        upload: true,
        download: true,
        delete: true,
        rename: true,
        notes: true,
        update_status: true,
        status_text: true,
      },
    };
  }
   if (!call_sync) {
     this.bringDocStructure(app, item)
   }
  }
  
  bringDocStructure(app, item){
    const doc = app.config[item].task.document_type;
    if(item==='config_8'&&!app.reqDocKeys.length){
      app.config[item].documentTypes = [];
      app.config[item].setup_done = true;
      return;
    }
    if(item==='config_9'&&!app.miscellaneousDocKeys.length){
      app.config[item].documentTypes = [];
      app.config[item].setup_done = true;
      return;
    }
    if (app.allDocumentTyes.length > 0 && item !== 'config_8' && item !== 'config_9') {
      app.config[item].documentTypes = [];
      app.allDocumentTyes.forEach((docType) => {
        if (docType.type === item) {
          app.config[item].documentTypes.push(...docType.response);
        }
      });
      app.config[item].setup_done = true;
    } else {
      app.config[item].documentTypes = [];
      this.taskInfoService.saveTaskInfo({ ...doc.params, app_id: app._id, user_id: app.user_id }, doc.body).subscribe(res => {
        // if (item === 'config_9') {
        //   app.config[item].documentTypes = res?.document_type_post?.data?.data;
          // app.config[item].documentTypes.sort((element: any) => {
          //   if (!element.filter_conditions.basic_doc) {
          //     return -1;
          //   }
          //   return 0;
          // });
        // } else {
          if (item === 'config_9') {
            res?.document_type_post?.data?.data?.forEach(element => {
              if (element?.parent_key) {
                delete element.parent_key;
              }
            });
        }
        res?.document_type_post?.data?.data?.forEach(element => {
          if (!element?.hide_accordian) {
            if (item === 'config_9') {
              if (element.key === 'decline_letter' && this.application_hard_decline === app.status_id) {
                app.config[item].documentTypes.push(element);
              } else if (element.key !== 'decline_letter') {
                app.config[item].documentTypes.push(element);
              }
            } else {
              app.config[item].documentTypes.push(element);
            }
          }
        });
          // app.config[item].documentTypes = res?.document_type_post?.data?.data || [];
          if (app.stages_docs.length > 0) {
            app.stages_docs = [...app.stages_docs, ...app.config[item].documentTypes];
          } else {
            app.stages_docs = [...app.config[item].documentTypes];
          }
        // }
        app.config[item].setup_done = true;
      })
    }
  }
  async syncDocQuerySetup(app, item) {
    let obj;
    switch (item) {
      case 'config_8':
        await this.reqDocsStage(app);
        obj = {
          ...app.config[item].task.document_type.body,
          key: app.reqDocKeys
        }
        break;
      case 'config_9':
        await this.miscellaneousDocsStage(app);
        obj = {
          ...app.config[item].task.document_type.body,
          key: app.miscellaneousDocKeys
        }
        break;
      default:
        obj = {};
        break;
    }
    return obj;
  }
 docQuerySetup(app, item){
  return {
          ...app.config[item].task.document_type.body,
          orIn: 'business_structure,loan_purpose',
          and: 'requested_document',
          andIn: 'product,stage',
          nin: 'rejected_specific_business_structure',
          or: 'bypass_business_structure_and_loan_purpose,bypass_loan_purpose',
          bypass_business_structure_and_loan_purpose: 'true',
          bypass_loan_purpose: 'true',
          requested_document: 'false',
          isArray: 'loan_purpose',
          stage: this.configtypes[item].value,
          loan_purpose: app?.business[0].purpose_arr ? (app.business[0].purpose_arr.map(tup => tup.purpose)).join(",") :'',
          business_structure: app?.business[0]?.business_structure,
          product: this.getStageCategory(app, this.configtypes[item].value),
          rejected_specific_business_structure: app?.business[0]?.business_structure
        }   
  }
  getStageCategory(app, stage) {
    if(app?.business[0]?.stage_data) {
    let particularStage = app.business[0].stage_data.find((elem) => elem.stage === stage);
    if (particularStage) {
      return particularStage.product;
      }
    }
    return app?.business[0]?.product;
  }
  async reqDocsStage(app) {
    await this.taskInfoService
      .getTaskInfo({
        slug: CONSTANTS.SLUG.requested_documents,
        requested_document: true,
        and: 'requested_document',
        app_id: app._id,
        user_id: app.user_id,
        only_selected_docs: true
      }).toPromise()
      .then((response) => {
        app.reqDocKeys = [];
        const doc_data = response.response_data?.get_saved_requested_docs?.data?.data.doc_data
        doc_data?.forEach(doc_type => {
          app.reqDocKeys.push(doc_type.doc_type_key);
        });
        if (app.config.config_8 && app.config.config_8.setup_done) {
          app.config.config_8.task.document_type.body = { key: app.reqDocKeys };
          this.bringDocStructure(app, 'config_8');
          // if(app.config?.config_9?.setup_done){
          //   this.miscellaneousDocsStage(app);
          // }
        }
      });
  }

  async miscellaneousDocsStage(app){
    // let params = {
    //   slug: "miscellaneous-documents",
    //   // basic_doc: true,
    //   // and: 'basic_doc',
    //   app_id: app._id,
    //   user_id: app.user_id
    // };
    // let payload = {
    //   orIn: 'business_structure,loan_purpose',
    //   and: 'requested_document',
    //   andIn: 'product,stage',
    //   nin: 'rejected_specific_business_structure',
    //   or: 'bypass_business_structure_and_loan_purpose,bypass_loan_purpose',
    //   bypass_business_structure_and_loan_purpose: 'true',
    //   bypass_loan_purpose: 'true',
    //   requested_document: 'false',
    //   isArray: 'loan_purpose,stage',
    //   loan_purpose: app?.business[0].purpose_arr ? (app.business[0].purpose_arr.map(tup => tup.purpose)).join(",") :'',
    //   business_structure: app?.business[0]?.business_structure,
    //   product: app?.business[0]?.product,
    //   rejected_specific_business_structure: app?.business[0]?.business_structure
    // }
    // Object.keys(this.configtypes).slice(0,-2).forEach(item=>{
    //   if(!app.config[item]?.setup_done){
    //     payload['stage'] = payload['stage'] ? `${payload['stage']},${this.configtypes[item].value}`: this.configtypes[item].value;
    //   }
    // })
    // if(!payload['stage']){
    //   params['dont_call_stage_data'] = true;
    // }
    // if(app.config?.config_8?.setup_done){
    //   params['dont_call_saved_requested_docs'] = true;
    // }
    // // app.allDocumentTyes = [];
    // await this.taskInfoService
    //   .saveTaskInfo(params,payload).toPromise()
    //   .then((response) => {
    //     let stages_docs = [];
    //     // let basic_docs = [];
    //     // app.reqDocKeys = [];
    //     // if(response?.get_saved_requested_docs?.data?.data.doc_data){
    //     //   const doc_data = response?.get_saved_requested_docs?.data?.data.doc_data
    //     //   doc_data?.forEach(doc_type => {
    //     //     app.reqDocKeys.push(doc_type.doc_type_key);
    //     //   });
    //     // }
    //     // if(response?.document_type?.data?.data){
    //     //   basic_docs = response?.document_type?.data?.data;
    //     // }
    //     if(response?.document_type_post?.data?.data){
    //       stages_docs = response?.document_type_post?.data?.data;          
    //       // app.allDocumentTyes = [...response?.document_type_post?.data?.data];
    //     }
    //     if (app.stages_docs.length > 0) {
    //       app.stages_docs = [...app.stages_docs, ...stages_docs];
    //     } else {
    //       app.stages_docs = [...stages_docs];
    //     }        
    //     let ignored_docs = [...app.stages_docs.map(doc=>doc.key)];
    //     let considered_doc = [];
    //     app.uploadedDocs.forEach(doc => {
    //       if (!ignored_docs.includes(doc.doc_type_key) && !considered_doc.includes(doc.doc_type_key)) {
    //         considered_doc.push(doc.doc_type_key);
    //       }
    //     });
    //     // basic_docs.forEach(doc => {
    //     //   considered_doc.push(doc.key);
    //     // });
    //     app.miscellaneousDocKeys = considered_doc;
    //     if (app.config.config_9&&app.config.config_9.setup_done) {
    //       app.config.config_9.task.document_type.body = { key: app.miscellaneousDocKeys };
    //       this.bringDocStructure(app,'config_9');
    //     }
    //   });

    let obs = [];
    let configArray = [];
    for(let item of Object.keys(this.configtypes).slice(0, -2)) {
        if (!app.config[item]?.setup_done) {
          this.configSetup(app, item, true);          
          const doc = app.config[item].task.document_type;
          configArray.push(item);
          obs.push(this.taskInfoService.saveTaskInfo({ ...doc.params, app_id: app._id, user_id: app.user_id }, doc.body));
          }
    }
    // if (!app.config?.config_8?.setup_done) {
    //   this.reqDocsStage(app);
    // }
    await forkJoin(obs)
      .toPromise()
      .then((response) => { 
        app.allDocumentTyes = [];
        response?.forEach((res: any, index) => {
          app.allDocumentTyes.push({response: res?.document_type_post?.data?.data, type: configArray[index]});
        });
        
        response?.forEach((res: any) => {
          app.stages_docs.push(...res.document_type_post.data.data);
        });
        let ignored_docs = [
          ...app.stages_docs.map((doc) => doc.key),
          ...app.reqDocKeys,
        ];
        let considered_doc = [];
        app.uploadedDocs.forEach((doc) => {
          if (
            !ignored_docs.includes(doc.doc_type_key) &&
            !considered_doc.includes(doc.doc_type_key)
          ) {
            considered_doc.push(doc.doc_type_key);
          }
        });

        app.miscellaneousDocKeys = considered_doc;
        if (app.config.config_9 && app.config.config_9.setup_done) {
          app.config.config_9.task.document_type.body = {
            key: app.miscellaneousDocKeys,
          };
          setTimeout(() => {
            this.bringDocStructure(app, 'config_9');
          }, 0);
        }
      });
  }

  downloadPdf(item){
    this.applicationPdf.downloadPdf(item);
  }
  
  ngOnDestroy(){
    if(this.modalRef){
      this.modalRef.hide();
    }
  }
}