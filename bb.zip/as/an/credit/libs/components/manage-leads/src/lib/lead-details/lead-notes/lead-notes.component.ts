import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TaskInfoService } from '@rubicon/utils';
import { ManageLeadsService } from '../../services/manage-leads.service';
@Component({
  selector: 'lead-notes',
  templateUrl: './lead-notes.component.html',
  styleUrls: ['./lead-notes.component.scss']
})
export class LeadNotesComponent implements OnInit {
  appID: string;
  userID: string;
  notes_data: any = null;
  all_users: any = null;
  constructor(
    private ActivateRoute: ActivatedRoute,
    private taskInfoService: TaskInfoService,
    private manageLeadsService: ManageLeadsService,
    @Inject('environment') public environment
  ) { }

  ngOnInit(): void {
    this.userID = this.ActivateRoute.parent.snapshot.params.id;
    this.manageLeadsService.data$.subscribe(res => {
      this.getData();
    });
  }
  getData(): void {
    this.taskInfoService.getTaskInfo({ slug: 'get_lead_notes', user_id: this.userID }).subscribe(res => {
      this.notes_data = res?.response_data?.get_lead_notes?.data?.data ? res.response_data.get_lead_notes.data.data : null;
      this.all_users = res?.response_data?.all_users?.data?.data ? res.response_data.all_users.data.data : null;
      if (this.notes_data?.length)
        this.notes_data.forEach(element => {
          element.createdby = this.all_users.find(elem => elem.id === element.backend_user_id)?.name
        });
    });
  }
}
