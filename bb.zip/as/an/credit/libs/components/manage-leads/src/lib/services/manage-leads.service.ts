import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable()
export class ManageLeadsService {
   private notes_added = new BehaviorSubject(false);
   private statusUpdated = new BehaviorSubject('');
  
   data$ = this.notes_added.asObservable();
   data1$ = this.statusUpdated.asObservable();

   notesAdded(data: boolean) {
       this.notes_added.next(data);
   }
   status_updated(data: string) {
       this.statusUpdated.next(data);
   }
}