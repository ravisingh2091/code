import { Component, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { TaskInfoService } from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { ActivatedRoute } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
 
@Component({
  selector: 'lead-details',
  templateUrl: './lead-details.component.html',
  styleUrls: ['./lead-details.component.scss']
})
export class LeadDetailsComponent implements OnInit,OnDestroy {

  id : String;
  userDataConfig : any;
  lead_master_data: any = [];
  actionType: String;
  leadId: String;
  modalRef: BsModalRef; 
  leadStatus: string;

  constructor(private taskInfoService : TaskInfoService,
              private ActivateRoute : ActivatedRoute,
              private modalService: BsModalService
            
    ) { }

  ngOnInit(): void {
    this.id = this.ActivateRoute.snapshot.params.id;
    this.getLeadData();
  }

  getLeadData(){
    this.taskInfoService.getTaskInfo({slug:CONSTANTS.SLUG['get-users-details'], user_id: this.id}).subscribe(response => {
      this.userDataConfig=response?.response_data?.get_user?.data?.data;
      this.lead_master_data=response?.response_data?.lead_status?.data?.data;
    });
  }

  openModal(template: TemplateRef<any>, actionType: string) {
    this.actionType = actionType;
    this.leadId = this.userDataConfig.id;
    this.leadStatus = this.userDataConfig?.status_id;
    let uiType = '';
    switch (actionType) {
      case 'Update Status':
        uiType = 'updateStatus'
        break;
      case 'Add Note':
        uiType = 'thankyouRegister'
        break;
    }
    
    this.modalRef = this.modalService.show(template, { class: `modal-lg ${uiType}`, backdrop: 'static' });
  }

  onCloseModal(event){
    if (event ) {
      this.getLeadData();
    
  }
  this.modalRef.hide();
}

ngOnDestroy(){
  if(this.modalRef){
    this.modalRef.hide();
  }
}
}