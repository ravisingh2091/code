import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonService, FormGenerateService, TaskInfoService } from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { FormGroup } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { take } from 'rxjs/operators';
import { ManageLeadsService } from '../services/manage-leads.service';

@Component({
  selector: 'lead-actions',
  templateUrl: './lead-actions.component.html',
  styleUrls: ['./lead-actions.component.scss']
})
export class LeadActionsComponent implements OnInit {
  @Input() actionType: string;
  @Input() leadStatus: string;
  @Input() leadId: string;
  @Output() closeModal = new EventEmitter<boolean>();
  leadStatusConfig = [];
  leadStatusForm: FormGroup;
  slug: string;
  author_name: string;
  userData: any = null;
  constructor(
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private formGenerate: FormGenerateService,
    private manageLeadsService: ManageLeadsService,
    private store: Store<any>
  ) { }

  ngOnInit(): void {
    this.store.pipe(select('app'), take(1)).subscribe(rootState => {
      this.userData = rootState.userData;
      this.author_name = rootState.userData.full_name;
    })
    let slugData = {};
    if (this.actionType === 'Update Status') {
      slugData = { slug: CONSTANTS.SLUG['update_lead_status'] };
    } else if (this.actionType === 'Add Note') {
      slugData = { slug: CONSTANTS.SLUG['add_notes'] };
    }
    this.taskInfoService.getTaskInfo(slugData).subscribe(response => {
      this.leadStatusConfig = response.form_fields;
      this.slug = response.task_slug;
      this.leadStatusForm = this.formGenerate.createControl(this.leadStatusConfig);
      if (this.actionType === 'Update Status') {
        this.common.sendMasterDataToFields(this.leadStatusConfig, response.response_data);
        this.formGenerate.setFormValues(this.leadStatusForm, { lead_status: this.leadStatus });
      }
    })
  }

  onSubmit(action: string) {
    if(this.formGenerate.validateCustomFormFields(this.leadStatusForm,action,this.leadStatusConfig )) {
      switch (this.actionType) {
        case 'Update Status':
          this.updateLeadStatus();
          break;
        case 'Add Note':
          this.addNotes();
          break;
      }
    }
  }

  updateLeadStatus(){
    let payload = {
      status_id: this.leadStatusForm.value.lead_status,
      user_id: this.leadId 
    };
    this.taskInfoService.saveTaskInfo({slug: this.slug},payload).subscribe(response => {
      if (response?.update_lead_status?.data?.code === 200) {
        this.manageLeadsService.status_updated(payload?.status_id);
        this.common.popToast('success', '', `Status updated successfully.`);
        this.closeModal.emit(true);
      }
    })
  }

  onCancel() {
    this.closeModal.emit(false);
  }

  addNotes(): void {
    if (this.formGenerate.validateCustomFormFields(this.leadStatusForm, 'continue', this.leadStatusConfig)) {
      const payload = {
        "backend_user_id": this.userData.user_id,
        "user_id": this.leadId,
        "comment": this.leadStatusForm.getRawValue()?.comment,
        "role_id": this.userData.role_id
      }
      this.taskInfoService.saveTaskInfo({ slug: 'add_notes' }, payload).subscribe(res => {
        if(res?.create_lead_notes?.data?.code == 201) {
          this.closeModal.emit(false);
          this.common.popToast('success', '', `Notes added successfully.`);
          this.manageLeadsService.notesAdded(true);
        }
      });
    }
  }
}
