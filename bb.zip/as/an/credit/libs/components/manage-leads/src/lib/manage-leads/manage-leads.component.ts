import { Component, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { addAppDetails, addAppID, addBusinessID, addUserDetails, CommonService, TaskInfoService } from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Store } from '@ngrx/store';
import { select } from '@ngrx/store';
import { take } from 'rxjs/operators';
@Component({
  selector: 'manage-leads',
  templateUrl: './manage-leads.component.html',
  styleUrls: ['./manage-leads.component.scss']
})
export class ManageLeadsComponent implements OnInit, OnDestroy {
  modalRef: BsModalRef;
  slug: string = '';
  filterConfig = [];
  leadData = [];
  lead_status = [];
  skip: number = 0;
  limit: number = 10;
  totalLeads: number = 0;
  currentPage = 1;
  perPageRecordChange = false;
  actionType: string;
  leadId: string;
  filter_payload: any = null;
  leadStatus: string;
  backendUserData: any;


  constructor(
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    private modalService: BsModalService
  ) { }

  ngOnInit(): void {
    this.store.dispatch(addAppID({ appID: null}));
    this.store.dispatch(addBusinessID({ businessID: null }));
    this.store.dispatch(addAppDetails({ appData: null}));
    // this.getManageLeads(this.limit, this.skip);
    this.store.pipe(select('app'), take(1))
      .subscribe(rootState => {
        let userData = rootState.userData;
        this.backendUserData = rootState.userData;
        this.getManageLeads(this.limit, this.skip);
        if (rootState?.userData?.status_pipeline_data) {
          userData = {
            ...userData,
            status_pipeline_data: null
          }
          this.store.dispatch(addUserDetails({ userData: userData}));
        }
      });
    this.taskInfoService.getTaskInfo({slug: CONSTANTS.SLUG['manage_leads_filter']}).subscribe(response => {
      this.filterConfig = response.form_fields;
      this.slug = response.task_slug;
      this.common.sendMasterDataToFields(this.filterConfig, {
        ...response.response_data, filter_type:{data:{data:CONSTANTS.FILTER_TYPE_MANAGE_LEADS}}
      });
      this.lead_status = response.response_data ?.lead_status ?.data ?.data;
    })
  }

  getManageLeads(limit, skip) {
    let query_params = {
      limit: limit,
      skip: skip
    }
    if(CONSTANTS.JUNIOR_ROLE_SLUGS.includes(this.backendUserData.role_slug)) query_params['assigned_to']= this.backendUserData.user_id;
    if (this.filter_payload && !Object.keys(this.filter_payload).map(e=>this.filter_payload[e]).every(x => (x === null || x === ''))){
      query_params = {
        ...query_params,
        ...this.filter_payload
      };
    }
      
    this.taskInfoService.getTaskInfo({slug: CONSTANTS.SLUG['manage_leads'], ...query_params}).subscribe(response => {
      this.leadData = response.response_data?.get_users_list?.data?.data?.result?response.response_data?.get_users_list?.data?.data?.result: response.response_data?.get_users_list?.data?.data;
      this.totalLeads = response.response_data?.get_users_list?.data?.data?.total;
      if(this.perPageRecordChange) {
        this.limit = limit;
      }
    })
  }

  onFilter(filter_data) {
    this.filter_payload = {
      first_name: filter_data?.first_name || null,
      last_name: filter_data?.last_name || null,
      record_id: filter_data?.lead_id || null,
      status_id: filter_data?.status || null
    }
    if(filter_data?.filter_type) {
      const filter_type = CONSTANTS.FILTER_TYPE_MANAGE_LEADS.find(elem=>elem.id === filter_data?.filter_type)?.type;
      if( filter_type )
        this.filter_payload[filter_type] = filter_type==='phone' ? Number(filter_data.phone_value) : filter_data.email_address_value;
    }
    this.skip = 0;
    this.perPageRecordChange = true;
    this.getManageLeads(this.limit, this.skip);
  }
 
  pageDetail(event) {
    this.perPageRecordChange = event.perPageRecordChange;
    this.skip = event.skip;
    this.getManageLeads(event.limit, event.skip)
  }

  openModal(template: TemplateRef<any>, actionType: string, leadId: string, leadStatus: string) {
    this.actionType = actionType;
    this.leadId = leadId;
    let uiType = '';
    this.leadStatus = leadStatus;
    switch (actionType) {
      case 'Update Status':
        uiType = 'updateStatus'
        break;
      case 'Add Note':
        uiType = 'thankyouRegister'
        break;
    }
    
    this.modalRef = this.modalService.show(template, { class: `modal-lg ${uiType}`, backdrop: 'static' });
  }

  onCloseModal(event){
    if (event) {
      this.getManageLeads(this.limit, this.skip);
    }
    this.modalRef.hide();
  }

  ngOnDestroy(){
    if(this.modalRef){
      this.modalRef.hide();
    }
  }
}
