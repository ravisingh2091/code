import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';
import { TaskInfoService, CommonService } from '@rubicon/utils';
import { CONSTANTS } from '@banker-journey-assets/constant/constant';
import {  Subscription, of } from 'rxjs';
import * as _ from 'lodash';
import { switchMap } from 'rxjs/operators';
@Component({
  selector: 'checklist',
  templateUrl: './checklist.component.html',
  styleUrls: ['./checklist.component.scss'],
})
export class ChecklistComponent implements OnInit , OnDestroy {
  accordian_config = [];
  checklist_data = {};
  currentProduct: string;
  appID: string;
  checklistOptions: any;
  backend_userData = null;
  subscription: Subscription;
  checkProductUpdate = true;
  tempaccordionData = [];
  stageData=[];
  userId: string;
  currentStage: string;
  appAssignment = [];
  STAGEIDTYPEMAP = {
    loan_officer: "60c6559d7020ef2b54ddc61b",
    fulfillment_services: "60c6559d7020ef2b54ddc61c",
    pre_underwriting: "60c6559d7020ef2b54ddc61d",
    underwriting: "60c6559d7020ef2b54ddc61e",
    pre_closing: "60c6559d7020ef2b54ddc61f",
    quality_assurance: "60c6559d7020ef2b54ddc620",
    closing: "60c6559d7020ef2b54ddc621",
    soft_declined: "60c65c0e4da12b3bc4f2b564",
    declined: "60c65baec6e6f5422874f8b0"
  }
  
  
  constructor(
    private taskInfoService: TaskInfoService,
    private store: Store<any>,
    private common: CommonService
  ) {}


  ngOnInit(): void {
    
    this.subscription= this.store
      .select('app')
      .subscribe((rootState) => { 
        this.appID = rootState?.appID;
        this.backend_userData = rootState?.userData;
        this.userId = rootState?.appData?.user_id;
        this.appAssignment = rootState?.appData?.app_assignment;
        if(this.currentProduct !== rootState?.appData?.product || this.stageData.length !== rootState.appData?.stage_data?.length ) {
          this.checkProductUpdate= false;
          this.currentProduct = rootState?.appData?.product;
          this.stageData = rootState.appData?.stage_data ? rootState.appData?.stage_data : [] ;
           this.accordian_config =  _.cloneDeep(this.tempaccordionData);
           if(this.accordian_config.length>0) {
              this.sliceMethod();
           }

          setTimeout(()=> {
             this.checkProductUpdate= true;
           },0) 
        }
      });

        this.taskInfoService
        .getTaskInfo({slug: CONSTANTS.SLUG['checklist'], master_data: true})
        .subscribe((res) => {
          if(res) {
            this.accordian_config = [
              ...res?.response_data?.get_master_checklist?.data?.data,
            ];
            this.tempaccordionData = _.cloneDeep(this.accordian_config);
            this.checklistOptions = [
              ...res.response_data.get_master_checklist_option.data.data,
            ];
            this.sliceMethod();
          }
        });   
  }

  sliceMethod() {
    if(this.stageData.length === 0) {
      this.accordian_config = this.accordian_config.slice(0,1);
    }else {
      this.accordian_config = this.accordian_config.slice(0,this.stageData.length+1);
    }
  }


  getChecklistData(event,stage?) {
    if(event && this.currentProduct ) {
        this.getData(stage);    
    } 
  }

  
  getData(stage) {
     let accordionData = this.accordian_config.find(accordion => accordion.stage === stage);
      accordionData.checklist = [];
      this.taskInfoService
        .getTaskInfo({ slug: CONSTANTS.SLUG['checklist'], master_data: false , app_id: this.appID, stage: stage,user_id:this.userId })
        .pipe(switchMap((res)=>{
            let currentChecklist = res?.response_data?.get_checklist?.data?.data.find(elem => elem.stage === stage);
            let stageData = _.get(res,'response_data.get_current_stage.data.data.stage');
            this.currentStage = stageData._id;
            
            accordionData['submitButtonEnable'] = this.isButtonEnable(accordionData);
            
            let tempChecklistData = this.tempaccordionData.find(accordion => accordion.stage === stage);
            accordionData.checklist = _.cloneDeep(tempChecklistData.checklist.filter(res=>res.product.includes(this.getStageCategory(stage))));
            
            if(currentChecklist) this.checklist_data[stage]=currentChecklist;
      
            if(currentChecklist && this.checkSameProduct(currentChecklist,stage)){
              accordionData.checklist = this.mergeArrayObjects(accordionData.checklist, currentChecklist['checklist']) ;
              const banker_ids = accordionData.checklist.filter(element=>element.backend_user_id).map(element => element.backend_user_id);    
              const unique_banker_ids = Array.from(new Set(banker_ids));
              if(!unique_banker_ids.length) return of({bankernotRequired: true });; 
              return this.taskInfoService.saveTaskInfo({slug: CONSTANTS.SLUG['banker-by-ids']}, {user_ids: unique_banker_ids});
            }
            return of({bankernotRequired: true });
          })
        )
        .subscribe((res) => {
          if(res.bankernotRequired) return;
          const bankerData = _.get(res,'get_banker_by_ids.data.data');
          accordionData.checklist.forEach(checklist => {
            if(checklist.backend_user_id) {
              checklist['banker_name']= bankerData.find(banker => checklist.backend_user_id === banker.id).name;
              checklist['updated_at'] = new Date(checklist.updated_at * 1000).toISOString();
            }
          })
        });

  }

  mergeArrayObjects(arr1,arr2): any{
    return arr1.map((item,i)=>{
       if(item?.checklist_id === arr2[i]?.checklist_id){
         return Object.assign({},item,arr2[i])
       }
    })
  }


  accordionSubmit(stage) {
    const selectedAccordian = this.accordian_config?.find(elem=> stage===elem?.stage);
    const update_checklist_data = this.checklist_data[stage];
    const checklist = [];
    let query = {};
      selectedAccordian.checklist.forEach(element => {
      let newChecklist= {
        checklist_id : element?.checklist_id,
        checklist_value : element?.checklist_value || null,
        checklist_action : "Submit",     
        order: element.order,
        comment : element.comment|| null
       }
       //tracking each checklist item and then  setting each checklist object according to conditions 
      if(update_checklist_data && this.currentProduct === update_checklist_data.product) {
        let oldChecklist =  update_checklist_data.checklist.find(elem => elem.checklist_id === element.checklist_id);

        if( (newChecklist.checklist_value && newChecklist.checklist_value !== oldChecklist.checklist_value)
            || (newChecklist.comment && newChecklist.comment !== oldChecklist.comment)) {
          newChecklist['backend_user_id']=this.backend_userData.user_id;
          newChecklist['updated_at']= Math.floor(Date.now()/1000);;  
         }else {
        //if there is no change in checklist value and comment 
          if(oldChecklist.backend_user_id) {
           newChecklist['backend_user_id'] = oldChecklist.backend_user_id;
           newChecklist['updated_at'] = oldChecklist.updated_at;
          }  
        }
      } else {
         if(newChecklist.checklist_value  || newChecklist.comment ) {
          newChecklist['backend_user_id']=this.backend_userData.user_id;
          newChecklist['updated_at']=  Math.floor(Date.now()/1000);;  
         }
      }
      checklist.push(newChecklist);
      });
    
    let payload = {
      product: this.currentProduct,
      checklist: checklist,
      accordion_key: stage,
      app_id: this.appID,
      role_id: this.backend_userData?.role_id,
      stage: selectedAccordian.stage,
      backend_user_id: this.backend_userData.user_id                  
    }
 
    if(update_checklist_data?._id) {
      query = {
        slug: CONSTANTS.SLUG['update_checklist'],
        checklist_id: update_checklist_data._id
      }
    } else {
      query = {slug: CONSTANTS.SLUG['submit_checklist']}
    }
    this.taskInfoService.saveTaskInfo(query,payload).subscribe(res=> {
      if(res.nextTask.value !=='error') {
          this.common.popToast('success', '', `Checklist submitted successfully`);
          this.getData(stage);
       }
    })
  }
   
  

  //get the product of current stage and if not , return current product
  getStageCategory(stage) {
    let particularStage = this.stageData.find(elem =>  elem.stage ===  stage);
    if(particularStage ) {
      return particularStage.product;
    } 
    return this.currentProduct;
  }

  checkSameProduct(currentChecklist,stage) {
    let particularStage = this.stageData.find(elem =>  elem.stage ===  stage);
    if(!particularStage && this.currentProduct === currentChecklist.product ) {
      //if no stage data and check current product with save checklist product,  merge  master checklist and old checklist data
      return true;
    } else if(particularStage && particularStage.product === currentChecklist.product) {
      //if product is same in both old checklist data and stage data , then dont merge 
      return true;
    }
    //if product is not same in both old checklist data and stage data , then don't merge
    return false;
  }
 
  isButtonEnable(accordionData) {
       let stagesUsers= this.appAssignment.filter(user => this.STAGEIDTYPEMAP[user.stage] === this.currentStage).map(user=> user.id);
       if( stagesUsers.length  && stagesUsers.includes(this.backend_userData.user_id) &&accordionData.stage === this.currentStage){
          return true;
       }
     
      return false;
     
       
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }
  
}
