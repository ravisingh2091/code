import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChecklistComponent } from './checklist/checklist.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';
import { Route, RouterModule } from '@angular/router';

export const routes: Route[] = [{ path: '', component: ChecklistComponent }];
@NgModule({
  imports: [CommonModule, SharedLazyModule, RouterModule.forChild(routes)],
  declarations: [ChecklistComponent],
})
export class ChecklistModule {}
