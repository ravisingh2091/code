import { Component, EventEmitter, Input, OnInit, Output, Inject, OnDestroy } from '@angular/core';
import { FormGroup } from '@angular/forms';
import {  Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { CommonService, FormGenerateService, TaskInfoService } from '@rubicon/utils';
import { take } from 'rxjs/operators';

@Component({
  selector: 'loan-type',
  templateUrl: './loan-type.component.html',
  styleUrls: ['./loan-type.component.scss']
})
export class LoanTypeComponent implements OnInit , OnDestroy{
  @Output() closeModal: EventEmitter<any> = new EventEmitter<any>();
  @Input() fromModal: boolean = false;
  slug: string = '';
  businessID: string = '';
  backendUser: any;
  banker_data: any;
  nextTask: string = '';
  application_status_id: string = '';
  appId: string = '';
  loadLoanTypeSubscription: Subscription;
  submitLoanTypeSubscription: Subscription;
  LoanTypeConfig = [];
  LoanTypeForm: FormGroup;
  constructor(
    private store: Store<any>,
    // private loanTypeFacade: LoanTypeFacade,
    private formGenerate: FormGenerateService,
    private common: CommonService,
    private taskInfoService: TaskInfoService,
    @Inject('CONSTANTS') public CONSTANTS,
    @Inject('environment' ) public environment
  ) { }

  ngOnInit(): void {
    this.store.select('app').pipe(take(1)).subscribe(rootState => {
      if(this.environment.journeyType === 'banker-journey'){
        this.application_status_id=rootState?.appData?.status_id;
        this.banker_data=rootState?.userData;
        this.appId = rootState?.appID
      }
      if (rootState ?.businessID) {
        this.businessID = rootState ?.businessID ? rootState.businessID : null;
        this.taskInfoService.getTaskInfo({ slug: this.CONSTANTS.SLUG['loan-type'], business_id: this.businessID }).subscribe(response => {
          if (response) {
            this.slug = response.task_slug;
            this.LoanTypeConfig = response.form_fields;
            this.LoanTypeForm = this.formGenerate.createControl(this.LoanTypeConfig);
            this.common.sendMasterDataToFields(this.LoanTypeConfig, response.response_data);
            const businessData = response ?.response_data ?.get_business_data ?.data ?.data;
            if (businessData.length && businessData[0]) {
              this.formGenerate.setFormValues(this.LoanTypeForm, businessData[0]);
            }
            this.common.updateStepState(this.CONSTANTS.APP_STEP[this.slug]);
          }
        });
      }
    });
  }
  addActivityLog(){
    const log_data = {
      role_slug:  this.banker_data?.role_slug,
      app_id: this.appId,
      backend_user_id: this.banker_data?.user_id,
      user_name: this.banker_data?.full_name,
      activity: 'application_edited'
    };
    this.common.addActivityLog(log_data);
  }

  onContinue(action: string) {
    if (this.formGenerate.validateCustomFormFields(this.LoanTypeForm, action, this.LoanTypeConfig)) {
      const payload = {
        business_id: this.businessID,
        ...this.LoanTypeForm.getRawValue(),
        action_type: action
      }
      this.taskInfoService.saveTaskInfo({ slug: 'loan-type' }, payload).subscribe(res => {
        if (res ?.nextTask ?.value) {
          if(this.environment.journeyType === 'banker-journey'){
            this.nextTask = action === 'continue' ? res.nextTask.value : 'manage-loans';
            if(action === 'save' && this.application_status_id!==this.CONSTANTS?.APPLICATION_STATUS?.application_in_progress) {
              this.addActivityLog()
            }
          }else{
            this.nextTask = action === 'continue' ? res.nextTask.value : 'dashboard';
          }
          this.common.navigate(this.nextTask, this.businessID);
        }
      });
    }
  }

  ngOnDestroy() {
    this.common.updateStepState(0);
  }
}
