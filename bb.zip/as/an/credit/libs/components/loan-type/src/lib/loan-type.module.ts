import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Route, RouterModule } from '@angular/router';
import { LoanTypeComponent } from './loan-type/loan-type.component';
import { SharedLazyModule } from '@credit-bench/shared-lazy';

export const loantypeRoute: Route[] = [
  {
    path:'' , component: LoanTypeComponent
  }
];

@NgModule({
  declarations: [LoanTypeComponent],
  imports: [
    RouterModule.forChild(loantypeRoute),
    CommonModule,
    SharedLazyModule
  ]
})
export class LoanTypeModule { }
