export const ROLE_STAGE_MAP = {
    loan_officer: ['loan_officer_l1', 'loan_officer_l2'],
    fulfillment_services: ['fulfillment_services_l1', 'fulfillment_services_l2'],
    pre_underwriting: ['loan_officer_l1', 'loan_officer_l2'],
    underwriting: ['underwriter_l1', 'underwriter_l2'],
    pre_closing: ['closing_team_l1', 'closing_team_l2'],
    quality_assurance: ['quality_assurance_l1', 'quality_assurance_l2'],
    closing: ['closing_team_l1', 'closing_team_l2'],
}

export const UPDATE_CATEGORY_AVAILABLITY = {
    loan_officer: true,
    fulfillment_services: true,
    pre_underwriting: true,
    underwriting: true,
    pre_closing: false,
    quality_assurance: false,
    closing: false,
}

export const SEND_TO_LASERPRO_AVAILABLITY = {
    loan_officer: false,
    fulfillment_services: false,
    pre_underwriting: false,
    underwriting: false,
    pre_closing: true,
    quality_assurance: false,
    closing: true
}

export const COMPLETE_APPLICATION_AVAILABLITY = {
    loan_officer: true,
    fulfillment_services: false,
    pre_underwriting: false,
    underwriting: false,
    pre_closing: false,
    quality_assurance: false,
    closing: false
}

export const ASSIGNMENT_ACTIONS = {

    /* action structure to easy access */
    // stage: {
    //     current_role: {
    //         to_role: {

    //         }
    //     }
    // }

    loan_officer: {
        loan_officer_l1: {
            loan_officer_l2: {action: 'SENIOR_LO_ASSIGN_TO_JUNIOR_LO', next_stage: 'loan_officer', unassign: true},
            loan_officer_l1: {action: 'SENIOR_LO_ASSIGN_TO_SENIOR_LO', next_stage: 'loan_officer' , unassign: true},
            fulfillment_services_l1: {action: 'SENIOR_LO_ASSIGN_TO_SENIOR_FS',next_stage: 'fulfillment_services', sub_status_id : "60cf9e1cf49aab0d7ca97f20"}
        },
        loan_officer_l2: {
            fulfillment_services_l1: {action: 'JUNIOR_LO_ASSIGN_TO_SENIOR_FS',next_stage: 'fulfillment_services',sub_status_id : "60cf9e1cf49aab0d7ca97f20"}
        }
    },
    fulfillment_services: {
        fulfillment_services_l1:{
            fulfillment_services_l1: {action: 'SENIOR_FS_ASSIGN_TO_SENIOR_FS', next_stage: 'fulfillment_services', unassign: true},
            fulfillment_services_l2: {action: 'SENIOR_FS_ASSIGN_TO_JUNIOR_FS', next_stage: 'fulfillment_services', unassign: true},
            loan_officer_l1: {action: 'SENIOR_FS_ASSIGN_TO_PRE_UW_SR_LO', next_stage: 'pre_underwriting',sub_status_id : "60d9d5fc67b48ec7788b7af8"},
            loan_officer_l2: {action: 'SENIOR_FS_ASSIGN_TO_PRE_UW_SR_LO', next_stage: 'pre_underwriting',sub_status_id : "60d9d5fc67b48ec7788b7af8"}
        },
        fulfillment_services_l2: {
            loan_officer_l1: {action: 'JUNIOR_FS_ASSIGNED_TO_PRE_UW_SR_LO',next_stage: 'pre_underwriting',sub_status_id : "60d9d5fc67b48ec7788b7af8"},
            loan_officer_l2: {action: 'JUNIOR_FS_ASSIGNED_TO_PRE_UW_SR_LO', next_stage: 'pre_underwriting',sub_status_id : "60d9d5fc67b48ec7788b7af8"}
        }
    },
    pre_underwriting: {
        loan_officer_l1: {
            loan_officer_l1: {action: 'SENIOR_PRE_UW_LO_ASSIGN_TO_SENIOR_PRE_UW_LO', next_stage: 'pre_underwriting', unassign: true},
            loan_officer_l2: {action: 'SENIOR_PRE_UW_LO_ASSIGN_TO_JUNIOR_PRE_UW_LO', next_stage: 'pre_underwriting', unassign: true},
            underwriter_l1: {action: 'SENIOR_PRE_UW_LO_ASSIGN_TO_SR_UW', next_stage: 'underwriting',sub_status_id : "60d9d5fc67b48ec7788b7b01"}
        },
        loan_officer_l2: {
            underwriter_l1: {action: 'JUNIOR_PRE_UW_LO_ASSIGN_TO_SR_UW', next_stage: 'underwriting',sub_status_id : "60d9d5fc67b48ec7788b7b01"}
        }
    },
    underwriting: {
        underwriter_l1: {
            underwriter_l1: {action: 'SENIOR_UW_ASSIGN_TO_SENIOR_UW', next_stage: 'underwriting', unassign: true},
            underwriter_l2: {action: 'SENIOR_UW_ASSIGN_TO_JUNIOR_UW', next_stage: 'underwriting', unassign: true},
            closing_team_l1: {action: 'SENIOR_UW_ASSIGN_TO_PRE_CLOSING_SR_Closing', next_stage: 'pre_closing',sub_status_id : "60d9d5fc67b48ec7788b7b08"}
        },
        underwriter_l2: {
            closing_team_l1: {action: 'JUNIOR_UW_ASSIGN_TO_PRE_CLOSING_SR_Closing',next_stage: 'pre_closing',sub_status_id : "60d9d5fc67b48ec7788b7b08"}
        },
    },
    pre_closing: {
        closing_team_l1: {
            closing_team_l1: {action: 'SENIOR_PRE_Closing_ASSIGN_TO_SENIOR_PRE_Closing', next_stage: 'pre_closing', unassign: true},
            closing_team_l2: {action: 'SENIOR_PRE_Closing_ASSIGN_TO_JUNIOR_PRE_Closing', next_stage: 'pre_closing', unassign: true},
            quality_assurance_l1: {action: 'SENIOR_PRE_Closing_ASSIGN_TO_QA', next_stage: 'quality_assurance',sub_status_id : "60d9d5fc67b48ec7788b7b0c"}
        },
        closing_team_l2: {
            quality_assurance_l1: {action: 'JUNIOR_PRE_Closing_ASSIGN_TO_QA', next_stage: 'quality_assurance',sub_status_id : "60d9d5fc67b48ec7788b7b0c"}
        }
    },
    quality_assurance: {
        quality_assurance_l1: {
            quality_assurance_l1: {action: 'SENIOR_QA_ASSIGN_TO_SENIOR_QA', next_stage: 'quality_assurance', unassign: true},
            quality_assurance_l2: {action: 'SENIOR_QA_ASSIGN_TO_JUNIOR_QA', next_stage: 'quality_assurance', unassign: true},
            closing_team_l1: {action: 'SENIOR_QA_ASSIGN_TO_CLOSING',next_stage: 'closing',sub_status_id : "60d9d5fc67b48ec7788b7b11"},
            closing_team_l2: {action: 'SENIOR_QA_ASSIGN_TO_CLOSING',next_stage: 'closing',sub_status_id : "60d9d5fc67b48ec7788b7b11"}
        },
        quality_assurance_l2: {
            closing_team_l1: {action: 'JUNIOR_QA_ASSIGN_TO_CLOSING', next_stage: 'closing',sub_status_id : "60d9d5fc67b48ec7788b7b11"},
            closing_team_l2: {action: 'JUNIOR_QA_ASSIGN_TO_CLOSING', next_stage: 'closing',sub_status_id : "60d9d5fc67b48ec7788b7b11"}

        },
    },
    closing: {
        closing_team_l1: {
            closing_team_l1: {action: 'SENIOR_Closing_ASSIGN_TO_SENIOR_Closing', next_stage: 'closing', unassign: true},
            closing_team_l2: {action: 'SENIOR_Closing_ASSIGN_TO_JUNIOR_Closing', next_stage: 'closing', unassign: true}
        },
        closing_team_l2: {

        },
    },
    soft_declined: {

    },
    declined: {

    },

}
   
export const ROLE_LISTING = {
    loan_officer: {
        loan_officer_l1: ['loan_officer_l1', 'loan_officer_l2', 'fulfillment_services_l1'],
        loan_officer_l2: ['fulfillment_services_l1']
    },
    fulfillment_services: {
        fulfillment_services_l1:['fulfillment_services_l1', 'fulfillment_services_l2', 'loan_officer_l1', 'loan_officer_l2'],
        fulfillment_services_l2:['loan_officer_l1', 'loan_officer_l2']
    },
    pre_underwriting: {
        loan_officer_l1: ['loan_officer_l1', 'loan_officer_l2', 'underwriter_l1'],
        loan_officer_l2: ['underwriter_l1'],
    },
    underwriting: {
        underwriter_l1: ['underwriter_l1', 'underwriter_l2', 'closing_team_l1'],
        underwriter_l2: ['closing_team_l1'],
    },
    pre_closing: {
        closing_team_l1: ['closing_team_l1', 'closing_team_l2', 'quality_assurance_l1'],
        closing_team_l2: ['quality_assurance_l1'],
    },
    quality_assurance: {
        quality_assurance_l1: ['quality_assurance_l1', 'quality_assurance_l2', 'closing_team_l1' ,'closing_team_l2'],
        quality_assurance_l2: ['closing_team_l1', 'closing_team_l2'],
    },
    closing: {
        closing_team_l1: ['closing_team_l1', 'closing_team_l2'],
        closing_team_l2: [],
    },
    soft_declined: {

    },
    declined: {

    },
}

export const STATUS_ACTIONS = {
    loan_officer: {
        loan_officer_l1: {
            "APP_ASSIGN_TO_LO": {
                action: "SR_LO_STATUS_TO_ASSIGNED_TO_LO",
                params: { status_id: '5c20bf7e27105c78ad7f9282' }
            },
            "APP_REVIEW_IN_PROGRESS_LO": {
                action: "SR_LO_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9282' }
            },
            "REVIEW_COMPLETED_LO": {
                action: "SR_LO_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: '5c20bf7e27105c78ad7f9282' }
            },
            "APP_DECLINED_LO": {
                action: "SR_LO_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            },
            "APP_WITHDRAWN_LO": {
                action: "SR_LO_STATUS_TO_APP_SOFT_WITHDRAWN",
                params: { status_id: "60d22bf23c05824838f8fe6b" },
                soft_withdrawn: true
            },
        },
        loan_officer_l2: {
            "APP_ASSIGN_TO_LO": {
                action: "JR_LO_STATUS_TO_ASSIGNED_TO_LO",
                params: { status_id: '5c20bf7e27105c78ad7f9282' }
            },
            "APP_REVIEW_IN_PROGRESS_LO": {
                action: "JR_LO_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9282' }
            },
            "REVIEW_COMPLETED_LO": {
                action: "JR_LO_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: '5c20bf7e27105c78ad7f9282'}
            },
            "APP_DECLINED_LO": {
                action: "JR_LO_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: '60bdfb51c0a3494024772c0d' },
                soft_declined: true
            },
            "APP_WITHDRAWN_LO": {
                action: "JR_LO_STATUS_TO_APP_SOFT_WITHDRAWN",
                params: { status_id: "60d22bf23c05824838f8fe6b" },
                soft_withdrawn: true
            }
        }
    },
    fulfillment_services: {
        fulfillment_services_l1: {
            "APP_ASSIGNED_TO_FS": {
                action: "SR_FS_STATUS_TO_ASSIGNED_TO_FS",
                params: { status_id: '5c20bf7e27105c78ad7f9283' }
            },
            "APP_REVIEW_IN_PROGRESS_FS": {
                action: "SR_FS_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9283' }
            },
            "ADDITIONAL_INFO_REQUESTED_FS": {
                action: "SR_FS_STATUS_TO_ADDITIONAL_INFO_REQUESTED",
                params: { status_id: '5c20bf7e27105c78ad7f9283' }
            },
            "REVIEW_COMPLETED_FS": {
                action: "SR_FS_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: "5c20bf7e27105c78ad7f9283" }
            },
            "APP_DECLINED_FS": {
                action: "SR_FS_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            },
            "APP_WITHDRAWN_FS": {
                action: "SR_FS_STATUS_TO_APP_SOFT_WITHDRAWN",
                params: { status_id: "60d22bf23c05824838f8fe6b" },
                soft_withdrawn: true
            }
        },
        fulfillment_services_l2: {
            "APP_ASSIGNED_TO_FS": {
                action: "JR_FS_STATUS_TO_ASSIGNED_TO_FS",
                params: { status_id: '5c20bf7e27105c78ad7f9283' }
            },
            "APP_REVIEW_IN_PROGRESS_FS": {
                action: "JR_FS_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9283' }
            },
            "ADDITIONAL_INFO_REQUESTED_FS": {
                action: "JR_FS_STATUS_TO_ADDITIONAL_INFO_REQUESTED",
                params: { status_id: '5c20bf7e27105c78ad7f9283' }
            },
            "REVIEW_COMPLETED_FS": {
                action: "JR_FS_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: "5c20bf7e27105c78ad7f9283" }
            },
            "APP_DECLINED_FS": {
                action: "JR_FS_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            },
            "APP_WITHDRAWN_FS": {
                action: "JR_FS_STATUS_TO_APP_SOFT_WITHDRAWN",
                params: { status_id: "60d22bf23c05824838f8fe6b" },
                soft_withdrawn: true

            }
        },
    },
    pre_underwriting: {
        loan_officer_l1: {
            "APP_ASSIGN_TO_PRE_UW_LO": {
                action: "SR_PRE_UW_LO_STATUS_TO_ASSIGNED_TO_PRE_UW_LO",
                params: { status_id: '5c20bf7e27105c78ad7f9284' }
            },
            "APP_REVIEW_IN_PROGRESS_PRE_UW_LO": {
                action: "SR_PRE_UW_LO_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9284' }
            },
            "ADDITIONAL_INFO_REQUESTED_PRE_UW_LO": {
                action: "SR_PRE_UW_LO_STATUS_TO_ADDITIONAL_INFO_REQUESTED",
                params: { status_id: '5c20bf7e27105c78ad7f9284' }
            },
            "TERM_LETTER_APPROVAL_PENDING_PRE_UW_LO": {
                action: "SR_PRE_UW_LO_STATUS_TO_TERM_LETTER_APPROVAL_PENDING",
                params: { status_id: "5c20bf7e27105c78ad7f9284" }
            },
            "TERM_LETTER_APPROVED_PRE_UW_LO": {
                action: "SR_PRE_UW_LO_STATUS_TO_TERM_LETTER_APPROVED",
                params: { status_id: "5c20bf7e27105c78ad7f9284" }
            },
            "REVIEW_COMPLETED_PRE_UW_LO": {
                action: "SR_PRE_UW_LO_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: "5c20bf7e27105c78ad7f9284" }
            },
            "APP_DECLINED_PRE_UW_LO": {
                action: "SR_PRE_UW_LO_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            },
            "APP_WITHDRAWN_PRE_UW_LO": {
                action: "SR_PRE_UW_LO_STATUS_TO_APP_SOFT_WITHDRAWN",
                params: { status_id: "60d22bf23c05824838f8fe6b" },
                soft_withdrawn: true

            }
        },
        loan_officer_l2: {
            "APP_ASSIGN_TO_PRE_UW_LO": {
                action: "JR_PRE_UW_LO_STATUS_TO_ASSIGNED_TO_PRE_UW_LO",
                params: { status_id: '5c20bf7e27105c78ad7f9284' }
            },
            "APP_REVIEW_IN_PROGRESS_PRE_UW_LO": {
                action: "JR_PRE_UW_LO_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9284' }
            },
            "ADDITIONAL_INFO_REQUESTED_PRE_UW_LO": {
                action: "JR_PRE_UW_LO_STATUS_TO_ADDITIONAL_INFO_REQUESTED",
                params: { status_id: '5c20bf7e27105c78ad7f9284' }
            },
            "TERM_LETTER_APPROVAL_PENDING_PRE_UW_LO": {
                action: "JR_PRE_UW_LO_STATUS_TO_TERM_LETTER_APPROVAL_PENDING",
                params: { status_id: "5c20bf7e27105c78ad7f9284" }
            },
            "TERM_LETTER_APPROVED_PRE_UW_LO": {
                action: "JR_PRE_UW_LO_STATUS_TO_TERM_LETTER_APPROVED",
                params: { status_id: "5c20bf7e27105c78ad7f9284" }
            },
            "REVIEW_COMPLETED_PRE_UW_LO": {
                action: "JR_PRE_UW_LO_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: "5c20bf7e27105c78ad7f9284" }
            },
            "APP_DECLINED_PRE_UW_LO": {
                action: "JR_PRE_UW_LO_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            },
            "APP_WITHDRAWN_PRE_UW_LO": {
                action: "JR_PRE_UW_LO_STATUS_TO_APP_SOFT_WITHDRAWN",
                params: { status_id: "60d22bf23c05824838f8fe6b" },
                soft_withdrawn: true
            }
        }
    },
    underwriting: {
        underwriter_l1: {
            "APP_ASSIGNED_TO_UW": {
                action: "SR_UW_STATUS_TO_ASSIGNED_TO_UW",
                params: { status_id: '60cf935635f4bc612456ac8c' }
            },
            "APP_REVIEW_IN_PROGRESS_UW": {
                action: "SR_UW_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '60cf935635f4bc612456ac8c' },
                app_resume: true
            },
            "ADDITIONAL_INFO_REQUESTED_UW": {
                action: "SR_UW_STATUS_TO_ADDITIONAL_INFO_REQUESTED",
                params: { status_id: '60cf935635f4bc612456ac8c' }
            },
            "PENDING_APPROVALS_UW": {
                action: "SR_UW_STATUS_TO_PENDING_APPROVALS",
                params: { status_id: "60cf935635f4bc612456ac8c" }
            },
            "APP_APPROVED_UW": {
                action: "SR_UW_STATUS_TO_APP_APPROVED",
                params: { status_id: "60cf935635f4bc612456ac8c" }
            },  
            "APP_DECLINED_UW": {
                action: "SR_UW_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            }
             
        },
        underwriter_l2: {
            "APP_ASSIGNED_TO_UW": {
                action: "JR_UW_STATUS_TO_ASSIGNED_TO_UW",
                params: { status_id: '60cf935635f4bc612456ac8c' }
            },
            "APP_REVIEW_IN_PROGRESS_UW": {
                action: "JR_UW_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '60cf935635f4bc612456ac8c' },
                app_resume: true
            },
            "ADDITIONAL_INFO_REQUESTED_UW": {
                action: "JR_UW_STATUS_TO_ADDITIONAL_INFO_REQUESTED",
                params: { status_id: '60cf935635f4bc612456ac8c' }
            },
            "PENDING_APPROVALS_UW": {
                action: "JR_UW_STATUS_TO_PENDING_APPROVALS",
                params: { status_id: "60cf935635f4bc612456ac8c" }
            },
            "APP_APPROVED_UW": {
                action: "JR_UW_STATUS_TO_APP_APPROVED",
                params: { status_id: "60cf935635f4bc612456ac8c" }
            },  
            "APP_DECLINED_UW": {
                action: "JR_UW_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            }
        },
    },
    pre_closing: {
        closing_team_l1: {
            "COMMITMENT_LETTER_APPROVAL_PENDING_PRE_CLOSING": {
                action: "SR_PRE_CLOSING_STATUS_TO_COMMITMENT_LETTER_APPROVAL_PENDING",
                params: { status_id: '5c20bf7e27105c78ad7f9285' }
            },
            "APP_ASSIGN_TO_PRE_CLOSING": {
                action: "SR_PRE_CLOSING_STATUS_TO_ASSIGNED_TO_PRE_CLOSING",
                params: { status_id: '5c20bf7e27105c78ad7f9285' }
            },
            "APP_REVIEW_IN_PROGRESS_PRE_CLOSING": {
                action: "SR_PRE_CLOSING_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9285' }
            },
            "REVIEW_COMPLETED_PRE_CLOSING": {
                action: "SR_PRE_CLOSING_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: '5c20bf7e27105c78ad7f9285' }
            },
            "APP_DECLINED_PRE_CLOSING": {
                action: "SR_PRE_CLOSING_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            }
        },
        closing_team_l2: {
            "COMMITMENT_LETTER_APPROVAL_PENDING_PRE_CLOSING": {
                action: "JR_PRE_CLOSING_STATUS_TO_COMMITMENT_LETTER_APPROVAL_PENDING",
                params: { status_id: '5c20bf7e27105c78ad7f9285' }
            },
            "APP_ASSIGN_TO_PRE_CLOSING": {
                action: "JR_PRE_CLOSING_STATUS_TO_ASSIGNED_TO_PRE_CLOSING",
                params: { status_id: '5c20bf7e27105c78ad7f9285' }
            },
            "APP_REVIEW_IN_PROGRESS_PRE_CLOSING": {
                action: "JR_PRE_CLOSING_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9285' }
            },
            "REVIEW_COMPLETED_PRE_CLOSING": {
                action: "JR_PRE_CLOSING_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: '5c20bf7e27105c78ad7f9285' }
            },
            "APP_DECLINED_PRE_CLOSING": {
                action: "JR_PRE_CLOSING_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            }
        }
    },
    quality_assurance: {
        quality_assurance_l1: {
            "APP_ASSIGN_TO_QA": {
                action: "SR_QA_STATUS_TO_APP_ASSIGNED_TO_QA",
                params: { status_id: '5c20bf7e27105c78ad7f9286' }
            },
            "APP_REVIEW_IN_PROGRESS_QA": {
                action: "SR_QA_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9286' }
            },
            "REVIEW_COMPLETED_QA": {
                action: "SR_QA_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: '5c20bf7e27105c78ad7f9286' }
            },
            "APP_DECLINED_QA": {
                action: "SR_QA_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            }
        },
        quality_assurance_l2: {
            "APP_ASSIGN_TO_QA": {
                action: "JR_QA_STATUS_TO_APP_ASSIGNED_TO_QA",
                params: { status_id: '5c20bf7e27105c78ad7f9286' }
            },
            "APP_REVIEW_IN_PROGRESS_QA": {
                action: "JR_QA_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9286' }
            },
            "REVIEW_COMPLETED_QA": {
                action: "JR_QA_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: '5c20bf7e27105c78ad7f9286' }
            },
            "APP_DECLINED_QA": {
                action: "JR_QA_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            }
        },
    },
    closing: {
        closing_team_l1: {
            "APP_ASSIGN_TO_CLOSING": {
                action: "SR_Closing_STATUS_TO_APP_ASSIGNED_TO_Closing",
                params: { status_id: '5c20bf7e27105c78ad7f9287' }
            },
            "APP_REVIEW_IN_PROGRESS_CLOSING": {
                action: "SR_Closing_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9287' }
            },
            "REVIEW_COMPLETED_CLOSING": {
                action: "SR_Closing_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: '5c20bf7e27105c78ad7f9287' }
            },
            "APP_DECLINED_CLOSING": {
                action: "SR_Closing_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            },
            "APP_COMPLETED_CLOSING": {
                action: "SR_Closing_STATUS_TO_APP_COMPLETED",
                params: { status_id: "5c20bf7e27105c78ad7f9288" }
            }
        },
        closing_team_l2: {
            "APP_ASSIGN_TO_CLOSING": {
                action: "JR_Closing_STATUS_TO_APP_ASSIGNED_TO_Closing",
                params: { status_id: '5c20bf7e27105c78ad7f9287' }
            },
            "APP_REVIEW_IN_PROGRESS_CLOSING": {
                action: "JR_Closing_STATUS_TO_REVIEW_IN_PROGRESS",
                params: { status_id: '5c20bf7e27105c78ad7f9287' }
            },
            "REVIEW_COMPLETED_CLOSING": {
                action: "JR_Closing_STATUS_TO_REVIEW_COMPLETED",
                params: { status_id: '5c20bf7e27105c78ad7f9287' }
            },
            "APP_DECLINED_CLOSING": {
                action: "JR_Closing_STATUS_TO_APP_SOFT_DECLINED",
                params: { status_id: "60bdfb51c0a3494024772c0d" },
                soft_declined: true
            },
            "APP_COMPLETED_CLOSING": {
                action: "JR_Closing_STATUS_TO_APP_COMPLETED",
                params: { status_id: "5c20bf7e27105c78ad7f9288"}
            }
        },
    },
    soft_declined: {

    },
    declined: {

    }
}

export const ROLE_SLUG = {
    loan_officer_l1:{ loan_officer:  'LO', pre_underwriting: 'PUW', default: 'LO' },
    loan_officer_l2: { loan_officer:  'LO', pre_underwriting: 'PUW', default: 'LO' },
    fulfillment_services_l1: { fulfillment_services:  'LPT', default: 'LPT' },
    fulfillment_services_l2: { fulfillment_services:  'LPT', default: 'LPT' },
    underwriter_l1: { underwriting: 'UW', default: 'UW' },
    underwriter_l2: { underwriting: 'UW', default: 'UW' },
    closing_team_l1: { closing:  'Closing', pre_closing: 'Pre Closing', default: 'Closing'},
    closing_team_l2: { closing:  'Closing', pre_closing: 'Pre Closing', default: 'Closing'},
    quality_assurance_l1: { quality_assurance:  'QA', default: 'QA'},
    quality_assurance_l2: { quality_assurance:  'QA', default: 'QA'},
}

export const STAGE = {
    loan_officer: 'LO',
    pre_underwriting: 'PUW',
    fulfillment_services: 'LPT',
    underwriting: 'UW',
    closing: 'Closing',
    pre_closing: 'Pre Closing',
    quality_assurance: 'QA'
}
export const STAGE_ROLE_MAP = {
    loan_officer_l1: ['loan_officer', 'pre_underwriting'],
    loan_officer_l2: ['loan_officer', 'pre_underwriting'],
    fulfillment_services_l1: ['fulfillment_services'],
    fulfillment_services_l2: ['fulfillment_services'],
    underwriter_l1: ['underwriting'],
    underwriter_l2: ['underwriting'],
    closing_team_l1: ['closing', 'pre_closing'],
    closing_team_l2: ['closing', 'pre_closing'],
    quality_assurance_l1: ['quality_assurance'],
    quality_assurance_l2: ['quality_assurance'],
}

export const ASSIGN_TO_ROLE_TYPE = {
    fulfillment_services : {
        loan_officer_l1 : "Senior Pre-Underwriting Team",
        loan_officer_l2 : "Junior Pre-Underwriting Team"
    },
    pre_underwriting : {
        loan_officer_l1 : "Senior Pre-Underwriting Team",
        loan_officer_l2 : "Junior Pre-Underwriting Team"
    },
    underwriting : {
        closing_team_l1 : "Senior Pre-Closing",
        closing_team_l2 : "Junior Pre-Closing"
    },
    pre_closing : {
        closing_team_l1 : "Senior Pre-Closing",
        closing_team_l2 : "Junior Pre-Closing"
    }
}

export const ASSIGNMENT_CONDITIONS = {
    fulfillment_services : {stage : 'loan_officer', roles : ['loan_officer_l1', 'loan_officer_l2']},
    quality_assurance : {stage : 'pre_closing', roles : ['closing_team_l1', 'closing_team_l2']}
}
// export const FILTER_ROLE = {
//     /* current role: {
//         child_role: true
//     } */

//     loan_officer_l1: {
//         loan_officer_l2: true
//     },
//     fulfillment_services_l1: {
//         fulfillment_services_l2: true
//     },
//     underwriter_l1: {
//         underwriter_l2: true,
//     },
//     closing_team_l1: {
//         closing_team_l2: true,
//     },
//     quality_assurance_l1: {
//         quality_assurance_l2: true,
//     },
// }

export const getAssignmentAction = (currentStage, currentRole, toRole) => {
    try {
        return ASSIGNMENT_ACTIONS[currentStage][currentRole][toRole].action;
    } catch(e) {
        return null;
    }
}

export const getStatusAction = (currentStage, currentRole, action) => {
    try {
        return STATUS_ACTIONS[currentStage][currentRole][action];
    } catch(e) {
        return null;
    }
}

export const isAppSoftDecline = (currentStage, currentRole, action) => {
    try {
        return STATUS_ACTIONS[currentStage][currentRole][action].soft_declined;
    } catch(e) {
        return null;
    }
}

export const isAppSoftWithdrawn = (currentStage, currentRole, action) => {
    try {
        return STATUS_ACTIONS[currentStage][currentRole][action].soft_withdrawn;
    } catch(e) {
        return null;
    }
}

export const isAppResume = (currentStage, currentRole, action) => {
    try {
        return STATUS_ACTIONS[currentStage][currentRole][action].app_resume;
    } catch(e) {
        return null;
    }
}

export const getShortRole = (role_slug, stage?: any) => {
    return stage ? ROLE_SLUG[role_slug][stage] : ROLE_SLUG[role_slug]?.default;
}

export const getShortStage = (stage?: any) => {
    return STAGE[stage] ? STAGE[stage] : null;
}

// export const getFilterReporting = (role, child_role) => {
//     return FILTER_ROLE[role] && FILTER_ROLE[role][child_role];
// }

export const isStageActionAllowed = (currentStage, currentRole) => {
    const stageRoles = ROLE_STAGE_MAP[currentStage];
    if(stageRoles) {
        return stageRoles.find((r) => r === currentRole);
    }
}

export const getStageFromRole = (role_slug) => {
    const stageRoles = STAGE_ROLE_MAP[role_slug];
    return stageRoles;
}

export const getNextStage = (currentStage, currentRole, toRole) => {
    try {
        return ASSIGNMENT_ACTIONS[currentStage][currentRole][toRole].next_stage;
    } catch(e) {
        return null;
    }
}

export const getisUnassign = (currentStage, currentRole, toRole) => {
    try {
        return ASSIGNMENT_ACTIONS[currentStage][currentRole][toRole].unassign;
    } catch(e) {
        return null;
    }
}

export const getisJuniorUnassign = (currentStage, currentRole, toRole) => {
    try {
        return ASSIGNMENT_ACTIONS[currentStage][currentRole][toRole].unassign_junior;
    } catch(e) {
        return null;
    }
}

export const getNextSubStatus = (currentStage, currentRole, toRole) => {
    try {
        return ASSIGNMENT_ACTIONS[currentStage][currentRole][toRole].sub_status_id;
    } catch(e) {
        return null;
    }
}

export const isFilteredAssignment = (current_stage, role_slug) => {
    return ASSIGNMENT_CONDITIONS[current_stage] && ASSIGNMENT_CONDITIONS[current_stage].roles.includes(role_slug);
}

export const getRoleName = (current_stage, role_slug) => {
    try {
        return ASSIGN_TO_ROLE_TYPE[current_stage][role_slug];
    } catch(e) {
        return false;
    }
}