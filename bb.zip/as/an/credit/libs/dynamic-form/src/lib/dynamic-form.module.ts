import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DynamicComponent } from './components/dynamic/dynamic.component';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { UtilsModule } from '@rubicon/utils';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

// Directives
import { FieldDirective } from './directives/field.directive';

// Component
import {
  TextComponent, NumberComponent, PasswordComponent, RadioComponent,
  SliderComponent, CheckboxComponent, SwitchComponent, TelComponent, DateComponent,
  SelectComponent, GroupComponent, TextareaComponent, FileComponent, AmountComponent,
  LabelComponent, ButtonComponent
} from './components/form-fields';

import { Ng5SliderModule } from 'ng5-slider';
import { NgxMaskModule } from 'ngx-mask';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  imports: [
    CommonModule,
    Ng5SliderModule,
    TooltipModule.forRoot(),
    UtilsModule,
    ReactiveFormsModule,
    TranslateModule.forChild(),
    BsDatepickerModule.forRoot(),
    NgxMaskModule,
    NgSelectModule
  ],
  declarations: [
    DynamicComponent,
    FieldDirective,
    TextComponent,
    DateComponent,
    NumberComponent,
    SwitchComponent,
    TelComponent,
    TextareaComponent,
    PasswordComponent,
    FileComponent,
    GroupComponent,
    CheckboxComponent,
    RadioComponent,
    SliderComponent,
    SelectComponent,
    AmountComponent,
    LabelComponent,
    ButtonComponent
  ],
  exports: [
    Ng5SliderModule,
    DynamicComponent,
    FieldDirective,
    TextComponent,
    DateComponent,
    NumberComponent,
    SwitchComponent,
    TelComponent,
    TextareaComponent,
    PasswordComponent,
    FileComponent,
    GroupComponent,
    CheckboxComponent,
    RadioComponent,
    SliderComponent,
    SelectComponent,
    AmountComponent,
    LabelComponent,
    ButtonComponent
  ]
})
export class DynamicFormModule {}
