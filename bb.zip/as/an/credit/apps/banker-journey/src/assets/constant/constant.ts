import  { environment } from '../../environments/environment';

export const  CONSTANTS = {
    
      FOOTER_CONGIF: {
        footer_text: environment.copyright_text 
      },
      CLIENT_CONFIG: {
        title: environment.title,
        name: environment.client_name,
        project_name: environment.project_name,
        addressl: environment.client_addressl,
        city: environment.client_city,
        state: environment.client_state,
        country: environment.client_country,
        zipcode: environment.client_zipcode,
        client_url: environment.client_url,
        privacy_url: environment.privacy,
        siteMap_url: environment.siteMap,
        terms_url: environment.terms,
        no_reply_mail: environment.noreplymail
      },
    SLUG: {
        'banker_signin': 'banker_signin',
        'manage_leads_filter': 'manage_leads_filter',
        'change-password': 'change-password',
        'reset-password' : 'reset-password',
        'manage_leads': 'manage_leads',
        'banker_create_application': 'banker_create_application',
        'get-users-details' : 'get-users-details',
        'loan-applications' : 'dashboard',
        'manage_loans_filter':'manage_loans_filter',
        'update_lead_status': 'update_lead_status',
        'manage_loans':'manage_loans',
        'add_notes': 'add_notes',
        'additional_information' : 'additional_information',
        'application_info': 'application_info',
        'update_loan_status': 'update_loan_status',
        'update_product' : 'update_product',
        'add_loan_notes': 'add_loan_notes',
        'business_financial': 'business_financial',
        'personal_financial': 'personal_financial',
        'cashflow_comment': 'cashflow_comment',
        'select_irs_type':'select_irs_type',
        'irs_online_owner':'irs_online_owner',
        'irs_online_Business':'irs_online_Business',
        'underwriter_accordion_info': 'underwriter_accordion_info',
        'application_detail': 'application_detail',
        'irs_manual_owner':'irs_manual_owner',
        'irs_manual_business':'irs_manual_business',
        'submit_checklist': 'submit_checklist',
        'update_checklist': 'update_checklist',
        'checklist': 'checklist',
        'bank_statement_summary': 'bank_statement_summary',
        'sba_form601': 'sba_form601',
        'sba_form1050': 'sba_form1050',
        'credit_approval_form': 'credit_approval_form',
        'approval_decision_form': 'approval_decision_form',
        'decline_decision_form': 'decline_decision_form',
        'withdrawn_decision_form': 'withdrawn_decision_form',
        'your_vote_loanDecision': 'your_vote_loanDecision',
        'collateral-reportable':'collateral_reportable',      
        'get_caf_data': 'get_caf_data',
        'get_caf_decision_history': 'get_caf_decision_history',
        'evaluation_cra': 'evaluation_cra', 
        'get_application_products': 'get_application_products',
        'gdscr': 'gdscr',
        'sba_tab': 'sba_tab',
        'sbaforms': 'sbaforms',
        'activity_logs': 'activity_logs',
        'update_sbaform': 'update_sbaform',
        'real_estate_form': 'real-estate-form',
        'aba_from': 'aba-form',
        'real_estate_valuation_form': 'real-estate-valuation-form',
        'aba_valuation_from': 'aba-valuation-form',
        'caf_pdf_data': 'caf_pdf_data',
        'collateral_extra_info_form': 'collateral-extra-info-form',
        'hmda':'hmda',
        'download_analyis_pdf':'download_analyis_pdf',
        'resend_form_1919': 'resend_form_1919',
        'esign_sba1919': 'esign_sba1919',
        'form_1919': 'form_1919',
        'request_owners_consent':'request_owners_consent',
        'get_owner_reference': 'get_owner_reference',
        'document_widget_data': 'document-widget-data',
        'get_backend_users': 'get_backend_users',
        'collateral_evaluation_analysis': 'collateral_evaluation_analysis',
        'start_an_application': 'start_an_application',
        'download-document': 'download-document',
        'loan-type': 'loan-type',
        'application-current-stage': 'application-current-stage',
        'requested_documents': 'requested-documents',
        'update_requested_docs': 'update_requested_docs',
        'send_notice_of_incompleteness': 'send_notice_of_incompleteness',
        'forget-password' : 'forget-password',
        'collateral_evaluation_masters': 'collateral_evaluation_masters',
        'assign_to': 'assign-to',
        'get-current-stage': 'get-current-stage',
        'about-business': 'about-business',
        'owner-details' : 'owner-details',
        'another-owner-detail': 'another-owner-detail',
        'delete-owner': 'delete-owner',
        'application-progress': 'application-progress',
        'gross-sales': 'gross-sales',
        'otp-verification': 'otp-verification',
        'resend-otp': 'resend-otp',
        'dashboard': 'dashboard',
        'documents': 'documents',
        'verify-owner-consent': 'verify-owner-consent',
        'create_new_application': 'create_new_application',
        'sba-form-1': 'sba-form-1',
        'sba-form-2': 'sba-form-2',
        'sba-form-3': 'sba-form-3',
        'sba-form-4': 'sba-form-4',
        'sba-form-5': 'sba-form-5',
        'sba-form-6': 'sba-form-6',
        'sba-form-8': 'sba-form-8',
        'sba-form-7': 'sba-form-7',
        'verify_owner_hash': 'verify_owner_hash',
        'loan-sub-status': 'loan-sub-status',
        'banker-by-ids':'banker-by-ids',
        'application_pdf_master':'application_pdf_master',
        'send-to-laserpro':'send-to-laserpro',
        'personal_financial_pdf': 'personal_financial_pdf',
        'business_financial_pdf' : 'business_financial_pdf'
    },
    APP_ROUTES: {
        'dashboard': '/dashboard',
        'manage-leads': '/manage-leads',
        'manage-loans': '/manage-loans',
        'signin': '',
        'invalid_session_redirect': '',
        'reset-password': '/reset-password',
        'change-password': '/change-password',
        'application-details':'/manage-loans/application-details',
        'irs-manual':'/manage-loans/irs-manual',
        'irs-online':'/manage-loans/irs-online',
        'business-financial': '/manage-loans/business-financial',
        'personal-financial': '/manage-loans/personal-financial',
        'credit-approval-form': 'manage-loans/credit-approval-form',
        'sba_tab': '/manage-loans/application-details/sba',
        'sbaform_159': 'manage-loans/form159',
        'sbaform_601': 'manage-loans/sbaform_601',
        'sbaform_1050': 'manage-loans/sbaform_1050',
        'landlord_waiver' : 'manage-loans/landlord_waiver',
        'collateral-reportable':'manage-loans/collateral-reportable',
        'collateral-eval': 'manage-loans/collateral-eval',
        'underWriting':'/manage-loans/application-details/underwriting',
        'hmda':'manage-loans/hmda/hmda-component',
        'sbaform_1920': 'manage-loans/form1920',
        'notice_of_incompleteness': 'manage-loans/notice-of-incompleteness',
        'gdscr': '/manage-loans/gdscr',
        
        'loan-type': '/loan-information',
        'gross-sales': '/business-details',
        'about-business': '/business-details/about-business',
        'owner-details': '/owner-details',
        'another-owner-detail': '/owner-details/business-info',
        'consent-received': '/owner/verification/consent-received',
        'sba-form': '/sba-form',
        'documents': '/documents',
        'sba-form-1': '/sba-form/sba-form-1',
        'sba-form-2': '/sba-form/sba-form-2',
        'sba-form-3': '/sba-form/sba-form-3',
        'sba-form-4': '/sba-form/sba-form-4',
        'sba-form-5': '/sba-form/sba-form-5',
        'sba-form-6': '/sba-form/sba-form-6',
        'sba-form-7': '/sba-form/sba-form-7',
        'sba-form-8': '/sba-form/sba-form-8',
        'owner-sba-form-1': '../sba-form-1',
        'owner-sba-form-2': '../sba-form-2',
        'owner-sba-form-3': '../sba-form-3',
        'owner-sba-form-4': '../sba-form-4',
        'owner-sba-form-5': '../sba-form-5',
        'owner-sba-form-6': '../sba-form-6',
        'owner-sba-form-7': '../sba-form-7',
        'owner-sba-form-8': '../sba-form-8',
        'sba-form-complete': '../sba-form-complete',
        
    },

    APP_STEP: {
        'select-business-structure': 1,
        'create-profile': 2,
        'loan-type': 3,
        'gross-sales': 4,
        'about-business': 4,
        'owner-details': 5,
        'another-owner-detail': 5,
        'documents': 6,
        'sba-form': 7,
        'sba-form-1': 7,
        'sba-form-2': 7,
        'sba-form-3': 7,
        'sba-form-4': 7,
        'sba-form-5': 7,
        'sba-form-6': 7,
        'sba-form-7': 7,
        'sba-form-8': 7,
        'pfs-get-started': 8,
        'pfs-schedule': 8,
        'pfs_assets_and_liabilities': 8
    },

    PER_PAGE_RECORDS: [
        {"value": 10 },
        {"value": 25 },
        {"value": 50 },
        {"value": 100 }
    ],
    FILTER_TYPE_MANAGE_LOANS: [
        {
            id: "5c20bf7e27105c78ad6f9281",
            order: 1,
            parent_id: null,
            product_type: null,
            status: 1,
            type: "loan_id",
            value: "Loan ID"
        },
        {
            id: "5c20bf7e27105c78ad5f9281",
            order: 2,
            parent_id: null,
            product_type: null,
            status: 1,
            type: "business_name",
            value: "Business Name"
        }
    ],
    FILTER_TYPE_MANAGE_LEADS: [
        {
            id: "5c20bf7e27105c78ad4f9281",
            order: 1,
            parent_id: null,
            product_type: null,
            status: 1,
            type: "email_address",
            value: "Email Address"
        },
        {
            id: "5c20bf7e27105c78ad3f9282",
            order: 2,
            parent_id: null,
            product_type: null,
            status: 1,
            type: "phone",
            value: "Phone"
        }
    ],
    
    APPLICATION_STATUS: {
        'application_in_progress': '5c20bf7e27105c78ad7f9289',
        'application_soft_decline': '60bdfb51c0a3494024772c0d',
        'application_hard_decline' : '60bdfd521b7b0c7268b744ab',
        'app_completed': '5c20bf7e27105c78ad7f9288',
        'app_soft_withdrawn' : '60d22bf23c05824838f8fe6b',
        'app_hard_withdrawn' : '60f1597ad61fcdcfe4eed5c2',
        'app_submitted': '5c20bf7e27105c78ad7f9281',
        'app_underwiter': '60cf935635f4bc612456ac8c'
    },

    MAIL_TEMPLATE : {
        copyright_text: environment.copyright_text,
        senders_name: environment.client_name,
        project_name: environment.project_name,
        no_reply_mail: environment.noreplymail
    },

    SBAFORMS_GENERATE_LENGTH: 6,

    YES_NO: {
        YES: '5e8723158f2f4e3ac475fab6',
        NO: '5e8723158f2f4e3ac475fab7'
    },

    SBA_1920_LENDER_INFO : {
        lender_name : environment.client_name,
        lender_id : environment.client_lender_id,
        lender_address : environment.client_addressl,
        lender_city : environment.client_city,
        lender_st : environment.client_state,
        lender_zip : environment.client_zipcode
    },

    CHECKLIST_DOCUMENT_MESSAGE: {
      checklist_error: 'Please mark the status of the checklist',
      document_error: 'Please mark the status of the document list',
      checklist_document_error: 'Please mark the status of checklist and document list'
    },

    ETRAN_MESSAGE: {
        score_error: 'Please pull SBA score before moving to next stage.',
        submission_error: 'Please submit your application to SBA before moving to next stage.'
    },

    DECLINE_WITHDRAW_MESSAGE: {
        soft_withdrawn : "Application is in Soft Withdrawn state.",
        soft_decline : "Application is in Soft Declined state."
    },

    BUSINESS_STRUCTURE : {
        franchise: "5c1ca192eb72d4c894b91612",
        others: "5c1ca192eb72d4c894b91610"
    },

    ROLE_SLUGS : {
        admin : "admin",
        senior_LO : "loan_officer_l1",
        junior_LO : "loan_officer_l2"
    },
    JUNIOR_ROLE_SLUGS : ['loan_officer_l2', 'fulfillment_services_l2', 'underwriter_l2', 'closing_team_l2', 'quality_assurance_l2']

}
