export const ERROR_MESSAGES = {
    200: {
        'backend_session_login': {
            'SESSION_LOADING_FAILED': 'Email is invalid.'
        },
        'start_an_application': {
            'check_email': {
                true: 'This email ID already exists.'
            }
        }
    },
    400: {
        'reset-password': {
            'RESOURCE_NOT_FOUND': 'The link has been expired.Please try again.',
            'FIELD_DUPLICATE': 'The value of the field is already used for last three password.'
        },
        'verify_hash': {
            'RESOURCE_NOT_FOUND': 'The link has been expired.Please try again.'
        },
        'change-password': {
            "FIELD_INVALID": "Old password is invalid.",
            "FIELD_DUPLICATE": "The value of the field is already used for last three password."
        },
        'forget-password' :  {
                'FIELD_INVALID': 'If your email address exists in our system, you will receive a password recovery link at your email address in a few minutes.'
        },
    },
    401: {
        'change-password': {
            "AUTHORIZATION_REQUIRED": "Performing this action on this resource requires authorization."
        }
    },
    403: {
        'reset-password': {
            'TOKEN_EXPIRED':'The token has been expired',
            'PERMISSIONS_DENIED': 'You do not have permissions to perform this action on this resource.'
        },
        'banker_signin': {
            'PERMISSIONS_DENIED': 'Password is invalid.'
        },
        'change-password': {
            "SESSION_EXPIRED": "The session has expired."
        },
        'verify_hash': {
            "TOKEN_EXPIRED": "The link has been expired. Please try again."
        }
    },
    404: {
        'reset-password': {
            'RESOURCE_NOT_FOUND': 'Link has been expired. Please try again.',
        },
        'verify_hash': {
            'RESOURCE_NOT_FOUND': 'Resource does not exist or has been removed.'
        }
    },
    429: {
        'forget-password': {
            "RATE_LIMIT_REACHED": "The rate limit for this action was reached."
        },
        'banker_signin': {
            "AUTHENTICATION_LOCKED": "The maximum number of authentication retries was reached."
        }
    },  
    454: {
        'banker_signin': {
            'SESSION_LOADING_FAILED': 'Email is invalid.'
        }
    }, 
    504: "Server timeout.",
    440: {
        error: 'Your session expired.'
    }
}