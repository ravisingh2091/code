import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import {​​​​​​​ BrowserAnimationsModule }​​​​​​​ from '@angular/platform-browser/animations';

// third party import 
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';

//import for store management 
import { StoreModule, MetaReducer, META_REDUCERS } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { EffectsModule } from '@ngrx/effects';

import { CommonService, UtilsModule } from '@rubicon/utils';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { LayoutModule } from '@credit-bench/layout';
import { UiKitModule } from '@credit-bench/ui-kit';
import { SharedModule } from '@credit-bench/shared';
import { CONSTANTS } from '../assets/constant/constant';
import { ERROR_MESSAGES } from '../assets/constant/error-messages';
import * as cssJson from '../assets/json/css.json';
import * as fromApp from './+state/app.reducer';
import { AppEffects } from './+state/app.effects';
import { storageMetaReducer, updateRootState } from './+state/app-meta.reducer';
import  { environment } from '../environments/environment';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BackNavigationGuard } from './guards/back-navigation.guard';

export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient, './assets/i18n/', '.json');
}

export function getMetaReducers(storageService: CommonService): MetaReducer<any> {
  return storageMetaReducer(storageService);
}

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    ModalModule.forRoot(),
    BrowserAnimationsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
      isolate: false,
    }),
    AppRoutingModule,
    SharedModule,
    StoreModule.forRoot(
      { [fromApp.APP_FEATURE_KEY]: fromApp.reducer },
      { metaReducers: [updateRootState] }),
    EffectsModule.forRoot([AppEffects]),
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    StoreRouterConnectingModule.forRoot(),
    UtilsModule.forRoot(environment,CONSTANTS,ERROR_MESSAGES),
    LayoutModule,
    UiKitModule,
    CommonModule,
  ],
  providers: [
    { provide: 'APP_ROUTES', useValue: CONSTANTS.APP_ROUTES },
    { provide: 'environment', useValue: environment },
    { provide: 'CONSTANTS', useValue: CONSTANTS },
    { provide: 'cssList', useValue: (cssJson as any).default },
    {
      provide: META_REDUCERS, multi: true, deps: [CommonService], useFactory: getMetaReducers
    },
    BackNavigationGuard,
    Title
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
