import { NgModule } from "@angular/core";
import { RouterModule, Routes } from '@angular/router';
import { SiteLayoutComponent } from "../../../../libs/layout/src/lib/site-layout/site-layout.component";
import { AuthLazyGuard } from "./guards/auth-lazy.guard";
import { BackNavigationGuard } from "./guards/back-navigation.guard";

const routes: Routes = [
    {
        path: '',  component: SiteLayoutComponent,
        children: [
            {
                path: '', loadChildren: () => import('@credit-bench/components/banker-login').then(
                    m => m.BankerLoginModule
                )
            },
            {
                path: 'reset-password', loadChildren: () => import('@credit-bench/components/forget-password').then(
                    m => m.ForgetPasswordModule
                )
            },
            {
                path: 'dashboard', loadChildren: () => import('@credit-bench/components/status-pipeline').then(
                    m => m.StatusPipelineModule
                ) ,
                canLoad: [AuthLazyGuard]
            },
            {
                path: 'manage-loans', loadChildren: () => import('@credit-bench/components/manage-loans').then(
                    m => m.ManageLoansModule
                ),
                canLoad: [AuthLazyGuard],
            },
            {
                path: 'manage-leads', loadChildren: () => import('@credit-bench/components/manage-leads').then(
                    m => m.ManageLeadsModule),
                canLoad: [AuthLazyGuard],
            },
            {
                path: 'change-password', loadChildren: () => import('@credit-bench/components/change-password').then(
                    m => m.ChangePasswordModule
                ),
                canLoad: [AuthLazyGuard],
            },
            {
                path: 'loan-information', loadChildren: () => import('@credit-bench/components/loan-type').then(
                    m => m.LoanTypeModule
                ),
                 canLoad: [AuthLazyGuard],
                 canDeactivate: [BackNavigationGuard]
            },
            {
                path: 'business-details', loadChildren: () => import('@credit-bench/components/business-details').then(
                    m => m.BusinessDetailsModule
                ),
                 canLoad: [AuthLazyGuard]
            },
            {
                path: 'owner-details', loadChildren: () => import('@credit-bench/components/owner-details').then(
                    m => m.OwnerDetailsModule
                ),
                 canLoad: [AuthLazyGuard]
            },
            {
                path:'sba-form', loadChildren: () => import('@credit-bench/sba-form').then(
                    m => m.SbaFormModule
                ),
            },
            {
                path: 'documents', loadChildren: () => import('@credit-bench/components/documents').then(
                    m => m.DocumentsModule
                ),
                canLoad: [AuthLazyGuard]
            }
            
         ]
    }, 
              
    {
        path: "",
        redirectTo: "",
        pathMatch: "full",
    },
    {
        path: "**",
        redirectTo: "",
        pathMatch: "full"
    },
]


@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }