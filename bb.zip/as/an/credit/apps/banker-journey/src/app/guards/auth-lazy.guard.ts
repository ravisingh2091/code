import { Injectable, OnDestroy } from '@angular/core';
import { CanLoad, UrlSegment } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { Route } from '@angular/compiler/src/core';
import { CommonService } from '@rubicon/utils';
import { Store, select } from '@ngrx/store';
import { take } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

export class AuthLazyGuard implements CanLoad, OnDestroy {

  tokenSubscription: Subscription;
  token: string = null;

  constructor(private store: Store<any>,
    private common: CommonService) {
    this.tokenSubscription = this.store.select('app').subscribe(rootState => {
      this.token = rootState?.userData?.id;
    })
  }

  canLoad(route: Route, segments: UrlSegment[]): boolean | Observable<boolean> | Promise<boolean> {
    if (!this.token) {
      this.common.setLogin(false);
      this.common.navigate('signin');
      return false;
    }
    this.common.setLogin(true);
    return true;
  }

  ngOnDestroy() {
    this.tokenSubscription.unsubscribe();
  }
}
