import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { CommonService } from '@rubicon/utils';

@Injectable({
  providedIn: 'root'
})
export class BackNavigationGuard implements CanDeactivate<any> {
  constructor(private common: CommonService) {}

  canDeactivate(component: any) 
  {
    // will prevent user from going back
    if (this.common.isBackButtonClicked){
      this.common.isBackButtonClicked=false;
      // push current state again to prevent further attempts.
      history.pushState(null, null, location.href);
      return false;
    }
    return true;
  }
  
}
