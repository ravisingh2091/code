import { ActionReducer, Action } from '@ngrx/store';
import { CommonService } from '@rubicon/utils';
import * as _ from 'lodash';

let onInit = true; // after load/refresh…

// the key for the local storage.
const localStorageKey = 'state';

export function storageMetaReducer<S, A extends Action = Action>(storageService: CommonService) {
    return (reducer: ActionReducer<S, A>) => {
        return (state: S, action: A): S => {
            // reduce the nextState.
            const nextState = reducer(state, action);
            // init the application state.
            if (onInit) {
                onInit = false;
                const savedState = storageService.getDataFromStorage(localStorageKey);
                return _.merge(nextState, savedState);
            }
            // save the next state to the application storage.
            const stateToSave = nextState;
            if (action.type === '[UIKITSTATE] Logout') {
                state = undefined;
                storageService.deleteDataFromStorage(localStorageKey);
                return reducer(state, action);
            }
            storageService.storeData(localStorageKey, stateToSave);
            return nextState;
        };
    }
}

export function updateRootState(reducer) {
    return (state, action) => {
        switch (action.type) {
            case '[UtilState] Add User Details':
                state = {
                    ...state,
                    app: {
                        ...state.app,
                        userData: action.userData
                    },
                };
                break;
            case '[UtilState] Add App ID':
                state = {
                    ...state,
                    app: {
                        ...state.app,
                        appID: action.appID
                    }
                };
                break;
            case '[UtilState] Add Business ID':
                state = {
                    ...state,
                    app: {
                        ...state.app,
                        businessID: action.businessID
                    }
                };
                break;
            case '[UtilState] Add App Details':
                    state = {
                        app: {
                            ...state.app,
                            appData: action.appData
                        }
                    };
                break;      
            case '[UtilState] App on Logout':
                state = {
                    app: {}
                };
                break;
            default:
                break;
        }
        return reducer(state, action);
    };
}