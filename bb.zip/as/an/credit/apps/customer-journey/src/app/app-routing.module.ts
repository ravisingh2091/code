import { NgModule } from "@angular/core";
import { RouterModule, Routes } from '@angular/router';
import { SiteLayoutComponent } from "../../../../libs/layout/src/lib/site-layout/site-layout.component";
import { AuthLazyGuard } from "./guards/auth-lazy.guard";
import { BackNavigationGuard } from "./guards/back-navigation.guard";
import { SbaFormAdditonalOwnerLayout } from "../../../../libs/layout/src/lib/sba-form-additional-owner-layout/sba-form-additional-owner-layout.component";

const routes: Routes = [
    {
        path: '', component: SiteLayoutComponent,
        children: [
            {
                path: '', loadChildren: () => import('@credit-bench/components/login').then(
                    m => m.LoginModule
                )
            },
            {
                path: 'get-started', loadChildren: () => import('@credit-bench/components/get-started').then(
                    m => m.GetStartedModule
                )
            },
            {
                path: 'loan-information', loadChildren: () => import('@credit-bench/components/loan-type').then(
                    m => m.LoanTypeModule
                ),
                 canLoad: [AuthLazyGuard],
                 canDeactivate: [BackNavigationGuard]
            },
            {
                path: 'business-details', loadChildren: () => import('@credit-bench/components/business-details').then(
                    m => m.BusinessDetailsModule
                ),
                 canLoad: [AuthLazyGuard]
            },
            {
                path: 'owner-details', loadChildren: () => import('@credit-bench/components/owner-details').then(
                    m => m.OwnerDetailsModule
                ),
                 canLoad: [AuthLazyGuard]
            },
            {
                path:'sba-form', loadChildren: () => import('@credit-bench/sba-form').then(
                    m => m.SbaFormModule
                ),
                // canLoad: [AuthLazyGuard],
                // canDeactivate: [BackNavigationGuard]
            },
            {
                path: 'reset-password', loadChildren: () => import('@credit-bench/components/forget-password').then(
                    m => m.ForgetPasswordModule
                )
            },
            {
                path: 'change-password', loadChildren: () => import('@credit-bench/components/change-password').then(
                    m => m.ChangePasswordModule
                ),
                 canLoad: [AuthLazyGuard],
            },
            {
                path: 'dashboard', loadChildren: () => import('@credit-bench/components/dashboard').then(
                    m => m.DashboardModule
                ),
                canLoad: [AuthLazyGuard],
            },
            {
                path: 'documents', loadChildren: () => import('@credit-bench/components/documents').then(
                    m => m.DocumentsModule
                ),
                canLoad: [AuthLazyGuard]
            },
            {
                path: 'connect-banker', loadChildren: () => import('@credit-bench/components/connect-banker-customer').then(
                    m => m.ComponentsConnectBankerCustomerModule
                ),
                canLoad: [AuthLazyGuard],
                canDeactivate: [BackNavigationGuard]
                
            },
            // {
            //     path: 'pfs', loadChildren: () => import('@credit-bench/components/pfs').then(
            //         m => m.PfsModule
            //     ),
            //     canLoad: [AuthLazyGuard],
            //     canDeactivate: [BackNavigationGuard]
            // },
        ],
    },
    {
      path: 'owner', component: SbaFormAdditonalOwnerLayout ,
      children: [
         {
            path:'sba-form/:hash', loadChildren: () => import('@credit-bench/sba-form').then(
                m => m.SbaFormModule
            )
         },
         {
            path: 'verification', loadChildren: () => import('@credit-bench/components/owner-verification').then(
                m => m.OwnerVerificationModule
            )
        },
        {
            path:':hash', loadChildren: () => import('@credit-bench/sba-form').then(
                m => m.SbaFormModule
            )
        }
      ]    
    },
    {
        path: "",
        redirectTo: "",
        pathMatch: "full",
    },
    {
        path: "**",
        redirectTo: "",
        pathMatch: "full"
    },
]


@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }