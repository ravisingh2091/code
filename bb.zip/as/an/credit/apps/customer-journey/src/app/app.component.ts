import { Component, Inject } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { CommonService } from '@rubicon/utils';
import { LocationStrategy } from '@angular/common';
import { NavigationEnd } from '@angular/router';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {

  constructor(translate: TranslateService, 
    private common: CommonService,  
    private locationStrategy: LocationStrategy, 
    private titleService: Title,
    @Inject('CONSTANTS') public CONSTANTS) {

       this.titleService.setTitle(CONSTANTS.CLIENT_CONFIG.title);
   
    this.common.routerEvent.subscribe((val) => {
      if (val instanceof NavigationEnd)
        window.scroll(0, 0);
    });
 // check if back or forward button is pressed.
    this.locationStrategy.onPopState(() => {
  // set isBackButtonClicked to true.
      this.common.isBackButtonClicked=true;
      return false;
    });
    translate.setDefaultLang('en');
  }
}
