export const ERROR_MESSAGES = {
    200: {
        'create-profile': {
            'check_email': {
                true: 'This email ID already exists. Please login to the application to continue.'
            },
            'check_phone': {
                true: 'This Mobile Number already exists. Please login to the application to continue.'
            }
        },
        'check_email': {
            'check_email': {
                true: 'This email ID already exists. Please login to the application to continue.'
            }
        },
        'signin': {
            'check_email': {
                false: 'This email ID not exist. Please signup.'
            }
        }
    },
    400: {
        'reset-password': {
            'RESOURCE_NOT_FOUND': 'The link has been expired.Please try again.',
            'FIELD_DUPLICATE': 'The value of the field is already used for last three password.'
        },
        'verify_hash': {
            'RESOURCE_NOT_FOUND': 'The link has been expired.Please try again.'
        },
        'otp-verification': {
            "FIELD_INVALID": "OTP is invalid."
        },
        'change-password': {
            "FIELD_INVALID": "Old password is invalid.",
            "FIELD_DUPLICATE": "The value of the field is already used for last three password."
        },
        'verify-owner-consent': {
            'FAILED': 'Hash expired.'
        },
        'another-owner-detail': {
            'FAILED': 'Something went wrong! please try again.'
        },
        'forget-password' :  {
                'FIELD_INVALID': 'If your email address exists in our system, you will receive a password recovery link at your email address in a few minutes.'
        },
        'verify_owner_hash': {
            'FAILED': 'The link has been expired.'
        },
        'force-change-password': {
            'FIELD_INVALID': 'Old password is invalid.',
            "FIELD_DUPLICATE": "The value of the field is already used for last three password."
        }
    },
    401: {
        'change-password': {
            "AUTHORIZATION_REQUIRED": "Performing this action on this resource requires authorization."
        }
    },
    403: {
        'reset-password': {
            'TOKEN_EXPIRED':'The token has been expired',
            'PERMISSIONS_DENIED': 'You do not have permissions to perform this action on this resource.'
        },
        'signin': {
            'PERMISSIONS_DENIED': 'Password is invalid.'
        },
        'change-password': {
            "SESSION_EXPIRED": "The session has expired."
        },
        'verify_hash': {
            "TOKEN_EXPIRED": "The link has been expired. Please try again."
        },
        'otp-verification': {
            'OTP_EXPIRED': 'OTP is Expired.'
        }
    },
    404: {
        'reset-password': {
            'RESOURCE_NOT_FOUND': 'Link has been expired. Please try again.',
        },
        'verify_hash': {
            'RESOURCE_NOT_FOUND': 'Resource does not exist or has been removed.'
        }
    },
    429: {
        'forget-password': {
            "RATE_LIMIT_REACHED": "The rate limit for this action was reached."
        },
        'signin': {
            "AUTHENTICATION_LOCKED": "The maximum number of authentication retries was reached."
        },
        'otp-verification': {
            'RATE_LIMIT_REACHED': 'The rate limit for this action was reached.'
        },
        'resend-otp': {
            'RATE_LIMIT_REACHED':'The rate limit for this action was reached.'
        }
    },
    454: {
        'signin': {
            'SESSION_LOADING_FAILED': 'Email is invalid.'
        }
    },
    504: "Server timeout.",
    440: {
        error: 'Your session expired.'
    }
}