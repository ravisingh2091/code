import  { environment } from '../../environments/environment';

export const  CONSTANTS = {
  
  FOOTER_CONGIF: {
    footer_text: environment.copyright_text 
  },
  CLIENT_CONFIG: {
    title: environment.title,
    name: environment.client_name,
    project_name: environment.project_name,
    addressl: environment.client_addressl,
    city: environment.client_city,
    state: environment.client_state,
    country: environment.client_country,
    zipcode: environment.client_zipcode,
    client_url: environment.client_url,
    privacy_url: environment.privacy,
    siteMap_url: environment.siteMap,
    terms_url: environment.terms,
    no_reply_mail: environment.noreplymail
  },

  APP_ROUTES: {
        'signin': '',
        'invalid_session_redirect': '',
        'get-started': '/get-started',
        'select-industry': '/get-started/select-industry',
        'select-business-structure': '/get-started/select-business-structure',
        'create-profile': '/get-started/create-profile',
        'gross-sales': '/business-details',
        'about-business': '/business-details/about-business',
        'owner-details': '/owner-details',
        'another-owner-detail': '/owner-details/business-info',
        'consent-received': '/owner/verification/consent-received',
        'sba-form': '/sba-form',
        'loan-type': '/loan-information',
        'reset-password': '/reset-password',
        'change-password': '/change-password',
        'dashboard': '/dashboard',
        'documents': '/documents',
        'sba-form-1': '/sba-form/sba-form-1',
        'sba-form-2': '/sba-form/sba-form-2',
        'sba-form-3': '/sba-form/sba-form-3',
        'sba-form-4': '/sba-form/sba-form-4',
        'sba-form-5': '/sba-form/sba-form-5',
        'sba-form-6': '/sba-form/sba-form-6',
        'sba-form-7': '/sba-form/sba-form-7',
        'sba-form-8': '/sba-form/sba-form-8',
        'owner-sba-form-1': '../sba-form-1',
        'owner-sba-form-2': '../sba-form-2',
        'owner-sba-form-3': '../sba-form-3',
        'owner-sba-form-4': '../sba-form-4',
        'owner-sba-form-5': '../sba-form-5',
        'owner-sba-form-6': '../sba-form-6',
        'owner-sba-form-7': '../sba-form-7',
        'owner-sba-form-8': '../sba-form-8',
        'sba-form-complete': '../sba-form-complete',
        'pfs-schedule': '/pfs/pfs-form/schedules',
        'pfs_assets_and_liabilities': '/pfs/pfs-form/assets',
        'pfs-get-started': '/pfs/get-started',
        'connect-banker': '/connect-banker'
    },

    APP_STEP: {
      'select-business-structure': 1,
      'create-profile': 2,
      'loan-type': 3,
      'gross-sales': 4,
      'about-business': 4,
      'owner-details': 5,
      'another-owner-detail': 5,
      'documents': 6,
      'sba-form': 7,
      'sba-form-1': 7,
      'sba-form-2': 7,
      'sba-form-3': 7,
      'sba-form-4': 7,
      'sba-form-5': 7,
      'sba-form-6': 7,
      'sba-form-7': 7,
      'sba-form-8': 7,
      'pfs-get-started': 8,
      'pfs-schedule': 8,
      'pfs_assets_and_liabilities': 8
    },

   SLUG: {
     'signin': 'signin' ,
     'get-started': 'get-started',
     'create-profile': 'create-profile',
     'select-industry': 'select-industry',
     'select-business-structure':'select-business-structure',
     'loan-type': 'loan-type',
     'owner-details': 'owner-details' ,
     'another-owner-detail': 'another-owner-detail',
     'delete-owner': 'delete-owner',
     'application-progress': 'application-progress',
     'gross-sales': 'gross-sales',
     'about-business': 'about-business',
     'forget-password' : 'forget-password',
     'otp-verification': 'otp-verification',
     'resend-otp': 'resend-otp',
     'change-password': 'change-password',
     'reset-password' : 'reset-password',
     'dashboard': 'dashboard',
     'documents': 'documents',
     'request_owners_consent':'request_owners_consent',
     'verify-owner-consent': 'verify-owner-consent',
     'create_new_application': 'create_new_application',
     'sba-form-1': 'sba-form-1',
     'sba-form-2': 'sba-form-2',
     'sba-form-3': 'sba-form-3',
     'sba-form-4': 'sba-form-4',
     'sba-form-5': 'sba-form-5',
     'sba-form-6': 'sba-form-6',
     'sba-form-8': 'sba-form-8',
     'sba-form-7': 'sba-form-7',
     'verify_owner_hash': 'verify_owner_hash',
     'reply_uw_request': 'reply_uw_request',
     'pfs_assets_and_liabilities': 'pfs_assets_and_liabilities',
     'schedule_cash': 'schedule_cash',
     'restricted_cash': 'restricted_cash',
     'non_marketable_securities': 'non_marketable_securities',
     'marketable_securities': 'marketable_securities',
     'account_taxes_receivable': 'account_taxes_receivable',
     'account_taxes_payable': 'account_taxes_payable',
     'real_estate_details': 'real_estate_details',
     'contingent_liabilities': 'contingent_liabilities',
     'pfs-schedule': 'pfs-schedule',
     'sba-confirmation': 'sba-confirmation',
     'post_form_1919': 'post_form_1919',
     'download_pdf' : 'download_pdf',
     'force-change-password': 'force-change-password',
     'agreed_terms_and_condition': 'agreed_terms_and_condition',
     'banker-by-ids': 'banker-by-ids',
     'document_widget_data': 'document-widget-data',
     'get_backend_users': 'get_backend_users',
     'requested_documents': 'requested-documents',
     'application_pdf_master': 'application_pdf_master',
     'withdraw_application' : 'withdraw_application'
   },
   
   APPLICATION_STATUS: {
    'application_in_progress': '5c20bf7e27105c78ad7f9289',
    'application_soft_decline': '60bdfb51c0a3494024772c0d',
    'application_hard_decline' : '60bdfd521b7b0c7268b744ab',
    'app_hard_withdrawn': '60f1597ad61fcdcfe4eed5c2',
    'app_soft_withdrawn' : '60d22bf23c05824838f8fe6b',
    'app_submitted': '5c20bf7e27105c78ad7f9281'
   },

   WITHDRAW_SUB_STATUS: {
    loan_officer : "60cf9e1cf49aab0d7ca97f1f",
    fulfillment_services : "60cf9e1cf49aab0d7ca97f25"
   },

   MAIL_TEMPLATE : {
    copyright_text: environment.copyright_text,
    senders_name: environment.client_name,
    project_name: environment.project_name,
    no_reply_mail: environment.noreplymail
  },

  STATUSMAP : {
    '5c20bf7e27105c78ad7f9289': 'Application in Progress'
  },

  BUSINESS_STRUCTURE : {
    franchise: "5c1ca192eb72d4c894b91612",
    others: "5c1ca192eb72d4c894b91610"
  }
}