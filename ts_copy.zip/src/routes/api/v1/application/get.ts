import ApiCriteriaBuilder from "../../../interface/ApiCriteriaBuilder";

export default class Get implements ApiCriteriaBuilder {
};
