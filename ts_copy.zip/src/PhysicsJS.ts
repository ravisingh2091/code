import { EventEmitter } from "events";
import path from 'path';
import fs from 'fs';

import App from "./config/App";


declare var config: any, middleware: any, event: any;

type physicsConfig = {
    maxEvents: number,
    redis?: Boolean,
    elastic?: Boolean,
    callback(error: any, result: any): void
}
export default class PhysicsJS extends App {
    _config: any;
    constructor(physicsConfig: physicsConfig) {
        super()
        EventEmitter.prototype.setMaxListeners(physicsConfig.maxEvents)
        const tasks = [this.initializeConfig(), this.loadServices(), this.initializeMiddleware(), this.initializeApplication(), this.initializeModels()]

        Promise.all(tasks).then(value => {
            physicsConfig.callback(null, value)
        }).catch(error => {
            physicsConfig.callback(error, null)
        })
    }
    initializeConfig() {
        return new Promise((resolve, reject) => {
            try {
                this.addSafeReadOnlyGlobal('config', this.dfsUtil("config", true));
                resolve(config)
            } catch (err) {
                reject(err)
            }
        })
    }

    loadServices() {
        let services = {};
        return new Promise((resolve, reject) => {
            try {
                let list = fs.readdirSync(path.join(this.app_base_dir, config.FIELDS.SERVICES));
                list.forEach(item => {
                    if (item.search(/.map$/) === -1 && item.search(/.[tj]s$/) !== -1) {
                        let name = item.toString().replace(/\.[tj]s$/, '');
                        services[this.functionNameToVariableName(name)] = new (require(path.join(this.app_base_dir, config.FIELDS.SERVICES, name)).default);
                    }
                });
                this.addSafeReadOnlyGlobal(config.FIELDS.SERVICES, services);
                resolve(services);
            } catch (err) {
                reject(err);
            }
        })
    }
    initializeMiddleware() {
        return new Promise((resolve, reject) => {
            try {
                this.addSafeReadOnlyGlobal(config.FIELDS.MIDDLEWARE, this.dfsUtil(config.FIELDS.MIDDLEWARE));
                resolve(middleware)
            } catch (err) {
                reject(err)
            }
        })
    }
    initializeModels() {
        return new Promise((resolve, reject) => {
            try {
                config.MODELS = {};
                console.log("config.FIELDS.MODELS", config.FIELDS.MODELS);

                let list = fs.readdirSync(path.join(this.app_base_dir, (config.FIELDS.MODELS).toString())), 
                    db = {}, i = 0, prod_flag = 1;
                list.forEach(async (item) => {
                    if (item.search(/.map$/) === -1 && item.search(/.[tj]s$/) !== -1) {
                        let name = item.toString().replace(/\.[tj]s$/, '');
                        let model = await (require(path.join(this.app_base_dir, config.FIELDS.MODELS, item)).default).initialize(this.DATABASE_URL)
                        ++i;
                        const model_name = this.functionNameToVariableName(name);
                        config.MODELS[model_name.toUpperCase()] = model_name;
                        db[model_name] = model;
                        if (i === list.length / prod_flag) {
                            this.addSafeReadOnlyGlobal(config.FIELDS._DB, db);
                            resolve(db);
                        }
                    } else if (item.search(/.map$/) !== -1){
                        prod_flag = 2;
                    } 
                });
            } catch (e) {
                reject(e);
            }
        })
    }


    dfsUtil(root, single = false) {
        let obj = {};
        try {
            let arr = fs.readdirSync(path.join(this.app_base_dir, root)) || [];
            for (let i = 0; i < arr.length; ++i) {
                if (arr[i].search(/.map$/) === -1 && arr[i].search(/.[tj]s$/) !== -1) {
                    let name = arr[i].toString().replace(/\.[tj]s$/, '');
                    if (single) {
                        const _class = new (require(path.join(this.app_base_dir, root, name)).default), keys = Object.getOwnPropertyNames(Object.getPrototypeOf(_class));
                        obj = { ...obj, ..._class };
                        for (let j = 0; j < keys.length; ++j) obj[keys[j]] = _class[keys[j]];
                    } else {
                        obj[this.functionNameToVariableName(name)] = require(path.join(this.app_base_dir, root, name)).default;
                    }
                } else if (arr[i] !== "base") {
                    if (single) obj = { ...obj, ...this.dfsUtil(root + "/" + arr[i], single) };
                    else obj[this.functionNameToVariableName(arr[i])] = this.dfsUtil(root + "/" + arr[i], single);
                }
            }
            return obj;
        } catch (err) {
            return obj;
        }
    }

    initializeApplication() {
        return new Promise((resolve, reject) => {
            new (require("./bootloader").default);
            //     // if (!!this._config.redis) new (require("./bootloader/redis").default);
            //     // if (!!this._config.elastic) new (require("./bootloader/elastic").default);
            resolve("success");

        })
    }

    addSafeReadOnlyGlobal(prop, val) {
        Object.defineProperty(global, prop, {
            get: function () {
                return val;
            },
            set: function () {
                console.warn('You are trying to set the READONLY GLOBAL variable `', prop, '`. This is not permitted. Ignored!');
            }
        });
    }

    functionNameToVariableName(str) {
        return str.replace(/([a-z])([A-Z])/g, '$1_$2').toLowerCase();
    }
}