export default interface URLType {
	url: string;
	method: string;
	query?: object;
}
