const ObjectId = require("mongoose").Types.ObjectId;

declare var services: any, _db: any, config: any, event: any;
export default class Collection {

	protected async find(request, response = {}, other: any = {}) {
		const _config = { ...services.util_services.getRequestFields(request), ...other };
		const aggregate_options = [], skip = Math.max(0, Number(+(_config.query.start || 1) - 1));
		let alias, _alis = {}, query = { ..._config.query, ..._config.params }, populate = [], select = [], hide = [], _hide: any = {}, _select: any = {}, sort_by = _config.query.sort_by, sort_by_keys = sort_by ? sort_by.split(",") : [], _sort_by: any = {}, limit: Number = 0;
		let child_ref = [], facet_options = [];
		let db_query = services.util_services.deleteUnwantedKeys(query, ["fields", "d_fields", "sort_by", "expands", "limit", "start", "child_ref", "start_date", "end_date"]), db_query_keys = Object.keys(db_query);
		try {
			limit = +_config.query.limit || limit;
			if (!db_query._id) delete db_query._id;

			child_ref = query.child_ref ? query.child_ref.split(",") : [];
			alias = query.alias ? query.alias.split(",") : [];
			populate = query.expands ? query.expands.split(",") : populate;
			select = query.fields ? query.fields.split(",") : select;
			hide = query.d_fields ? query.d_fields.split(",") : hide;

			for (let i = 0; i < db_query_keys.length; ++i) {
				let schema_paths = _db[request.model].schema.paths, n = db_query_keys[i].length, key = db_query_keys[i], old_key = key, ch = db_query_keys[i][n - 1], _ch = ch;
				if (!db_query[db_query_keys[i]]) {
					delete db_query[db_query_keys[i]];
					continue;
				} else if (db_query[key][0] === "=") {
					ch += "=";
					db_query[key] = db_query[key].replace(/[=]/gm, "");
				} else if (db_query_keys[i].search(/.in$/) !== -1) {
					key = db_query_keys[i].replace(/.in$/, "");
					db_query[key] = this.in(db_query[old_key]);
					delete db_query[old_key];
				}
				if (!!config.operators[ch]) {
					key = db_query_keys[i].replace(_ch, "");
					db_query[key] = this[config.operators[ch]](db_query[db_query_keys[i]]);
					delete db_query[db_query_keys[i]];
				}
				// else if (!!schema_paths[key] && schema_paths[key].instance === "ObjectID" && old_key === key) {
				else if (!!schema_paths[key] && key === config.FIELDS._ID && !populate.length) {
					db_query[key] = this.convertToObjectId(db_query[key]);
				}
				db_query[key] = !isNaN(db_query[key]) ? +db_query[key] : db_query[key];
			}

			if (!!_config.query.count) {
				let aggregate_options = [];
				db_query = {};
				if (_config.query.assigned_to) {
					let assignedApplications = await _db[config.MODELS.ASSIGNMENT].aggregate(
						[
							this.match({ assigned_to: _config.query.assigned_to }),
							this.addFields(this.convert(config.FIELDS.APP_ID, 1)),
							this.group({
								_id: "$" + config.FIELDS.ASSIGNED_TO
								, applications: { $push: "$" + config.FIELDS.APP_ID }
							})
						]);
					if (assignedApplications.length > 0) {
						db_query[config.FIELDS._ID] = { $in: assignedApplications[0].applications };
					}
					else {
						return assignedApplications;
					}
				}
				if (_config.query.end_date) {
					db_query[config.CREATED_AT] = { ...this.lte(_config.query.end_date) };
				}
				if (_config.query.start_date) {
					db_query[config.CREATED_AT] = db_query[config.CREATED_AT] ? { ...db_query[config.CREATED_AT], ...this.gte(_config.query.start_date) } : { ...this.gte(_config.query.start_date) };
				}


				aggregate_options.push(this.match(db_query));

				const project = {
					_id: 0,
					count: 1
				};
				project[_config.query.count] = "$_id";
				aggregate_options.push(this.group({ _id: "$" + _config.query.count, count: { $sum: 1 } }));
				aggregate_options.push(this.project(project));
				return _db[request.model].aggregate(aggregate_options);
			}

			for (let i = 0; !alias.length && i < hide.length; ++i) _hide[hide[i].trim()] = 0;
			for (let i = 0; i < select.length; ++i) {
				if (_hide.hasOwnProperty(select[i].trim())) delete _hide[select[i].trim()];
				_select[select[i].trim()] = 1;
			}
			for (let i = 0; i < sort_by_keys.length; ++i) _sort_by[sort_by_keys[i].replace(/[-+]/, "")] = sort_by_keys[i][0] === "-" ? -1 : 1;
			if (populate.length) aggregate_options.push(this.addFields(this.convert()));
			for (let i = 0; i < populate.length; ++i) {
				let old_key = populate[i], _key = old_key;
				if (config.EXPANDS[populate[i]]) _key = config.EXPANDS[populate[i]];
				let local_field = config.FIELDS._ID, foreign_field = config.FIELDS.APP_ID;
				if (config[request[config.FIELDS.MODEL]] && config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER]) {
					const filter_object = config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER];
					local_field = filter_object.local_field ? filter_object.local_field : local_field;
					foreign_field = filter_object.foreign_field ? filter_object.foreign_field : foreign_field;
				}
				if (query[old_key]) {

					const sub_document_query = query[old_key], sub_document_query_keys = Object.keys(sub_document_query);
					const pipeline = [this.eq("$" + foreign_field, "$$" + foreign_field)];
					for (let j = 0; j < sub_document_query_keys.length; ++j) {
						pipeline.push(this.eq("$" + sub_document_query_keys[j], query[populate[i]][sub_document_query_keys[j]]));
					}
					aggregate_options.push(this.lookup(_key, local_field, foreign_field, populate[i], pipeline));
					aggregate_options.push(this.match({ [populate[i]]: this.ne([]) }));

					delete query[old_key];
					delete db_query[old_key];
				}
				else {
					aggregate_options.push(this.lookup(_key, local_field, foreign_field, populate[i]));

				}
			}
			for (let i = 0; i < alias.length; ++i) {
				let val = alias[i].split(":");
				if (val.length < 2) val = [val[0], val[0]];
				if (_select[val[0].toString().trim()] === 1) delete _select[val[0].toString().trim()];
				_alis[val[1].toString().trim()] = "$" + val[0].toString().trim();
				_alis["_id"] = 0;
			}
			if (!sort_by_keys.length) _sort_by.created_at = 1;
			aggregate_options.push(this.sort(_sort_by));

			if (request.disable_is_deleted !== true) db_query.is_deleted = this.ne(true);
			_hide.is_deleted = 0;
			_hide.other = 0;
			if (db_query && db_query.status_id) {
				let obj = this.in([db_query.status_id + ""])
				db_query.status_id = obj
			}
			aggregate_options.push(this.match(db_query));
			if (!!_config.headers && Boolean(_config.headers[config.FIELDS.X_TOTAL_COUNT]) === true) {
				facet_options = [this.facet({ total: [...aggregate_options, this.group()], data: aggregate_options })]
			}
			aggregate_options.push(this.skip(skip));
			aggregate_options.push(this.project(_hide));
			if (select.length) aggregate_options.push(this.project(_select));
			if (limit) aggregate_options.push(this.limit(limit));
			if (child_ref.length) {
				for (let i = 0; i < child_ref.length; ++i) {
					const _ref_table = child_ref[i].trim();
					let local_field = _ref_table;
					let foreign_field = config.FIELDS._ID;
					if (config[request[config.FIELDS.MODEL]] && config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER] && config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER][_ref_table]) {
						const filter_object = config[request[config.FIELDS.MODEL]][config.FIELDS.FILTER][_ref_table];
						local_field = filter_object.local_field ? filter_object.local_field : local_field;
						foreign_field = filter_object.foreign_field ? filter_object.foreign_field : foreign_field;
					}
					if (foreign_field === config.FIELDS._ID) {
						aggregate_options.push(this.addFields(this.convert(local_field, 1)));
					}
					aggregate_options.push(this.lookup(child_ref[i].trim(), local_field, foreign_field));
					const obj = {};
					obj[_ref_table + "." + config.FIELDS.OTHER] = 0;
					obj[_ref_table + "." + config.FIELDS.IS_DELETED] = 0;
					aggregate_options.push(this.project(obj));
				}
			}
			aggregate_options.push(this.addFields({
				created_at: { $toDate: { $multiply: ['$' + config.FIELDS.CREATED_AT, 1000] } },
				updated_at: { $toDate: { $multiply: ['$' + config.FIELDS.UPDATED_AT, 1000] } }
			}));
			if (request.groupBy) {
				aggregate_options.push(this.group(request.groupBy));
			}
			return _db[request.model].aggregate(facet_options.length > 0 ? facet_options : aggregate_options);
		} catch (exception) {
			return new Error(exception.message);
		}
	};


	protected update(request, response, other: any = {}) {
		const options = { new: true, useFindAndModify: true };
		return this.findOneAndUpdate(request, response, { ...other, db: options });
	}


	protected updateMany(request, response, other: any = {}) {
		const obj = this.getDbQuery(request, other);
		return _db[request.model].updateMany(obj.db_query, { $set: obj.data });
	}


	protected deleteMany(request, response, other: any = {}) {
		request.body = { is_deleted: true };
		return this.updateMany(request, response, other);
	}

	private getDbQuery(request, other) {
		const obj = { ...services.util_services.getRequestFields(request), ...other }, db_query = {}, query = { ...obj.query, ...obj.params }, keys = Object.keys(query);
		for (let i = 0; i < keys.length; ++i) db_query[keys[i]] = typeof query[keys[i]] === "string" ? this.in(query[keys[i]].split(",")) : query[keys[i]];
		return { ...obj, db_query };
	}


	protected findOne(param) {
		return _db[param.model].findOne(param.query);
	}


	protected async findAllAndClone(param, appData: any, ignore: any) {
		const result = await _db[param.model].find({ ...param.query, ...this.ignoreQuery(ignore) }, { _id: 0 });
		const copiedData = {};
		result.forEach(async (item) => {
			item.app_id = appData._id;
			copiedData[param.model] = await services.collection.saveItem(param.model, item);
		});

		return copiedData;
	}


	protected ignoreQuery(ignoreParams) {
		const ignoreQuery = {};
		if (ignoreParams && ignoreParams.match_key) {
			ignoreQuery[ignoreParams.match_key] = { $nin: ignoreParams.match };
		}

		return { ...ignoreQuery };
	}


	protected saveItem(model, data) {
		const item = new _db[model](data);
		item.isNew = true;
		item.copied = true;
		return item.save();
	}


	protected save(param) {
		return _db[param.model](param.data).save();
	}


	protected async findOneAndUpdate(request, response, other: any = {}) {
		if (!request.query) request.query = {};
		let options = { upsert: true, new: true };
		if (other.db) {
			options = options = other.db;
			delete other.db;
		}

		request.query.is_deleted = this.ne(true);
		const obj = this.getDbQuery(request, other);
		let isMultipleStatus = request.multiple_Status;

		if (isMultipleStatus) {
			let data = await _db[request.model].findById(obj.query, { status_id: 1 });
			let multiple_status = data.status_id;
			if (Array.isArray(multiple_status)) {
				return _db[request.model].findOneAndUpdate(
					obj.db_query,
					{ $push: obj.data },
					options
				);
			} else {
				let multiple_status_id_arr = [multiple_status, obj.data.status_id];
				obj.data.status_id = multiple_status_id_arr;
				return _db[request.model].findOneAndUpdate(
					obj.db_query,
					{ $set: obj.data },
					options
				);
			}
		} else {
			return _db[request.model].findOneAndUpdate(
				obj.db_query,
				{ $set: obj.data },
				options
			);
		}
	}



	protected insert(request, response = {}, other: any = {}) {
		const _config = { ...services.util_services.getRequestFields(request), ...other };
		return new _db[request.model](_config.data).save();
	}

	protected delete(request, response) {
		request.body = {};
		request.body.deleted_at = new Date();
		request.body.is_deleted = true;
		return this.update(request, response);
	}

	protected undo(request, response) {
		request.body.deleted_at = new Date();
		request.body.is_deleted = false;
		return this.update(request, response)
	}

	protected _delete(request, response) {
		const _config = services.util_services.getRequestFields(request), db_query = {}, query = { ..._config.query, ..._config.params, is_deleted: false };
		const keys = Object.keys(db_query);
		for (let i = 0; i < keys.length; ++i) db_query[keys[i]] = this.in(query[keys[i]].split(","));
		return _db[request.model].deleteMany(db_query);
	}


	protected async replaceOne(request, response, p: { new: boolean; useFindAndModify: boolean }) {
		const _config = services.util_services.getRequestFields(request), query = { ..._config.query, ..._config.params, is_deleted: false };
		return _db[request.model].replaceOne(query, _config.data, { new: true, useFindAndModify: true });
	}

	lookup(from, local_field, foreign_field, as = undefined, pipeline = undefined) {
		if (!pipeline) {
			return {
				$lookup: {
					from: from,
					localField: local_field,
					foreignField: foreign_field,
					as: as || from
				}
			};
		}
		else {
			return {
				$lookup: {
					from: from,
					let: { [foreign_field]: "$" + local_field },
					pipeline: [this.match(this.expr(this.and(pipeline)))],
					as: as || from
				}
			};
		}
	}
	expr(query = {}) {
		return { $expr: query }
	}
	and(query = {}) {
		return { $and: query }
	}
	facet(query = {}) {
		return { $facet: query }
	}
	group(query: any = { _id: null, total: { $sum: 1 } }) {
		return { $group: query };
	}

	project(query: any = { _id: 0 }) {
		return { $project: query };
	}

	addFields(query: any) {
		return { $addFields: query };
	}

	replaceRoot(query: any) {
		return {
			$replaceRoot: {
				newRoot: query
			}
		};
	}

	filter(input, query: any, as = null) {
		return {
			$filter: {
				input: "$" + input,
				as: as || input,
				cond: query
			}
		};
	}

	convert(field = "_id", type: number = -1) {
		let obj = {}, convert_type = "toString";
		obj[field] = {};
		if (type == 1) convert_type = "toObjectId";
		else if (type == 2) convert_type = "parseInt";
		obj[field]["$" + convert_type] = "$" + field;
		return obj;
	}

	in(query: any) {
		return { $in: query };
	}

	ne(value: any) {
		return { $ne: value };
	}

	eq(key, value) {
		return { "$eq": [key, value] };
	}
	regexMatch(input, regex, options = "") {
		return { "$regexMatch": { input, regex, options } };
	}
	strcasecmp(key, value) {
		return { "$strcasecmp": [key, value] };
	}
	gt(value: String) {
		return { $gt: +value };
	}

	gte(value: String) {
		return { $gte: +value };
	}

	lt(value: String) {
		return { $lt: +value };
	}

	lte(value: String) {
		return { $lte: +value };
	}

	skip(value: Number) {
		return { $skip: +value };
	}

	limit(query: {}) {
		return { $limit: query };
	}

	sort(query: {}) {
		return { $sort: query };
	}

	match(query: {}) {
		return { $match: query };
	}

	convertToObjectId(id) {
		if (!id) return null;
		if (id instanceof ObjectId) return id;

		try {
			return ObjectId(id);
		}
		catch (c) {
			return null;
		}
	}
};
