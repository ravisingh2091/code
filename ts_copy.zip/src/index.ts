require("dotenv").config();
import PhysicsJs from "./PhysicsJs";
new PhysicsJs({
	maxEvents: 30,
	callback: function (error, success) {
		if (error) throw error;
		else console.log("Application Loaded Successfully");
	}
});
