import mongoose from "mongoose";

declare var config: any;
export default class Connection {

    public connect(mongo_url): Promise<any> {
        if (!mongo_url) throw new Error(config.mongo.URL_NOT_FOUND);
        return new Promise((resolve, reject) => {
            mongoose.connect(mongo_url, { useCreateIndex: true, useNewUrlParser: true, useUnifiedTopology: true })
                .then((db) => {
                    resolve(db)
                })
                .catch(error => {
                    reject(error.message)
                });

        })


    }
}
