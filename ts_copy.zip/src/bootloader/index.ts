
import ApiRoutes from '../routes/ApiRoute';

declare var middleware: any, services: any, config: any;
export default class App extends ApiRoutes {
    constructor() {
        super();
        this.serverAndResourceNotFoundError();
    }

  
    serverAndResourceNotFoundError() {
        this._app.use(middleware.http.urlNotFound);
        this._app.use(middleware.http.serverError);
    }
}
